<?php
// Prevent any output before headers
ob_start();

session_start();
require_once 'db.php';
require_once 'auth.php';

class AdminBooking {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Get all bookings
    public function getAllBookings() {
        try {
            // Latest IDs first so admin sees newest bookings on top
            $result = $this->db->query("SELECT b.*, f.name as farm_name, u.username, s.name as staff_name, s.id as staff_id FROM bookings b JOIN farms f ON b.farm_id = f.id JOIN users u ON b.user_id = u.id LEFT JOIN staff s ON s.assigned_booking_id = b.id ORDER BY b.id DESC");
            
            if (!$result) {
                return [];
            }
            
            $bookings = [];
            while ($row = $result->fetch_assoc()) {
                $bookings[] = $row;
            }
            return $bookings;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get all cancellation requests (pending, approved, denied)
    public function getCancellationRequests() {
        try {
            $result = $this->db->query("
                SELECT 
                    c.id as cancellation_id,
                    c.status as cancellation_status,
                    c.cancellation_reason,
                    c.admin_decision_at,
                    c.created_at as cancellation_created_at,
                    b.*,
                    f.name as farm_name,
                    u.username
                FROM cancellations c
                JOIN bookings b ON c.booking_id = b.id
                JOIN farms f ON b.farm_id = f.id
                JOIN users u ON b.user_id = u.id
                ORDER BY c.created_at DESC, c.id DESC
            ");
            
            if (!$result) {
                return [];
            }
            
            $cancellations = [];
            while ($row = $result->fetch_assoc()) {
                $cancellations[] = $row;
            }
            return $cancellations;
        } catch (Exception $e) {
            // Fallback to old method if cancellations table doesn't exist yet
            try {
                $result = $this->db->query("SELECT b.*, f.name as farm_name, u.username FROM bookings b JOIN farms f ON b.farm_id = f.id JOIN users u ON b.user_id = u.id WHERE b.status = 'pending_cancellation' ORDER BY b.id DESC");
                
                if (!$result) {
                    return [];
                }
                
                $bookings = [];
                while ($row = $result->fetch_assoc()) {
                    $row['cancellation_status'] = 'pending';
                    $bookings[] = $row;
                }
                return $bookings;
            } catch (Exception $e2) {
                return [];
            }
        }
    }
    
    // Get booking by ID
    public function getBookingById($bookingId) {
        try {
            // Include staff assignment info (if any) for detailed admin view
            $stmt = $this->db->prepare("SELECT b.*, f.name AS farm_name, u.username, s.id AS staff_id, s.name AS staff_name
                FROM bookings b
                JOIN farms f ON b.farm_id = f.id
                JOIN users u ON b.user_id = u.id
                LEFT JOIN staff s ON s.assigned_booking_id = b.id
                WHERE b.id = ?");
            $stmt->bind_param("i", $bookingId);
            $stmt->execute();
            $result = $stmt->get_result();
            return $result->fetch_assoc();
        } catch (Exception $e) {
            return null;
        }
    }
    
    // Update booking status
    public function updateBookingStatus($bookingId, $status) {
        try {
            // Get current booking to check previous status and calculate capacity change
            $booking = $this->getBookingById($bookingId);
            if (!$booking) {
                return ['success' => false, 'message' => 'Booking not found'];
            }
            
            $oldStatus = $booking['status'];
            $peopleCount = 1 + ($booking['companions_count'] ?? 0);
            $farmId = $booking['farm_id'];
            
            // Get current farm capacity
            $farmStmt = $this->db->prepare("SELECT capacity FROM farms WHERE id = ?");
            $farmStmt->bind_param("i", $farmId);
            $farmStmt->execute();
            $farmResult = $farmStmt->get_result();
            $farm = $farmResult->fetch_assoc();
            
            if (!$farm) {
                return ['success' => false, 'message' => 'Farm not found'];
            }
            
            // Start transaction
            $this->db->begin_transaction();
            
            try {
                // Update booking status
                $stmt = $this->db->prepare("UPDATE bookings SET status = ? WHERE id = ?");
                $stmt->bind_param("si", $status, $bookingId);
                
                if (!$stmt->execute()) {
                    throw new Exception('Failed to update booking status');
                }
                
                // Handle capacity changes
                // If changing from cancelled to active (pending/accepted), reduce capacity
                if ($oldStatus === 'cancelled' && ($status === 'pending' || $status === 'accepted')) {
                    $newCapacity = max(0, $farm['capacity'] - $peopleCount);
                    $updateStmt = $this->db->prepare("UPDATE farms SET capacity = ? WHERE id = ?");
                    $updateStmt->bind_param("ii", $newCapacity, $farmId);
                    
                    if (!$updateStmt->execute()) {
                        throw new Exception('Failed to update farm capacity');
                    }
                }
                // If changing from active to cancelled, restore capacity
                elseif (($oldStatus === 'pending' || $oldStatus === 'accepted') && $status === 'cancelled') {
                    $newCapacity = $farm['capacity'] + $peopleCount;
                    $updateStmt = $this->db->prepare("UPDATE farms SET capacity = ? WHERE id = ?");
                    $updateStmt->bind_param("ii", $newCapacity, $farmId);
                    
                    if (!$updateStmt->execute()) {
                        throw new Exception('Failed to restore farm capacity');
                    }
                }

                // If booking is now cancelled, unassign any staff linked to this booking
                if ($status === 'cancelled') {
                    $unassignStmt = $this->db->prepare("UPDATE staff SET assigned_booking_id = NULL WHERE assigned_booking_id = ?");
                    $unassignStmt->bind_param("i", $bookingId);
                    if (!$unassignStmt->execute()) {
                        throw new Exception('Failed to unassign staff for cancelled booking');
                    }
                }
                
                // Notify user about booking status changes
                require_once 'notifications.php';
                $notifications = new Notifications();
                
                // If changing from pending to accepted, notify user
                if ($oldStatus === 'pending' && $status === 'accepted') {
                    $farmName = $booking['farm_name'] ?? 'the farm';
                    $message = "Your booking request #{$bookingId} for {$farmName} has been accepted! Your booking date is {$booking['booking_date']}.";
                    $notifications->createNotification($booking['user_id'], $bookingId, $message);
                }
                // If changing from pending to cancelled (declined), notify user
                elseif ($oldStatus === 'pending' && $status === 'cancelled') {
                    $farmName = $booking['farm_name'] ?? 'the farm';
                    $message = "Your booking request #{$bookingId} for {$farmName} on {$booking['booking_date']} has been declined.";
                    $notifications->createNotification($booking['user_id'], $bookingId, $message);
                }
                // If changing from accepted to cancelled (admin cancelled), notify user
                elseif ($oldStatus === 'accepted' && $status === 'cancelled') {
                    $farmName = $booking['farm_name'] ?? 'the farm';
                    $message = "Your Reservation #{$bookingId} for {$farmName} on {$booking['booking_date']} has been cancelled by the admin.";
                    $notifications->createNotification($booking['user_id'], $bookingId, $message);
                }
                
                // Commit transaction
                $this->db->commit();
                
                return ['success' => true, 'message' => 'Booking status updated successfully'];
            } catch (Exception $e) {
                // Rollback transaction on error
                $this->db->rollback();
                return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Update payment status
    public function updatePaymentStatus($bookingId, $paymentStatus) {
        try {
            // Get current booking to know user and schedule info
            $booking = $this->getBookingById($bookingId);
            if (!$booking) {
                return ['success' => false, 'message' => 'Booking not found'];
            }

            $oldPaymentStatus = $booking['payment_status'] ?? 'pending';

            $stmt = $this->db->prepare("UPDATE bookings SET payment_status = ? WHERE id = ?");
            $stmt->bind_param("si", $paymentStatus, $bookingId);
            
            if ($stmt->execute()) {
                require_once 'notifications.php';
                $notifications = new Notifications();
                
                // When payment is marked as PAID, notify user and include assigned staff if available
                if ($paymentStatus === 'paid') {
                    // Look up assigned staff for this booking, if any
                    $staffStmt = $this->db->prepare("SELECT name FROM staff WHERE assigned_booking_id = ? LIMIT 1");
                    $staffStmt->bind_param("i", $bookingId);
                    $staffStmt->execute();
                    $staffResult = $staffStmt->get_result();
                    $staff = $staffResult->fetch_assoc();

                    $staffName = $staff['name'] ?? null;
                    $farmName = $booking['farm_name'] ?? 'the farm';

                    if ($staffName) {
                        $message = "Your payment for Reservatiob #{$bookingId} ({$farmName} on {$booking['booking_date']}) has been received. Staff {$staffName} has been assigned for your booking.";
                    } else {
                        $message = "Your payment for Reservation #{$bookingId} ({$farmName} on {$booking['booking_date']}) has been received. A staff member will be assigned for your booking.";
                    }

                    $notifications->createNotification($booking['user_id'], $bookingId, $message);
                }
                // When payment status changes from paid to pending (e.g., refund, error correction)
                elseif ($oldPaymentStatus === 'paid' && $paymentStatus === 'pending') {
                    $farmName = $booking['farm_name'] ?? 'the farm';
                    $message = "The payment status for reservation #{$bookingId} ({$farmName} on {$booking['booking_date']}) has been changed to pending. Please contact support if you have questions.";
                    $notifications->createNotification($booking['user_id'], $bookingId, $message);
                }

                return ['success' => true, 'message' => 'Payment status updated successfully'];
            } else {
                return ['success' => false, 'message' => 'Failed to update payment status'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Search bookings
    public function searchBookings($searchTerm) {
        try {
            $searchTerm = "%{$searchTerm}%";
            $stmt = $this->db->prepare("SELECT b.*, f.name as farm_name, u.username, s.name as staff_name, s.id as staff_id FROM bookings b JOIN farms f ON b.farm_id = f.id JOIN users u ON b.user_id = u.id LEFT JOIN staff s ON s.assigned_booking_id = b.id WHERE b.full_name LIKE ? OR b.nationality LIKE ? OR f.name LIKE ? ORDER BY b.id DESC");
            $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $bookings = [];
            while ($row = $result->fetch_assoc()) {
                $bookings[] = $row;
            }
            return $bookings;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Approve cancellation
    public function approveCancellation($bookingId) {
        try {
            // Get booking details
            $booking = $this->getBookingById($bookingId);
            if (!$booking) {
                return ['success' => false, 'message' => 'Booking not found'];
            }
            
            if ($booking['status'] !== 'pending_cancellation') {
                return ['success' => false, 'message' => 'Booking is not pending cancellation'];
            }
            
            $peopleCount = 1 + ($booking['companions_count'] ?? 0);
            $farmId = $booking['farm_id'];
            
            // Get farm to restore capacity
            $farmStmt = $this->db->prepare("SELECT capacity FROM farms WHERE id = ?");
            $farmStmt->bind_param("i", $farmId);
            $farmStmt->execute();
            $farmResult = $farmStmt->get_result();
            $farm = $farmResult->fetch_assoc();
            
            if (!$farm) {
                return ['success' => false, 'message' => 'Farm not found'];
            }
            
            // Start transaction
            $this->db->begin_transaction();
            
            try {
                // Update booking status to cancelled
                $stmt = $this->db->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
                $stmt->bind_param("i", $bookingId);
                
                if (!$stmt->execute()) {
                    throw new Exception('Failed to approve cancellation');
                }
                
                // Update cancellation record status to approved
                $cancelStmt = $this->db->prepare("UPDATE cancellations SET status = 'approved', admin_decision_at = NOW() WHERE booking_id = ? AND status = 'pending'");
                $cancelStmt->bind_param("i", $bookingId);
                $cancelStmt->execute(); // Don't throw error if table doesn't exist or record not found
                
                // Restore farm capacity
                $newCapacity = $farm['capacity'] + $peopleCount;
                $updateStmt = $this->db->prepare("UPDATE farms SET capacity = ? WHERE id = ?");
                $updateStmt->bind_param("ii", $newCapacity, $farmId);
                
                if (!$updateStmt->execute()) {
                    throw new Exception('Failed to restore farm capacity');
                }
                
                // Unassign any staff linked to this booking now that it is cancelled
                $unassignStmt = $this->db->prepare("UPDATE staff SET assigned_booking_id = NULL WHERE assigned_booking_id = ?");
                $unassignStmt->bind_param("i", $bookingId);
                if (!$unassignStmt->execute()) {
                    throw new Exception('Failed to unassign staff for cancelled booking');
                }

                // Create notification for user (ensure we use the booking's user_id, not admin's)
                require_once 'notifications.php';
                $notifications = new Notifications();
                $farmName = $booking['farm_name'] ?? 'the farm';
                $bookingDate = $booking['booking_date'] ?? '';
                $message = "Your request for cancellation for reservation #{$bookingId} ({$farmName}" . ($bookingDate ? " on {$bookingDate}" : "") . ") has been approved. The booking has been cancelled.";
                
                // Ensure we're using the booking's user_id, not the current admin's user_id
                $targetUserId = intval($booking['user_id'] ?? 0);
                if ($targetUserId > 0) {
                    $notifications->createNotification($targetUserId, $bookingId, $message);
                }
                
                // Commit transaction
                $this->db->commit();
                
                return ['success' => true, 'message' => 'Cancellation approved successfully'];
            } catch (Exception $e) {
                // Rollback transaction on error
                $this->db->rollback();
                return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Deny cancellation
    public function denyCancellation($bookingId) {
        try {
            // Get booking details
            $booking = $this->getBookingById($bookingId);
            if (!$booking) {
                return ['success' => false, 'message' => 'Booking not found'];
            }
            
            if ($booking['status'] !== 'pending_cancellation') {
                return ['success' => false, 'message' => 'Booking is not pending cancellation'];
            }
            
            // Start transaction
            $this->db->begin_transaction();
            
            try {
                // Update booking status back to accepted
                $stmt = $this->db->prepare("UPDATE bookings SET status = 'accepted', cancellation_reason = NULL WHERE id = ?");
                $stmt->bind_param("i", $bookingId);
                
                if (!$stmt->execute()) {
                    throw new Exception('Failed to deny cancellation');
                }
                
                // Update cancellation record status to denied
                $cancelStmt = $this->db->prepare("UPDATE cancellations SET status = 'denied', admin_decision_at = NOW() WHERE booking_id = ? AND status = 'pending'");
                $cancelStmt->bind_param("i", $bookingId);
                $cancelStmt->execute(); // Don't throw error if table doesn't exist or record not found
                
                // Commit transaction
                $this->db->commit();
                
                // Create notification for user (ensure we use the booking's user_id, not admin's)
                require_once 'notifications.php';
                $notifications = new Notifications();
                $farmName = $booking['farm_name'] ?? 'the farm';
                $bookingDate = $booking['booking_date'] ?? '';
                $message = "Your request for cancellation for reservation #{$bookingId} ({$farmName}" . ($bookingDate ? " on {$bookingDate}" : "") . ") has been denied. The booking remains active.";
                
                // Ensure we're using the booking's user_id, not the current admin's user_id
                $targetUserId = intval($booking['user_id'] ?? 0);
                if ($targetUserId > 0) {
                    $notifications->createNotification($targetUserId, $bookingId, $message);
                }
                
                return ['success' => true, 'message' => 'Cancellation request denied'];
            } catch (Exception $e) {
                // Rollback transaction on error
                $this->db->rollback();
                return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Clear any output buffer
    ob_clean();
    
    // Set headers first
    header('Content-Type: application/json; charset=utf-8');
    
    $auth = new Auth();
    
    if (!$auth->isAdmin()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $booking = new AdminBooking();
    $action = $_REQUEST['action'] ?? '';
    
    try {
        if ($action === 'get_all_bookings') {
            $bookings = $booking->getAllBookings();
            echo json_encode(['success' => true, 'bookings' => $bookings, 'count' => count($bookings)], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_booking') {
            $bookingId = intval($_REQUEST['booking_id'] ?? 0);
            $bookingData = $booking->getBookingById($bookingId);
            echo json_encode(['success' => true, 'booking' => $bookingData], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'update_status') {
            $bookingId = intval($_POST['booking_id'] ?? 0);
            $status = $_POST['status'] ?? '';
            $result = $booking->updateBookingStatus($bookingId, $status);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'update_payment') {
            $bookingId = intval($_POST['booking_id'] ?? 0);
            $paymentStatus = $_POST['payment_status'] ?? '';
            $result = $booking->updatePaymentStatus($bookingId, $paymentStatus);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'search_bookings') {
            $searchTerm = $_REQUEST['search'] ?? '';
            $bookings = $booking->searchBookings($searchTerm);
            echo json_encode(['success' => true, 'bookings' => $bookings], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_cancellation_requests') {
            $bookings = $booking->getCancellationRequests();
            echo json_encode(['success' => true, 'bookings' => $bookings], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'approve_cancellation') {
            $bookingId = intval($_POST['booking_id'] ?? 0);
            $result = $booking->approveCancellation($bookingId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'deny_cancellation') {
            $bookingId = intval($_POST['booking_id'] ?? 0);
            $result = $booking->denyCancellation($bookingId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action'], JSON_UNESCAPED_UNICODE);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Server error occurred'], JSON_UNESCAPED_UNICODE);
    }
    
    // End output buffering
    ob_end_flush();
    exit;
}
?>
