<?php
// Prevent any output before headers
ob_start();

session_start();
require_once 'db.php';
require_once 'auth.php';

class AdminFarm {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Get all farms
    public function getAllFarms() {
        try {
            // Show most recently added farms first for admin view
            $result = $this->db->query("SELECT * FROM farms ORDER BY id DESC");
            
            if (!$result) {
                return [];
            }
            
            $farms = [];
            while ($row = $result->fetch_assoc()) {
                $farms[] = $row;
            }
            return $farms;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get farm by ID
    public function getFarmById($farmId) {
        $stmt = $this->db->prepare("SELECT * FROM farms WHERE id = ?");
        $stmt->bind_param("i", $farmId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Add farm
    public function addFarm($data) {
        $stmt = $this->db->prepare("INSERT INTO farms (name, description, pricing_child, pricing_teen, pricing_adult, pricing_pregnant, pricing_senior, pricing_disabled, capacity) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssddddddi",
            $data['name'],
            $data['description'],
            $data['pricing_child'],
            $data['pricing_teen'],
            $data['pricing_adult'],
            $data['pricing_pregnant'],
            $data['pricing_senior'],
            $data['pricing_disabled'],
            $data['capacity']
        );
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Farm added successfully', 'id' => $this->db->getLastInsertId()];
        } else {
            return ['success' => false, 'message' => 'Failed to add farm'];
        }
    }
    
    // Update farm
    public function updateFarm($farmId, $data) {
        $stmt = $this->db->prepare("UPDATE farms SET name = ?, description = ?, pricing_child = ?, pricing_teen = ?, pricing_adult = ?, pricing_pregnant = ?, pricing_senior = ?, pricing_disabled = ?, capacity = ? WHERE id = ?");
        $stmt->bind_param("ssddddddii",
            $data['name'],
            $data['description'],
            $data['pricing_child'],
            $data['pricing_teen'],
            $data['pricing_adult'],
            $data['pricing_pregnant'],
            $data['pricing_senior'],
            $data['pricing_disabled'],
            $data['capacity'],
            $farmId
        );
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Farm updated successfully'];
        } else {
            return ['success' => false, 'message' => 'Failed to update farm'];
        }
    }
    
    // Delete farm
    public function deleteFarm($farmId) {
        // Check if farm has bookings
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM bookings WHERE farm_id = ?");
        $stmt->bind_param("i", $farmId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        if ($row['count'] > 0) {
            return ['success' => false, 'message' => 'Cannot delete farm with existing bookings'];
        }
        
        $stmt = $this->db->prepare("DELETE FROM farms WHERE id = ?");
        $stmt->bind_param("i", $farmId);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Farm deleted successfully'];
        } else {
            return ['success' => false, 'message' => 'Failed to delete farm'];
        }
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Clear any output buffer
    ob_clean();
    
    // Set headers first
    header('Content-Type: application/json; charset=utf-8');
    
    $auth = new Auth();
    
    if (!$auth->isAdmin()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $farm = new AdminFarm();
    $action = $_REQUEST['action'] ?? '';
    
    try {
        if ($action === 'get_all_farms') {
            $farms = $farm->getAllFarms();
            echo json_encode(['success' => true, 'farms' => $farms, 'count' => count($farms)], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_farm') {
            $farmId = $_REQUEST['farm_id'] ?? 0;
            $farmData = $farm->getFarmById($farmId);
            echo json_encode(['success' => true, 'farm' => $farmData], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'add_farm') {
            $data = [
                'name' => $_POST['name'] ?? '',
                'description' => $_POST['description'] ?? '',
                'pricing_child' => floatval($_POST['pricing_child'] ?? 0),
                'pricing_teen' => floatval($_POST['pricing_teen'] ?? 0),
                'pricing_adult' => floatval($_POST['pricing_adult'] ?? 0),
                'pricing_pregnant' => floatval($_POST['pricing_pregnant'] ?? 0),
                'pricing_senior' => floatval($_POST['pricing_senior'] ?? 0),
                'pricing_disabled' => floatval($_POST['pricing_disabled'] ?? 0),
                'capacity' => intval($_POST['capacity'] ?? 0)
            ];
            $result = $farm->addFarm($data);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'update_farm') {
            $farmId = intval($_POST['farm_id'] ?? 0);
            $data = [
                'name' => $_POST['name'] ?? '',
                'description' => $_POST['description'] ?? '',
                'pricing_child' => floatval($_POST['pricing_child'] ?? 0),
                'pricing_teen' => floatval($_POST['pricing_teen'] ?? 0),
                'pricing_adult' => floatval($_POST['pricing_adult'] ?? 0),
                'pricing_pregnant' => floatval($_POST['pricing_pregnant'] ?? 0),
                'pricing_senior' => floatval($_POST['pricing_senior'] ?? 0),
                'pricing_disabled' => floatval($_POST['pricing_disabled'] ?? 0),
                'capacity' => intval($_POST['capacity'] ?? 0)
            ];
            $result = $farm->updateFarm($farmId, $data);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'delete_farm') {
            $farmId = intval($_POST['farm_id'] ?? 0);
            $result = $farm->deleteFarm($farmId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action'], JSON_UNESCAPED_UNICODE);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Server error occurred'], JSON_UNESCAPED_UNICODE);
    }
    
    // End output buffering
    ob_end_flush();
    exit;
}
?>
