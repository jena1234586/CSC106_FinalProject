<?php
// Prevent any output before headers
ob_start();

session_start();
require_once 'db.php';
require_once 'auth.php';

class AdminStaff {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Get all staff
    public function getAllStaff() {
        try {
            $result = $this->db->query("SELECT s.*, b.id as booking_id, b.full_name as booking_name FROM staff s LEFT JOIN bookings b ON s.assigned_booking_id = b.id ORDER BY s.name");
            
            if (!$result) {
                return [];
            }
            
            $staff = [];
            while ($row = $result->fetch_assoc()) {
                // Ensure status is set, default to 'waiting_for_assign'
                if (!isset($row['status']) || $row['status'] === null) {
                    $row['status'] = 'waiting_for_assign';
                }
                $staff[] = $row;
            }
            return $staff;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get staff by ID
    public function getStaffById($staffId) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM staff WHERE id = ?");
            $stmt->bind_param("i", $staffId);
            $stmt->execute();
            $result = $stmt->get_result();
            return $result->fetch_assoc();
        } catch (Exception $e) {
            return null;
        }
    }
    
    // Add staff
    public function addStaff($data) {
        try {
            // Validate required fields
            if (empty($data['name']) || empty($data['username']) || empty($data['password'])) {
                return ['success' => false, 'message' => 'Name, username, and password are required'];
            }
            
            // Check if username already exists
            $checkStmt = $this->db->prepare("SELECT id FROM staff WHERE username = ?");
            $checkStmt->bind_param("s", $data['username']);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            if ($checkResult->num_rows > 0) {
                return ['success' => false, 'message' => 'Username already exists'];
            }
            
            // Hash password
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare("INSERT INTO staff (name, username, password, email, phone, status) VALUES (?, ?, ?, ?, ?, 'waiting_for_assign')");
            $stmt->bind_param("sssss",
                $data['name'],
                $data['username'],
                $hashedPassword,
                $data['email'],
                $data['phone']
            );
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Staff added successfully', 'id' => $this->db->getLastInsertId()];
            } else {
                return ['success' => false, 'message' => 'Failed to add staff'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Update staff
    public function updateStaff($staffId, $data) {
        try {
            // Build update query dynamically based on what's provided
            $updates = [];
            $params = [];
            $types = '';
            
            $updates[] = "name = ?";
            $params[] = $data['name'];
            $types .= 's';
            
            $updates[] = "email = ?";
            $params[] = $data['email'];
            $types .= 's';
            
            $updates[] = "phone = ?";
            $params[] = $data['phone'];
            $types .= 's';
            
            // Update username if provided
            if (!empty($data['username'])) {
                // Check if username already exists (excluding current staff)
                $checkStmt = $this->db->prepare("SELECT id FROM staff WHERE username = ? AND id != ?");
                $checkStmt->bind_param("si", $data['username'], $staffId);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();
                if ($checkResult->num_rows > 0) {
                    return ['success' => false, 'message' => 'Username already exists'];
                }
                
                $updates[] = "username = ?";
                $params[] = $data['username'];
                $types .= 's';
            }
            
            // Update password if provided
            if (!empty($data['password'])) {
                if (strlen($data['password']) < 6) {
                    return ['success' => false, 'message' => 'Password must be at least 6 characters'];
                }
                $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
                $updates[] = "password = ?";
                $params[] = $hashedPassword;
                $types .= 's';
            }
            
            $params[] = $staffId;
            $types .= 'i';
            
            $sql = "UPDATE staff SET " . implode(', ', $updates) . " WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->bind_param($types, ...$params);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Staff updated successfully'];
            } else {
                return ['success' => false, 'message' => 'Failed to update staff'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Delete staff
    public function deleteStaff($staffId) {
        try {
            $stmt = $this->db->prepare("DELETE FROM staff WHERE id = ?");
            $stmt->bind_param("i", $staffId);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Staff deleted successfully'];
            } else {
                return ['success' => false, 'message' => 'Failed to delete staff'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Assign staff to booking
    public function assignStaffToBooking($staffId, $bookingId) {
        try {
            // Start transaction
            $this->db->begin_transaction();
            
            try {
                // Fetch staff info and check status
                $staffStmt = $this->db->prepare("SELECT id, name, status FROM staff WHERE id = ?");
                $staffStmt->bind_param("i", $staffId);
                $staffStmt->execute();
                $staffResult = $staffStmt->get_result();
                $staffData = $staffResult->fetch_assoc();
                
                if (!$staffData) {
                    throw new Exception('Staff not found');
                }
                
                // Check if staff status is 'ongoing' - cannot assign if ongoing
                $staffStatus = $staffData['status'] ?? 'waiting_for_assign';
                if ($staffStatus === 'ongoing') {
                    $this->db->rollback();
                    return ['success' => false, 'message' => 'Cannot assign staff member with "Ongoing" status. Please wait until current task is completed.'];
                }
                
                // Fetch booking + user info
                $bookingStmt = $this->db->prepare("SELECT b.*, f.name AS farm_name 
                    FROM bookings b 
                    JOIN farms f ON b.farm_id = f.id 
                    WHERE b.id = ?");
                $bookingStmt->bind_param("i", $bookingId);
                $bookingStmt->execute();
                $bookingResult = $bookingStmt->get_result();
                $bookingData = $bookingResult->fetch_assoc();
                
                if (!$bookingData) {
                    throw new Exception('Booking not found');
                }
                
                // Unassign from previous booking if any
                $unassignStmt = $this->db->prepare("UPDATE staff SET assigned_booking_id = NULL, status = 'waiting_for_assign' WHERE assigned_booking_id = ?");
                $unassignStmt->bind_param("i", $bookingId);
                $unassignStmt->execute();
                
                // Assign to new booking and update status to 'ongoing'
                $assignStmt = $this->db->prepare("UPDATE staff SET assigned_booking_id = ?, status = 'ongoing' WHERE id = ?");
                $assignStmt->bind_param("ii", $bookingId, $staffId);
                
                if (!$assignStmt->execute()) {
                    throw new Exception('Failed to assign staff');
                }
                
                // Send notification to user
                if ($staffData && isset($bookingData['user_id'])) {
                    require_once 'notifications.php';
                    $notifications = new Notifications();
                    $staffName = $staffData['name'] ?? 'a staff member';
                    $message = "Staff {$staffName} has been assigned to your reservation #{$bookingId} for {$bookingData['farm_name']} on {$bookingData['booking_date']}.";
                    $notifications->createNotification($bookingData['user_id'], $bookingId, $message);
                }
                
                // Send notification to staff member
                require_once 'staff_auth.php';
                $staffAuth = new StaffAuth();
                $staffAuth->createStaffNotification(
                    $staffId, 
                    $bookingId, 
                    "You have been assigned to reservation #{$bookingId} for {$bookingData['farm_name']} on {$bookingData['booking_date']}. Customer: {$bookingData['full_name']}."
                );
                
                // Commit transaction
                $this->db->commit();
                return ['success' => true, 'message' => 'Staff assigned successfully'];
            } catch (Exception $e) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Clear any output buffer
    ob_clean();
    
    // Set headers first
    header('Content-Type: application/json; charset=utf-8');
    
    $auth = new Auth();
    
    if (!$auth->isAdmin()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $staff = new AdminStaff();
    $action = $_REQUEST['action'] ?? '';
    
    try {
        if ($action === 'get_all_staff') {
            $staffList = $staff->getAllStaff();
            echo json_encode(['success' => true, 'staff' => $staffList, 'count' => count($staffList)], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_staff') {
            $staffId = intval($_REQUEST['staff_id'] ?? 0);
            $staffData = $staff->getStaffById($staffId);
            echo json_encode(['success' => true, 'staff' => $staffData], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'add_staff') {
            $data = [
                'name' => $_POST['name'] ?? '',
                'username' => $_POST['username'] ?? '',
                'password' => $_POST['password'] ?? '',
                'email' => $_POST['email'] ?? '',
                'phone' => $_POST['phone'] ?? ''
            ];
            $result = $staff->addStaff($data);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'update_staff') {
            $staffId = intval($_POST['staff_id'] ?? 0);
            $data = [
                'name' => $_POST['name'] ?? '',
                'username' => $_POST['username'] ?? '',
                'password' => $_POST['password'] ?? '',
                'email' => $_POST['email'] ?? '',
                'phone' => $_POST['phone'] ?? ''
            ];
            $result = $staff->updateStaff($staffId, $data);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'delete_staff') {
            $staffId = intval($_POST['staff_id'] ?? 0);
            $result = $staff->deleteStaff($staffId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'assign_staff') {
            $staffId = intval($_POST['staff_id'] ?? 0);
            $bookingId = intval($_POST['booking_id'] ?? 0);
            $result = $staff->assignStaffToBooking($staffId, $bookingId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action'], JSON_UNESCAPED_UNICODE);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Server error occurred'], JSON_UNESCAPED_UNICODE);
    }
    
    // End output buffering
    ob_end_flush();
    exit;
}
?>
