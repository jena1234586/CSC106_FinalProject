<?php
// Prevent any output before headers
ob_start();

session_start();
require_once 'db.php';
require_once 'auth.php';

class Analytics {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Get weekly analytics
    public function getWeeklyAnalytics($week, $year) {
        try {
            $startDate = date('Y-m-d', strtotime("{$year}-W{$week}"));
            $endDate = date('Y-m-d', strtotime("{$year}-W{$week} +6 days"));
            
            $stmt = $this->db->prepare("SELECT 
                COUNT(*) as total_bookings,
                COALESCE(SUM(total_price), 0) as total_revenue,
                COUNT(DISTINCT farm_id) as farms_count,
                COUNT(DISTINCT nationality) as nationalities_count
                FROM bookings 
                WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' AND payment_status = 'paid'");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $summary = $result->fetch_assoc() ?: ['total_bookings' => 0, 'total_revenue' => 0, 'farms_count' => 0, 'nationalities_count' => 0];

            // Upcoming tours within week (accepted bookings)
            $stmt = $this->db->prepare("SELECT COUNT(*) as upcoming_tours FROM bookings WHERE booking_date BETWEEN ? AND ? AND status = 'accepted'");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $upcomingRow = $result->fetch_assoc() ?: ['upcoming_tours' => 0];
            $summary['upcoming_tours'] = intval($upcomingRow['upcoming_tours'] ?? 0);

            // Cancellations in this week (inclusive end via < end+1day)
            $endNext = date('Y-m-d', strtotime($endDate . ' +1 day'));
            $stmt = $this->db->prepare("SELECT COUNT(*) as total_cancellations FROM cancellations WHERE created_at >= ? AND created_at < ?");
            $stmt->bind_param("ss", $startDate, $endNext);
            $stmt->execute();
            $result = $stmt->get_result();
            $cancelRow = $result->fetch_assoc() ?: ['total_cancellations' => 0];
            $summary['total_cancellations'] = intval($cancelRow['total_cancellations'] ?? 0);

            // Users created in this month (inclusive end via < end+1day to avoid TZ edge)
            $endNext = date('Y-m-d', strtotime($endDate . ' +1 day'));
            $stmt = $this->db->prepare("SELECT COUNT(*) as total_users FROM users WHERE created_at >= ? AND created_at < ?");
            $stmt->bind_param("ss", $startDate, $endNext);
            $stmt->execute();
            $result = $stmt->get_result();
            $usersRow = $result->fetch_assoc() ?: ['total_users' => 0];
            $summary['total_users'] = intval($usersRow['total_users'] ?? 0);

            // Users created in this week (inclusive end via < end+1day to avoid TZ edge)
            $endNext = date('Y-m-d', strtotime($endDate . ' +1 day'));
            $stmt = $this->db->prepare("SELECT COUNT(*) as total_users FROM users WHERE created_at >= ? AND created_at < ?");
            $stmt->bind_param("ss", $startDate, $endNext);
            $stmt->execute();
            $result = $stmt->get_result();
            $usersRow = $result->fetch_assoc() ?: ['total_users' => 0];
            $summary['total_users'] = intval($usersRow['total_users'] ?? 0);
            
            // Bookings by nationality
            $stmt = $this->db->prepare("SELECT nationality, COUNT(*) as count FROM bookings WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' AND nationality IS NOT NULL GROUP BY nationality");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $nationalities = [];
            while ($row = $result->fetch_assoc()) {
                $nationalities[] = $row;
            }
            
            // Bookings by age group
            $stmt = $this->db->prepare("SELECT 
                CASE 
                    WHEN age < 13 THEN 'Child'
                    WHEN age < 18 THEN 'Teenager'
                    WHEN age >= 65 THEN 'Senior'
                    ELSE 'Adult'
                END as age_group,
                COUNT(*) as count
                FROM bookings 
                WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled'
                GROUP BY age_group");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $ageGroups = [];
            while ($row = $result->fetch_assoc()) {
                $ageGroups[] = $row;
            }
            
            // Bookings by marital status
            $stmt = $this->db->prepare("SELECT marital_status, COUNT(*) as count FROM bookings WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' AND marital_status IS NOT NULL GROUP BY marital_status");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $maritalStatus = [];
            while ($row = $result->fetch_assoc()) {
                $maritalStatus[] = $row;
            }
            
            // Bookings by type
            $stmt = $this->db->prepare("SELECT COALESCE(type, 'normal') as booking_type, COUNT(*) as count FROM bookings WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' GROUP BY booking_type");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $bookingTypes = [];
            while ($row = $result->fetch_assoc()) {
                $bookingTypes[] = $row;
            }
            
            // Farm popularity and income
            $stmt = $this->db->prepare("SELECT f.id, f.name, COUNT(b.id) as bookings_count, COALESCE(SUM(b.total_price), 0) as revenue FROM farms f LEFT JOIN bookings b ON f.id = b.farm_id AND b.booking_date BETWEEN ? AND ? AND b.status != 'cancelled' AND b.payment_status = 'paid' GROUP BY f.id ORDER BY bookings_count DESC");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $farmPopularity = [];
            while ($row = $result->fetch_assoc()) {
                $farmPopularity[] = $row;
            }
            
            // Staff statistics
            try {
                $stmt = $this->db->prepare("
                    SELECT s.id, s.name, COUNT(ct.id) as tours_completed
                    FROM staff s
                    LEFT JOIN completed_tours ct ON s.id = ct.staff_id
                    LEFT JOIN bookings b ON ct.booking_id = b.id
                    WHERE (b.booking_date BETWEEN ? AND ? OR ct.completed_at BETWEEN ? AND ?)
                    GROUP BY s.id, s.name
                    ORDER BY tours_completed DESC
                ");
                $stmt->bind_param("ssss", $startDate, $endDate, $startDate, $endDate);
                $stmt->execute();
                $result = $stmt->get_result();
                $staffStats = [];
                while ($row = $result->fetch_assoc()) {
                    $staffStats[] = $row;
                }
            } catch (Exception $e) {
                $staffStats = [];
            }
            
            return [
                'summary' => $summary,
                // Top-level convenience for UI fallbacks
                'total_users' => intval($summary['total_users'] ?? 0),
                'nationalities' => $nationalities,
                'age_groups' => $ageGroups,
                'marital_status' => $maritalStatus,
                'booking_types' => $bookingTypes,
                'farm_popularity' => $farmPopularity,
                'staff_stats' => $staffStats
            ];
        } catch (Exception $e) {
            return [
                'summary' => ['total_bookings' => 0, 'total_revenue' => 0, 'farms_count' => 0, 'nationalities_count' => 0],
                'nationalities' => [],
                'age_groups' => [],
                'marital_status' => [],
                'booking_types' => [],
                'farm_popularity' => [],
                'staff_stats' => []
            ];
        }
    }
    
    // Get monthly analytics
    public function getMonthlyAnalytics($month, $year) {
        try {
            $startDate = "{$year}-{$month}-01";
            $endDate = date('Y-m-t', strtotime($startDate));
            
            $stmt = $this->db->prepare("SELECT 
                COUNT(*) as total_bookings,
                COALESCE(SUM(total_price), 0) as total_revenue,
                COUNT(DISTINCT farm_id) as farms_count,
                COUNT(DISTINCT nationality) as nationalities_count
                FROM bookings 
                WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' AND payment_status = 'paid'");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $summary = $result->fetch_assoc() ?: ['total_bookings' => 0, 'total_revenue' => 0, 'farms_count' => 0, 'nationalities_count' => 0];
            
            // Upcoming tours within month (accepted bookings)
            $stmt = $this->db->prepare("SELECT COUNT(*) as upcoming_tours FROM bookings WHERE booking_date BETWEEN ? AND ? AND status = 'accepted'");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $upcomingRow = $result->fetch_assoc() ?: ['upcoming_tours' => 0];
            $summary['upcoming_tours'] = intval($upcomingRow['upcoming_tours'] ?? 0);

            // Cancellations in this month (inclusive end via < end+1day)
            $endNext = date('Y-m-d', strtotime($endDate . ' +1 day'));
            $stmt = $this->db->prepare("SELECT COUNT(*) as total_cancellations FROM cancellations WHERE created_at >= ? AND created_at < ?");
            $stmt->bind_param("ss", $startDate, $endNext);
            $stmt->execute();
            $result = $stmt->get_result();
            $cancelRow = $result->fetch_assoc() ?: ['total_cancellations' => 0];
            $summary['total_cancellations'] = intval($cancelRow['total_cancellations'] ?? 0);

            // Users created in this month (inclusive end via < end+1day to avoid TZ edge)
            $endNext = date('Y-m-d', strtotime($endDate . ' +1 day'));
            $stmt = $this->db->prepare("SELECT COUNT(*) as total_users FROM users WHERE created_at >= ? AND created_at < ?");
            $stmt->bind_param("ss", $startDate, $endNext);
            $stmt->execute();
            $result = $stmt->get_result();
            $usersRow = $result->fetch_assoc() ?: ['total_users' => 0];
            $summary['total_users'] = intval($usersRow['total_users'] ?? 0);
            
            // Bookings by nationality
            $stmt = $this->db->prepare("SELECT nationality, COUNT(*) as count FROM bookings WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' AND nationality IS NOT NULL GROUP BY nationality");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $nationalities = [];
            while ($row = $result->fetch_assoc()) {
                $nationalities[] = $row;
            }
            
            // Bookings by age group
            $stmt = $this->db->prepare("SELECT 
                CASE 
                    WHEN age < 13 THEN 'Child'
                    WHEN age < 18 THEN 'Teenager'
                    WHEN age >= 65 THEN 'Senior'
                    ELSE 'Adult'
                END as age_group,
                COUNT(*) as count
                FROM bookings 
                WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled'
                GROUP BY age_group");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $ageGroups = [];
            while ($row = $result->fetch_assoc()) {
                $ageGroups[] = $row;
            }
            
            // Bookings by marital status
            $stmt = $this->db->prepare("SELECT marital_status, COUNT(*) as count FROM bookings WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' AND marital_status IS NOT NULL GROUP BY marital_status");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $maritalStatus = [];
            while ($row = $result->fetch_assoc()) {
                $maritalStatus[] = $row;
            }
            
            // Bookings by type
            $stmt = $this->db->prepare("SELECT COALESCE(type, 'normal') as booking_type, COUNT(*) as count FROM bookings WHERE booking_date BETWEEN ? AND ? AND status != 'cancelled' GROUP BY booking_type");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $bookingTypes = [];
            while ($row = $result->fetch_assoc()) {
                $bookingTypes[] = $row;
            }
            
            // Farm popularity and income
            $stmt = $this->db->prepare("SELECT f.id, f.name, COUNT(b.id) as bookings_count, COALESCE(SUM(b.total_price), 0) as revenue FROM farms f LEFT JOIN bookings b ON f.id = b.farm_id AND b.booking_date BETWEEN ? AND ? AND b.status != 'cancelled' AND b.payment_status = 'paid' GROUP BY f.id ORDER BY bookings_count DESC");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $farmPopularity = [];
            while ($row = $result->fetch_assoc()) {
                $farmPopularity[] = $row;
            }
            
            // Staff statistics
            try {
                $stmt = $this->db->prepare("
                    SELECT s.id, s.name, COUNT(ct.id) as tours_completed
                    FROM staff s
                    LEFT JOIN completed_tours ct ON s.id = ct.staff_id
                    LEFT JOIN bookings b ON ct.booking_id = b.id
                    WHERE (b.booking_date BETWEEN ? AND ? OR ct.completed_at BETWEEN ? AND ?)
                    GROUP BY s.id, s.name
                    ORDER BY tours_completed DESC
                ");
                $stmt->bind_param("ssss", $startDate, $endDate, $startDate, $endDate);
                $stmt->execute();
                $result = $stmt->get_result();
                $staffStats = [];
                while ($row = $result->fetch_assoc()) {
                    $staffStats[] = $row;
                }
            } catch (Exception $e) {
                $staffStats = [];
            }
            
            return [
                'summary' => $summary,
                // Top-level convenience for UI fallbacks
                'total_users' => intval($summary['total_users'] ?? 0),
                'nationalities' => $nationalities,
                'age_groups' => $ageGroups,
                'marital_status' => $maritalStatus,
                'booking_types' => $bookingTypes,
                'farm_popularity' => $farmPopularity,
                'staff_stats' => $staffStats
            ];
        } catch (Exception $e) {
            return [
                'summary' => ['total_bookings' => 0, 'total_revenue' => 0, 'farms_count' => 0, 'nationalities_count' => 0],
                'nationalities' => [],
                'age_groups' => [],
                'marital_status' => [],
                'booking_types' => [],
                'farm_popularity' => [],
                'staff_stats' => []
            ];
        }
    }
    
    // Get summary statistics
    public function getSummary() {
        try {
            // Total revenue
            $result = $this->db->query("SELECT COALESCE(SUM(total_price), 0) as total_revenue FROM bookings WHERE status != 'cancelled' AND payment_status = 'paid'");
            $revenue = $result->fetch_assoc() ?: ['total_revenue' => 0];
            
            // Total bookings
            $result = $this->db->query("SELECT COUNT(*) as total_bookings FROM bookings WHERE status != 'cancelled'");
            $bookings = $result->fetch_assoc() ?: ['total_bookings' => 0];

            // Total cancellations (all time)
            $result = $this->db->query("SELECT COUNT(*) as total_cancellations FROM cancellations");
            $cancellations = $result->fetch_assoc() ?: ['total_cancellations' => 0];

            // Total users (exclude admin)
            $result = $this->db->query("SELECT COUNT(*) as total_users FROM users WHERE role = 'user'");
            $usersRow = $result->fetch_assoc() ?: ['total_users' => 0];
            
            // Upcoming tours
            $today = date('Y-m-d');
            $result = $this->db->query("SELECT COUNT(*) as upcoming_tours FROM bookings WHERE booking_date >= '$today' AND status = 'accepted'");
            $upcoming = $result->fetch_assoc() ?: ['upcoming_tours' => 0];

            // Total users (exclude admin accounts)
            $result = $this->db->query("SELECT COUNT(*) as total_users FROM users WHERE role = 'user'");
            $totalUsers = $result->fetch_assoc() ?: ['total_users' => 0];

            // Staff count (show how many staff exist, regardless of assignment)
            $result = $this->db->query("SELECT COUNT(*) as staff_count FROM staff");
            $staffCount = $result->fetch_assoc() ?: ['staff_count' => 0];
            
            // Bookings by type
            $result = $this->db->query("SELECT COALESCE(type, 'normal') as booking_type, COUNT(*) as count FROM bookings WHERE status != 'cancelled' GROUP BY booking_type");
            $bookingTypes = [];
            while ($row = $result->fetch_assoc()) {
                $bookingTypes[] = $row;
            }
            
            // Bookings by marital status
            $result = $this->db->query("SELECT marital_status, COUNT(*) as count FROM bookings WHERE status != 'cancelled' AND marital_status IS NOT NULL GROUP BY marital_status");
            $maritalStatus = [];
            while ($row = $result->fetch_assoc()) {
                $maritalStatus[] = $row;
            }
            
            // Bookings by nationality
            $result = $this->db->query("SELECT nationality, COUNT(*) as count FROM bookings WHERE status != 'cancelled' AND nationality IS NOT NULL GROUP BY nationality ORDER BY count DESC LIMIT 10");
            $nationalities = [];
            while ($row = $result->fetch_assoc()) {
                $nationalities[] = $row;
            }
            
            // Age group breakdown
            $result = $this->db->query("SELECT 
                CASE 
                    WHEN age < 13 THEN 'Child'
                    WHEN age < 18 THEN 'Teenager'
                    WHEN age >= 65 THEN 'Senior'
                    ELSE 'Adult'
                END as age_group,
                COUNT(*) as count
                FROM bookings 
                WHERE status != 'cancelled'
                GROUP BY age_group");
            $ageGroups = [];
            while ($row = $result->fetch_assoc()) {
                $ageGroups[] = $row;
            }
            
            // Farm income (all time)
            $result = $this->db->query("SELECT f.id, f.name, COUNT(b.id) as bookings_count, COALESCE(SUM(b.total_price), 0) as revenue FROM farms f LEFT JOIN bookings b ON f.id = b.farm_id AND b.status != 'cancelled' AND b.payment_status = 'paid' GROUP BY f.id ORDER BY revenue DESC");
            $farmIncome = [];
            while ($row = $result->fetch_assoc()) {
                $farmIncome[] = $row;
            }
            
            // Staff statistics (all time)
            $result = $this->db->query("
                SELECT s.id, s.name, 
                       COUNT(ct.id) as total_tours,
                       COUNT(CASE WHEN ct.completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) as weekly_tours,
                       COUNT(CASE WHEN ct.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as monthly_tours,
                       COUNT(CASE WHEN YEAR(ct.completed_at) = YEAR(NOW()) THEN 1 END) as annual_tours
                FROM staff s
                LEFT JOIN completed_tours ct ON s.id = ct.staff_id
                GROUP BY s.id, s.name
                ORDER BY total_tours DESC
            ");
            $staffStats = [];
            while ($row = $result->fetch_assoc()) {
                $staffStats[] = $row;
            }
            
            return [
                'total_revenue' => floatval($revenue['total_revenue'] ?? 0),
                'total_bookings' => intval($bookings['total_bookings'] ?? 0),
                'total_cancellations' => intval($cancellations['total_cancellations'] ?? 0),
                'upcoming_tours' => intval($upcoming['upcoming_tours'] ?? 0),
                'total_users' => intval($usersRow['total_users'] ?? 0),
                // Keep the legacy key name but feed staff count so UI remains compatible
                'staff_assignments' => intval($staffCount['staff_count'] ?? 0),
                'staff_count' => intval($staffCount['staff_count'] ?? 0),
                'booking_types' => $bookingTypes,
                'marital_status' => $maritalStatus,
                'nationalities' => $nationalities,
                'age_groups' => $ageGroups,
                'farm_income' => $farmIncome,
                'staff_stats' => $staffStats
            ];
        } catch (Exception $e) {
            return [
                'total_revenue' => 0,
                'total_bookings' => 0,
                'upcoming_tours' => 0,
                'staff_assignments' => 0,
                'booking_types' => [],
                'marital_status' => [],
                'nationalities' => [],
                'age_groups' => [],
                'farm_income' => [],
                'staff_stats' => []
            ];
        }
    }
    
    // Get farm income by period
    public function getFarmIncome($startDate, $endDate) {
        try {
            $stmt = $this->db->prepare("
                SELECT f.id, f.name, 
                       COUNT(b.id) as bookings_count, 
                       COALESCE(SUM(b.total_price), 0) as revenue
                FROM farms f 
                LEFT JOIN bookings b ON f.id = b.farm_id 
                    AND b.booking_date BETWEEN ? AND ? 
                    AND b.status != 'cancelled'
                    AND b.payment_status = 'paid'
                GROUP BY f.id, f.name
                ORDER BY revenue DESC
            ");
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            $farmIncome = [];
            while ($row = $result->fetch_assoc()) {
                $farmIncome[] = $row;
            }
            return $farmIncome;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get staff statistics by period
    public function getStaffStatistics($startDate = null, $endDate = null) {
        try {
            if ($startDate && $endDate) {
                $stmt = $this->db->prepare("
                    SELECT s.id, s.name, 
                           COUNT(ct.id) as tours_completed
                    FROM staff s
                    LEFT JOIN completed_tours ct ON s.id = ct.staff_id
                    LEFT JOIN bookings b ON ct.booking_id = b.id
                    WHERE (b.booking_date BETWEEN ? AND ? OR ct.completed_at BETWEEN ? AND ?)
                    GROUP BY s.id, s.name
                    ORDER BY tours_completed DESC
                ");
                $stmt->bind_param("ssss", $startDate, $endDate, $startDate, $endDate);
            } else {
                $stmt = $this->db->prepare("
                    SELECT s.id, s.name, 
                           COUNT(ct.id) as total_tours,
                           COUNT(CASE WHEN ct.completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) as weekly_tours,
                           COUNT(CASE WHEN ct.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as monthly_tours,
                           COUNT(CASE WHEN YEAR(ct.completed_at) = YEAR(NOW()) THEN 1 END) as annual_tours
                    FROM staff s
                    LEFT JOIN completed_tours ct ON s.id = ct.staff_id
                    GROUP BY s.id, s.name
                    ORDER BY total_tours DESC
                ");
            }
            $stmt->execute();
            $result = $stmt->get_result();
            $staffStats = [];
            while ($row = $result->fetch_assoc()) {
                $staffStats[] = $row;
            }
            return $staffStats;
        } catch (Exception $e) {
            return [];
        }
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Clear any output buffer
    ob_clean();
    
    // Set headers first
    header('Content-Type: application/json; charset=utf-8');
    
    $auth = new Auth();
    
    if (!$auth->isAdmin()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $analytics = new Analytics();
    $action = $_REQUEST['action'] ?? '';
    
    try {
        if ($action === 'weekly') {
            $week = intval($_REQUEST['week'] ?? date('W'));
            $year = intval($_REQUEST['year'] ?? date('Y'));
            $data = $analytics->getWeeklyAnalytics($week, $year);
            echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'monthly') {
            $month = intval($_REQUEST['month'] ?? date('m'));
            $year = intval($_REQUEST['year'] ?? date('Y'));
            $data = $analytics->getMonthlyAnalytics($month, $year);
            echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'summary') {
            $data = $analytics->getSummary();
            echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action'], JSON_UNESCAPED_UNICODE);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Server error occurred'], JSON_UNESCAPED_UNICODE);
    }
    
    // End output buffering
    ob_end_flush();
    exit;
}
?>
