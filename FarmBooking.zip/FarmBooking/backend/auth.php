<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

class Auth {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Register new user
    public function register($fullName, $username, $password) {
        // Check if username exists
        if ($this->usernameExists($username)) {
            return ['success' => false, 'message' => 'Username already taken'];
        }
        
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert user
        $stmt = $this->db->prepare("INSERT INTO users (full_name, username, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $fullName, $username, $hashedPassword);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Registration successful'];
        } else {
            return ['success' => false, 'message' => 'Registration failed'];
        }
    }
    
    // Check if username exists
    public function usernameExists($username) {
        $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    // Unified login - checks both users and staff tables automatically
    public function login($username, $password) {
        // First, check users table (includes admin and regular users)
        $stmt = $this->db->prepare("SELECT id, full_name, username, password, role FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            if (password_verify($password, $user['password'])) {
                // Store session data (allows multiple role logins)
                $sessionKey = $user['role'] === 'admin' ? 'admin_session' : 'user_session';
                $_SESSION[$sessionKey] = [
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'full_name' => $user['full_name'],
                    'role' => $user['role']
                ];
                
                // Also set current session for backward compatibility
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];
                
                return [
                    'success' => true,
                    'role' => $user['role'],
                    'user_id' => $user['id'],
                    'full_name' => $user['full_name'],
                    'username' => $user['username'],
                    'message' => 'Login successful'
                ];
            } else {
                return ['success' => false, 'message' => 'Invalid password'];
            }
        }
        
        // If not found in users table, check staff table
        $stmt = $this->db->prepare("SELECT id, name, username, password FROM staff WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $staff = $result->fetch_assoc();
            
            if (password_verify($password, $staff['password'])) {
                // Store staff session
                $_SESSION['staff_session'] = [
                    'staff_id' => $staff['id'],
                    'username' => $staff['username'],
                    'full_name' => $staff['name'],
                    'role' => 'staff'
                ];
                
                // Also set current session for backward compatibility
                $_SESSION['staff_id'] = $staff['id'];
                $_SESSION['username'] = $staff['username'];
                $_SESSION['full_name'] = $staff['name'];
                $_SESSION['role'] = 'staff';
                
                return [
                    'success' => true,
                    'role' => 'staff',
                    'staff_id' => $staff['id'],
                    'user_id' => $staff['id'], // For compatibility
                    'full_name' => $staff['name'],
                    'username' => $staff['username'],
                    'message' => 'Login successful'
                ];
            } else {
                return ['success' => false, 'message' => 'Invalid password'];
            }
        }
        
        // Username not found in either table
        return ['success' => false, 'message' => 'Username not found'];
    }
    
    // Logout user
    // If a specific role is provided, only that role's session will be cleared.
    // If no role is provided, all sessions will be cleared.
    public function logout($role = null) {
        if ($role === 'admin') {
            unset($_SESSION['admin_session']);
        } elseif ($role === 'user') {
            unset($_SESSION['user_session']);
        } elseif ($role === 'staff') {
            unset($_SESSION['staff_session'], $_SESSION['staff_id']);
        } else {
            // Clear all known session data (users, admin, and staff)
            unset($_SESSION['admin_session'], $_SESSION['user_session'], $_SESSION['staff_session'], 
                  $_SESSION['user_id'], $_SESSION['staff_id'], $_SESSION['username'], 
                  $_SESSION['full_name'], $_SESSION['role']);
        }

        // If there is nothing left in the session, fully destroy it
        if (empty($_SESSION)) {
            session_unset();
            session_destroy();
        }

        return ['success' => true, 'message' => 'Logged out successfully'];
    }
    
    // Check if user is logged in (checks user, admin, and staff sessions)
    public function isLoggedIn() {
        return isset($_SESSION['user_id']) || isset($_SESSION['user_session']) || 
               isset($_SESSION['admin_session']) || isset($_SESSION['staff_session']) || 
               isset($_SESSION['staff_id']);
    }
    
    // Check if user is admin
    public function isAdmin() {
        // Check admin session specifically
        if (isset($_SESSION['admin_session']) && $_SESSION['admin_session']['role'] === 'admin') {
            return true;
        }
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
    
    // Check if user is regular user
    public function isUser() {
        // Check user session specifically
        if (isset($_SESSION['user_session']) && $_SESSION['user_session']['role'] === 'user') {
            return true;
        }
        return isset($_SESSION['role']) && $_SESSION['role'] === 'user';
    }
    
    // Get current user (prioritizes role-specific session)
    public function getCurrentUser($role = null) {
        if ($role === 'admin' && isset($_SESSION['admin_session'])) {
            return $_SESSION['admin_session'];
        } elseif ($role === 'user' && isset($_SESSION['user_session'])) {
            return $_SESSION['user_session'];
        } elseif ($role === 'staff' && isset($_SESSION['staff_session'])) {
            return $_SESSION['staff_session'];
        } elseif (isset($_SESSION['admin_session'])) {
            return $_SESSION['admin_session'];
        } elseif (isset($_SESSION['user_session'])) {
            return $_SESSION['user_session'];
        } elseif (isset($_SESSION['staff_session'])) {
            return $_SESSION['staff_session'];
        } elseif ($this->isLoggedIn()) {
            return [
                'id' => $_SESSION['user_id'] ?? $_SESSION['staff_id'] ?? null,
                'username' => $_SESSION['username'],
                'full_name' => $_SESSION['full_name'],
                'role' => $_SESSION['role']
            ];
        }
        return null;
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $auth = new Auth();
    $action = $_POST['action'] ?? '';
    
    header('Content-Type: application/json');
    
    if ($action === 'register') {
        $fullName = $_POST['full_name'] ?? '';
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($fullName) || empty($username) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'All fields are required']);
            exit;
        }
        
        echo json_encode($auth->register($fullName, $username, $password));
    } elseif ($action === 'login') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Username and password are required']);
            exit;
        }
        
        echo json_encode($auth->login($username, $password));
    } elseif ($action === 'logout') {
        $role = $_POST['role'] ?? null;
        echo json_encode($auth->logout($role));
    } elseif ($action === 'check_username') {
        $username = $_POST['username'] ?? '';
        $exists = $auth->usernameExists($username);
        echo json_encode(['exists' => $exists]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $auth = new Auth();
    $action = $_GET['action'] ?? '';
    
    header('Content-Type: application/json');
    
    if ($action === 'check') {
        // Allow the frontend to specify which role/session to check
        // so that admin, user, and staff can stay logged in at the same time
        $role = $_GET['role'] ?? null;
        if ($role !== 'admin' && $role !== 'user' && $role !== 'staff') {
            $role = null;
        }

        $user = $auth->getCurrentUser($role);
        if ($user) {
            echo json_encode([
                'logged_in' => true,
                'role' => $user['role'],
                'full_name' => $user['full_name'],
                'username' => $user['username']
            ]);
        } else {
            echo json_encode(['logged_in' => false]);
        }
    }
}
?>

