<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'auth.php';

class Notifications {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Get user notifications
    public function getUserNotifications($userId) {
        // Newest first; fall back to id DESC when timestamps tie
        $stmt = $this->db->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
        return $notifications;
    }
    
    // Get unread notifications count
    public function getUnreadCount($userId) {
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = FALSE");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'] ?? 0;
    }
    
    // Mark notification as read
    public function markAsRead($notificationId, $userId) {
        $stmt = $this->db->prepare("UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $notificationId, $userId);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Notification marked as read'];
        } else {
            return ['success' => false, 'message' => 'Failed to update notification'];
        }
    }
    
    // Mark all as read
    public function markAllAsRead($userId) {
        $stmt = $this->db->prepare("UPDATE notifications SET is_read = TRUE WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'All notifications marked as read'];
        } else {
            return ['success' => false, 'message' => 'Failed to update notifications'];
        }
    }
    
    // Create notification (admin)
    public function createNotification($userId, $bookingId, $message) {
        // Validate user_id is a positive integer
        $userId = intval($userId);
        if ($userId <= 0) {
            return ['success' => false, 'message' => 'Invalid user ID provided'];
        }
        
        // Validate message is not empty
        if (empty(trim($message))) {
            return ['success' => false, 'message' => 'Notification message cannot be empty'];
        }
        
        $stmt = $this->db->prepare("INSERT INTO notifications (user_id, booking_id, message) VALUES (?, ?, ?)");
        $bookingIdInt = $bookingId ? intval($bookingId) : null;
        $stmt->bind_param("iis", $userId, $bookingIdInt, $message);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Notification created successfully'];
        } else {
            return ['success' => false, 'message' => 'Failed to create notification: ' . $stmt->error];
        }
    }
    
    // Get all notifications (admin)
    public function getAllNotifications() {
        // Ensure consistent newest-first ordering for admin view
        $result = $this->db->query("SELECT n.*, u.username, b.id as booking_id FROM notifications n JOIN users u ON n.user_id = u.id LEFT JOIN bookings b ON n.booking_id = b.id ORDER BY n.created_at DESC, n.id DESC");
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
        return $notifications;
    }
}

// Handle API requests only when this file is the direct target
if (isset($_SERVER['REQUEST_METHOD']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
        $auth = new Auth();
        
        $role = $_REQUEST['role'] ?? null;
        $currentUser = $auth->getCurrentUser($role);
        
        if (!$currentUser) {
            // Fall back to role-specific session data if getCurrentUser didn't find it
            if ($role === 'user' && isset($_SESSION['user_session'])) {
                $currentUser = $_SESSION['user_session'];
            } elseif ($role === 'admin' && isset($_SESSION['admin_session'])) {
                $currentUser = $_SESSION['admin_session'];
            } elseif ($role === 'staff' && isset($_SESSION['staff_session'])) {
                $currentUser = $_SESSION['staff_session'];
            } elseif (isset($_SESSION['user_session'])) {
                $currentUser = $_SESSION['user_session'];
            } elseif (isset($_SESSION['admin_session'])) {
                $currentUser = $_SESSION['admin_session'];
            } elseif (isset($_SESSION['staff_session'])) {
                $currentUser = $_SESSION['staff_session'];
            } elseif (isset($_SESSION['user_id'])) {
                // Last resort: use generic session
                $currentUser = [
                    'user_id' => $_SESSION['user_id'],
                    'username' => $_SESSION['username'] ?? '',
                    'full_name' => $_SESSION['full_name'] ?? '',
                    'role' => $_SESSION['role'] ?? ''
                ];
            }
        }

        if (!$currentUser) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Not authenticated for this role']);
            exit;
        }
        
        $notifications = new Notifications();
        header('Content-Type: application/json');
        
        $action = $_REQUEST['action'] ?? '';
        // Extract user_id - check both 'user_id' and 'id' keys, prioritizing 'user_id'
        $userId = null;
        if (isset($currentUser['user_id'])) {
            $userId = $currentUser['user_id'];
        } elseif (isset($currentUser['id'])) {
            $userId = $currentUser['id'];
        } elseif (isset($currentUser['staff_id']) && $role === 'staff') {
            // Staff notifications use staff_id, but we need to handle this differently
            // For now, staff notifications are separate, so this shouldn't be called
            $userId = null;
        }

        if (!$userId) {
            echo json_encode(['success' => false, 'message' => 'Unable to determine user session']);
            exit;
        }
        
        if ($action === 'get_notifications') {
            echo json_encode(['success' => true, 'notifications' => $notifications->getUserNotifications($userId)]);
        } elseif ($action === 'get_unread_count') {
            echo json_encode(['success' => true, 'count' => $notifications->getUnreadCount($userId)]);
        } elseif ($action === 'mark_read') {
            $notificationId = $_POST['notification_id'] ?? 0;
            echo json_encode($notifications->markAsRead($notificationId, $userId));
        } elseif ($action === 'mark_all_read') {
            echo json_encode($notifications->markAllAsRead($userId));
        } elseif ($action === 'create_notification' && $auth->isAdmin()) {
            $targetUserId = $_POST['user_id'] ?? 0;
            $bookingId = $_POST['booking_id'] ?? null;
            $message = $_POST['message'] ?? '';
            echo json_encode($notifications->createNotification($targetUserId, $bookingId, $message));
        } elseif ($action === 'get_all_notifications' && $auth->isAdmin()) {
            echo json_encode(['success' => true, 'notifications' => $notifications->getAllNotifications()]);
        }
    }
}
?>

