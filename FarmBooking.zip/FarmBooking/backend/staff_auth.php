<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

class StaffAuth {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Login staff
    public function login($username, $password) {
        $stmt = $this->db->prepare("SELECT id, name, username, password FROM staff WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $staff = $result->fetch_assoc();
            
            if (password_verify($password, $staff['password'])) {
                // Store staff session
                $_SESSION['staff_session'] = [
                    'staff_id' => $staff['id'],
                    'username' => $staff['username'],
                    'full_name' => $staff['name'],
                    'role' => 'staff'
                ];
                
                // Also set current session for backward compatibility
                $_SESSION['staff_id'] = $staff['id'];
                $_SESSION['username'] = $staff['username'];
                $_SESSION['full_name'] = $staff['name'];
                $_SESSION['role'] = 'staff';
                
                return [
                    'success' => true,
                    'role' => 'staff',
                    'staff_id' => $staff['id'],
                    'full_name' => $staff['name'],
                    'username' => $staff['username'],
                    'message' => 'Login successful'
                ];
            } else {
                return ['success' => false, 'message' => 'Invalid password'];
            }
        } else {
            return ['success' => false, 'message' => 'Username not found'];
        }
    }
    
    // Logout staff
    public function logout() {
        unset($_SESSION['staff_session'], $_SESSION['staff_id'], $_SESSION['username'], $_SESSION['full_name'], $_SESSION['role']);
        
        // If there is nothing left in the session, fully destroy it
        if (empty($_SESSION)) {
            session_unset();
            session_destroy();
        }
        
        return ['success' => true, 'message' => 'Logged out successfully'];
    }
    
    // Check if staff is logged in
    public function isLoggedIn() {
        return isset($_SESSION['staff_id']) || isset($_SESSION['staff_session']);
    }
    
    // Get current staff
    public function getCurrentStaff() {
        if (isset($_SESSION['staff_session'])) {
            return $_SESSION['staff_session'];
        } elseif ($this->isLoggedIn()) {
            return [
                'staff_id' => $_SESSION['staff_id'],
                'username' => $_SESSION['username'],
                'full_name' => $_SESSION['full_name'],
                'role' => 'staff'
            ];
        }
        return null;
    }
    
    // Create staff notification
    public function createStaffNotification($staffId, $bookingId, $message) {
        try {
            $stmt = $this->db->prepare("INSERT INTO staff_notifications (staff_id, booking_id, message) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $staffId, $bookingId, $message);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Notification created successfully'];
            } else {
                return ['success' => false, 'message' => 'Failed to create notification'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    $staffAuth = new StaffAuth();
    $action = $_REQUEST['action'] ?? '';
    
    header('Content-Type: application/json');
    
    if ($action === 'login') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Username and password are required']);
            exit;
        }
        
        echo json_encode($staffAuth->login($username, $password));
    } elseif ($action === 'logout') {
        echo json_encode($staffAuth->logout());
    } elseif ($action === 'check') {
        $staff = $staffAuth->getCurrentStaff();
        if ($staff) {
            echo json_encode([
                'logged_in' => true,
                'role' => 'staff',
                'full_name' => $staff['full_name'],
                'username' => $staff['username'],
                'staff_id' => $staff['staff_id']
            ]);
        } else {
            echo json_encode(['logged_in' => false]);
        }
    }
}
?>

