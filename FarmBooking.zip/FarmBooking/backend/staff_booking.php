<?php
// Prevent any output before headers
ob_start();

session_start();
require_once 'db.php';
require_once 'staff_auth.php';

class StaffBooking {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Get assigned bookings for staff
    public function getAssignedBookings($staffId) {
        try {
            $stmt = $this->db->prepare("SELECT b.*, f.name as farm_name, f.description as farm_description,
                s.status as staff_status, s.id as staff_id
                FROM bookings b
                JOIN farms f ON b.farm_id = f.id
                JOIN staff s ON s.assigned_booking_id = b.id
                WHERE s.id = ? AND b.status != 'cancelled'
                ORDER BY b.booking_date DESC");
            $stmt->bind_param("i", $staffId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $bookings = [];
            while ($row = $result->fetch_assoc()) {
                $bookings[] = $row;
            }
            return $bookings;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get booking details
    public function getBookingDetails($bookingId, $staffId) {
        try {
            // First try to get from assigned bookings
            $stmt = $this->db->prepare("SELECT b.*, f.name as farm_name, f.description as farm_description,
                s.status as staff_status
                FROM bookings b
                JOIN farms f ON b.farm_id = f.id
                JOIN staff s ON s.assigned_booking_id = b.id
                WHERE b.id = ? AND s.id = ?");
            $stmt->bind_param("ii", $bookingId, $staffId);
            $stmt->execute();
            $result = $stmt->get_result();
            $booking = $result->fetch_assoc();
            
            // If not found in assigned bookings, check completed tours
            if (!$booking) {
                try {
                    $completedStmt = $this->db->prepare("SELECT b.*, f.name as farm_name, f.description as farm_description,
                        ct.completed_at
                        FROM completed_tours ct
                        JOIN bookings b ON ct.booking_id = b.id
                        JOIN farms f ON b.farm_id = f.id
                        WHERE ct.booking_id = ? AND ct.staff_id = ?");
                    $completedStmt->bind_param("ii", $bookingId, $staffId);
                    $completedStmt->execute();
                    $completedResult = $completedStmt->get_result();
                    $booking = $completedResult->fetch_assoc();
                    if ($booking) {
                        $booking['staff_status'] = 'completed';
                    }
                } catch (Exception $e) {
                    // If completed_tours table doesn't exist, return null
                    return null;
                }
            }
            
            return $booking;
        } catch (Exception $e) {
            return null;
        }
    }
    
    // Mark booking as done (complete tour)
    public function markTourDone($bookingId, $staffId) {
        try {
            // Start transaction
            $this->db->begin_transaction();
            
            try {
                // Verify staff is assigned to this booking
                $checkStmt = $this->db->prepare("SELECT id FROM staff WHERE id = ? AND assigned_booking_id = ?");
                $checkStmt->bind_param("ii", $staffId, $bookingId);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();
                
                if ($checkResult->num_rows === 0) {
                    throw new Exception('You are not assigned to this booking');
                }
                
                // Update staff status back to 'waiting_for_assign' and unassign
                $updateStmt = $this->db->prepare("UPDATE staff SET status = 'waiting_for_assign', assigned_booking_id = NULL WHERE id = ?");
                $updateStmt->bind_param("i", $staffId);
                
                if (!$updateStmt->execute()) {
                    throw new Exception('Failed to update staff status');
                }
                
                // Get booking details for notification
                $bookingStmt = $this->db->prepare("SELECT b.*, s.name as staff_name FROM bookings b LEFT JOIN staff s ON s.id = ? WHERE b.id = ?");
                $bookingStmt->bind_param("ii", $staffId, $bookingId);
                $bookingStmt->execute();
                $bookingResult = $bookingStmt->get_result();
                $booking = $bookingResult->fetch_assoc();
                
                // Record completed tour in completed_tours table
                try {
                    $completedStmt = $this->db->prepare("INSERT INTO completed_tours (staff_id, booking_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE completed_at = CURRENT_TIMESTAMP");
                    $completedStmt->bind_param("ii", $staffId, $bookingId);
                    $completedStmt->execute();
                } catch (Exception $e) {
                    // If table doesn't exist yet, continue without error
                    // This allows the system to work even if migration hasn't been run
                }
                
                // Send notification to user
                if ($booking && isset($booking['user_id'])) {
                    require_once 'notifications.php';
                    $notifications = new Notifications();
                    $staffName = $booking['staff_name'] ?? 'Staff member';
                    $message = "Tour completed for reservation #{$bookingId}. Staff {$staffName} has marked the tour as done.";
                    $notifications->createNotification($booking['user_id'], $bookingId, $message);
                }
                
                // Commit transaction
                $this->db->commit();
                return ['success' => true, 'message' => 'Tour marked as done successfully. Your status has been updated to "Waiting for Assign".'];
            } catch (Exception $e) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Get staff notifications
    public function getStaffNotifications($staffId) {
        try {
            // Newest first; tie-breaker on id
            $stmt = $this->db->prepare("SELECT * FROM staff_notifications WHERE staff_id = ? ORDER BY created_at DESC, id DESC");
            $stmt->bind_param("i", $staffId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $notifications = [];
            while ($row = $result->fetch_assoc()) {
                $notifications[] = $row;
            }
            return $notifications;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get unread notifications count
    public function getUnreadCount($staffId) {
        try {
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM staff_notifications WHERE staff_id = ? AND is_read = FALSE");
            $stmt->bind_param("i", $staffId);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            return $row['count'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    // Mark notification as read
    public function markAsRead($notificationId, $staffId) {
        try {
            $stmt = $this->db->prepare("UPDATE staff_notifications SET is_read = TRUE WHERE id = ? AND staff_id = ?");
            $stmt->bind_param("ii", $notificationId, $staffId);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'Notification marked as read'];
            } else {
                return ['success' => false, 'message' => 'Failed to update notification'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Mark all as read
    public function markAllAsRead($staffId) {
        try {
            $stmt = $this->db->prepare("UPDATE staff_notifications SET is_read = TRUE WHERE staff_id = ?");
            $stmt->bind_param("i", $staffId);
            
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'All notifications marked as read'];
            } else {
                return ['success' => false, 'message' => 'Failed to update notifications'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    // Get staff profile info
    public function getStaffProfile($staffId) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM staff WHERE id = ?");
            $stmt->bind_param("i", $staffId);
            $stmt->execute();
            $result = $stmt->get_result();
            return $result->fetch_assoc();
        } catch (Exception $e) {
            return null;
        }
    }
    
    // Get completed tours for staff
    public function getCompletedTours($staffId) {
        try {
            // Try to get from completed_tours table first
            // Exclude cancelled bookings - they should only appear in notifications
            $stmt = $this->db->prepare("
                SELECT b.*, f.name as farm_name, f.description as farm_description,
                       ct.completed_at
                FROM completed_tours ct
                JOIN bookings b ON ct.booking_id = b.id
                JOIN farms f ON b.farm_id = f.id
                WHERE ct.staff_id = ? AND b.status != 'cancelled'
                ORDER BY ct.completed_at DESC
            ");
            $stmt->bind_param("i", $staffId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $tours = [];
            while ($row = $result->fetch_assoc()) {
                $tours[] = $row;
            }
            
            // If no results and table might not exist, return empty array
            return $tours;
        } catch (Exception $e) {
            // If table doesn't exist, return empty array
            return [];
        }
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Clear any output buffer
    ob_clean();
    
    // Set headers first
    header('Content-Type: application/json; charset=utf-8');
    
    $staffAuth = new StaffAuth();
    
    if (!$staffAuth->isLoggedIn()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $currentStaff = $staffAuth->getCurrentStaff();
    $staffId = $currentStaff['staff_id'] ?? null;
    
    if (!$staffId) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Unable to determine staff session'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $staffBooking = new StaffBooking();
    $action = $_REQUEST['action'] ?? '';
    
    try {
        if ($action === 'get_bookings') {
            $bookings = $staffBooking->getAssignedBookings($staffId);
            echo json_encode(['success' => true, 'bookings' => $bookings], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_booking') {
            $bookingId = intval($_REQUEST['booking_id'] ?? 0);
            $booking = $staffBooking->getBookingDetails($bookingId, $staffId);
            echo json_encode(['success' => true, 'booking' => $booking], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'mark_done') {
            $bookingId = intval($_POST['booking_id'] ?? 0);
            $result = $staffBooking->markTourDone($bookingId, $staffId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_notifications') {
            $notifications = $staffBooking->getStaffNotifications($staffId);
            echo json_encode(['success' => true, 'notifications' => $notifications], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_unread_count') {
            $count = $staffBooking->getUnreadCount($staffId);
            echo json_encode(['success' => true, 'count' => $count], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'mark_read') {
            $notificationId = intval($_POST['notification_id'] ?? 0);
            $result = $staffBooking->markAsRead($notificationId, $staffId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'mark_all_read') {
            $result = $staffBooking->markAllAsRead($staffId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_profile') {
            $profile = $staffBooking->getStaffProfile($staffId);
            echo json_encode(['success' => true, 'profile' => $profile], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_completed_tours') {
            $tours = $staffBooking->getCompletedTours($staffId);
            echo json_encode(['success' => true, 'tours' => $tours], JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action'], JSON_UNESCAPED_UNICODE);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Server error occurred'], JSON_UNESCAPED_UNICODE);
    }
    
    // End output buffering
    ob_end_flush();
    exit;
}
?>

