<?php
// Prevent any output before headers
if (ob_get_level()) {
    ob_end_clean();
}
ob_start();

// Suppress any warnings/notices that might corrupt JSON
error_reporting(E_ALL);
ini_set('display_errors', 0);

session_start();
require_once 'db.php';
require_once 'auth.php';
require_once 'notifications.php';

class UserBooking {
    private $db;
    
    public function __construct() {
        global $db;
        $this->db = $db;
    }
    
    // Get all farms
    public function getFarms() {
        try {
            $result = $this->db->query("SELECT * FROM farms ORDER BY name");
            
            if (!$result) {
                global $conn;
                $error = $conn ? $conn->error : "Unknown database error";
                return [];
            }
            
            $farms = [];
            while ($row = $result->fetch_assoc()) {
                $farms[] = $row;
            }
            
            return $farms;
        } catch (Exception $e) {
            return [];
        }
    }
    
    // Get farm by ID
    public function getFarmById($farmId) {
        $stmt = $this->db->prepare("SELECT * FROM farms WHERE id = ?");
        $stmt->bind_param("i", $farmId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Calculate price based on age and type
    public function calculatePrice($farm, $age, $companions, $type = 'normal') {
        $mainPrice = 0;
        
        // Determine main price based on type first, then age
        if ($type === 'pregnant') {
            $mainPrice = $farm['pricing_pregnant'];
        } elseif ($type === 'disabled') {
            $mainPrice = $farm['pricing_disabled'];
        } elseif ($age < 13) {
            $mainPrice = $farm['pricing_child'];
        } elseif ($age < 18) {
            $mainPrice = $farm['pricing_teen'];
        } elseif ($age >= 65) {
            $mainPrice = $farm['pricing_senior'];
        } else {
            $mainPrice = $farm['pricing_adult'];
        }
        
        // Calculate companions price
        $companionsPrice = 0;
        if (!empty($companions)) {
            $companionsData = json_decode($companions, true);
            if (is_array($companionsData)) {
                foreach ($companionsData as $companion) {
                    $compAge = $companion['age'] ?? 0;
                    $compType = $companion['type'] ?? '';
                    
                    if ($compType === 'pregnant') {
                        $companionsPrice += $farm['pricing_pregnant'];
                    } elseif ($compType === 'disabled') {
                        $companionsPrice += $farm['pricing_disabled'];
                    } elseif ($compAge < 13) {
                        $companionsPrice += $farm['pricing_child'];
                    } elseif ($compAge < 18) {
                        $companionsPrice += $farm['pricing_teen'];
                    } elseif ($compAge >= 65) {
                        $companionsPrice += $farm['pricing_senior'];
                    } else {
                        $companionsPrice += $farm['pricing_adult'];
                    }
                }
            }
        }
        
        return $mainPrice + $companionsPrice;
    }
    
    // Create booking
    public function createBooking($data) {
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            return ['success' => false, 'message' => 'User not authenticated'];
        }
        
        $userId = $_SESSION['user_id'];
        $farmId = $data['farm_id'];
        $farm = $this->getFarmById($farmId);
        
        if (!$farm) {
            return ['success' => false, 'message' => 'Farm not found'];
        }
        
        // Check capacity (initial check before transaction)
        $totalPeople = 1 + ($data['companions_count'] ?? 0);
        if ($totalPeople > $farm['capacity']) {
            return ['success' => false, 'message' => 'Booking exceeds farm capacity'];
        }
        
        // Calculate price
        $type = $data['type'] ?? 'normal';
        $totalPrice = $this->calculatePrice($farm, $data['age'], $data['companions_details'] ?? '', $type);
        
        // Start transaction
        $this->db->begin_transaction();
        
        try {
            // Re-read farm capacity inside transaction to get most up-to-date value
            $farmStmt = $this->db->prepare("SELECT capacity FROM farms WHERE id = ? FOR UPDATE");
            $farmStmt->bind_param("i", $farmId);
            $farmStmt->execute();
            $farmResult = $farmStmt->get_result();
            $currentFarm = $farmResult->fetch_assoc();
            
            if (!$currentFarm) {
                throw new Exception('Farm not found');
            }
            
            // Final capacity check inside transaction
            if ($totalPeople > $currentFarm['capacity']) {
                throw new Exception('Booking exceeds farm capacity');
            }
            
            // Insert booking with explicit 'pending' status
            $status = 'pending';
            // Check if type column exists, if not, use old query
            $checkColumn = $this->db->query("SHOW COLUMNS FROM bookings LIKE 'type'");
            if ($checkColumn && $checkColumn->num_rows > 0) {
                $stmt = $this->db->prepare("INSERT INTO bookings (user_id, farm_id, full_name, age, gender, nationality, marital_status, type, companions_count, companions_details, total_price, booking_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                if (!$stmt) {
                    throw new Exception('Failed to prepare statement: ' . $this->db->error);
                }
                $stmt->bind_param("iisissssisdss", 
                    $userId,
                    $farmId,
                    $data['full_name'],
                    $data['age'],
                    $data['gender'],
                    $data['nationality'],
                    $data['marital_status'],
                    $type,
                    $data['companions_count'],
                    $data['companions_details'],
                    $totalPrice,
                    $data['booking_date'],
                    $status
                );
            } else {
                $stmt = $this->db->prepare("INSERT INTO bookings (user_id, farm_id, full_name, age, gender, nationality, marital_status, companions_count, companions_details, total_price, booking_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                if (!$stmt) {
                    throw new Exception('Failed to prepare statement: ' . $this->db->error);
                }
                $stmt->bind_param("iisisssisdss", 
                    $userId,
                    $farmId,
                    $data['full_name'],
                    $data['age'],
                    $data['gender'],
                    $data['nationality'],
                    $data['marital_status'],
                    $data['companions_count'],
                    $data['companions_details'],
                    $totalPrice,
                    $data['booking_date'],
                    $status
                );
            }
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to create booking: ' . $stmt->error);
            }
            
            $bookingId = $this->db->getLastInsertId();
            
            // Decrease farm capacity using the locked value
            $newCapacity = max(0, $currentFarm['capacity'] - $totalPeople);
            $updateStmt = $this->db->prepare("UPDATE farms SET capacity = ? WHERE id = ?");
            
            if (!$updateStmt) {
                throw new Exception('Failed to prepare update statement: ' . $this->db->error);
            }
            
            $updateStmt->bind_param("ii", $newCapacity, $farmId);
            
            if (!$updateStmt->execute()) {
                throw new Exception('Failed to update farm capacity: ' . $updateStmt->error);
            }
            
            // Commit transaction
            $this->db->commit();
            
            // Create notification for 1 day before
            $this->createNotification($userId, $bookingId, $totalPrice, $data['booking_date']);
            
            return ['success' => true, 'message' => 'Booking created successfully', 'booking_id' => $bookingId];
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->db->rollback();
            return ['success' => false, 'message' => 'Failed to create booking: ' . $e->getMessage()];
        }
    }
    
    // Get user bookings (accepted only)
    public function getUserBookings($userId) {
        $stmt = $this->db->prepare("SELECT b.*, f.name as farm_name FROM bookings b JOIN farms f ON b.farm_id = f.id WHERE b.user_id = ? AND (b.status = 'accepted' OR b.status = 'pending_cancellation') ORDER BY b.created_at DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $bookings = [];
        while ($row = $result->fetch_assoc()) {
            $bookings[] = $row;
        }
        return $bookings;
    }
    
    // Get booking requests (pending or pending cancellation)
    public function getBookingRequests($userId) {
        $stmt = $this->db->prepare("SELECT b.*, f.name as farm_name FROM bookings b JOIN farms f ON b.farm_id = f.id WHERE b.user_id = ? AND (b.status = 'pending' OR b.status = 'pending_cancellation') ORDER BY b.created_at DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $bookings = [];
        while ($row = $result->fetch_assoc()) {
            $bookings[] = $row;
        }
        return $bookings;
    }
    
    // Get booking by ID
    public function getBookingById($bookingId, $userId) {
        $stmt = $this->db->prepare("SELECT b.*, f.name as farm_name FROM bookings b JOIN farms f ON b.farm_id = f.id WHERE b.id = ? AND b.user_id = ?");
        $stmt->bind_param("ii", $bookingId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Update booking
    public function updateBooking($bookingId, $data, $userId) {
        // Verify ownership
        $booking = $this->getBookingById($bookingId, $userId);
        if (!$booking) {
            return ['success' => false, 'message' => 'Booking not found'];
        }
        
        if ($booking['status'] === 'cancelled') {
            return ['success' => false, 'message' => 'Cannot update cancelled booking'];
        }
        
        // Only allow editing pending bookings
        if ($booking['status'] !== 'pending') {
            return ['success' => false, 'message' => 'Can only edit pending booking requests'];
        }
        
        // Get farm and recalculate price
        $farm = $this->getFarmById($booking['farm_id']);
        $type = $data['type'] ?? 'normal';
        $totalPrice = $this->calculatePrice($farm, $data['age'], $data['companions_details'] ?? '', $type);
        
        // Calculate old and new people count
        $oldPeopleCount = 1 + ($booking['companions_count'] ?? 0);
        $newPeopleCount = 1 + ($data['companions_count'] ?? 0);
        $peopleDifference = $newPeopleCount - $oldPeopleCount;
        
        // Check if new capacity would be exceeded
        $newCapacity = $farm['capacity'] - $peopleDifference;
        if ($newCapacity < 0) {
            return ['success' => false, 'message' => 'Booking exceeds farm capacity'];
        }
        
        // Start transaction
        $this->db->begin_transaction();
        
        try {
            // Check if type column exists
            $checkColumn = $this->db->query("SHOW COLUMNS FROM bookings LIKE 'type'");
            if ($checkColumn && $checkColumn->num_rows > 0) {
                // Update booking with type
                $stmt = $this->db->prepare("UPDATE bookings SET full_name = ?, age = ?, gender = ?, nationality = ?, marital_status = ?, type = ?, companions_count = ?, companions_details = ?, total_price = ?, booking_date = ? WHERE id = ? AND user_id = ?");
                $stmt->bind_param("sissssisdsii",
                    $data['full_name'],
                    $data['age'],
                    $data['gender'],
                    $data['nationality'],
                    $data['marital_status'],
                    $type,
                    $data['companions_count'],
                    $data['companions_details'],
                    $totalPrice,
                    $data['booking_date'],
                    $bookingId,
                    $userId
                );
            } else {
                // Update booking without type
                $stmt = $this->db->prepare("UPDATE bookings SET full_name = ?, age = ?, gender = ?, nationality = ?, marital_status = ?, companions_count = ?, companions_details = ?, total_price = ?, booking_date = ? WHERE id = ? AND user_id = ?");
                $stmt->bind_param("sisssisdsii",
                    $data['full_name'],
                    $data['age'],
                    $data['gender'],
                    $data['nationality'],
                    $data['marital_status'],
                    $data['companions_count'],
                    $data['companions_details'],
                    $totalPrice,
                    $data['booking_date'],
                    $bookingId,
                    $userId
                );
            }
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to update booking');
            }
            
            // Update farm capacity (adjust based on difference)
            $updateStmt = $this->db->prepare("UPDATE farms SET capacity = ? WHERE id = ?");
            $updateStmt->bind_param("ii", $newCapacity, $booking['farm_id']);
            
            if (!$updateStmt->execute()) {
                throw new Exception('Failed to update farm capacity');
            }
            
            // Commit transaction
            $this->db->commit();
            
            return ['success' => true, 'message' => 'Booking updated successfully'];
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->db->rollback();
            return ['success' => false, 'message' => 'Failed to update booking: ' . $e->getMessage()];
        }
    }
    
    // Cancel booking (for pending bookings only - immediate cancellation)
    public function cancelBooking($bookingId, $userId) {
        $booking = $this->getBookingById($bookingId, $userId);
        if (!$booking) {
            return ['success' => false, 'message' => 'Booking not found'];
        }
        
        if ($booking['status'] === 'cancelled') {
            return ['success' => false, 'message' => 'Booking already cancelled'];
        }
        
        // Only allow immediate cancellation for pending bookings
        if ($booking['status'] !== 'pending') {
            return ['success' => false, 'message' => 'Cannot cancel accepted booking directly. Please request cancellation.'];
        }
        
        // Get farm to restore capacity
        $farm = $this->getFarmById($booking['farm_id']);
        $peopleCount = 1 + ($booking['companions_count'] ?? 0);
        
        // Start transaction
        $this->db->begin_transaction();
        
        try {
            // Update booking status
            $stmt = $this->db->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $bookingId, $userId);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to cancel booking');
            }
            
            // Restore farm capacity
            $newCapacity = $farm['capacity'] + $peopleCount;
            $updateStmt = $this->db->prepare("UPDATE farms SET capacity = ? WHERE id = ?");
            $updateStmt->bind_param("ii", $newCapacity, $booking['farm_id']);
            
            if (!$updateStmt->execute()) {
                throw new Exception('Failed to restore farm capacity');
            }

            // Unassign any staff linked to this booking
            $unassignStmt = $this->db->prepare("UPDATE staff SET assigned_booking_id = NULL WHERE assigned_booking_id = ?");
            $unassignStmt->bind_param("i", $bookingId);
            if (!$unassignStmt->execute()) {
                throw new Exception('Failed to unassign staff for cancelled booking');
            }
            
            // Commit transaction
            $this->db->commit();
            
            // Create notification for user
            $notifications = new Notifications();
            $message = "Your reservation #{$bookingId} for {$booking['farm_name']} on {$booking['booking_date']} has been cancelled successfully.";
            $notifications->createNotification($userId, $bookingId, $message);

            // Notify all admins about the user cancellation (NotificationA)
            $adminResult = $this->db->query("SELECT id, full_name FROM users WHERE role = 'admin'");
            if ($adminResult) {
                while ($admin = $adminResult->fetch_assoc()) {
                    $adminMessage = "Reservation #{$bookingId} for {$booking['farm_name']} on {$booking['booking_date']} was cancelled by {$booking['full_name']}.";
                    $notifications->createNotification($admin['id'], $bookingId, $adminMessage);
                }
            }
            
            return ['success' => true, 'message' => 'Booking cancelled successfully'];
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->db->rollback();
            return ['success' => false, 'message' => 'Failed to cancel booking: ' . $e->getMessage()];
        }
    }
    
    // Request cancellation (for accepted bookings - requires admin approval)
    public function requestCancellation($bookingId, $userId, $reason) {
        $booking = $this->getBookingById($bookingId, $userId);
        if (!$booking) {
            return ['success' => false, 'message' => 'Booking not found'];
        }
        
        if ($booking['status'] === 'cancelled') {
            return ['success' => false, 'message' => 'Booking already cancelled'];
        }
        
        if ($booking['status'] === 'pending_cancellation') {
            return ['success' => false, 'message' => 'Cancellation request already pending'];
        }
        
        // Start transaction to update booking and create cancellation record
        $this->db->begin_transaction();
        
        try {
            // Update booking to pending_cancellation status
            $stmt = $this->db->prepare("UPDATE bookings SET status = 'pending_cancellation', cancellation_reason = ? WHERE id = ? AND user_id = ?");
            $stmt->bind_param("sii", $reason, $bookingId, $userId);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to update booking status');
            }
            
            // Create cancellation record in cancellations table
            $cancelStmt = $this->db->prepare("INSERT INTO cancellations (booking_id, user_id, cancellation_reason, status) VALUES (?, ?, ?, 'pending')");
            $cancelStmt->bind_param("iis", $bookingId, $userId, $reason);
            
            if (!$cancelStmt->execute()) {
                throw new Exception('Failed to create cancellation record');
            }
            
            // Commit transaction
            $this->db->commit();
            
            // Notify user that request was submitted
            $notifications = new Notifications();
            $message = "Your cancellation request for reservation #{$bookingId} ({$booking['farm_name']} on {$booking['booking_date']}) has been submitted and is awaiting admin approval.";
            $notifications->createNotification($userId, $bookingId, $message);

            // Notify all admins about the pending cancellation request (NotificationA)
            $adminResult = $this->db->query("SELECT id, full_name FROM users WHERE role = 'admin'");
            if ($adminResult) {
                while ($admin = $adminResult->fetch_assoc()) {
                    $adminMessage = "User {$booking['full_name']} requested cancellation for reservation #{$bookingId} ({$booking['farm_name']} on {$booking['booking_date']}).";
                    $notifications->createNotification($admin['id'], $bookingId, $adminMessage);
                }
            }
            
            return ['success' => true, 'message' => 'Cancellation request submitted successfully'];
        } catch (Exception $e) {
            // Rollback transaction on error
            $this->db->rollback();
            return ['success' => false, 'message' => 'Failed to submit cancellation request: ' . $e->getMessage()];
        }
    }
    
    // Create notification for payment reminder
    private function createNotification($userId, $bookingId, $totalPrice, $bookingDate) {
        $notificationDate = date('Y-m-d', strtotime($bookingDate . ' -1 day'));
        $message = "Reminder: Your booking payment of ₱" . number_format($totalPrice, 2) . " is due tomorrow.";
        
        // Schedule notification (in real app, use cron job)
        $stmt = $this->db->prepare("INSERT INTO notifications (user_id, booking_id, message, created_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $userId, $bookingId, $message, $notificationDate);
        $stmt->execute();
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Clear any output buffer completely
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Set headers first - before any output
    header('Content-Type: application/json; charset=utf-8');
    
    // Enable error logging for debugging (remove in production)
    error_log('User booking request: ' . ($_REQUEST['action'] ?? 'no action'));
    
    $auth = new Auth();
    
    if (!$auth->isLoggedIn()) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Not authenticated', 'logged_in' => false], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $booking = new UserBooking();
    $action = $_REQUEST['action'] ?? '';
    
    try {
        if ($action === 'get_farms') {
            $farms = $booking->getFarms();
            echo json_encode(['success' => true, 'farms' => $farms, 'count' => count($farms)], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_farm') {
            $farmId = $_REQUEST['farm_id'] ?? 0;
            $farm = $booking->getFarmById($farmId);
            echo json_encode(['success' => true, 'farm' => $farm], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'create_booking') {
            // Log received data for debugging
            error_log('Received POST data: ' . print_r($_POST, true));
            error_log('User ID from session: ' . ($_SESSION['user_id'] ?? 'NOT SET'));
            
            // Validate required fields
            $farmId = $_POST['farm_id'] ?? 0;
            $fullName = trim($_POST['full_name'] ?? '');
            $age = intval($_POST['age'] ?? 0);
            $gender = trim($_POST['gender'] ?? '');
            $nationality = trim($_POST['nationality'] ?? '');
            $maritalStatus = trim($_POST['marital_status'] ?? '');
            $bookingDate = trim($_POST['booking_date'] ?? '');
            
            error_log('Parsed data - Farm ID: ' . $farmId . ', Full Name: ' . $fullName . ', Age: ' . $age);
            
            if (!$farmId || $farmId <= 0) {
                error_log('Validation failed: Invalid farm ID');
                echo json_encode(['success' => false, 'message' => 'Please select a farm'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            if (empty($fullName)) {
                error_log('Validation failed: Empty full name');
                echo json_encode(['success' => false, 'message' => 'Please enter your full name'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            if (!$age || $age < 1 || $age > 120) {
                error_log('Validation failed: Invalid age');
                echo json_encode(['success' => false, 'message' => 'Please enter a valid age (1-120)'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            if (empty($gender)) {
                error_log('Validation failed: Empty gender');
                echo json_encode(['success' => false, 'message' => 'Please select your gender'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            if (empty($nationality)) {
                error_log('Validation failed: Empty nationality');
                echo json_encode(['success' => false, 'message' => 'Please enter your nationality'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            if (empty($maritalStatus)) {
                error_log('Validation failed: Empty marital status');
                echo json_encode(['success' => false, 'message' => 'Please select your marital status'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            if (empty($bookingDate)) {
                error_log('Validation failed: Empty booking date');
                echo json_encode(['success' => false, 'message' => 'Please select a booking date'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            $data = [
                'farm_id' => $farmId,
                'full_name' => $fullName,
                'age' => $age,
                'gender' => $gender,
                'nationality' => $nationality,
                'marital_status' => $maritalStatus,
                'companions_count' => intval($_POST['companions_count'] ?? 0),
                'companions_details' => $_POST['companions_details'] ?? '[]',
                'booking_date' => $bookingDate
            ];
            
            error_log('Calling createBooking with data: ' . print_r($data, true));
            $result = $booking->createBooking($data);
            error_log('createBooking result: ' . print_r($result, true));
            
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_booking_requests') {
            $userId = $_SESSION['user_id'];
            $bookings = $booking->getBookingRequests($userId);
            echo json_encode(['success' => true, 'bookings' => $bookings], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_bookings') {
            $userId = $_SESSION['user_id'];
            $bookings = $booking->getUserBookings($userId);
            echo json_encode(['success' => true, 'bookings' => $bookings], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'get_booking') {
            $bookingId = $_REQUEST['booking_id'] ?? 0;
            $userId = $_SESSION['user_id'];
            $booking_data = $booking->getBookingById($bookingId, $userId);
            echo json_encode(['success' => true, 'booking' => $booking_data], JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'update_booking') {
            $bookingId = $_POST['booking_id'] ?? 0;
            $userId = $_SESSION['user_id'];
            $data = [
                'full_name' => $_POST['full_name'] ?? '',
                'age' => $_POST['age'] ?? 0,
                'gender' => $_POST['gender'] ?? '',
                'nationality' => $_POST['nationality'] ?? '',
                'marital_status' => $_POST['marital_status'] ?? '',
                'companions_count' => $_POST['companions_count'] ?? 0,
                'companions_details' => $_POST['companions_details'] ?? '[]',
                'booking_date' => $_POST['booking_date'] ?? ''
            ];
            $result = $booking->updateBooking($bookingId, $data, $userId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'cancel_booking') {
            $bookingId = $_POST['booking_id'] ?? 0;
            $userId = $_SESSION['user_id'];
            $result = $booking->cancelBooking($bookingId, $userId);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($action === 'request_cancellation') {
            $bookingId = $_POST['booking_id'] ?? 0;
            $userId = $_SESSION['user_id'];
            $reason = $_POST['cancellation_reason'] ?? '';
            if (empty($reason)) {
                echo json_encode(['success' => false, 'message' => 'Cancellation reason is required'], JSON_UNESCAPED_UNICODE);
            } else {
                $result = $booking->requestCancellation($bookingId, $userId, $reason);
                echo json_encode($result, JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action'], JSON_UNESCAPED_UNICODE);
        }
    } catch (Exception $e) {
        http_response_code(500);
        // Log error for debugging (in production, don't expose error details)
        error_log('User booking error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Server error occurred: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    
    // End output buffering
    if (ob_get_level()) {
        ob_end_flush();
    }
    exit;
}
?>
