// ============================================
// ADMIN DASHBOARD JAVASCRIPT
// Handles all dashboard functionality including
// data loading, sidebar toggle, and interactions
// ============================================

// Global variables
let farms = [];
let bookings = [];
let bookingDetailsList = [];
let staff = [];
let currentFarm = null;
let currentStaff = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    setupSidebar();
    setupNavigation();
    setupModals();
    setupReportType();
    loadFarms();
    loadBookings();
    loadCancellations();
    loadStaff();
    loadAnalytics();
    
    // Set admin name
    const adminName = sessionStorage.getItem('full_name') || 'Admin';
    document.getElementById('adminName').textContent = adminName;
    
    // Setup forms
    document.getElementById('farmForm').addEventListener('submit', handleFarmSubmit);
    document.getElementById('staffForm').addEventListener('submit', handleStaffSubmit);
    
    // Setup notifications
    updateNotificationBadge();
    // Refresh notification badge every 30 seconds
    setInterval(() => {
        updateNotificationBadge();
        // Also reload notifications if panel is open
        const panel = document.getElementById('notificationPanel');
        if (panel && panel.classList.contains('open')) {
            loadAdminNotifications();
        }
    }, 30000);
    
    // Close notification panel when clicking outside
    document.addEventListener('click', function(event) {
        const panel = document.getElementById('notificationPanel');
        const icon = document.getElementById('notificationIcon');
        if (panel && icon && !panel.contains(event.target) && !icon.contains(event.target)) {
            panel.classList.remove('active');
        }
    });
});

// ============================================
// AUTHENTICATION
// ============================================
function checkAuth() {
    // Use localStorage to pre-fill UI but always verify with backend
    const adminSession = localStorage.getItem('admin_session');
    if (adminSession) {
        try {
            const adminData = JSON.parse(adminSession);
            sessionStorage.setItem('full_name', adminData.full_name);
            sessionStorage.setItem('username', adminData.username);
            document.getElementById('adminName').textContent = adminData.full_name;
        } catch (e) {
            localStorage.removeItem('admin_session');
        }
    }
    
    // Always confirm PHP session so backend endpoints have access
    fetch('./backend/auth.php?action=check&role=admin', {
        credentials: 'same-origin'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (!data.logged_in || data.role !== 'admin') {
                alert('Admin session expired. Please log in again.');
                localStorage.removeItem('admin_session');
                sessionStorage.clear();
                window.location.href = './index.html';
            } else {
                sessionStorage.setItem('full_name', data.full_name);
                document.getElementById('adminName').textContent = data.full_name;
            }
        })
        .catch(error => {
            console.error('Auth check error:', error);
            alert('Unable to verify admin session. Please log in again.');
            localStorage.removeItem('admin_session');
            sessionStorage.clear();
            window.location.href = './index.html';
        });
}

// ============================================
// SIDEBAR FUNCTIONALITY
// ============================================
function setupSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    
    // Mobile menu toggle
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.add('active');
            sidebarOverlay.classList.add('active');
        });
    }
    
    // Close sidebar
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    // Close sidebar when clicking overlay
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        }
    });
}

// ============================================
// NAVIGATION
// ============================================
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-item');
    const pageTitle = document.getElementById('pageTitle');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            
            // Update active nav item
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Update active section
            document.querySelectorAll('.dashboard-section').forEach(s => s.classList.remove('active'));
            const targetSection = document.getElementById(section + 'Section');
            if (targetSection) {
                targetSection.classList.add('active');
            }
            
            // Update page title
            const titles = {
                'farms': 'Farm Management',
                'bookings': 'Farm Reservation',
                'bookingDetails': 'Booking Details',
                'cancellations': 'Cancellation Requests',
                'staff': 'Staff Management',
                'analytics': 'Analytics & Reports'
            };
            if (pageTitle && titles[section]) {
                pageTitle.textContent = titles[section];
            }
            
            // Close sidebar on mobile after navigation
            if (window.innerWidth <= 1024) {
                document.getElementById('sidebar').classList.remove('active');
                document.getElementById('sidebarOverlay').classList.remove('active');
            }
            
            // Reload data if needed
            if (section === 'analytics') {
                loadAnalytics();
            } else if (section === 'cancellations') {
                loadCancellations();
            } else if (section === 'bookingDetails') {
                // When navigating to Booking Details from sidebar, show all bookings
                loadAllBookingDetails();
            }
        });
    });
}

// ============================================
// MODAL SETUP
// ============================================
function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closes = document.querySelectorAll('.close');
    
    closes.forEach(close => {
        close.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    window.addEventListener('click', function(e) {
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

function setupReportType() {
    const reportType = document.getElementById('reportType');
    if (reportType) {
        reportType.addEventListener('change', function() {
            const type = this.value;
            document.getElementById('weeklyControls').style.display = type === 'weekly' ? 'block' : 'none';
            document.getElementById('monthlyControls').style.display = type === 'monthly' ? 'block' : 'none';
            loadAnalytics();
        });
    }
}

// ============================================
// FARM MANAGEMENT
// ============================================
async function loadFarms() {
    const container = document.getElementById('farmsTableContainer');
    const loading = document.getElementById('farmsLoading');
    
    if (loading) {
        container.innerHTML = '<div class="loading-spinner" id="farmsLoading"><i class="fas fa-spinner fa-spin"></i><p>Loading farms...</p></div>';
    }
    
    try {
        const response = await fetch('./backend/admin_farm.php?action=get_all_farms');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.farms) {
            farms = data.farms;
            displayFarms();
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>No Farms Found</h3><p>Add your first farm to get started.</p></div>';
        }
    } catch (error) {
        console.error('Error loading farms:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Farms</h3><p>Please check your database connection and try again.</p></div>';
    }
}

function displayFarms() {
    const container = document.getElementById('farmsTableContainer');
    
    if (!farms || farms.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-tractor"></i><h3>No Farms Found</h3><p>Add your first farm to get started.</p></div>';
        return;
    }
    
    // Ensure newest farms appear first
    const sortedFarms = [...farms].sort((a, b) => Number(b.id || 0) - Number(a.id || 0));
    
    // Use card-based layout for better visual appeal
    let html = '<div class="cards-grid">';
    
    sortedFarms.forEach(farm => {
        const farmImage = getFarmImagePath(farm.name);
        html += `
            <div class="farm-card">
                <div class="farm-image-container">
                    <img src="${farmImage}" alt="${escapeHtml(farm.name || 'Farm')}" class="farm-image" onerror="this.src='./image/Green-Valley.jpg'">
                    <div class="farm-overlay">
                        <div class="farm-badge">
                            <i class="fas fa-map-marker-alt"></i>
                            ${escapeHtml(farm.name || 'Farm')}
                        </div>
                    </div>
                </div>
                <div class="farm-card-content">
                    <h3><i class="fas fa-tractor"></i> ${escapeHtml(farm.name)}</h3>
                    <p class="farm-description">${farm.description ? escapeHtml(farm.description) : 'No description available'}</p>
                    <div class="pricing-info">
                        <h4><i class="fas fa-coins"></i> Pricing</h4>
                        <div class="pricing-list">
                            <div class="pricing-item"><span>Child:</span> <strong>₱${parseFloat(farm.pricing_child || 0).toFixed(2)}</strong></div>
                            <div class="pricing-item"><span>Teen:</span> <strong>₱${parseFloat(farm.pricing_teen || 0).toFixed(2)}</strong></div>
                            <div class="pricing-item"><span>Adult:</span> <strong>₱${parseFloat(farm.pricing_adult || 0).toFixed(2)}</strong></div>
                            <div class="pricing-item"><span>Pregnant:</span> <strong>₱${parseFloat(farm.pricing_pregnant || 0).toFixed(2)}</strong></div>
                            <div class="pricing-item"><span>Senior:</span> <strong>₱${parseFloat(farm.pricing_senior || 0).toFixed(2)}</strong></div>
                            <div class="pricing-item"><span>Person with Disability:</span> <strong>₱${parseFloat(farm.pricing_disabled || 0).toFixed(2)}</strong></div>
                        </div>
                    </div>
                    <div class="capacity-info">
                        <i class="fas fa-users"></i> Capacity: <strong>${farm.capacity || 0}</strong>
                    </div>
                    <div class="action-buttons">
                        <button class="btn btn-secondary btn-sm" onclick="editFarm(${farm.id})">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="deleteFarm(${farm.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

function openFarmModal(farmId = null) {
    const modal = document.getElementById('farmModal');
    const title = document.getElementById('farmModalTitle');
    const form = document.getElementById('farmForm');
    
    if (farmId) {
        currentFarm = farms.find(f => f.id == farmId);
        if (currentFarm) {
            title.innerHTML = '<i class="fas fa-edit"></i> Edit Farm';
            document.getElementById('farmId').value = farmId;
            document.getElementById('farmName').value = currentFarm.name || '';
            document.getElementById('farmDescription').value = currentFarm.description || '';
            document.getElementById('pricingChild').value = currentFarm.pricing_child || 0;
            document.getElementById('pricingTeen').value = currentFarm.pricing_teen || 0;
            document.getElementById('pricingAdult').value = currentFarm.pricing_adult || 0;
            document.getElementById('pricingPregnant').value = currentFarm.pricing_pregnant || 0;
            document.getElementById('pricingSenior').value = currentFarm.pricing_senior || 0;
            document.getElementById('pricingDisabled').value = currentFarm.pricing_disabled || 0;
            document.getElementById('farmCapacity').value = currentFarm.capacity || 0;
        }
    } else {
        title.innerHTML = '<i class="fas fa-plus"></i> Add Farm';
        form.reset();
        document.getElementById('farmId').value = '';
        currentFarm = null;
    }
    
    const errorDiv = document.getElementById('farmErrorMessage');
    if (errorDiv) {
        errorDiv.textContent = '';
        errorDiv.classList.remove('show');
    }
    modal.style.display = 'block';
}

function closeFarmModal() {
    document.getElementById('farmModal').style.display = 'none';
}

function editFarm(farmId) {
    openFarmModal(farmId);
}

async function handleFarmSubmit(e) {
    e.preventDefault();
    
    const errorDiv = document.getElementById('farmErrorMessage');
    if (errorDiv) {
        errorDiv.classList.remove('show');
    }
    
    const farmId = document.getElementById('farmId').value;
    const formData = new FormData();
    
    formData.append('action', farmId ? 'update_farm' : 'add_farm');
    if (farmId) formData.append('farm_id', farmId);
    formData.append('name', document.getElementById('farmName').value);
    formData.append('description', document.getElementById('farmDescription').value);
    formData.append('pricing_child', document.getElementById('pricingChild').value);
    formData.append('pricing_teen', document.getElementById('pricingTeen').value);
    formData.append('pricing_adult', document.getElementById('pricingAdult').value);
    formData.append('pricing_pregnant', document.getElementById('pricingPregnant').value);
    formData.append('pricing_senior', document.getElementById('pricingSenior').value);
    formData.append('pricing_disabled', document.getElementById('pricingDisabled').value);
    formData.append('capacity', document.getElementById('farmCapacity').value);
    
    try {
        const response = await fetch('./backend/admin_farm.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Farm saved successfully!');
            document.getElementById('farmModal').style.display = 'none';
            loadFarms();
        } else {
            if (errorDiv) {
                errorDiv.textContent = data.message || 'Failed to save farm';
                errorDiv.classList.add('show');
            } else {
                alert(data.message || 'Failed to save farm');
            }
        }
    } catch (error) {
        console.error('Farm save error:', error);
        if (errorDiv) {
            errorDiv.textContent = 'An error occurred. Please try again.';
            errorDiv.classList.add('show');
        } else {
            alert('An error occurred. Please try again.');
        }
    }
}

async function deleteFarm(farmId) {
    if (!confirm('Are you sure you want to delete this farm?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'delete_farm');
    formData.append('farm_id', farmId);
    
    try {
        const response = await fetch('./backend/admin_farm.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Farm deleted successfully!');
            loadFarms();
        } else {
            alert(data.message || 'Failed to delete farm');
        }
    } catch (error) {
        console.error('Delete farm error:', error);
        alert('An error occurred. Please try again.');
    }
}

// ============================================
// BOOKING MANAGEMENT
// ============================================
async function loadBookings() {
    const container = document.getElementById('bookingsTableContainer');
    
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading bookings...</p></div>';
    
    try {
        const response = await fetch('./backend/admin_booking.php?action=get_all_bookings');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.bookings) {
            bookings = data.bookings;
            displayBookings();
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Bookings Found</h3><p>No bookings have been made yet.</p></div>';
        }
    } catch (error) {
        console.error('Error loading bookings:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Bookings</h3><p>Please check your database connection and try again.</p></div>';
    }
}

function displayBookings() {
    const container = document.getElementById('bookingsTableContainer');
    
    if (!bookings || bookings.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Bookings Found</h3><p>No bookings have been made yet.</p></div>';
        return;
    }
    
    // Filter out pending_cancellation bookings (they should be in cancellations section)
    // Always show newest IDs first to match admin expectation
    const activeBookings = bookings
        .filter(b => b.status !== 'pending_cancellation')
        .sort((a, b) => Number(b.id || 0) - Number(a.id || 0));
    
    if (activeBookings.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Active Bookings</h3><p>No active bookings found.</p></div>';
        return;
    }
    
    let html = `
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Farm</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Companions</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Staff Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    activeBookings.forEach(booking => {
        // Get staff name from the booking data
        const staffName = booking.staff_name ? escapeHtml(booking.staff_name) : 'Unassigned';
        const companionsCount = booking.companions_count || 0;
        const isPending = (booking.status || 'pending').toLowerCase() === 'pending';
        
        html += `
            <tr>
                <td>${booking.id}</td>
                <td><strong>${escapeHtml(booking.farm_name || 'N/A')}</strong></td>
                <td>${escapeHtml(booking.full_name || 'N/A')}</td>
                <td>${booking.booking_date || 'N/A'}</td>
                <td>${renderAdminCompanionsCell(companionsCount, booking.id)}</td>
                <td><strong>₱${parseFloat(booking.total_price || 0).toFixed(2)}</strong></td>
                <td><span class="status-badge ${booking.status || 'pending'}">${formatBookingStatus(booking.status)}</span></td>
                <td><span class="status-badge ${booking.payment_status === 'paid' ? 'paid' : 'pending-payment'}">${(booking.payment_status || 'pending').toUpperCase()}</span></td>
                <td><strong>${staffName}</strong></td>
                <td>
                    <div class="action-buttons stacked">
                        ${isPending ? `
                        <div>
                            <button class="btn btn-success btn-sm" onclick="updateBookingStatus(${booking.id}, 'accepted')" title="Approve">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="updateBookingStatus(${booking.id}, 'cancelled')" title="Decline">
                                <i class="fas fa-times"></i> Decline
                            </button>
                        </div>
                        ` : ''}
                        <div>
                            <button class="btn btn-secondary btn-sm" onclick="openBookingDetailsFromList(${booking.id})" title="View Details">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = html;
}

function renderAdminCompanionsCell(count = 0, bookingId) {
    const total = parseInt(count, 10) || 0;
    if (total <= 0) {
        return '0';
    }
    return `
        <button class="btn btn-link companion-link" onclick="openAdminCompanionDetails(${bookingId})" title="View companions">
            ${total}
        </button>
    `;
}

function openAdminCompanionDetails(bookingId) {
    const booking = bookings.find(b => Number(b.id) === Number(bookingId));
    const container = document.getElementById('adminCompanionInfoContainer');
    let companions = [];

    if (booking && booking.companions_details) {
        try {
            companions = JSON.parse(booking.companions_details) || [];
        } catch (error) {
            console.error('Error parsing companions:', error);
        }
    }

    if (!companions || companions.length === 0) {
        container.innerHTML = '<p>No companion details provided for this booking.</p>';
    } else {
        const rows = companions.map((comp, index) => `
            <tr>
                <td>${index + 1}</td>
                <td>${escapeHtml(comp.name || 'N/A')}</td>
                <td>${comp.age || 'N/A'}</td>
                <td>${escapeHtml(comp.sex || 'N/A')}</td>
                <td>${formatTypeDisplay(comp.type || 'normal')}</td>
            </tr>
        `).join('');

        container.innerHTML = `
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows}
                    </tbody>
                </table>
            </div>
        `;
    }

    document.getElementById('adminCompanionInfoModal').style.display = 'block';
}

function closeAdminCompanionModal() {
    const modal = document.getElementById('adminCompanionInfoModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function formatBookingStatus(status) {
    const normalized = (status || 'pending').toLowerCase();
    if (normalized === 'accepted') return 'APPROVED';
    if (normalized === 'cancelled') return 'DECLINED';
    if (normalized === 'pending_cancellation') return 'PENDING CANCELLATION';
    return normalized.toUpperCase();
}

// ============================================
// BOOKING DETAILS (ADMIN)
// ============================================
async function loadAllBookingDetails() {
    const container = document.getElementById('bookingDetailsContainer');
    if (!container) return;

    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading all booking details...</p></div>';
    const searchInput = document.getElementById('bookingDetailsSearch');
    if (searchInput) {
        searchInput.value = '';
    }

    try {
        const response = await fetch('./backend/admin_booking.php?action=get_all_bookings');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.bookings) {
            displayAllBookingDetails(data.bookings);
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Bookings Found</h3><p>No bookings have been made yet.</p></div>';
        }
    } catch (error) {
        console.error('Error loading all booking details:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Booking Details</h3><p>Please check your database connection and try again.</p></div>';
    }
}

function displayAllBookingDetails(allBookings) {
    const container = document.getElementById('bookingDetailsContainer');
    if (!container) return;

    if (!allBookings || allBookings.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Bookings Found</h3><p>No bookings have been made yet.</p></div>';
        return;
    }

    // Sort newest first then filter to show only approved (accepted) and paid bookings
    // Newest IDs first for consistency
    const sortedBookings = [...allBookings].sort((a, b) => Number(b.id || 0) - Number(a.id || 0));

    const filteredBookings = sortedBookings.filter(booking => {
        const status = (booking.status || '').toLowerCase();
        const paymentStatus = (booking.payment_status || '').toLowerCase();
        return status === 'accepted' && paymentStatus === 'paid';
    });

    bookingDetailsList = filteredBookings;

    if (filteredBookings.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Approved and Paid Bookings</h3><p>No bookings with approved status and paid payment found.</p></div>';
        return;
    }

    renderBookingDetailsTable(filteredBookings);
}

function renderBookingDetailsTable(bookingsToRender, emptyMessage = null) {
    const container = document.getElementById('bookingDetailsContainer');
    if (!container) return;

    if (!bookingsToRender || bookingsToRender.length === 0) {
        container.innerHTML = emptyMessage || '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Approved and Paid Bookings</h3><p>No bookings with approved status and paid payment found.</p></div>';
        return;
    }

    let html = `
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Farm</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Companions</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Staff Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    bookingsToRender.forEach(booking => {
        const staffName = booking.staff_name ? escapeHtml(booking.staff_name) : 'Unassigned';
        const companionsCount = booking.companions_count || 0;
        
        html += `
            <tr>
                <td>${booking.id}</td>
                <td><strong>${escapeHtml(booking.farm_name || 'N/A')}</strong></td>
                <td>${escapeHtml(booking.full_name || 'N/A')}</td>
                <td>${booking.booking_date || 'N/A'}</td>
                <td>${renderAdminCompanionsCell(companionsCount, booking.id)}</td>
                <td><strong>₱${parseFloat(booking.total_price || 0).toFixed(2)}</strong></td>
                <td><span class="status-badge ${booking.status || 'pending'}">${formatBookingStatus(booking.status)}</span></td>
                <td><span class="status-badge ${booking.payment_status === 'paid' ? 'paid' : 'pending-payment'}">${(booking.payment_status || 'pending').toUpperCase()}</span></td>
                <td><strong>${staffName}</strong></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-secondary btn-sm" onclick="openBookingDetailsFromList(${booking.id})" title="View Details">
                            <i class="fas fa-eye"></i> View
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = html;
}

function searchBookingDetails() {
    const searchInput = document.getElementById('bookingDetailsSearch');
    if (!searchInput) return;

    const term = searchInput.value.trim().toLowerCase();
    if (!term) {
        renderBookingDetailsTable(bookingDetailsList);
        return;
    }

    const filtered = bookingDetailsList.filter(booking => {
        const name = (booking.full_name || '').toLowerCase();
        return name.includes(term);
    });

    renderBookingDetailsTable(filtered, '<div class="empty-state"><i class="fas fa-search"></i><h3>No Matching Bookings</h3><p>Try another customer name.</p></div>');
}

async function showBookingDetails(bookingId) {
    const container = document.getElementById('bookingDetailsContainer');
    if (!container) return;

    // Remember last booking so Booking Details tab works after refresh
    if (bookingId) {
        sessionStorage.setItem('admin_last_booking_id', String(bookingId));
    }

    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading booking details...</p></div>';

    try {
        const response = await fetch(`./backend/admin_booking.php?action=get_booking&booking_id=${encodeURIComponent(bookingId)}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        if (!data.success || !data.booking) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Unable to load booking</h3><p>Please try again.</p></div>';
            return;
        }

        const booking = data.booking;

        // Ensure staff list is loaded for assignment
        if (!staff || staff.length === 0) {
            await loadStaff();
        }

        const companionsCount = booking.companions_count || 0;
        let companionsRows = '';
        if (booking.companions_details) {
            try {
                const companions = JSON.parse(booking.companions_details) || [];
                companionsRows = companions.map((comp, index) => `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${escapeHtml(comp.name || 'N/A')}</td>
                        <td>${comp.age || 'N/A'}</td>
                        <td>${escapeHtml(comp.sex || 'N/A')}</td>
                        <td>${formatTypeDisplay(comp.type || 'normal')}</td>
                    </tr>
                `).join('');
            } catch (e) {
                console.error('Error parsing companions in details:', e);
            }
        }

        const staffOptions = (staff || []).map(s => {
            const isAssignedElsewhere = s.assigned_booking_id && Number(s.assigned_booking_id) !== Number(booking.id);
            const isCurrent = booking.staff_id && Number(booking.staff_id) === Number(s.id);
            const isOngoing = (s.status || 'waiting_for_assign') === 'ongoing' && !isCurrent;
            const disabled = isAssignedElsewhere || isOngoing;
            let reason = '';
            if (isAssignedElsewhere) reason = ' (Assigned to another booking)';
            else if (isOngoing) reason = ' (Ongoing - cannot assign)';
            return `
                <option value="${s.id}" ${isCurrent ? 'selected' : ''} ${disabled ? 'disabled' : ''}>
                    ${escapeHtml(s.name || '')}${reason}
                </option>
            `;
        }).join('');

        container.innerHTML = `
            <div class="booking-details-card">
                <div class="booking-details-grid">
                    <div class="details-section">
                        <h4><i class="fas fa-file-invoice"></i> Booking & Customer</h4>
                        <p><strong>Reservation #:</strong> ${booking.id}</p>
                        <p><strong>Farm:</strong> ${escapeHtml(booking.farm_name || 'N/A')}</p>
                        <p><strong>Customer:</strong> ${escapeHtml(booking.full_name || 'N/A')}</p>
                        <p><strong>Date:</strong> ${booking.booking_date || 'N/A'}</p>
                        <p><strong>Status:</strong> <span class="status-badge ${booking.status || 'pending'}">${formatBookingStatus(booking.status)}</span></p>
                        <p><strong>Payment:</strong> <span class="status-badge ${booking.payment_status === 'paid' ? 'paid' : 'pending-payment'}">${(booking.payment_status || 'pending').toUpperCase()}</span></p>
                        <p><strong>Total Price:</strong> ₱${parseFloat(booking.total_price || 0).toFixed(2)}</p>
                        <hr>
                        <p><strong>Age:</strong> ${booking.age || 'N/A'}</p>
                        <p><strong>Gender:</strong> ${escapeHtml(booking.gender || 'N/A')}</p>
                        <p><strong>Nationality:</strong> ${escapeHtml(booking.nationality || 'N/A')}</p>
                        <p><strong>Marital Status:</strong> ${escapeHtml(booking.marital_status || 'N/A')}</p>
                    </div>

                    <div class="details-section">
                        <h4><i class="fas fa-users"></i> Companions (${companionsCount})</h4>
                        ${companionsRows
                            ? `
                            <div class="table-container">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Age</th>
                                            <th>Gender</th>
                                            <th>Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${companionsRows}
                                    </tbody>
                                </table>
                            </div>`
                            : '<p>No companion details provided.</p>'
                        }
                    </div>

                    <div class="details-section">
                        <h4><i class="fas fa-user-tie"></i> Staff & Actions</h4>
                        ${(staff && staff.length)
                            ? (() => {
                                const hasStaff = booking.staff_id && Number(booking.staff_id) > 0;
                                const canAssign = (booking.payment_status === 'paid' && booking.status !== 'cancelled' && !hasStaff);

                                let helperText = '';
                                if (!canAssign) {
                                    if (hasStaff) {
                                        helperText = '<p style="margin-top:6px;font-size:0.85em;color:#888;">Staff is already assigned for this booking.</p>';
                                    } else if (booking.status === 'cancelled') {
                                        helperText = '<p style="margin-top:6px;font-size:0.85em;color:#888;">Cannot assign staff to a cancelled booking.</p>';
                                    } else if (booking.payment_status !== 'paid') {
                                        helperText = '<p style="margin-top:6px;font-size:0.85em;color:#888;">Payment must be <strong>PAID</strong> before assigning staff.</p>';
                                    }
                                }

                                return `
                                    ${booking.staff_name ? `<p><strong>Assigned Staff:</strong> ${escapeHtml(booking.staff_name)}</p>` : ''}
                                    <label for="bookingDetailsStaffSelect"><strong>Select Staff</strong></label>
                                    <select id="bookingDetailsStaffSelect" ${canAssign ? '' : 'disabled'}>
                                        <option value="">-- Choose staff --</option>
                                        ${staffOptions}
                                    </select>
                                    ${helperText}
                                    <div class="action-buttons" style="margin-top: 1rem;">
                                        <button class="btn btn-primary btn-sm" onclick="assignStaffFromDetails(${booking.id})" ${canAssign ? '' : 'disabled'}>
                                            <i class="fas fa-user-check"></i> Assign Staff
                                        </button>
                                    </div>
                                `;
                              })()
                            : '<p>No staff available. Please add staff first in Staff Management.</p>'
                        }

                        <div class="action-buttons" style="margin-top: 1.5rem;">
                            ${booking.status !== 'cancelled' ? `
                            <button class="btn btn-danger btn-sm" onclick="updateBookingStatus(${booking.id}, 'cancelled')">
                                <i class="fas fa-times"></i> Cancel Booking
                            </button>
                            ` : ''}
                            ${(booking.payment_status !== 'paid' && booking.status !== 'cancelled') ? `
                            <button class="btn btn-primary btn-sm" onclick="markPaymentPaidFromDetails(${booking.id})">
                                <i class="fas fa-coins"></i> Mark as Paid
                            </button>
                            ` : ''}
                        </div>
                    </div>
                </div>
            </div>
        `;
    } catch (error) {
        console.error('Error loading booking details:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Booking Details</h3><p>Please try again.</p></div>';
    }
}

async function assignStaffFromDetails(bookingId) {
    const select = document.getElementById('bookingDetailsStaffSelect');
    if (!select) return;

    const staffId = select.value;
    if (!staffId) {
        alert('Please select a staff member first.');
        return;
    }

    const formData = new FormData();
    formData.append('action', 'assign_staff');
    formData.append('staff_id', staffId);
    formData.append('booking_id', bookingId);

    try {
        const response = await fetch('./backend/admin_staff.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
            alert('Staff assigned successfully!');
            await loadBookings();
            await loadStaff();
            showBookingDetails(bookingId);
        } else {
            alert(data.message || 'Failed to assign staff');
        }
    } catch (error) {
        console.error('Assign staff from details error:', error);
        alert('An error occurred. Please try again.');
    }
}

async function markPaymentPaidFromDetails(bookingId) {
    await updatePaymentStatus(bookingId, 'paid');
    showBookingDetails(bookingId);
}

function openBookingDetailsFromList(bookingId) {
    // Store and show details
    showBookingDetails(bookingId);

    // Switch nav to Booking Details section directly without triggering reload
    const navLinks = document.querySelectorAll('.nav-item');
    const pageTitle = document.getElementById('pageTitle');
    const section = 'bookingDetails';
    
    // Update active nav item
    navLinks.forEach(l => l.classList.remove('active'));
    const bookingDetailsLink = document.querySelector('.nav-item[data-section="bookingDetails"]');
    if (bookingDetailsLink) {
        bookingDetailsLink.classList.add('active');
    }
    
    // Update active section
    document.querySelectorAll('.dashboard-section').forEach(s => s.classList.remove('active'));
    const targetSection = document.getElementById(section + 'Section');
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // Update page title
    if (pageTitle) {
        pageTitle.textContent = 'Booking Details';
    }
    
    // Close sidebar on mobile after navigation
    if (window.innerWidth <= 1024) {
        document.getElementById('sidebar').classList.remove('active');
        document.getElementById('sidebarOverlay').classList.remove('active');
    }
}

async function searchBookings() {
    const searchTerm = document.getElementById('bookingSearch').value.trim();
    
    if (!searchTerm) {
        loadBookings();
        return;
    }
    
    const container = document.getElementById('bookingsTableContainer');
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Searching...</p></div>';
    
    try {
        const response = await fetch(`./backend/admin_booking.php?action=search_bookings&search=${encodeURIComponent(searchTerm)}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.bookings) {
            bookings = data.bookings;
            displayBookings();
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><h3>No Results Found</h3><p>Try a different search term.</p></div>';
        }
    } catch (error) {
        console.error('Error searching bookings:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Search Error</h3><p>Please try again.</p></div>';
    }
}

async function updateBookingStatus(bookingId, status) {
    const formData = new FormData();
    formData.append('action', 'update_status');
    formData.append('booking_id', bookingId);
    formData.append('status', status);
    
    try {
        const response = await fetch('./backend/admin_booking.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Booking status updated successfully!');
            await loadBookings();

            // If booking is accepted, automatically open its details
            if (status === 'accepted') {
                openBookingDetailsFromList(bookingId);
            }
        } else {
            alert(data.message || 'Failed to update booking status');
        }
    } catch (error) {
        console.error('Update booking status error:', error);
        alert('An error occurred. Please try again.');
    }
}

async function updatePaymentStatus(bookingId, paymentStatus) {
    const formData = new FormData();
    formData.append('action', 'update_payment');
    formData.append('booking_id', bookingId);
    formData.append('payment_status', paymentStatus);
    
    try {
        const response = await fetch('./backend/admin_booking.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Payment status updated successfully!');
            loadBookings();
        } else {
            alert(data.message || 'Failed to update payment status');
        }
    } catch (error) {
        console.error('Update payment status error:', error);
        alert('An error occurred. Please try again.');
    }
}

async function loadCancellations() {
    const container = document.getElementById('cancellationsTableContainer');
    
    if (!container) return;
    
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading cancellation requests...</p></div>';
    
    try {
        const response = await fetch('./backend/admin_booking.php?action=get_cancellation_requests');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.bookings) {
            displayCancellations(data.bookings);
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-ban"></i><h3>No Cancellation Requests</h3><p>No pending cancellation requests.</p></div>';
        }
    } catch (error) {
        console.error('Error loading cancellations:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Cancellations</h3><p>Please check your database connection and try again.</p></div>';
    }
}

function displayCancellations(cancellations) {
    const container = document.getElementById('cancellationsTableContainer');
    
    if (!cancellations || cancellations.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-ban"></i><h3>No Cancellation Requests</h3><p>No cancellation requests found.</p></div>';
        return;
    }
    
    const sortedCancellations = [...cancellations].sort((a, b) => Number(b.id || 0) - Number(a.id || 0));

    let html = `
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Farm</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Companions</th>
                        <th>Price</th>
                        <th>Cancellation Reason</th>
                        <th>Status</th>
                        <th>Decision Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    sortedCancellations.forEach(booking => {
        const companionsCount = booking.companions_count || 0;
        const cancellationStatus = booking.cancellation_status || 'pending';
        const decisionDate = booking.admin_decision_at ? new Date(booking.admin_decision_at).toLocaleString() : 'N/A';
        
        // Determine status badge class
        let statusBadgeClass = 'pending';
        let statusText = 'PENDING';
        if (cancellationStatus === 'approved') {
            statusBadgeClass = 'accepted';
            statusText = 'APPROVED';
        } else if (cancellationStatus === 'denied') {
            statusBadgeClass = 'cancelled';
            statusText = 'DENIED';
        }
        
        html += `
            <tr>
                <td><strong>${booking.id}</strong></td>
                <td>${escapeHtml(booking.farm_name || 'N/A')}</td>
                <td>${escapeHtml(booking.full_name || 'N/A')}</td>
                <td>${booking.booking_date || 'N/A'}</td>
                <td><strong>${companionsCount}</strong></td>
                <td><strong>₱${parseFloat(booking.total_price || 0).toFixed(2)}</strong></td>
                <td>${escapeHtml(booking.cancellation_reason || 'N/A')}</td>
                <td><span class="status-badge ${statusBadgeClass}">${statusText}</span></td>
                <td>${decisionDate}</td>
                <td>
                    ${cancellationStatus === 'pending' ? `
                    <div class="action-buttons">
                        <button class="btn btn-success btn-sm" onclick="approveCancellation(${booking.id})" title="Approve">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="denyCancellation(${booking.id})" title="Deny">
                            <i class="fas fa-times"></i> Deny
                        </button>
                    </div>
                    ` : '<span style="color: #888; font-size: 0.9em;">No actions available</span>'}
                </td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = html;
}

async function approveCancellation(bookingId) {
    if (!confirm('Are you sure you want to approve this cancellation request?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'approve_cancellation');
    formData.append('booking_id', bookingId);
    
    try {
        const response = await fetch('./backend/admin_booking.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cancellation approved successfully!');
            loadCancellations();
            loadBookings();
        } else {
            alert(data.message || 'Failed to approve cancellation');
        }
    } catch (error) {
        console.error('Approve cancellation error:', error);
        alert('An error occurred. Please try again.');
    }
}

async function denyCancellation(bookingId) {
    if (!confirm('Are you sure you want to deny this cancellation request?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'deny_cancellation');
    formData.append('booking_id', bookingId);
    
    try {
        const response = await fetch('./backend/admin_booking.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cancellation request denied.');
            loadCancellations();
            loadBookings();
        } else {
            alert(data.message || 'Failed to deny cancellation');
        }
    } catch (error) {
        console.error('Deny cancellation error:', error);
        alert('An error occurred. Please try again.');
    }
}

async function assignStaff(bookingId) {
    await loadStaff();
    
    if (!staff || staff.length === 0) {
        alert('No staff members available. Please add staff first.');
        return;
    }
    
    const staffOptions = staff.map(s => `${s.id}. ${s.name}${s.assigned_booking_id ? ' (Assigned)' : ' (Available)'}`).join('\n');
    
    const staffId = prompt(`Select staff ID:\n\n${staffOptions}\n\nEnter staff ID:`);
    if (!staffId) return;
    
    const formData = new FormData();
    formData.append('action', 'assign_staff');
    formData.append('staff_id', staffId);
    formData.append('booking_id', bookingId);
    
    try {
        const response = await fetch('./backend/admin_staff.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Staff assigned successfully!');
            loadBookings();
            loadStaff();
        } else {
            alert(data.message || 'Failed to assign staff');
        }
    } catch (error) {
        console.error('Assign staff error:', error);
        alert('An error occurred. Please try again.');
    }
}

// ============================================
// STAFF MANAGEMENT
// ============================================
async function loadStaff() {
    const container = document.getElementById('staffTableContainer');
    
    if (container) {
        container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading staff...</p></div>';
    }
    
    try {
        const response = await fetch('./backend/admin_staff.php?action=get_all_staff');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.staff) {
            staff = data.staff;
            displayStaff();
        } else {
            if (container) {
                container.innerHTML = '<div class="empty-state"><i class="fas fa-users"></i><h3>No Staff Found</h3><p>Add your first staff member to get started.</p></div>';
            }
        }
    } catch (error) {
        console.error('Error loading staff:', error);
        if (container) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Staff</h3><p>Please check your database connection and try again.</p></div>';
        }
    }
}

function displayStaff() {
    const container = document.getElementById('staffTableContainer');
    
    if (!container) return;
    
    if (!staff || staff.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-users"></i><h3>No Staff Found</h3><p>Add your first staff member to get started.</p></div>';
        return;
    }
    
    let html = `
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Assigned Booking</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    staff.forEach(s => {
        const status = s.status || 'waiting_for_assign';
        const statusBadge = status === 'ongoing' 
            ? '<span class="status-badge ongoing">Ongoing</span>' 
            : '<span class="status-badge accepted">Waiting for Assign</span>';
        const bookingDisplay = s.booking_name 
            ? `<span>#${s.booking_id} - ${escapeHtml(s.booking_name)}</span>` 
            : '<span class="status-badge accepted">Available</span>';
        
        html += `
            <tr>
                <td><strong>${escapeHtml(s.name || 'N/A')}</strong></td>
                <td>${escapeHtml(s.email || 'N/A')}</td>
                <td>${escapeHtml(s.phone || 'N/A')}</td>
                <td>${statusBadge}</td>
                <td>${bookingDisplay}</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-secondary btn-sm" onclick="editStaff(${s.id})" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="deleteStaff(${s.id})" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = html;
}

function openStaffModal(staffId = null) {
    const modal = document.getElementById('staffModal');
    const title = document.getElementById('staffModalTitle');
    const form = document.getElementById('staffForm');
    const usernameGroup = document.getElementById('staffUsernameGroup');
    const passwordGroup = document.getElementById('staffPasswordGroup');
    const usernameInput = document.getElementById('staffUsername');
    const passwordInput = document.getElementById('staffPassword');
    
    if (staffId) {
        currentStaff = staff.find(s => s.id == staffId);
        if (currentStaff) {
            title.innerHTML = '<i class="fas fa-user-edit"></i> Edit Staff';
            document.getElementById('staffId').value = staffId;
            document.getElementById('staffName').value = currentStaff.name || '';
            document.getElementById('staffEmail').value = currentStaff.email || '';
            document.getElementById('staffPhone').value = currentStaff.phone || '';
            usernameInput.value = currentStaff.username || '';
            passwordInput.value = ''; // Don't show password
            // Make username and password optional when editing
            usernameInput.removeAttribute('required');
            passwordInput.removeAttribute('required');
            usernameGroup.querySelector('label').innerHTML = '<i class="fas fa-user-circle"></i> Username <small>(leave blank to keep current)</small>';
            passwordGroup.querySelector('label').innerHTML = '<i class="fas fa-lock"></i> Password <small>(leave blank to keep current)</small>';
        }
    } else {
        title.innerHTML = '<i class="fas fa-user-plus"></i> Add Staff';
        form.reset();
        document.getElementById('staffId').value = '';
        currentStaff = null;
        // Make username and password required when adding
        usernameInput.setAttribute('required', 'required');
        passwordInput.setAttribute('required', 'required');
        usernameGroup.querySelector('label').innerHTML = '<i class="fas fa-user-circle"></i> Username *';
        passwordGroup.querySelector('label').innerHTML = '<i class="fas fa-lock"></i> Password *';
    }
    
    const errorDiv = document.getElementById('staffErrorMessage');
    if (errorDiv) {
        errorDiv.textContent = '';
        errorDiv.classList.remove('show');
    }
    modal.style.display = 'block';
}

function closeStaffModal() {
    document.getElementById('staffModal').style.display = 'none';
}

function editStaff(staffId) {
    openStaffModal(staffId);
}

async function handleStaffSubmit(e) {
    e.preventDefault();
    
    const errorDiv = document.getElementById('staffErrorMessage');
    if (errorDiv) {
        errorDiv.classList.remove('show');
    }
    
    const staffId = document.getElementById('staffId').value;
    const formData = new FormData();
    const password = document.getElementById('staffPassword').value;
    const username = document.getElementById('staffUsername').value;
    
    // Validate password if provided (minimum 6 characters)
    if (!staffId && (!password || password.length < 6)) {
        if (errorDiv) {
            errorDiv.textContent = 'Password must be at least 6 characters long.';
            errorDiv.classList.add('show');
        }
        return;
    }
    
    if (!staffId && (!username || username.length < 3)) {
        if (errorDiv) {
            errorDiv.textContent = 'Username must be at least 3 characters long.';
            errorDiv.classList.add('show');
        }
        return;
    }
    
    formData.append('action', staffId ? 'update_staff' : 'add_staff');
    if (staffId) formData.append('staff_id', staffId);
    formData.append('name', document.getElementById('staffName').value);
    formData.append('email', document.getElementById('staffEmail').value);
    formData.append('phone', document.getElementById('staffPhone').value);
    if (username) formData.append('username', username);
    if (password) formData.append('password', password);
    
    try {
        const response = await fetch('./backend/admin_staff.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Staff saved successfully!');
            document.getElementById('staffModal').style.display = 'none';
            loadStaff();
        } else {
            if (errorDiv) {
                errorDiv.textContent = data.message || 'Failed to save staff';
                errorDiv.classList.add('show');
            } else {
                alert(data.message || 'Failed to save staff');
            }
        }
    } catch (error) {
        console.error('Staff save error:', error);
        if (errorDiv) {
            errorDiv.textContent = 'An error occurred. Please try again.';
            errorDiv.classList.add('show');
        } else {
            alert('An error occurred. Please try again.');
        }
    }
}

async function deleteStaff(staffId) {
    if (!confirm('Are you sure you want to delete this staff member?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'delete_staff');
    formData.append('staff_id', staffId);
    
    try {
        const response = await fetch('./backend/admin_staff.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('Staff deleted successfully!');
            loadStaff();
        } else {
            alert(data.message || 'Failed to delete staff');
        }
    } catch (error) {
        console.error('Delete staff error:', error);
        alert('An error occurred. Please try again.');
    }
}

// ============================================
// ANALYTICS
// ============================================
async function loadAnalytics() {
    const container = document.getElementById('analyticsContainer');
    if (!container) return;
    
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading analytics...</p></div>';
    
    try {
        const reportType = document.getElementById('reportType').value;
        let url = `./backend/analytics.php?action=${reportType}`;
        
        if (reportType === 'weekly') {
            const weekInput = document.getElementById('weekSelector').value;
            if (weekInput) {
                const [year, week] = weekInput.split('-W');
                url += `&week=${week}&year=${year}`;
            }
        } else if (reportType === 'monthly') {
            const monthInput = document.getElementById('monthSelector').value;
            if (monthInput) {
                const [year, month] = monthInput.split('-');
                url += `&month=${month}&year=${year}`;
            }
        }
        
        const response = await fetch('./' + url.replace('./', ''));
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            displayAnalytics(data.data, reportType);
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Analytics</h3><p>Please try again later.</p></div>';
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Analytics</h3><p>Please check your database connection and try again.</p></div>';
    }
}

// Store chart instances to destroy them when updating
let chartInstances = [];

function destroyAllCharts() {
    chartInstances.forEach(chart => {
        if (chart) chart.destroy();
    });
    chartInstances = [];
}

function displayAnalytics(analytics, type) {
    const container = document.getElementById('analyticsContainer');
    if (!container) return;
    
    // Destroy existing charts
    destroyAllCharts();
    
    let html = '';
    const summary = type === 'summary' ? analytics : (analytics.summary || {});
    
    // Summary cards
    html += `
        <div class="analytics-summary">
            <div class="summary-card">
                <h3><i class="fas fa-money-bill-wave"></i> Total Revenue</h3>
                <div class="value">₱${parseFloat(summary.total_revenue || analytics.total_revenue || 0).toFixed(2)}</div>
            </div>
            <div class="summary-card">
                <h3><i class="fas fa-calendar-check"></i> Total Reservations</h3>
                <div class="value">${summary.total_bookings || analytics.total_bookings || 0}</div>
            </div>
            <div class="summary-card">
                <h3><i class="fas fa-ban"></i> Cancellations</h3>
                <div class="value">${summary.total_cancellations || analytics.total_cancellations || 0}</div>
            </div>
            <div class="summary-card">
                <h3><i class="fas fa-users"></i> Total Users</h3>
                <div class="value">${summary.total_users || analytics.total_users || 0}</div>
            </div>
            <div class="summary-card">
                <h3><i class="fas fa-calendar-alt"></i> Upcoming Tours</h3>
                <div class="value">${summary.upcoming_tours || analytics.upcoming_tours || 0}</div>
            </div>
        </div>
    `;
    
    // Bookings by Type and Marital Status Charts (Side by Side)
    const bookingTypes = (analytics.booking_types || []).filter(b => Number(b.count) > 0);
    const maritalStatus = analytics.marital_status || [];
    if (bookingTypes.length > 0 || maritalStatus.length > 0) {
        html += `
            <div class="analytics-chart-container" style="display: flex; gap: 20px; flex-wrap: wrap;">
                ${bookingTypes.length > 0 ? `
                <div class="analytics-chart" style="flex: 1; min-width: 300px;">
                    <h3><i class="fas fa-tags"></i> Reservations by Type</h3>
                    <canvas id="bookingTypesChart"></canvas>
                </div>
                ` : ''}
                ${maritalStatus.length > 0 ? `
                <div class="analytics-chart" style="flex: 1; min-width: 300px;">
                    <h3><i class="fas fa-heart"></i> Reservations by Marital Status</h3>
                    <canvas id="maritalStatusChart"></canvas>
                </div>
                ` : ''}
            </div>
        `;
    }
    
    // Bookings by Nationality Chart
    const nationalities = analytics.nationalities || [];
    if (nationalities.length > 0) {
        html += `
            <div class="analytics-chart-container">
                <div class="analytics-chart">
                    <h3><i class="fas fa-globe"></i> Reservations by Nationality</h3>
                    <canvas id="nationalityChart"></canvas>
                </div>
            </div>
        `;
    }
    
    // Age Group Breakdown Chart
    const ageGroups = analytics.age_groups || [];
    if (ageGroups.length > 0) {
        html += `
            <div class="analytics-chart-container">
                <div class="analytics-chart">
                    <h3><i class="fas fa-users"></i> Age Group Breakdown</h3>
                    <canvas id="ageGroupChart"></canvas>
                </div>
            </div>
        `;
    }
    
    // Farm Income Chart
    const farmIncome = analytics.farm_popularity || analytics.farm_income || [];
    if (farmIncome.length > 0) {
        const totalFarmRevenue = farmIncome.reduce((sum, f) => sum + parseFloat(f.revenue || 0), 0);
        html += `
            <div class="analytics-chart-container">
                <div class="analytics-chart">
                    <h3><i class="fas fa-seedling"></i> Farm Income & Reservations</h3>
                    <p style="margin-bottom: 15px; color: #666;"><strong>Total Farm Revenue: ₱${totalFarmRevenue.toFixed(2)}</strong></p>
                    <canvas id="farmIncomeChart"></canvas>
                </div>
            </div>
        `;
    }
    
    // Staff Statistics
    const staffStats = analytics.staff_stats || [];
    if (staffStats.length > 0) {
        html += `
            <div class="analytics-chart-container">
                <div class="analytics-chart">
                    <h3><i class="fas fa-user-tie"></i> Staff Performance Statistics</h3>
                    <div class="table-container" style="margin-top: 20px;">
                        <table>
                            <thead>
                                <tr>
                                    <th>Staff Name</th>
                                    ${type === 'summary' ? `
                                    <th>Total Tours</th>
                                    <th>Weekly Tours</th>
                                    <th>Monthly Tours</th>
                                    <th>Annual Tours</th>
                                    ` : `
                                    <th>Tours Completed</th>
                                    `}
                                </tr>
                            </thead>
                            <tbody>
                                ${staffStats.map(s => `
                                    <tr>
                                        <td>${escapeHtml(s.name || 'Unknown')}</td>
                                        ${type === 'summary' ? `
                                        <td>${s.total_tours || 0}</td>
                                        <td>${s.weekly_tours || 0}</td>
                                        <td>${s.monthly_tours || 0}</td>
                                        <td>${s.annual_tours || 0}</td>
                                        ` : `
                                        <td>${s.tours_completed || 0}</td>
                                        `}
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }
    
    container.innerHTML = html;
    
    // Create charts after HTML is rendered
    setTimeout(() => {
        createCharts(analytics, type);
    }, 100);
}

function createCharts(analytics, type) {
    const colors = {
        primary: '#2d8659',
        secondary: '#4a9d73',
        accent: '#6bb88a',
        warning: '#ffc107',
        danger: '#dc3545',
        info: '#17a2b8',
        success: '#28a745'
    };
    
    const chartColors = [
        colors.primary,
        colors.secondary,
        colors.accent,
        colors.warning,
        colors.info,
        colors.success,
        '#ff6b6b',
        '#4ecdc4',
        '#45b7d1',
        '#f9ca24'
    ];
    
    // Bookings by Type Pie Chart
    const bookingTypes = (analytics.booking_types || []).filter(b => Number(b.count) > 0);
    if (bookingTypes.length > 0) {
        const ctx = document.getElementById('bookingTypesChart');
        if (ctx) {
            const chart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: bookingTypes.map(b => b.booking_type || 'Unknown'),
                    datasets: [{
                        data: bookingTypes.map(b => b.count || 0),
                        backgroundColor: chartColors.slice(0, bookingTypes.length),
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `${context.label}: ${context.parsed}`;
                                }
                            }
                        }
                    }
                }
            });
            chartInstances.push(chart);
        }
    }
    
    // Marital Status Pie Chart
    const maritalStatus = analytics.marital_status || [];
    if (maritalStatus.length > 0) {
        const ctx = document.getElementById('maritalStatusChart');
        if (ctx) {
            const chart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: maritalStatus.map(m => m.marital_status || 'Unknown'),
                    datasets: [{
                        data: maritalStatus.map(m => m.count || 0),
                        backgroundColor: chartColors.slice(0, maritalStatus.length),
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
            chartInstances.push(chart);
        }
    }
    
    // Nationality Bar Chart
    const nationalities = analytics.nationalities || [];
    if (nationalities.length > 0) {
        const ctx = document.getElementById('nationalityChart');
        if (ctx) {
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: nationalities.map(n => n.nationality || 'Unknown'),
                    datasets: [{
                        label: 'Number of Bookings',
                        data: nationalities.map(n => n.count || 0),
                        backgroundColor: colors.primary,
                        borderColor: colors.secondary,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            chartInstances.push(chart);
        }
    }
    
    // Age Group Bar Chart
    const ageGroups = analytics.age_groups || [];
    if (ageGroups.length > 0) {
        const ctx = document.getElementById('ageGroupChart');
        if (ctx) {
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ageGroups.map(a => a.age_group || 'Unknown'),
                    datasets: [{
                        label: 'Number of Bookings',
                        data: ageGroups.map(a => a.count || 0),
                        backgroundColor: [
                            colors.info,
                            colors.warning,
                            colors.primary,
                            colors.success
                        ],
                        borderColor: [
                            colors.secondary,
                            colors.secondary,
                            colors.secondary,
                            colors.secondary
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            chartInstances.push(chart);
        }
    }
    
    // Farm Income Chart
    const farmIncome = analytics.farm_popularity || analytics.farm_income || [];
    if (farmIncome.length > 0) {
        const ctx = document.getElementById('farmIncomeChart');
        if (ctx) {
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: farmIncome.map(f => f.name || 'Unknown'),
                    datasets: [
                        {
                            label: 'Bookings',
                            data: farmIncome.map(f => f.bookings_count || 0),
                            backgroundColor: colors.primary,
                            yAxisID: 'y'
                        },
                        {
                            label: 'Revenue (₱)',
                            data: farmIncome.map(f => parseFloat(f.revenue || 0)),
                            backgroundColor: colors.accent,
                            yAxisID: 'y1',
                            type: 'line'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Bookings'
                            }
                        },
                        y1: {
                            type: 'linear',
                            display: true,
                            position: 'right',
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Revenue (₱)'
                            },
                            grid: {
                                drawOnChartArea: false
                            }
                        }
                    }
                }
            });
            chartInstances.push(chart);
        }
    }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

function formatTypeDisplay(type) {
    if (!type) return 'Normal';
    const typeMap = {
        'normal': 'Normal',
        'pregnant': 'Pregnant',
        'disabled': 'Person with Disability',
        'senior': 'Senior',
        'teen': 'Teen',
        'child': 'Child'
    };
    return typeMap[type.toLowerCase()] || escapeHtml(type);
}

// Map farm names to images used on the user side so admin sees the same pictures
function getFarmImagePath(farmName) {
    if (!farmName) {
        return './image/Green-Valley.jpg';
    }

    const normalizedName = farmName.toLowerCase().trim();

    const imageMap = {
        'agata': 'Agata.jpg',
        'calo': 'Calo-Farm.jpg',
        'eco': 'Eco-Farm.jpg',
        'family': 'Family.jpg',
        'green valley': 'Green-Valley.jpg',
        'heritage': 'Heritage-Farm.jpg',
        'sunshine': 'MeadowFarm1.jpeg',
        'meadow': 'MeadowFarm1.jpeg',
        'tonybee': 'TonyBee.jpg',
        'tony bee': 'TonyBee.jpg'
    };

    for (const [key, imageFile] of Object.entries(imageMap)) {
        if (normalizedName.includes(key)) {
            return `./image/${imageFile}`;
        }
    }

    return './image/Green-Valley.jpg';
}

// ============================================
// NOTIFICATIONS
// ============================================

async function loadAdminNotifications() {
    const panelBody = document.getElementById('notificationPanelBody');
    
    if (!panelBody) return;
    
    try {
        const response = await fetch('./backend/notifications.php?action=get_notifications&role=admin', {
            credentials: 'same-origin'
        });
        const data = await response.json();
        
        if (data.success && data.notifications) {
            // Filter only cancellation-related notifications that belong to admin
            // The backend should already filter by user_id, but add extra safety check
            const cancellationNotifications = data.notifications.filter(notif => {
                const isCancellationRelated = 
                    notif.message.toLowerCase().includes('cancellation') || 
                    notif.message.toLowerCase().includes('cancelled') ||
                    notif.message.toLowerCase().includes('cancel');
                
                // Ensure notification belongs to admin (user_id should match admin's ID)
                // Backend already filters this, but this is an extra safeguard
                return isCancellationRelated;
            });
            
            // Ensure notifications are sorted by most recent first (by created_at DESC)
            const sortedNotifications = cancellationNotifications.sort((a, b) => {
                const dateA = new Date(a.created_at);
                const dateB = new Date(b.created_at);
                return dateB - dateA; // Most recent first
            });
            
            displayAdminNotifications(sortedNotifications);
        } else {
            panelBody.innerHTML = '<div class="empty-state"><p style="text-align: center; padding: 20px; color: #888;">No notifications</p></div>';
        }
    } catch (error) {
        console.error('Error loading admin notifications:', error);
        panelBody.innerHTML = '<div class="empty-state"><p style="text-align: center; padding: 20px; color: #888;">Error loading notifications</p></div>';
    }
}

function displayAdminNotifications(notifications) {
    const panelBody = document.getElementById('notificationPanelBody');
    
    if (!panelBody) return;
    
    if (!notifications || notifications.length === 0) {
        panelBody.innerHTML = '<div style="text-align: center; padding: 40px 20px; color: #888;"><i class="fas fa-bell-slash" style="font-size: 2em; margin-bottom: 10px; opacity: 0.3;"></i><p>No cancellation notifications yet</p></div>';
        return;
    }
    
    // Clear and create notification elements with improved styling
    panelBody.innerHTML = '';
    
    notifications.forEach(notification => {
        const wrapper = document.createElement('div');
        const isUnread = !notification.is_read;
        wrapper.className = 'notification-item' + (isUnread ? ' unread' : '');
        wrapper.innerHTML = `
            <div class="notification-message">${escapeHtml(notification.message)}</div>
            <div class="notification-time">${new Date(notification.created_at).toLocaleString()}</div>
        `;
        
        // When clicked, navigate to cancellations section and mark as read
        wrapper.addEventListener('click', () => {
            markNotificationRead(notification.id);
            // Navigate to cancellations section
            const cancellationsLink = document.querySelector('.nav-item[data-section="cancellations"]');
            if (cancellationsLink) {
                cancellationsLink.click();
                // Reload cancellations to show latest
                setTimeout(() => {
                    loadCancellations();
                }, 100);
            }
            // Close notification panel
            const panel = document.getElementById('notificationPanel');
            if (panel) {
                panel.classList.remove('open');
            }
        });
        
        panelBody.appendChild(wrapper);
    });
}

function getTimeAgo(dateString) {
    const now = new Date();
    const date = new Date(dateString);
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    return date.toLocaleDateString();
}

async function updateNotificationBadge() {
    try {
        const response = await fetch('./backend/notifications.php?action=get_notifications&role=admin', {
            credentials: 'same-origin'
        });
        const data = await response.json();
        
        if (data.success && data.notifications) {
            // Count only unread cancellation notifications
            // Sort by most recent first to ensure accurate count
            const sortedNotifications = data.notifications.sort((a, b) => {
                const dateA = new Date(a.created_at);
                const dateB = new Date(b.created_at);
                return dateB - dateA; // Most recent first
            });
            
            const cancellationNotifications = sortedNotifications.filter(notif => 
                (!notif.is_read) && (
                    notif.message.toLowerCase().includes('cancellation') || 
                    notif.message.toLowerCase().includes('cancelled') ||
                    notif.message.toLowerCase().includes('cancel')
                )
            );
            
            const badge = document.getElementById('notificationBadge');
            if (badge) {
                const count = cancellationNotifications.length;
                badge.textContent = count;
                badge.style.display = count > 0 ? 'flex' : 'none';
            }
        }
    } catch (error) {
        console.error('Error updating notification badge:', error);
    }
}

function toggleNotificationPanel() {
    const panel = document.getElementById('notificationPanel');
    if (panel) {
        panel.classList.toggle('open');
        if (panel.classList.contains('open')) {
            loadAdminNotifications();
        }
    }
}

async function markNotificationRead(notificationId) {
    const formData = new FormData();
    formData.append('action', 'mark_read');
    formData.append('notification_id', notificationId);
    formData.append('role', 'admin');
    
    try {
        await fetch('./backend/notifications.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        loadAdminNotifications();
        updateNotificationBadge();
    } catch (error) {
        console.error('Error marking notification as read:', error);
    }
}

async function markAllNotificationsRead() {
    const formData = new FormData();
    formData.append('action', 'mark_all_read');
    formData.append('role', 'admin');
    
    try {
        await fetch('./backend/notifications.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        loadAdminNotifications();
        updateNotificationBadge();
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
    }
}

// Make notification functions globally accessible
window.toggleNotificationPanel = toggleNotificationPanel;
window.markNotificationRead = markNotificationRead;
window.markAllNotificationsRead = markAllNotificationsRead;

// Logout function - Make sure it's globally accessible
function logout() {
    if (confirm('Are you sure you want to logout from admin dashboard?')) {
        // Remove only admin session from localStorage
        localStorage.removeItem('admin_session');
        
        // Clear current session storage
        sessionStorage.clear();
        
        // Logout from PHP session (admin only)
        const formData = new FormData();
        formData.append('action', 'logout');
        formData.append('role', 'admin');
        
        fetch('./backend/auth.php', {
            method: 'POST',
            body: formData
        })
        .then(() => {
            // Redirect to login page
            window.location.href = './index.html';
        })
        .catch(error => {
            console.error('Logout error:', error);
            // Still redirect to login page
            window.location.href = './index.html';
        });
    }
}

// Make logout function globally accessible
window.logout = logout;
