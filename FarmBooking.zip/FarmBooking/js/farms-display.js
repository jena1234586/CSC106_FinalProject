// Farm Display functionality with carousel (3 farms at a time, auto-slide)
let farms = [];
let currentIndex = 0;
let farmsPerView = 3;
let carouselInterval = null;

// Calculate farms per view based on screen size
function calculateFarmsPerView() {
    const width = window.innerWidth;
    if (width < 768) {
        return 1;
    } else if (width < 1024) {
        return 2;
    }
    return 3;
}

// Function to get farm image path based on farm name
function getFarmImagePath(farmName) {
    if (!farmName) {
        return './image/Green-Valley.jpg';
    }
    
    const normalizedName = farmName.toLowerCase().trim();
    
    const imageMap = {
        'agata': 'Agata.jpg',
        'calo': 'Calo-Farm.jpg',
        'eco': 'Eco-Farm.jpg',
        'family': 'Family.jpg',
        'green valley': 'Green-Valley.jpg',
        'heritage': 'Heritage-Farm.jpg',
        'sunshine': 'MeadowFarm1.jpeg',
        'meadow': 'MeadowFarm1.jpeg',
        'tonybee': 'TonyBee.jpg',
        'tony bee': 'TonyBee.jpg'
    };
    
    for (const [key, imageFile] of Object.entries(imageMap)) {
        if (normalizedName.includes(key)) {
            return `./image/${imageFile}`;
        }
    }
    
    return './image/Green-Valley.jpg';
}

// Load farms from API
async function loadFarms() {
    const farmsGrid = document.getElementById('farmsGrid');
    
    try {
        // Try to fetch farms (may require auth, but we'll handle errors gracefully)
        const response = await fetch('./backend/user_booking.php?action=get_farms', {
            method: 'GET',
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.success && data.farms && data.farms.length > 0) {
                farms = data.farms;
                renderFarms();
                startCarousel();
                return;
            }
        }
        
        // If API fails or no farms, use default farm images
        farms = [
            { name: 'Green Valley Farm', image_url: './image/Green-Valley.jpg' },
            { name: 'Heritage Farm', image_url: './image/Heritage-Farm.jpg' },
            { name: 'Eco Farm', image_url: './image/Eco-Farm.jpg' },
            { name: 'Calo Farm', image_url: './image/Calo-Farm.jpg' },
            { name: 'Agata Farm', image_url: './image/Agata.jpg' },
            { name: 'Family Farm', image_url: './image/Family.jpg' }
        ];
        renderFarms();
        startCarousel();
    } catch (error) {
        console.error('Error loading farms:', error);
        // Use default farms on error
        farms = [
            { name: 'Green Valley Farm', image_url: './image/Green-Valley.jpg' },
            { name: 'Heritage Farm', image_url: './image/Heritage-Farm.jpg' },
            { name: 'Eco Farm', image_url: './image/Eco-Farm.jpg' },
            { name: 'Calo Farm', image_url: './image/Calo-Farm.jpg' },
            { name: 'Agata Farm', image_url: './image/Agata.jpg' }
        ];
        renderFarms();
        startCarousel();
    }
}

// Render farms in carousel layout with continuous sliding
function renderFarms() {
    const farmsGrid = document.getElementById('farmsGrid');
    
    if (!farms || farms.length === 0) {
        farmsGrid.innerHTML = '<div class="farms-loading"><p>No farms available</p></div>';
        return;
    }
    
    // Clear existing content
    farmsGrid.innerHTML = '';
    
    // Create wrapper for smooth continuous sliding
    const wrapper = document.createElement('div');
    wrapper.className = 'farms-grid-wrapper';
    
    // Duplicate farms array to create seamless loop (add farms twice)
    const duplicatedFarms = [...farms, ...farms];
    
    // Create all farm cards (duplicated for seamless loop)
    duplicatedFarms.forEach((farm) => {
        const farmCard = document.createElement('div');
        farmCard.className = 'farm-card-item';
        
        const farmImage = farm.image_url || getFarmImagePath(farm.name);
        
        farmCard.innerHTML = `
            <div class="farm-image-wrapper">
                <img src="${farmImage}" alt="${farm.name}" class="farm-card-image" 
                     onerror="this.src='./image/Green-Valley.jpg'">
                <div class="farm-name-overlay">
                    <span>${farm.name}</span>
                </div>
            </div>
        `;
        
        wrapper.appendChild(farmCard);
    });
    
    farmsGrid.appendChild(wrapper);
    
    // Add continuous slide class for CSS animation
    wrapper.classList.add('continuous-slide');
    
    // Reset position to start
    currentIndex = 0;
}

// Update carousel position (not needed for CSS animation, but kept for compatibility)
function updateCarouselPosition() {
    // CSS animation handles the continuous sliding
    // This function is kept for potential future use or manual control
}

// Move to next farm (not needed for CSS animation, but kept for compatibility)
function nextFarms() {
    // CSS animation handles continuous sliding automatically
    // This function is kept for potential future use
}

// Start auto-slide carousel with continuous animation
function startCarousel() {
    // CSS animation handles the continuous sliding automatically
    // No interval needed, but we keep this function for compatibility
    if (carouselInterval) clearInterval(carouselInterval);
    carouselInterval = null;
}

// Handle window resize
window.addEventListener('resize', function() {
    farmsPerView = calculateFarmsPerView();
    // CSS animation will continue automatically on resize
    // No manual reset needed
});

// Stop carousel
function stopCarousel() {
    if (carouselInterval) {
        clearInterval(carouselInterval);
        carouselInterval = null;
    }
}

// Pause on hover
document.addEventListener('DOMContentLoaded', function() {
    const farmsGrid = document.getElementById('farmsGrid');
    
    if (farmsGrid) {
        farmsGrid.addEventListener('mouseenter', stopCarousel);
        farmsGrid.addEventListener('mouseleave', startCarousel);
    }
    
    // Load farms
    loadFarms();
});

