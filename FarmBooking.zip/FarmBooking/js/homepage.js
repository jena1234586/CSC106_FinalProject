// Homepage view management
document.addEventListener('DOMContentLoaded', function() {
    const switchToRegister = document.getElementById('switchToRegister');
    const switchToLogin = document.getElementById('switchToLogin');
    const closeRegister = document.getElementById('closeRegister');
    const registerView = document.getElementById('registerView');

    // Show register overlay
    function showRegister() {
        if (registerView) {
            registerView.style.display = 'flex';
        }
    }

    // Hide register overlay
    function hideRegister() {
        if (registerView) {
            registerView.style.display = 'none';
        }
    }

    // Event listeners
    if (switchToRegister) {
        switchToRegister.addEventListener('click', function(e) {
            e.preventDefault();
            showRegister();
        });
    }

    if (switchToLogin) {
        switchToLogin.addEventListener('click', function(e) {
            e.preventDefault();
            hideRegister();
        });
    }

    if (closeRegister) {
        closeRegister.addEventListener('click', function(e) {
            e.preventDefault();
            hideRegister();
        });
    }

    // Close register overlay when clicking outside
    if (registerView) {
        registerView.addEventListener('click', function(e) {
            if (e.target === registerView) {
                hideRegister();
            }
        });
    }
});

