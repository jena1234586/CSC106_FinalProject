// Login functionality - Supports multiple simultaneous logins (User & Admin)
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const errorMessage = document.getElementById('errorMessage');
    const quickAccess = document.getElementById('quickAccess');

    // Always hide the quick access section so it won't show at the bottom
    // even if both user and admin are logged in.
    if (quickAccess) {
        quickAccess.style.display = 'none';
    }
    
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        errorMessage.classList.remove('show');
        errorMessage.textContent = '';
        
        try {
            const formData = new FormData();
            formData.append('action', 'login');
            formData.append('username', username);
            formData.append('password', password);
            
            const response = await fetch('./backend/auth.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Store login info in localStorage with role-specific key
                let loginKey;
                if (data.role === 'admin') {
                    loginKey = 'admin_session';
                } else if (data.role === 'staff') {
                    loginKey = 'staff_session';
                } else {
                    loginKey = 'user_session';
                }
                
                const loginData = {
                    user_id: data.user_id || data.staff_id,
                    staff_id: data.staff_id,
                    username: username,
                    full_name: data.full_name,
                    role: data.role,
                    login_time: new Date().toISOString()
                };
                
                localStorage.setItem(loginKey, JSON.stringify(loginData));
                
                // Also store in sessionStorage for current session
                sessionStorage.setItem('current_role', data.role);
                sessionStorage.setItem('full_name', data.full_name);
                sessionStorage.setItem('username', username);
                
                // Show success message
                errorMessage.textContent = `Successfully logged in as ${data.role}!`;
                errorMessage.style.color = '#27ae60';
                errorMessage.style.background = '#d4edda';
                errorMessage.style.borderColor = '#27ae60';
                errorMessage.classList.add('show');
                
                // Clear form
                loginForm.reset();
                
                // Auto-redirect after 1 second based on detected role
                setTimeout(() => {
                    if (data.role === 'admin') {
                        window.location.href = './admin_dashboard.html';
                    } else if (data.role === 'staff') {
                        window.location.href = './staff_dashboard.html';
                    } else {
                        window.location.href = './user_dashboard.html';
                    }
                }, 1000);
            } else {
                errorMessage.textContent = data.message || 'Login failed';
                errorMessage.style.color = '#e74c3c';
                errorMessage.style.background = '#fee';
                errorMessage.style.borderColor = '#e74c3c';
                errorMessage.classList.add('show');
            }
        } catch (error) {
            errorMessage.textContent = 'An error occurred. Please try again.';
            errorMessage.style.color = '#e74c3c';
            errorMessage.style.background = '#fee';
            errorMessage.style.borderColor = '#e74c3c';
            errorMessage.classList.add('show');
            console.error('Login error:', error);
        }
    });
});

function checkExistingLogins() {
    const quickAccess = document.getElementById('quickAccess');
    const userSession = localStorage.getItem('user_session');
    const adminSession = localStorage.getItem('admin_session');
    const staffSession = localStorage.getItem('staff_session');
    
    // Only show the quick access block when multiple sessions exist
    // so the user doesn't have to choose a role during a normal single-role login.
    const sessionCount = [userSession, adminSession, staffSession].filter(s => s).length;
    if (sessionCount > 1) {
        quickAccess.style.display = 'block';
        
        // Show/hide buttons based on available sessions
        const userBtn = document.getElementById('goToUserDashboard');
        const adminBtn = document.getElementById('goToAdminDashboard');
        
        if (userSession) {
            const userData = JSON.parse(userSession);
            userBtn.style.display = 'block';
            userBtn.innerHTML = `<i class="fas fa-user"></i> User Dashboard (${userData.full_name})`;
        } else {
            userBtn.style.display = 'none';
        }
        
        if (adminSession) {
            const adminData = JSON.parse(adminSession);
            adminBtn.style.display = 'block';
            adminBtn.innerHTML = `<i class="fas fa-user-shield"></i> Admin Dashboard (${adminData.full_name})`;
        } else {
            adminBtn.style.display = 'none';
        }
    } else {
        quickAccess.style.display = 'none';
    }
}

function goToDashboard(role) {
    if (role === 'admin') {
        const adminSession = localStorage.getItem('admin_session');
        if (adminSession) {
            const adminData = JSON.parse(adminSession);
            sessionStorage.setItem('current_role', 'admin');
            sessionStorage.setItem('full_name', adminData.full_name);
            sessionStorage.setItem('username', adminData.username);
            window.location.href = './admin_dashboard.html';
        } else {
            alert('Please login as admin first');
        }
    } else {
        const userSession = localStorage.getItem('user_session');
        if (userSession) {
            const userData = JSON.parse(userSession);
            sessionStorage.setItem('current_role', 'user');
            sessionStorage.setItem('full_name', userData.full_name);
            sessionStorage.setItem('username', userData.username);
            window.location.href = './user_dashboard.html';
        } else {
            alert('Please login as user first');
        }
    }
}

function logoutAll() {
    if (confirm('Are you sure you want to logout from all accounts?')) {
        localStorage.removeItem('user_session');
        localStorage.removeItem('admin_session');
        localStorage.removeItem('staff_session');
        sessionStorage.clear();
        
        // Also logout from PHP session
        const formData = new FormData();
        formData.append('action', 'logout');
        fetch('./backend/auth.php', {
            method: 'POST',
            body: formData
        }).then(() => {
            window.location.reload();
        });
    }
}
