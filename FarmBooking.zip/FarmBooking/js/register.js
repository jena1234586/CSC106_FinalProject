// Registration functionality
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    // Prefer the register overlay fields first to avoid binding to the login inputs
    const passwordInput = document.getElementById('reg_password') || document.getElementById('password');
    const usernameInput = document.getElementById('reg_username') || document.getElementById('username');
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    const usernameError = document.getElementById('usernameError');
    const errorMessage = document.getElementById('errorMessageReg') || document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');
    
    let usernameCheckTimeout;
    
    // If the form or required inputs aren't on the page, exit quietly
    if (!registerForm || !passwordInput || !usernameInput || !strengthBar || !strengthText || !errorMessage) {
        return;
    }
    
    // Password strength checker
    passwordInput.addEventListener('input', function() {
        const password = passwordInput.value;
        const strength = checkPasswordStrength(password);
        
        strengthBar.className = 'strength-bar';
        if (strength.level > 0) {
            strengthBar.classList.add(strength.levelName);
        }
        strengthText.textContent = strength.text;
    });
    
    // Username availability checker
    usernameInput.addEventListener('input', function() {
        clearTimeout(usernameCheckTimeout);
        const username = usernameInput.value;
        
        if (username.length < 3) {
            usernameError.textContent = '';
            return;
        }
        
        usernameCheckTimeout = setTimeout(async function() {
            try {
                const formData = new FormData();
                formData.append('action', 'check_username');
                formData.append('username', username);
                
                const response = await fetch('backend/auth.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.exists) {
                    usernameError.textContent = 'Username already taken';
                    usernameError.classList.add('show');
                } else {
                    usernameError.textContent = '';
                    usernameError.classList.remove('show');
                }
            } catch (error) {
                console.error('Username check error:', error);
            }
        }, 500);
    });
    
    registerForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        errorMessage.classList.remove('show');
        successMessage.classList.remove('show');
        
        const fullName = document.getElementById('full_name').value;
        const username = usernameInput.value;
        const password = passwordInput.value;
        
        // Validate
        if (!fullName || !username || !password) {
            errorMessage.textContent = 'All fields are required';
            errorMessage.classList.add('show');
            return;
        }
        
        const strength = checkPasswordStrength(password);
        if (strength.level === 0) {
            errorMessage.textContent = 'Password is too weak. Please use a stronger password.';
            errorMessage.classList.add('show');
            return;
        }
        
        try {
            const formData = new FormData();
            formData.append('action', 'register');
            formData.append('full_name', fullName);
            formData.append('username', username);
            formData.append('password', password);
            
            const response = await fetch('backend/auth.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                successMessage.textContent = 'Registration successful! Redirecting to login...';
                successMessage.classList.add('show');
                
                setTimeout(function() {
                    window.location.href = 'index.html';
                }, 2000);
            } else {
                errorMessage.textContent = data.message || 'Registration failed';
                errorMessage.classList.add('show');
            }
        } catch (error) {
            errorMessage.textContent = 'An error occurred. Please try again.';
            errorMessage.classList.add('show');
            console.error('Registration error:', error);
        }
    });
});

function checkPasswordStrength(password) {
    if (password.length === 0) {
        return { level: 0, levelName: '', text: 'Password strength' };
    }
    
    if (password.length < 6 || /^[a-zA-Z]+$/.test(password)) {
        return { level: 1, levelName: 'weak', text: 'Weak password' };
    }
    
    if (password.length >= 6 && password.length <= 10 && /[a-zA-Z]/.test(password) && /[0-9]/.test(password)) {
        return { level: 2, levelName: 'medium', text: 'Medium password' };
    }
    
    if (password.length >= 10 && /[a-zA-Z]/.test(password) && /[0-9]/.test(password) && /[^a-zA-Z0-9]/.test(password)) {
        return { level: 3, levelName: 'strong', text: 'Strong password' };
    }
    
    return { level: 2, levelName: 'medium', text: 'Medium password' };
}

