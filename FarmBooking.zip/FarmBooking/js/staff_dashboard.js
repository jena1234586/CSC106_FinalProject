// Staff Dashboard functionality
let bookings = [];
let notifications = [];

document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    setupSidebar();
    setupNavigation();
    setupModals();
    loadBookings();
    loadNotifications();
    updateNotificationBadge();
    
    // Set staff name
    const staffName = sessionStorage.getItem('staff_name') || 'Staff';
    document.getElementById('staffName').textContent = staffName;
    
    // Refresh notification badge every 30 seconds
    setInterval(() => {
        updateNotificationBadge();
        const panel = document.getElementById('notificationPanel');
        if (panel && panel.classList.contains('open')) {
            loadNotifications();
        }
    }, 30000);
    
    // Close notification panel when clicking outside
    document.addEventListener('click', function(event) {
        const panel = document.getElementById('notificationPanel');
        const icon = document.getElementById('notificationIcon');
        if (panel && icon && !panel.contains(event.target) && !icon.contains(event.target)) {
            panel.classList.remove('open');
        }
    });
});

// ============================================
// AUTHENTICATION
// ============================================
function checkAuth() {
    const staffSession = localStorage.getItem('staff_session');
    if (staffSession) {
        try {
            const staffData = JSON.parse(staffSession);
            sessionStorage.setItem('staff_name', staffData.full_name);
            sessionStorage.setItem('staff_id', staffData.staff_id);
            document.getElementById('staffName').textContent = staffData.full_name || 'Staff';
        } catch (e) {
            localStorage.removeItem('staff_session');
        }
    }
    
    fetch('./backend/staff_auth.php?action=check', {
        credentials: 'same-origin'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (!data.logged_in || data.role !== 'staff') {
                alert('Staff session expired. Please log in again.');
                localStorage.removeItem('staff_session');
                sessionStorage.clear();
                window.location.href = './staff_login.html';
            } else {
                sessionStorage.setItem('staff_name', data.full_name);
                sessionStorage.setItem('staff_id', data.staff_id);
                document.getElementById('staffName').textContent = data.full_name || 'Staff';
            }
        })
        .catch(error => {
            console.error('Auth check error:', error);
            alert('Unable to verify staff session. Please log in again.');
            localStorage.removeItem('staff_session');
            sessionStorage.clear();
            window.location.href = './staff_login.html';
        });
}

// ============================================
// SIDEBAR FUNCTIONALITY
// ============================================
function setupSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.add('active');
            sidebarOverlay.classList.add('active');
        });
    }
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    window.addEventListener('resize', function() {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        }
    });
}

// ============================================
// NAVIGATION
// ============================================
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-item');
    const pageTitle = document.getElementById('pageTitle');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            document.querySelectorAll('.dashboard-section').forEach(s => s.classList.remove('active'));
            const targetSection = document.getElementById(section + 'Section');
            if (targetSection) {
                targetSection.classList.add('active');
            }
            
            const titles = {
                'bookings': 'Reservation Details',
                'notifications': 'Notifications',
                'tourHistory': 'Tour History'
            };
            if (pageTitle && titles[section]) {
                pageTitle.textContent = titles[section];
            }
            
            if (window.innerWidth <= 1024) {
                document.getElementById('sidebar').classList.remove('active');
                document.getElementById('sidebarOverlay').classList.remove('active');
            }
            
            if (section === 'notifications') {
                loadNotifications();
            } else if (section === 'tourHistory') {
                loadTourHistory();
            }
        });
    });
}

// ============================================
// MODAL SETUP
// ============================================
function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closes = document.querySelectorAll('.close');
    
    closes.forEach(close => {
        close.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    window.addEventListener('click', function(e) {
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

// ============================================
// BOOKINGS
// ============================================
async function loadBookings() {
    const container = document.getElementById('bookingsContainer');
    
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading reservations...</p></div>';
    
    try {
        const response = await fetch('./backend/staff_booking.php?action=get_bookings');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.bookings) {
            bookings = data.bookings;
            displayBookings();
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Reservations Found</h3><p>You have no assigned reservations yet.</p></div>';
        }
    } catch (error) {
        console.error('Error loading bookings:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Reservations</h3><p>Please check your connection and try again.</p></div>';
    }
}

function displayBookings() {
    const container = document.getElementById('bookingsContainer');
    
    if (!bookings || bookings.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Reservations Found</h3><p>You have no assigned reservations yet.</p></div>';
        return;
    }
    
    let html = '<div class="cards-grid">';
    
    bookings.forEach(booking => {
        html += `
            <div class="farm-card">
                <div class="farm-card-content">
                    <h3><i class="fas fa-calendar-check"></i> Reservation #${booking.id}</h3>
                    <p><strong>Farm:</strong> ${escapeHtml(booking.farm_name || 'N/A')}</p>
                    <p><strong>Customer:</strong> ${escapeHtml(booking.full_name || 'N/A')}</p>
                    <p><strong>Date:</strong> ${booking.booking_date || 'N/A'}</p>
                    <p><strong>Total Price:</strong> ₱${parseFloat(booking.total_price || 0).toFixed(2)}</p>
                    <div class="action-buttons" style="margin-top: 1rem;">
                        <button class="btn btn-secondary btn-sm" onclick="viewBookingDetails(${booking.id})">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                        <button class="btn btn-success btn-sm" onclick="markTourDone(${booking.id})">
                            <i class="fas fa-check-circle"></i> Done Tour
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

async function viewBookingDetails(bookingId) {
    const modal = document.getElementById('bookingDetailsModal');
    const content = document.getElementById('bookingDetailsContent');
    
    content.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading details...</p></div>';
    modal.style.display = 'block';
    
    try {
        const response = await fetch(`./backend/staff_booking.php?action=get_booking&booking_id=${bookingId}`);
        const data = await response.json();
        
        if (data.success && data.booking) {
            const booking = data.booking;
            let companionsRows = '';
            
            if (booking.companions_details) {
                try {
                    const companions = JSON.parse(booking.companions_details) || [];
                    companionsRows = companions.map((comp, index) => `
                        <tr>
                            <td>${index + 1}</td>
                            <td>${escapeHtml(comp.name || 'N/A')}</td>
                            <td>${comp.age || 'N/A'}</td>
                            <td>${escapeHtml(comp.sex || 'N/A')}</td>
                            <td>${formatTypeDisplay(comp.type || 'normal')}</td>
                        </tr>
                    `).join('');
                } catch (e) {
                    console.error('Error parsing companions:', e);
                }
            }
            
            content.innerHTML = `
                <div class="booking-details-card">
                    <div class="booking-details-grid">
                        <div class="top-sections-row">
                            <div class="details-section">
                                <h4><i class="fas fa-file-invoice"></i> Booking Information</h4>
                                <p><strong>Reservation #:</strong> ${booking.id}</p>
                                <p><strong>Farm:</strong> ${escapeHtml(booking.farm_name || 'N/A')}</p>
                                <p><strong>Customer:</strong> ${escapeHtml(booking.full_name || 'N/A')}</p>
                                <p><strong>Booking Date:</strong> ${booking.booking_date || 'N/A'}</p>
                                <p><strong>Total Price:</strong> ₱${parseFloat(booking.total_price || 0).toFixed(2)}</p>
                                <hr>
                                <p><strong>Age:</strong> ${booking.age || 'N/A'}</p>
                                <p><strong>Gender:</strong> ${escapeHtml(booking.gender || 'N/A')}</p>
                                <p><strong>Nationality:</strong> ${escapeHtml(booking.nationality || 'N/A')}</p>
                                <p><strong>Marital Status:</strong> ${escapeHtml(booking.marital_status || 'N/A')}</p>
                            </div>
                            
                            ${booking.staff_status !== 'completed' ? `
                            <div class="details-section">
                                <h4><i class="fas fa-tasks"></i> Actions</h4>
                                <p>Mark this tour as completed when you finish the assigned booking.</p>
                                <div class="action-buttons" style="margin-top: 1rem;">
                                    <button class="btn btn-success" onclick="markTourDone(${booking.id})">
                                        <i class="fas fa-check-circle"></i> Done Tour
                                    </button>
                                </div>
                            </div>
                            ` : `
                            <div class="details-section">
                                <h4><i class="fas fa-check-circle"></i> Tour Status</h4>
                                <p><strong>Status:</strong> <span class="status-badge completed">Completed</span></p>
                                ${booking.completed_at ? `<p><strong>Completed On:</strong> ${new Date(booking.completed_at).toLocaleString()}</p>` : ''}
                            </div>
                            `}
                        </div>
                        
                        <div class="details-section full-width">
                            <h4><i class="fas fa-users"></i> Companions (${booking.companions_count || 0})</h4>
                            ${companionsRows
                                ? `
                                <div class="table-container">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Age</th>
                                                <th>Gender</th>
                                                <th>Type</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${companionsRows}
                                        </tbody>
                                    </table>
                                </div>`
                                : '<p>No companion details provided.</p>'
                            }
                        </div>
                    </div>
                </div>
            `;
        } else {
            content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Unable to load booking</h3><p>Please try again.</p></div>';
        }
    } catch (error) {
        console.error('Error loading booking details:', error);
        content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Details</h3><p>Please try again.</p></div>';
    }
}

async function markTourDone(bookingId) {
    if (!confirm('Are you sure you want to mark this tour as done? This will update your status to "Waiting for Assign".')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'mark_done');
    formData.append('booking_id', bookingId);
    
    try {
        const response = await fetch('./backend/staff_booking.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(data.message || 'Tour marked as done successfully!');
            document.getElementById('bookingDetailsModal').style.display = 'none';
            loadBookings();
            updateNotificationBadge();
            // Reload tour history if tour history section is active
            const tourHistorySection = document.getElementById('tourHistorySection');
            if (tourHistorySection && tourHistorySection.classList.contains('active')) {
                loadTourHistory();
            }
        } else {
            alert(data.message || 'Failed to mark tour as done');
        }
    } catch (error) {
        console.error('Mark tour done error:', error);
        alert('An error occurred. Please try again.');
    }
}

// ============================================
// NOTIFICATIONS
// ============================================
async function loadNotifications() {
    const loading = document.getElementById('notificationsLoading');
    const container = document.getElementById('notificationsSectionList');
    const panelBody = document.getElementById('notificationPanelBody');
    
    // Show loading spinner
    if (loading) loading.style.display = 'flex';
    if (container) container.style.display = 'none';
    
    try {
        const response = await fetch('./backend/staff_booking.php?action=get_notifications');
        const data = await response.json();
        
        if (data.success && data.notifications) {
            // Ensure notifications are sorted by most recent first (by created_at DESC)
            notifications = data.notifications.sort((a, b) => {
                const dateA = new Date(a.created_at);
                const dateB = new Date(b.created_at);
                return dateB - dateA; // Most recent first
            });
            
            if (container) {
                displayNotifications(container, notifications);
            }
            if (panelBody) {
                displayNotifications(panelBody, notifications);
            }
        } else {
            if (container) {
                container.innerHTML = '<div class="empty-state"><p>No notifications</p></div>';
            }
            if (panelBody) {
                panelBody.innerHTML = '<div style="text-align: center; padding: 20px;"><p>No notifications</p></div>';
            }
        }
    } catch (error) {
        console.error('Error loading notifications:', error);
        if (container) {
            container.innerHTML = '<div class="empty-state"><p>Error loading notifications</p></div>';
        }
        if (panelBody) {
            panelBody.innerHTML = '<div style="text-align: center; padding: 20px;"><p>Error loading notifications</p></div>';
        }
    } finally {
        // Hide loading spinner and show container
        if (loading) loading.style.display = 'none';
        if (container) container.style.display = 'block';
    }
}

function displayNotifications(container, notificationsList) {
    if (!notificationsList || notificationsList.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 40px 20px; color: #888;"><i class="fas fa-bell-slash" style="font-size: 2em; margin-bottom: 10px; opacity: 0.3;"></i><p>No notifications yet</p></div>';
        return;
    }
    
    container.innerHTML = '';
    
    notificationsList.forEach(notification => {
        const wrapper = document.createElement('div');
        const isUnread = !notification.is_read;
        wrapper.className = 'notification-item' + (isUnread ? ' unread' : '');
        wrapper.innerHTML = `
            <div class="notification-message">${escapeHtml(notification.message)}</div>
            <div class="notification-time">${new Date(notification.created_at).toLocaleString()}</div>
        `;
        
        wrapper.addEventListener('click', () => {
            markNotificationRead(notification.id);
            const panel = document.getElementById('notificationPanel');
            if (panel) {
                panel.classList.remove('open');
            }
        });
        
        container.appendChild(wrapper);
    });
}

async function updateNotificationBadge() {
    try {
        const response = await fetch('./backend/staff_booking.php?action=get_unread_count');
        const data = await response.json();
        
        if (data.success) {
            const badge = document.getElementById('notificationBadge');
            if (badge) {
                const count = data.count || 0;
                badge.textContent = count;
                badge.style.display = count > 0 ? 'flex' : 'none';
            }
        }
    } catch (error) {
        console.error('Error updating notification badge:', error);
    }
}

function toggleNotificationPanel() {
    const panel = document.getElementById('notificationPanel');
    if (panel) {
        panel.classList.toggle('open');
        if (panel.classList.contains('open')) {
            loadNotifications();
        }
    }
}

async function markNotificationRead(notificationId) {
    const formData = new FormData();
    formData.append('action', 'mark_read');
    formData.append('notification_id', notificationId);
    
    try {
        await fetch('./backend/staff_booking.php', {
            method: 'POST',
            body: formData
        });
        loadNotifications();
        updateNotificationBadge();
    } catch (error) {
        console.error('Error marking notification as read:', error);
    }
}

async function markAllNotificationsRead() {
    const formData = new FormData();
    formData.append('action', 'mark_all_read');
    
    try {
        await fetch('./backend/staff_booking.php', {
            method: 'POST',
            body: formData
        });
        loadNotifications();
        updateNotificationBadge();
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
    }
}

// ============================================
// TOUR HISTORY
// ============================================
async function loadTourHistory() {
    const loading = document.getElementById('tourHistoryLoading');
    const container = document.getElementById('tourHistoryList');
    
    // Show loading spinner
    if (loading) loading.style.display = 'flex';
    if (container) container.style.display = 'none';
    
    try {
        const response = await fetch('./backend/staff_booking.php?action=get_completed_tours');
        const data = await response.json();
        
        if (data.success && data.tours) {
            // Filter out cancelled bookings - they should only appear in notifications
            const filteredTours = data.tours.filter(tour => tour.status !== 'cancelled');
            
            // Ensure tours are sorted by most recent first
            const sortedTours = filteredTours.sort((a, b) => {
                const dateA = new Date(a.completed_at || a.created_at);
                const dateB = new Date(b.completed_at || b.created_at);
                return dateB - dateA; // Most recent first
            });
            displayTourHistory(sortedTours);
        } else {
            if (container) {
                container.innerHTML = '<div class="empty-state"><p>No completed tours yet</p></div>';
            }
        }
    } catch (error) {
        console.error('Error loading tour history:', error);
        if (container) {
            container.innerHTML = '<div class="empty-state"><p>Error loading tour history</p></div>';
        }
    } finally {
        // Hide loading spinner and show container
        if (loading) loading.style.display = 'none';
        if (container) container.style.display = 'block';
    }
}

function displayTourHistory(tours) {
    const container = document.getElementById('tourHistoryList');
    
    if (!container) return;
    
    if (!tours || tours.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-history"></i>
                <h3>No Tour History</h3>
                <p>Completed tours will appear here</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    
    tours.forEach(tour => {
        const card = document.createElement('div');
        card.className = 'booking-card';
        
        const bookingDate = new Date(tour.booking_date).toLocaleDateString();
        const completedDate = tour.completed_at 
            ? new Date(tour.completed_at).toLocaleString() 
            : 'Date not available';
        
        // All tours in history are completed (cancelled ones are filtered out)
        const statusBadge = '<span class="status-badge completed">Completed</span>';
        
        card.innerHTML = `
            <div class="booking-card-header">
                <div class="booking-id">
                    <i class="fas fa-ticket-alt"></i>
                    <span>Reservation #${tour.id}</span>
                </div>
                ${statusBadge}
            </div>
            <div class="booking-card-body">
                <div class="booking-info-grid">
                    <div class="booking-info-item">
                        <div class="info-label">
                            <i class="fas fa-seedling"></i>
                            <span>Farm</span>
                        </div>
                        <div class="info-value">${escapeHtml(tour.farm_name || 'N/A')}</div>
                    </div>
                    <div class="booking-info-item">
                        <div class="info-label">
                            <i class="fas fa-calendar"></i>
                            <span>Tour Date</span>
                        </div>
                        <div class="info-value">${bookingDate}</div>
                    </div>
                    <div class="booking-info-item">
                        <div class="info-label">
                            <i class="fas fa-user"></i>
                            <span>Customer</span>
                        </div>
                        <div class="info-value">${escapeHtml(tour.full_name || 'N/A')}</div>
                    </div>
                    <div class="booking-info-item">
                        <div class="info-label">
                            <i class="fas fa-users"></i>
                            <span>Total Guests</span>
                        </div>
                        <div class="info-value">${1 + (tour.companions_count || 0)}</div>
                    </div>
                    <div class="booking-info-item">
                        <div class="info-label">
                            <i class="fas fa-check-circle"></i>
                            <span>Completed</span>
                        </div>
                        <div class="info-value">${completedDate}</div>
                    </div>
                    ${tour.farm_description ? `
                    <div class="booking-info-item full-width">
                        <div class="info-label">
                            <i class="fas fa-info-circle"></i>
                            <span>Description</span>
                        </div>
                        <div class="info-value">${escapeHtml(tour.farm_description)}</div>
                    </div>
                    ` : ''}
                </div>
            </div>
            <div class="booking-card-footer">
                <button class="btn-secondary" onclick="viewTourDetails(${tour.id})">
                    <i class="fas fa-eye"></i> View Details
                </button>
            </div>
        `;
        
        container.appendChild(card);
    });
}

function viewTourDetails(bookingId) {
    // Reuse the existing viewBookingDetails function
    viewBookingDetails(bookingId);
}

// ============================================
// UTILITY FUNCTIONS
// ============================================
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

function formatTypeDisplay(type) {
    if (!type) return 'Normal';
    const typeMap = {
        'normal': 'Normal',
        'pregnant': 'Pregnant',
        'disabled': 'Person with Disability',
        'senior': 'Senior',
        'teen': 'Teen',
        'child': 'Child'
    };
    return typeMap[type.toLowerCase()] || escapeHtml(type);
}

// ============================================
// LOGOUT
// ============================================
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('staff_session');
        sessionStorage.clear();
        
        const formData = new FormData();
        formData.append('action', 'logout');
        
        fetch('./backend/staff_auth.php', {
            method: 'POST',
            body: formData
        })
        .then(() => {
            window.location.href = './index.html';
        })
        .catch(error => {
            console.error('Logout error:', error);
            window.location.href = './index.html';
        });
    }
}

// Make functions globally accessible
window.viewBookingDetails = viewBookingDetails;
window.viewTourDetails = viewTourDetails;
window.markTourDone = markTourDone;
window.toggleNotificationPanel = toggleNotificationPanel;
window.markAllNotificationsRead = markAllNotificationsRead;
window.logout = logout;

