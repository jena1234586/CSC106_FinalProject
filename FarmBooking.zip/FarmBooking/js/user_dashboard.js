// User Dashboard functionality
let farms = [];
let bookings = [];
let bookingRequests = [];
let currentFarm = null;
let currentBooking = null;

document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    setupSidebar();
    setupNavigation();
    setupModals();
    loadFarms();
    loadBookingRequests();
    loadBookings();
    loadNotifications();
    setMinDate();
    
    // Set user name
    const userName = sessionStorage.getItem('full_name') || 'User';
    document.getElementById('userName').textContent = userName;
    
    // Setup notifications icon
    document.getElementById('notificationsIcon').addEventListener('click', function() {
        const panel = document.getElementById('notificationsPanel');
        panel.classList.toggle('open');
    });
    
    // Setup booking form - with delay to ensure DOM is ready
    setTimeout(function() {
        const bookingForm = document.getElementById('bookingForm');
        if (bookingForm) {
            // Remove any existing listeners by cloning
            const newForm = bookingForm.cloneNode(true);
            bookingForm.parentNode.replaceChild(newForm, bookingForm);
            
            // Get the new form reference
            const form = document.getElementById('bookingForm');
            const confirmBtn = document.getElementById('confirmBookingBtn');
            
            // Add form submit handler
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('✅ Form submit event triggered');
                handleBookingSubmit(e);
                return false;
            });
            
            // Add direct button click handler
            if (confirmBtn) {
                confirmBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('✅ Submit button clicked directly');
                    
                    // Trigger form validation
                    if (form.checkValidity()) {
                        handleBookingSubmit(e);
                    } else {
                        form.reportValidity();
                    }
                    return false;
                });
                
                // Make sure button is not disabled
                confirmBtn.disabled = false;
                confirmBtn.style.pointerEvents = 'auto';
                confirmBtn.style.cursor = 'pointer';
            }
            
            console.log('✅ Booking form and button event listeners attached');
        } else {
            console.error('❌ Booking form not found!');
        }
    }, 100);
    
    const bookingAge = document.getElementById('bookingAge');
    if (bookingAge) {
        bookingAge.addEventListener('input', calculatePrice);
    }
    
    const companionsCount = document.getElementById('companionsCount');
    if (companionsCount) {
        companionsCount.addEventListener('input', updateCompanionsForm);
    }
    
    // Setup edit booking form
    document.getElementById('editBookingForm').addEventListener('submit', handleEditBookingSubmit);
    document.getElementById('editAge').addEventListener('input', calculateEditPrice);
    document.getElementById('editCompanionsCount').addEventListener('input', updateEditCompanionsForm);
    
    // Setup cancel booking form
    document.getElementById('cancelBookingForm').addEventListener('submit', handleCancelBookingSubmit);
});

// Sidebar functionality
function setupSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    
    // Mobile menu toggle
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.add('active');
            sidebarOverlay.classList.add('active');
        });
    }
    
    // Close sidebar
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    // Close sidebar when clicking overlay
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });
    }
    
    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        }
    });
}

function checkAuth() {
    // Use localStorage to pre-fill UI but still verify with backend
    const userSession = localStorage.getItem('user_session');
    if (userSession) {
        try {
            const userData = JSON.parse(userSession);
            sessionStorage.setItem('full_name', userData.full_name);
            sessionStorage.setItem('username', userData.username);
            document.getElementById('userName').textContent = userData.full_name || 'User';
        } catch (e) {
            localStorage.removeItem('user_session');
        }
    }
    
    fetch('./backend/auth.php?action=check&role=user', {
        credentials: 'same-origin'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (!data.logged_in || data.role !== 'user') {
                alert('User session expired. Please log in again.');
                localStorage.removeItem('user_session');
                sessionStorage.clear();
                window.location.href = './index.html';
            } else {
                sessionStorage.setItem('full_name', data.full_name);
                document.getElementById('userName').textContent = data.full_name || 'User';
            }
        })
        .catch(error => {
            console.error('Auth check error:', error);
            alert('Unable to verify session. Please log in again.');
            localStorage.removeItem('user_session');
            sessionStorage.clear();
            window.location.href = './index.html';
        });
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-item');
    const pageTitle = document.getElementById('pageTitle');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            
            // Update active nav item
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Update active section
            document.querySelectorAll('.dashboard-section').forEach(s => s.classList.remove('active'));
            const targetSection = document.getElementById(section + 'Section');
            if (targetSection) {
                targetSection.classList.add('active');
            }
            
            // Update page title
            const titles = {
                'browse': 'Browse Farms',
                'bookingRequests': 'Booking Requests',
                'bookings': 'My Reservation',
                'notifications': 'Notifications'
            };
            if (pageTitle && titles[section]) {
                pageTitle.textContent = titles[section];
            }
            
            // Close sidebar on mobile after navigation
            if (window.innerWidth <= 1024) {
                document.getElementById('sidebar').classList.remove('active');
                document.getElementById('sidebarOverlay').classList.remove('active');
            }
        });
    });
}

function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closes = document.querySelectorAll('.close');
    
    closes.forEach(close => {
        close.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    window.addEventListener('click', function(e) {
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

function setMinDate() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('bookingDate').setAttribute('min', today);
    document.getElementById('editBookingDate').setAttribute('min', today);
}

async function loadFarms() {
    const container = document.getElementById('farmsContainer');
    const loading = document.getElementById('farmsLoading');
    
    if (loading) {
        container.innerHTML = '<div class="loading-spinner" id="farmsLoading"><i class="fas fa-spinner fa-spin"></i><p>Loading farms...</p></div>';
    }
    
    try {
        console.log('Fetching farms from: ./backend/user_booking.php?action=get_farms');
        const response = await fetch('./backend/user_booking.php?action=get_farms', {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Accept': 'application/json'
            }
        });
        
        console.log('Response status:', response.status);
        console.log('Response ok:', response.ok);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Response error:', errorText);
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
        }
        
        const responseText = await response.text();
        console.log('Response text:', responseText);
        
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('JSON parse error:', parseError);
            console.error('Response was:', responseText);
            throw new Error('Invalid JSON response from server');
        }
        
        console.log('Parsed data:', data);
        
        if (data.success && data.farms) {
            console.log('Farms loaded:', data.farms.length);
            farms = data.farms;
            displayFarms();
        } else if (data.success && (!data.farms || data.farms.length === 0)) {
            console.warn('No farms in response');
            container.innerHTML = '<div class="empty-state"><i class="fas fa-tractor"></i><h3>No Farms Available</h3><p>Please check back later.</p></div>';
        } else {
            console.error('API returned error:', data.message || 'Unknown error');
            container.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Error Loading Farms</h3><p>${data.message || 'Please check your connection and try again.'}</p></div>`;
        }
    } catch (error) {
        console.error('Error loading farms:', error);
        container.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Farms</h3><p>${error.message || 'Please check your connection and try again.'}</p><p style="font-size: 0.8em; color: #999;">Check browser console for details.</p></div>`;
    }
}

// Function to get farm image path based on farm name
function getFarmImagePath(farmName) {
    if (!farmName) {
        return './image/Green-Valley.jpg'; // Default fallback
    }
    
    // Normalize farm name for matching
    const normalizedName = farmName.toLowerCase().trim();
    
    // Map farm names to image filenames
    const imageMap = {
        'agata': 'Agata.jpg',
        'calo': 'Calo-Farm.jpg',
        'eco': 'Eco-Farm.jpg',
        'family': 'Family.jpg',
        'green valley': 'Green-Valley.jpg',
        'heritage': 'Heritage-Farm.jpg',
        'sunshine': 'MeadowFarm1.jpeg',
        'meadow': 'MeadowFarm1.jpeg',
        'tonybee': 'TonyBee.jpg',
        'tony bee': 'TonyBee.jpg'
    };
    
    // Try to find a match
    for (const [key, imageFile] of Object.entries(imageMap)) {
        if (normalizedName.includes(key)) {
            return `./image/${imageFile}`;
        }
    }
    
    // If no match found, try to construct filename from farm name
    // Remove common words and normalize
    let imageName = normalizedName
        .replace(/\s+(farm|farms|nature|mines|del|norte|paradise|fun|valley|meadows|meadow)\s+/gi, ' ')
        .replace(/\s+/g, '-')
        .replace(/[^a-z0-9-]/g, '')
        .trim();
    
    // Try with .jpg extension first (most common)
    if (imageName) {
        return `./image/${imageName}.jpg`;
    }
    
    // Final fallback
    return './image/Green-Valley.jpg';
}

function displayFarms() {
    const container = document.getElementById('farmsContainer');
    
    if (!farms || farms.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-tractor"></i><h3>No Farms Available</h3><p>Please check back later.</p></div>';
        return;
    }
    
    // Default fallback image
    const defaultImage = './image/Green-Valley.jpg';
    
    container.innerHTML = '';
    
    farms.forEach((farm, index) => {
        const card = document.createElement('div');
        card.className = 'farm-card';
        // Use image_url if provided, otherwise get image based on farm name
        const farmImage = farm.image_url || getFarmImagePath(farm.name);
        
        card.innerHTML = `
            <div class="farm-image-container">
                <img src="${farmImage}" alt="${escapeHtml(farm.name)}" class="farm-image" 
                     onerror="this.src='${defaultImage}'">
                <div class="farm-overlay">
                    <span class="farm-badge"><i class="fas fa-tractor"></i> Farm</span>
                </div>
            </div>
            <div class="farm-card-content">
                <h3><i class="fas fa-seedling"></i> ${escapeHtml(farm.name)}</h3>
                <p class="farm-description">${farm.description ? escapeHtml(farm.description.substring(0, 120)) + (farm.description.length > 120 ? '...' : '') : 'Experience the beauty of nature and farm life.'}</p>
                <div class="pricing-info">
                    <h4><i class="fas fa-coins"></i> Pricing</h4>
                    <div class="pricing-list">
                        <div class="pricing-item"><span>Child:</span> <strong>₱${parseFloat(farm.pricing_child || 0).toFixed(2)}</strong></div>
                        <div class="pricing-item"><span>Teen:</span> <strong>₱${parseFloat(farm.pricing_teen || 0).toFixed(2)}</strong></div>
                        <div class="pricing-item"><span>Adult:</span> <strong>₱${parseFloat(farm.pricing_adult || 0).toFixed(2)}</strong></div>
                        <div class="pricing-item"><span>Pregnant:</span> <strong>₱${parseFloat(farm.pricing_pregnant || 0).toFixed(2)}</strong></div>
                        <div class="pricing-item"><span>Senior:</span> <strong>₱${parseFloat(farm.pricing_senior || 0).toFixed(2)}</strong></div>
                        <div class="pricing-item"><span>Person with Disability:</span> <strong>₱${parseFloat(farm.pricing_disabled || 0).toFixed(2)}</strong></div>
                    </div>
                </div>
                <div class="capacity-info">
                    <i class="fas fa-users"></i> Capacity: <strong>${farm.capacity || 0}</strong> people
                </div>
                <div class="action-buttons">
                    <button class="btn btn-primary" onclick="openBookingModal(${farm.id})">
                        <i class="fas fa-calendar-plus"></i> Reserve Now
                    </button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

function formatTypeDisplay(type) {
    if (!type) return 'Normal';
    const typeMap = {
        'normal': 'Normal',
        'pregnant': 'Pregnant',
        'disabled': 'Person with Disability',
        'senior': 'Senior',
        'teen': 'Teen',
        'child': 'Child'
    };
    return typeMap[type.toLowerCase()] || escapeHtml(type);
}

function openBookingModal(farmId) {
    currentFarm = farms.find(f => f.id == farmId);
    if (!currentFarm) return;
    
    document.getElementById('bookingFarmId').value = farmId;
    document.getElementById('bookingForm').reset();
    document.getElementById('companionsContainer').innerHTML = '';
    document.getElementById('totalPrice').textContent = '₱0.00';
    const errorDiv = document.getElementById('bookingErrorMessage');
    if (errorDiv) {
        errorDiv.classList.remove('show');
    }
    
    document.getElementById('bookingModal').style.display = 'block';
    calculatePrice();
}

function closeBookingModal() {
    document.getElementById('bookingModal').style.display = 'none';
}

function closeEditBookingModal() {
    document.getElementById('editBookingModal').style.display = 'none';
}

function closeCancelBookingModal() {
    document.getElementById('cancelBookingModal').style.display = 'none';
    document.getElementById('cancelReason').value = '';
}

function updateCompanionsForm() {
    const count = parseInt(document.getElementById('companionsCount').value) || 0;
    const container = document.getElementById('companionsContainer');
    container.innerHTML = '';
    
    for (let i = 0; i < count; i++) {
        const companionDiv = document.createElement('div');
        companionDiv.className = 'companion-item';
        companionDiv.innerHTML = `
            <h4><i class="fas fa-user"></i> Companion ${i + 1}</h4>
            <div class="form-group">
                <label><i class="fas fa-user"></i> Name *</label>
                <input type="text" class="companion-name" placeholder="Enter companion name" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-birthday-cake"></i> Age *</label>
                    <input type="number" class="companion-age" min="1" max="120" placeholder="Enter age" required oninput="calculatePrice()">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-venus-mars"></i> Gender*</label>
                    <select class="companion-sex" required>
                        <option value="">Select</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label><i class="fas fa-tag"></i> Type *</label>
                <select class="companion-type" required onchange="calculatePrice()">
                    <option value="">Select</option>
                    <option value="normal">Normal</option>
                    <option value="pregnant">Pregnant</option>
                    <option value="disabled">Person with Disability</option>
                    <option value="senior">Senior</option>
                </select>
            </div>
        `;
        container.appendChild(companionDiv);
    }
    
    calculatePrice();
}

function calculatePrice() {
    if (!currentFarm) return;
    
    const age = parseInt(document.getElementById('bookingAge').value) || 0;
    const type = document.getElementById('bookingType') ? document.getElementById('bookingType').value : 'normal';
    const companions = [];
    
    document.querySelectorAll('.companion-item').forEach(item => {
        const compName = item.querySelector('.companion-name').value.trim();
        const compAge = parseInt(item.querySelector('.companion-age').value) || 0;
        const compSex = item.querySelector('.companion-sex').value;
        const compType = item.querySelector('.companion-type').value;
        companions.push({ 
            name: compName, 
            age: compAge, 
            sex: compSex, 
            type: compType 
        });
    });
    
    // Calculate main price based on type first, then age
    let mainPrice = 0;
    if (type === 'pregnant') {
        mainPrice = parseFloat(currentFarm.pricing_pregnant);
    } else if (type === 'disabled') {
        mainPrice = parseFloat(currentFarm.pricing_disabled);
    } else if (age < 13) {
        mainPrice = parseFloat(currentFarm.pricing_child);
    } else if (age < 18) {
        mainPrice = parseFloat(currentFarm.pricing_teen);
    } else if (age >= 65) {
        mainPrice = parseFloat(currentFarm.pricing_senior);
    } else {
        mainPrice = parseFloat(currentFarm.pricing_adult);
    }
    
    // Calculate companions price
    let companionsPrice = 0;
    companions.forEach(comp => {
        if (comp.type === 'pregnant') {
            companionsPrice += parseFloat(currentFarm.pricing_pregnant);
        } else if (comp.type === 'disabled') {
            companionsPrice += parseFloat(currentFarm.pricing_disabled);
        } else if (comp.age < 13) {
            companionsPrice += parseFloat(currentFarm.pricing_child);
        } else if (comp.age < 18) {
            companionsPrice += parseFloat(currentFarm.pricing_teen);
        } else if (comp.age >= 65) {
            companionsPrice += parseFloat(currentFarm.pricing_senior);
        } else {
            companionsPrice += parseFloat(currentFarm.pricing_adult);
        }
    });
    
    const total = mainPrice + companionsPrice;
    document.getElementById('totalPrice').textContent = '₱' + total.toFixed(2);
}

async function handleBookingSubmit(e) {
    if (e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    console.log('=== handleBookingSubmit called! ===');
    
    const errorDiv = document.getElementById('bookingErrorMessage');
    if (errorDiv) {
        errorDiv.classList.remove('show');
        errorDiv.textContent = '';
    } else {
        console.error('Error div not found!');
    }
    
    // Validate all required fields
    const fullName = document.getElementById('bookingFullName').value.trim();
    const age = parseInt(document.getElementById('bookingAge').value);
    const gender = document.getElementById('bookingGender').value;
    const nationality = document.getElementById('bookingNationality').value.trim();
    const maritalStatus = document.getElementById('bookingMaritalStatus').value;
    const type = document.getElementById('bookingType') ? document.getElementById('bookingType').value : '';
    const bookingDate = document.getElementById('bookingDate').value;
    const farmId = document.getElementById('bookingFarmId').value;
    
    if (!fullName) {
        errorDiv.textContent = 'Please enter your full name';
        errorDiv.classList.add('show');
        return;
    }
    
    if (!age || age < 1 || age > 120) {
        errorDiv.textContent = 'Please enter a valid age (1-120)';
        errorDiv.classList.add('show');
        return;
    }
    
    if (!gender) {
        errorDiv.textContent = 'Please select your gender';
        errorDiv.classList.add('show');
        return;
    }
    
    if (!nationality) {
        errorDiv.textContent = 'Please enter your nationality';
        errorDiv.classList.add('show');
        return;
    }
    
    if (!maritalStatus) {
        errorDiv.textContent = 'Please select your marital status';
        errorDiv.classList.add('show');
        return;
    }
    
    if (!type) {
        errorDiv.textContent = 'Please select your type';
        errorDiv.classList.add('show');
        return;
    }
    
    if (!bookingDate) {
        errorDiv.textContent = 'Please select a booking date';
        errorDiv.classList.add('show');
        return;
    }
    
    if (!farmId || !currentFarm) {
        errorDiv.textContent = 'Please select a farm';
        errorDiv.classList.add('show');
        return;
    }
    
    const companions = [];
    
    // Validate and collect companion data
    const companionItems = document.querySelectorAll('.companion-item');
    for (let item of companionItems) {
        const compName = item.querySelector('.companion-name').value.trim();
        const compAge = parseInt(item.querySelector('.companion-age').value) || 0;
        const compSex = item.querySelector('.companion-sex').value;
        const compType = item.querySelector('.companion-type').value;
        
        // Validate companion fields
        if (!compName || !compAge || !compSex || !compType) {
            errorDiv.textContent = 'Please fill in all companion details (name, age, sex, type) for all companions';
            errorDiv.classList.add('show');
            return;
        }
        
        companions.push({ 
            name: compName, 
            age: compAge, 
            sex: compSex, 
            type: compType 
        });
    }
    
    const companionsCount = companions.length;
    const totalPeople = 1 + companionsCount;
    
    if (totalPeople > currentFarm.capacity) {
        errorDiv.textContent = `Booking exceeds farm capacity of ${currentFarm.capacity} people`;
        errorDiv.classList.add('show');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'create_booking');
    formData.append('farm_id', farmId);
    formData.append('full_name', fullName);
    formData.append('age', age);
    formData.append('gender', gender);
    formData.append('nationality', nationality);
    formData.append('marital_status', maritalStatus);
    formData.append('type', type);
    formData.append('companions_count', companionsCount);
    formData.append('companions_details', JSON.stringify(companions));
    formData.append('booking_date', bookingDate);
    
    // Log form data being sent
    console.log('=== BOOKING SUBMISSION DEBUG ===');
    console.log('Farm ID:', farmId);
    console.log('Full Name:', fullName);
    console.log('Age:', age);
    console.log('Gender:', gender);
    console.log('Nationality:', nationality);
    console.log('Marital Status:', maritalStatus);
    console.log('Companions Count:', companionsCount);
    console.log('Booking Date:', bookingDate);
    console.log('Current Farm:', currentFarm);
    
    // Show loading state
    const submitButton = document.getElementById('confirmBookingBtn') || document.querySelector('#bookingForm button[type="submit"]') || document.querySelector('#bookingForm button[type="button"]');
    const originalButtonText = submitButton ? submitButton.innerHTML : '';
    if (submitButton) {
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    }
    
    try {
        console.log('Sending request to: ./backend/user_booking.php');
        const response = await fetch('./backend/user_booking.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        
        console.log('Response status:', response.status);
        console.log('Response ok:', response.ok);
        
        const responseText = await response.text();
        console.log('Raw response length:', responseText.length);
        console.log('Raw response:', responseText);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('JSON parse error:', parseError);
            console.error('Response was:', responseText);
            errorDiv.textContent = 'Invalid response from server: ' + responseText.substring(0, 100);
            errorDiv.classList.add('show');
            return;
        }
        
        console.log('Booking response:', data);
        
        if (data.success) {
            console.log('✅ Booking created successfully!');
            alert('Booking request created successfully! Waiting for admin approval.');
            
            // Close modal
            const modal = document.getElementById('bookingModal');
            if (modal) {
                modal.style.display = 'none';
            }
            
            // Reset form
            const form = document.getElementById('bookingForm');
            if (form) {
                form.reset();
            }
            const companionsContainer = document.getElementById('companionsContainer');
            if (companionsContainer) {
                companionsContainer.innerHTML = '';
            }
            
            // Reload data
            await loadBookingRequests();
            await loadFarms(); // Refresh farms to show updated capacity
            
            // Navigate to Booking Requests tab
            setTimeout(function() {
                const bookingRequestsNav = document.querySelector('.nav-item[data-section="bookingRequests"]');
                if (bookingRequestsNav) {
                    console.log('Navigating to Booking Requests tab...');
                    bookingRequestsNav.click();
                } else {
                    console.error('Booking Requests nav item not found');
                }
            }, 500);
        } else {
            errorDiv.textContent = data.message || 'Failed to create booking';
            errorDiv.classList.add('show');
            console.error('Booking failed:', data.message);
            console.error('Full error response:', data);
        }
    } catch (error) {
        errorDiv.textContent = 'An error occurred: ' + error.message;
        errorDiv.classList.add('show');
        console.error('Booking error:', error);
        console.error('Error stack:', error.stack);
    } finally {
        // Restore button state
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.innerHTML = originalButtonText;
        }
        console.log('=== END BOOKING SUBMISSION DEBUG ===');
    }
}

async function loadBookingRequests() {
    const container = document.getElementById('bookingRequestsContainer');
    
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading booking requests...</p></div>';
    
    try {
        const response = await fetch('./backend/user_booking.php?action=get_booking_requests', {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const responseText = await response.text();
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('JSON parse error:', parseError);
            console.error('Response was:', responseText);
            container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Booking Requests</h3><p>Invalid response from server.</p></div>';
            return;
        }
        
        console.log('Booking requests loaded:', data);
        
        if (data.success && data.bookings) {
            bookingRequests = data.bookings;
            displayBookingRequests(bookingRequests);
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-clock"></i><h3>No Pending Requests</h3><p>You don\'t have any pending booking requests.</p></div>';
        }
    } catch (error) {
        console.error('Error loading booking requests:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Booking Requests</h3><p>Please check your connection and try again.</p></div>';
    }
}

async function loadBookings() {
    const container = document.getElementById('bookingsContainer');
    
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p>Loading bookings...</p></div>';
    
    try {
        const response = await fetch('./backend/user_booking.php?action=get_bookings');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.bookings) {
            // Filter to show only accepted bookings (not pending or cancelled)
            const acceptedBookings = data.bookings.filter(b => b.status === 'accepted' || b.status === 'pending_cancellation');
            bookings = acceptedBookings;
            displayBookings();
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Reservation Found</h3><p>You don\'t have any accepted reservation yet.</p></div>';
        }
    } catch (error) {
        console.error('Error loading bookings:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><h3>Error Loading Reservations</h3><p>Please check your connection and try again.</p></div>';
    }
}

function displayBookingRequests(bookingRequests) {
    const container = document.getElementById('bookingRequestsContainer');
    
    if (!bookingRequests || bookingRequests.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-clock"></i><h3>No Pending Requests</h3><p>You don\'t have any pending booking requests.</p></div>';
        return;
    }
    
    let html = `
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Farm</th>
                        <th>Full Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Nationality</th>
                        <th>Marital Status</th>
                        <th>Booking Date</th>
                        <th>Companions</th>
                        <th>Total Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    bookingRequests.forEach(booking => {
        const isPendingCancellation = booking.status === 'pending_cancellation';
        html += `
            <tr>
                <td><span class="status-badge ${booking.status || 'pending'}">${isPendingCancellation ? 'CANCELLATION PENDING' : (booking.status || 'pending').toUpperCase()}</span></td>
                <td>${escapeHtml(booking.farm_name || 'N/A')}</td>
                <td>${escapeHtml(booking.full_name || 'N/A')}</td>
                <td>${booking.age || 'N/A'}</td>
                <td>${escapeHtml(booking.gender || 'N/A')}</td>
                <td>${escapeHtml(booking.nationality || 'N/A')}</td>
                <td>${escapeHtml(booking.marital_status || 'N/A')}</td>
                <td>${booking.booking_date || 'N/A'}</td>
                <td>${renderCompanionsCell(booking.companions_count, 'requests', booking.id)}</td>
                <td><strong>₱${parseFloat(booking.total_price || 0).toFixed(2)}</strong></td>
                <td>
                    <div class="action-buttons">
                        ${!isPendingCancellation ? `
                        <button class="btn btn-secondary btn-sm" onclick="openEditBookingModal(${booking.id}, 'requests')" title="Edit">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="openCancelBookingModal(${booking.id}, 'requests')" title="Cancel">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        ` : `
                        <span class="status-badge pending">Awaiting admin approval</span>
                        `}
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = html;
}

function displayBookings() {
    const container = document.getElementById('bookingsContainer');
    
    if (!bookings || bookings.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No Reservations Found</h3><p>You don\'t have any accepted reservation yet.</p></div>';
        return;
    }
    
    let html = `
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Farm</th>
                        <th>Full Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Nationality</th>
                        <th>Marital Status</th>
                        <th>Booking Date</th>
                        <th>Companions</th>
                        <th>Total Price</th>
                        <th>Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    bookings.forEach(booking => {
        const isPendingCancellation = booking.status === 'pending_cancellation';
        const companionsCount = booking.companions_count || 0;
        const notes = isPendingCancellation && booking.cancellation_reason
            ? escapeHtml(booking.cancellation_reason)
            : (booking.status || 'accepted').toUpperCase();
        
        html += `
            <tr>
                <td><span class="status-badge ${booking.status || 'accepted'}">${isPendingCancellation ? 'CANCELLATION PENDING' : (booking.status || 'accepted').toUpperCase()}</span></td>
                <td>${escapeHtml(booking.farm_name || 'N/A')}</td>
                <td>${escapeHtml(booking.full_name || 'N/A')}</td>
                <td>${booking.age || 'N/A'}</td>
                <td>${escapeHtml(booking.gender || 'N/A')}</td>
                <td>${escapeHtml(booking.nationality || 'N/A')}</td>
                <td>${escapeHtml(booking.marital_status || 'N/A')}</td>
                <td>${booking.booking_date || 'N/A'}</td>
                <td>${renderCompanionsCell(companionsCount, 'bookings', booking.id)}</td>
                <td><strong>₱${parseFloat(booking.total_price || 0).toFixed(2)}</strong></td>
                <td>${notes}</td>
                <td>
                    ${!isPendingCancellation ? `
                        <button class="btn btn-danger btn-sm" onclick="openCancelBookingModal(${booking.id}, 'bookings')" title="Cancel">
                            <i class="fas fa-times"></i> Cancel Booking
                        </button>
                    ` : `
                        <span class="status-badge pending">Awaiting approval</span>
                    `}
                </td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = html;
}

function renderCompanionsCell(count = 0, source = 'bookings', bookingId) {
    const total = parseInt(count, 10) || 0;
    if (total <= 0) {
        return '0';
    }
    return `
        <button class="btn btn-link companion-link" onclick="openCompanionDetails('${source}', ${bookingId})" title="View companions">
            ${total}
        </button>
    `;
}

function openCompanionDetails(source, bookingId) {
    const list = source === 'requests' ? bookingRequests : bookings;
    const booking = list.find(b => Number(b.id) === Number(bookingId));
    const container = document.getElementById('companionInfoContainer');
    let companions = [];
    
    if (booking && booking.companions_details) {
        try {
            companions = JSON.parse(booking.companions_details) || [];
        } catch (error) {
            console.error('Error parsing companions:', error);
        }
    }
    
    if (!companions || companions.length === 0) {
        container.innerHTML = '<p>No companion details provided for this booking.</p>';
    } else {
        const rows = companions.map((comp, index) => `
            <tr>
                <td>${index + 1}</td>
                <td>${escapeHtml(comp.name || 'N/A')}</td>
                <td>${comp.age || 'N/A'}</td>
                <td>${escapeHtml(comp.sex || 'N/A')}</td>
                <td>${formatTypeDisplay(comp.type || 'normal')}</td>
            </tr>
        `).join('');
        
        container.innerHTML = `
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows}
                    </tbody>
                </table>
            </div>
        `;
    }
    
    document.getElementById('companionInfoModal').style.display = 'block';
}

function closeCompanionModal() {
    document.getElementById('companionInfoModal').style.display = 'none';
}

function openEditBookingModal(bookingId, source = 'bookings') {
    const list = source === 'requests' ? bookingRequests : bookings;
    currentBooking = list.find(b => b.id == bookingId);
    if (!currentBooking) return;
    
    document.getElementById('editBookingId').value = bookingId;
    document.getElementById('editFullName').value = currentBooking.full_name;
    document.getElementById('editAge').value = currentBooking.age;
    document.getElementById('editGender').value = currentBooking.gender;
    document.getElementById('editNationality').value = currentBooking.nationality;
    document.getElementById('editMaritalStatus').value = currentBooking.marital_status;
    if (document.getElementById('editType')) {
        document.getElementById('editType').value = currentBooking.type || 'normal';
    }
    document.getElementById('editBookingDate').value = currentBooking.booking_date;
    document.getElementById('editCompanionsCount').value = currentBooking.companions_count || 0;
    
    const companions = currentBooking.companions_details ? JSON.parse(currentBooking.companions_details) : [];
    updateEditCompanionsForm(companions);
    
    document.getElementById('editBookingModal').style.display = 'block';
    calculateEditPrice();
}

function updateEditCompanionsForm(existingCompanions = []) {
    const count = parseInt(document.getElementById('editCompanionsCount').value) || 0;
    const container = document.getElementById('editCompanionsContainer');
    container.innerHTML = '';
    
    for (let i = 0; i < count; i++) {
        const companion = existingCompanions[i] || {};
        const companionDiv = document.createElement('div');
        companionDiv.className = 'companion-item';
        companionDiv.innerHTML = `
            <h4>Companion ${i + 1}</h4>
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="edit-companion-name" value="${escapeHtml(companion.name || '')}" oninput="calculateEditPrice()">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Age</label>
                    <input type="number" class="edit-companion-age" min="1" max="120" value="${companion.age || ''}" oninput="calculateEditPrice()">
                </div>
                <div class="form-group">
                    <label>Gender</label>
                    <select class="edit-companion-sex" onchange="calculateEditPrice()">
                        <option value="">Select</option>
                        <option value="male" ${companion.sex === 'male' ? 'selected' : ''}>Male</option>
                        <option value="female" ${companion.sex === 'female' ? 'selected' : ''}>Female</option>
                        <option value="other" ${companion.sex === 'other' ? 'selected' : ''}>Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Type</label>
                    <select class="edit-companion-type" onchange="calculateEditPrice()">
                        <option value="normal" ${companion.type === 'normal' ? 'selected' : ''}>Normal</option>
                        <option value="pregnant" ${companion.type === 'pregnant' ? 'selected' : ''}>Pregnant</option>
                        <option value="disabled" ${companion.type === 'disabled' ? 'selected' : ''}>Person with Disability</option>
                    </select>
                </div>
            </div>
        `;
        container.appendChild(companionDiv);
    }
    
    calculateEditPrice();
}

function calculateEditPrice() {
    if (!currentBooking) return;
    
    const farm = farms.find(f => f.id == currentBooking.farm_id);
    if (!farm) return;
    
    const age = parseInt(document.getElementById('editAge').value) || 0;
    const type = document.getElementById('editType') ? document.getElementById('editType').value : 'normal';
    const companions = [];
    
    document.querySelectorAll('#editCompanionsContainer .companion-item').forEach(item => {
        const compName = item.querySelector('.edit-companion-name').value.trim();
        const compAge = parseInt(item.querySelector('.edit-companion-age').value) || 0;
        const compSex = item.querySelector('.edit-companion-sex').value;
        const compType = item.querySelector('.edit-companion-type').value;
        companions.push({ 
            name: compName, 
            age: compAge, 
            sex: compSex, 
            type: compType 
        });
    });
    
    // Calculate main price based on type first, then age
    let mainPrice = 0;
    if (type === 'pregnant') {
        mainPrice = parseFloat(farm.pricing_pregnant);
    } else if (type === 'disabled') {
        mainPrice = parseFloat(farm.pricing_disabled);
    } else if (age < 13) {
        mainPrice = parseFloat(farm.pricing_child);
    } else if (age < 18) {
        mainPrice = parseFloat(farm.pricing_teen);
    } else if (age >= 65) {
        mainPrice = parseFloat(farm.pricing_senior);
    } else {
        mainPrice = parseFloat(farm.pricing_adult);
    }
    
    // Calculate companions price
    let companionsPrice = 0;
    companions.forEach(comp => {
        if (comp.type === 'pregnant') {
            companionsPrice += parseFloat(farm.pricing_pregnant);
        } else if (comp.type === 'disabled') {
            companionsPrice += parseFloat(farm.pricing_disabled);
        } else if (comp.age < 13) {
            companionsPrice += parseFloat(farm.pricing_child);
        } else if (comp.age < 18) {
            companionsPrice += parseFloat(farm.pricing_teen);
        } else if (comp.age >= 65) {
            companionsPrice += parseFloat(farm.pricing_senior);
        } else {
            companionsPrice += parseFloat(farm.pricing_adult);
        }
    });
    
    const total = mainPrice + companionsPrice;
    document.getElementById('editTotalPrice').textContent = '₱' + total.toFixed(2);
}

async function handleEditBookingSubmit(e) {
    e.preventDefault();
    
    const errorDiv = document.getElementById('editErrorMessage');
    errorDiv.classList.remove('show');
    
    const bookingId = document.getElementById('editBookingId').value;
    const companions = [];
    
    // Validate and collect companion data
    const companionItems = document.querySelectorAll('#editCompanionsContainer .companion-item');
    for (let item of companionItems) {
        const compName = item.querySelector('.edit-companion-name').value.trim();
        const compAge = parseInt(item.querySelector('.edit-companion-age').value) || 0;
        const compSex = item.querySelector('.edit-companion-sex').value;
        const compType = item.querySelector('.edit-companion-type').value;
        
        // Validate companion fields
        if (!compName || !compAge || !compSex || !compType) {
            errorDiv.textContent = 'Please fill in all companion details (name, age, sex, type) for all companions';
            errorDiv.classList.add('show');
            return;
        }
        
        companions.push({ 
            name: compName, 
            age: compAge, 
            sex: compSex, 
            type: compType 
        });
    }
    
    const companionsCount = companions.length;
    const farm = farms.find(f => f.id == currentBooking.farm_id);
    const totalPeople = 1 + companionsCount;
    
    if (totalPeople > farm.capacity) {
        errorDiv.textContent = `Booking exceeds farm capacity of ${farm.capacity} people`;
        errorDiv.classList.add('show');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'update_booking');
    formData.append('booking_id', bookingId);
    formData.append('full_name', document.getElementById('editFullName').value);
    formData.append('age', document.getElementById('editAge').value);
    formData.append('gender', document.getElementById('editGender').value);
    formData.append('nationality', document.getElementById('editNationality').value);
    formData.append('marital_status', document.getElementById('editMaritalStatus').value);
    formData.append('type', document.getElementById('editType') ? document.getElementById('editType').value : 'normal');
    formData.append('companions_count', companionsCount);
    formData.append('companions_details', JSON.stringify(companions));
    formData.append('booking_date', document.getElementById('editBookingDate').value);
    
    try {
        const response = await fetch('./backend/user_booking.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Booking updated successfully!');
            document.getElementById('editBookingModal').style.display = 'none';
            loadBookingRequests();
            loadBookings();
        } else {
            errorDiv.textContent = data.message || 'Failed to update booking';
            errorDiv.classList.add('show');
        }
    } catch (error) {
        errorDiv.textContent = 'An error occurred. Please try again.';
        errorDiv.classList.add('show');
        console.error('Update booking error:', error);
    }
}

function openCancelBookingModal(bookingId, source = 'bookings') {
    document.getElementById('cancelBookingId').value = bookingId;
    document.getElementById('cancelBookingSource').value = source;
    document.getElementById('cancelReason').value = '';
    const errorDiv = document.getElementById('cancelErrorMessage');
    if (errorDiv) {
        errorDiv.classList.remove('show');
    }
    document.getElementById('cancelBookingModal').style.display = 'block';
}

async function handleCancelBookingSubmit(e) {
    e.preventDefault();
    
    const errorDiv = document.getElementById('cancelErrorMessage');
    errorDiv.classList.remove('show');
    
    const bookingId = document.getElementById('cancelBookingId').value;
    const reason = document.getElementById('cancelReason').value.trim();
    
    if (!reason) {
        errorDiv.textContent = 'Please provide a reason for cancellation';
        errorDiv.classList.add('show');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'request_cancellation');
    formData.append('booking_id', bookingId);
    formData.append('cancellation_reason', reason);
    
    try {
        const response = await fetch('./backend/user_booking.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cancellation request submitted. Waiting for admin approval.');
            document.getElementById('cancelBookingModal').style.display = 'none';
            loadBookingRequests();
            loadBookings();
        } else {
            errorDiv.textContent = data.message || 'Failed to submit cancellation request';
            errorDiv.classList.add('show');
        }
    } catch (error) {
        errorDiv.textContent = 'An error occurred. Please try again.';
        errorDiv.classList.add('show');
        console.error('Cancel booking error:', error);
    }
}

async function loadNotifications() {
    const loading = document.getElementById('notificationsLoading');
    const sectionContainer = document.getElementById('notificationsSectionList');
    const panelContainer = document.getElementById('notificationsList');

    if (loading) loading.style.display = 'flex';
    if (sectionContainer) sectionContainer.style.display = 'none';
    if (panelContainer) panelContainer.style.display = 'none';

    try {
        const response = await fetch('./backend/notifications.php?action=get_notifications&role=user', {
            credentials: 'same-origin'
        });
        const data = await response.json();
        
        if (data.success) {
            // Ensure notifications are sorted by most recent first (by created_at DESC)
            const sortedNotifications = data.notifications.sort((a, b) => {
                const dateA = new Date(a.created_at);
                const dateB = new Date(b.created_at);
                return dateB - dateA; // Most recent first
            });
            displayNotifications(sortedNotifications);
            
            const unreadCount = sortedNotifications.filter(n => !n.is_read).length;
            document.getElementById('notificationCount').textContent = unreadCount;
        } else {
            displayNotifications([]);
            console.error('Notifications error:', data.message);
        }
    } catch (error) {
        console.error('Error loading notifications:', error);
        if (sectionContainer) {
            sectionContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-triangle-exclamation"></i>
                    <h3>Unable to load notifications</h3>
                    <p>Please refresh the page or try again later.</p>
                </div>
            `;
        }
    } finally {
        if (loading) loading.style.display = 'none';
        if (sectionContainer) sectionContainer.style.display = 'block';
        if (panelContainer) panelContainer.style.display = 'block';
    }
}

function displayNotifications(notifications) {
    const panelContainer = document.getElementById('notificationsList');
    const sectionContainer = document.getElementById('notificationsSectionList');
    
    if (panelContainer) panelContainer.innerHTML = '';
    if (sectionContainer) sectionContainer.innerHTML = '';
    
    if (!notifications.length) {
        if (panelContainer) panelContainer.innerHTML = '<p>No notifications yet</p>';
        if (sectionContainer) {
            sectionContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <h3>No Notifications</h3>
                    <p>You\'ll see booking updates here.</p>
                </div>
            `;
        }
        return;
    }
    
    const createNotificationElement = (notification) => {
        const wrapper = document.createElement('div');
        wrapper.className = 'notification-item' + (notification.is_read ? '' : ' unread');
        wrapper.innerHTML = `
            <div class="notification-message">${notification.message}</div>
            <div class="notification-time">${new Date(notification.created_at).toLocaleString()}</div>
        `;
        wrapper.addEventListener('click', () => markNotificationRead(notification.id));
        return wrapper;
    };
    
    notifications.forEach(notification => {
        if (panelContainer) panelContainer.appendChild(createNotificationElement(notification));
        if (sectionContainer) sectionContainer.appendChild(createNotificationElement(notification));
    });
}

async function markNotificationRead(notificationId) {
    const formData = new FormData();
    formData.append('action', 'mark_read');
    formData.append('notification_id', notificationId);
    formData.append('role', 'user');
    
    try {
        await fetch('./backend/notifications.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        loadNotifications();
    } catch (error) {
        console.error('Error marking notification as read:', error);
    }
}

async function markAllNotificationsRead() {
    const formData = new FormData();
    formData.append('action', 'mark_all_read');
    formData.append('role', 'user');
    
    try {
        await fetch('./backend/notifications.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        loadNotifications();
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
    }
}

// Logout function - Make sure it's globally accessible
function logout() {
    if (confirm('Are you sure you want to logout from user dashboard?')) {
        // Remove only user session from localStorage
        localStorage.removeItem('user_session');
        
        // Clear current session storage
        sessionStorage.clear();
        
        // Logout from PHP session (user only)
        const formData = new FormData();
        formData.append('action', 'logout');
        formData.append('role', 'user');
        
        fetch('./backend/auth.php', {
            method: 'POST',
            body: formData
        })
        .then(() => {
            // Redirect to login page
            window.location.href = './index.html';
        })
        .catch(error => {
            console.error('Logout error:', error);
            // Still redirect to login page
            window.location.href = './index.html';
        });
    }
}

// Make logout function globally accessible
window.logout = logout;


