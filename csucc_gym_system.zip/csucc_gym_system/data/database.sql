-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2025 at 04:06 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `fullname` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password_hash`, `fullname`, `email`, `created_at`) VALUES
(1, 'admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'System Administrator', 'admin@csucc.edu', '2025-11-23 07:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` bigint(20) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `start_date` date NOT NULL,
  `start_time` varchar(20) NOT NULL,
  `end_date` date NOT NULL,
  `end_time` varchar(20) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `created_by` varchar(120) NOT NULL DEFAULT 'Admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `message`, `start_date`, `start_time`, `end_date`, `end_time`, `duration_days`, `created_by`, `created_at`) VALUES
(1, 'GYM MAINTENANCE', 'DI MAGAMIT', '2025-11-24', '15:26', '2025-11-24', '16:26', 1, 'Admin', '2025-11-23 07:26:52');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) NOT NULL,
  `actor_type` enum('Admin','Faculty','GenServe','System') NOT NULL,
  `actor_name` varchar(120) NOT NULL,
  `action` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `actor_type`, `actor_name`, `action`, `created_at`) VALUES
(1, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 07:21:53'),
(2, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 07:22:38'),
(3, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 07:24:21'),
(4, 'System', 'Admin', 'Announcement sent to ki: GYM MAINTENANCE', '2025-11-23 07:26:52'),
(5, 'System', 'Admin', 'Announcement sent to jelyn: GYM MAINTENANCE', '2025-11-23 07:26:52'),
(6, 'System', 'Admin', 'Announcement sent to jena: GYM MAINTENANCE', '2025-11-23 07:26:52'),
(7, 'System', 'Admin', 'Announcement sent to Jena Ytac: GYM MAINTENANCE', '2025-11-23 07:26:52'),
(8, 'System', 'Admin', 'Announcement sent to oswing: GYM MAINTENANCE', '2025-11-23 07:26:52'),
(9, 'System', 'Admin', 'Announcement sent to jen: GYM MAINTENANCE', '2025-11-23 07:26:52'),
(10, 'System', 'Admin', 'Announcement sent to Jena: GYM MAINTENANCE', '2025-11-23 07:26:52'),
(11, 'System', 'Admin', 'Announcement sent to Jhon Louie Sanrojo: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(12, 'System', 'Admin', 'Announcement sent to Lowi: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(13, 'System', 'Admin', 'Announcement sent to Louie: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(14, 'System', 'Admin', 'Announcement sent to Corinne: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(15, 'System', 'Admin', 'Announcement sent to Kian: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(16, 'System', 'Admin', 'Announcement sent to Jhon: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(17, 'System', 'Admin', 'Announcement sent to Jelyn: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(18, 'System', 'Admin', 'Announcement sent to Jelyn: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(19, 'System', 'Admin', 'Announcement sent to Rica: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(20, 'System', 'Admin', 'Announcement sent to Rica: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(21, 'System', 'Admin', 'Announcement sent to Jona: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(22, 'System', 'Admin', 'Announcement sent to Jhon: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(23, 'System', 'Admin', 'Announcement sent to Jen: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(24, 'System', 'Admin', 'Announcement sent to Mara: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(25, 'System', 'Admin', 'Announcement sent to Lowi: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(26, 'System', 'Admin', 'Announcement sent to Lowi: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(27, 'System', 'Admin', 'Announcement sent to Wawa: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(28, 'System', 'Admin', 'Announcement sent to Joel Jan Ytac: GYM MAINTENANCE', '2025-11-23 07:26:53'),
(29, 'Faculty', 'Joel Jan Ytac', 'Reserved 1 LED for 2025-11-25', '2025-11-23 07:27:46'),
(30, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 07:29:17'),
(31, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 08:13:38'),
(32, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 08:24:09'),
(33, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 08:26:38'),
(34, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 08:31:34'),
(35, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 08:44:08'),
(36, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 08:47:52'),
(37, 'Faculty', 'Joel Jan Ytac', 'Reserved 2 Large Electric Fans for 2025-11-24', '2025-11-23 09:01:00'),
(38, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 09:22:12'),
(39, 'Admin', 'Admin', 'Edited faculty account: yan', '2025-11-23 09:27:09'),
(40, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 09:29:53'),
(41, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 09:31:54'),
(42, 'Admin', 'Admin', 'Edited faculty account: yan', '2025-11-23 09:32:10'),
(43, 'Admin', 'Admin', 'Deleted faculty account: yan (kikiki2)', '2025-11-23 09:32:29'),
(44, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 09:42:18'),
(45, 'Faculty', 'Jena', 'Logged in successfully', '2025-11-23 09:46:10'),
(46, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 09:46:26'),
(47, 'Admin', 'Admin', 'Added 10 Large Electric Fans: 0→10', '2025-11-23 09:49:47'),
(48, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 09:50:03'),
(49, 'Admin', 'Admin', 'Added 10 Large Electric Fans: 0→10', '2025-11-23 09:51:07'),
(50, 'System', 'GenServe Administrator', 'Added 10 Large Electric Fans (Power & Ventilation): 0/4 → 10/14', '2025-11-23 09:57:34'),
(51, 'System', 'GenServe Administrator', 'Added 10 Large Electric Fans (Power & Ventilation): 0/4 → 10/14', '2025-11-23 10:03:52'),
(52, 'Faculty', 'Jena', 'Reserved 10 Large Electric Fans for 2025-11-24', '2025-11-23 10:05:51'),
(53, 'Admin', 'Admin', 'Added 10 LED: 3→13', '2025-11-23 10:10:41'),
(54, 'System', 'GenServe Administrator', 'Added 5 Large Electric Fans (Power & Ventilation): 10/14 → 15/19', '2025-11-23 10:13:31'),
(55, 'Faculty', 'Jena', 'Reserved 15 Large Electric Fans for 2025-11-24', '2025-11-23 10:14:10'),
(56, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 10:37:02'),
(57, 'System', 'GenServe Administrator', 'Added 5 Large Electric Fans (Power & Ventilation): 0/19 → 5/24', '2025-11-23 10:37:29'),
(58, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 10:38:52'),
(59, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 10:39:28'),
(60, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 10:49:21'),
(61, 'Faculty', 'Joel Jan Ytac', 'Reserved 1 LED for 2025-11-23', '2025-11-23 10:50:26'),
(62, 'Faculty', 'Joel Jan Ytac', 'Requested return of 1 LED', '2025-11-23 11:28:16'),
(63, 'System', 'GenServe Administrator', 'Cleared return: Joel Jan Ytac returned 1 LED', '2025-11-23 11:28:31'),
(64, 'Faculty', 'Joel Jan Ytac', 'Requested return of 2 Large Electric Fans', '2025-11-23 11:29:25'),
(65, 'System', 'GenServe Administrator', 'Cleared return: Joel Jan Ytac returned 2 Large Electric Fans', '2025-11-23 11:29:35'),
(66, 'Faculty', 'Joel Jan Ytac', 'Reserved 5 Chairs for 2025-11-23', '2025-11-23 11:37:58'),
(67, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 12:14:41'),
(68, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 12:15:07'),
(69, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 12:15:27'),
(70, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 12:35:01'),
(71, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 12:38:25'),
(72, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 12:40:14'),
(73, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 12:40:41'),
(74, 'Faculty', 'Joel Jan Ytac', 'Logged in successfully', '2025-11-23 13:48:33'),
(75, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-23 13:49:10'),
(76, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-23 13:49:51'),
(77, 'System', 'GenServe Administrator', 'Added 3 Large Electric Fans (Power & Ventilation): 7/24 → 10/27', '2025-11-25 02:32:28'),
(78, 'Faculty', 'Jenalyn Ytac', 'Logged in successfully', '2025-11-25 02:34:02'),
(79, 'Faculty', 'Jenalyn Ytac', 'Reserved 1 LED for 2025-11-25', '2025-11-25 02:34:22'),
(80, 'Faculty', 'Jenalyn Ytac', 'Reserved 15 LED for 2025-11-25', '2025-11-25 02:36:08'),
(81, 'GenServe', 'GenServe Administrator', 'Logged in successfully', '2025-11-25 02:36:45'),
(82, 'System', 'GenServe Administrator', 'Added 15 LED (Audio & Visual): 0/15 → 15/30', '2025-11-25 02:36:56'),
(83, 'Faculty', 'Jenalyn Ytac', 'Reserved 2 Chair Covers for 2025-11-25', '2025-11-25 02:37:28'),
(84, 'Faculty', 'Jenalyn Ytac', 'Reserved 3 LED for 2025-11-25', '2025-11-25 02:45:11'),
(85, 'Faculty', 'Jenalyn Ytac', 'Reserved 1 LED for 2025-11-25', '2025-11-25 02:48:47'),
(86, 'Faculty', 'Jenalyn Ytac', 'Reserved 1 Lights for 2025-11-26', '2025-11-25 02:49:07'),
(87, 'Faculty', 'Jenalyn Ytac', 'Reserved 1 Mics for 2025-11-25', '2025-11-25 02:50:36'),
(88, 'Admin', 'System Administrator', 'Logged in successfully', '2025-11-25 02:53:24'),
(89, 'Faculty', 'Jenalyn Ytac', 'Cancelled reservation for LED', '2025-11-25 02:53:44'),
(90, 'Faculty', 'Jenalyn Ytac', 'Cancelled reservation for LED', '2025-11-25 02:54:03'),
(91, 'Faculty', 'Jenalyn Ytac', 'Cancelled reservation for Chair Covers', '2025-11-25 02:54:29'),
(92, 'Faculty', 'Jenalyn Ytac', 'Cancelled reservation for LED', '2025-11-25 03:01:09'),
(93, 'Faculty', 'Jenalyn Ytac', 'Reserved 2 Large Electric Fans for 2025-11-25', '2025-11-25 03:02:33'),
(94, 'Faculty', 'Jenalyn Ytac', 'Reserved 2 Chairs for 2025-11-26', '2025-11-25 03:03:31'),
(95, 'Faculty', 'Jenalyn Ytac', 'Requested return of 2 Chairs', '2025-11-25 03:03:52'),
(96, 'Faculty', 'Jenalyn Ytac', 'Cancelled reservation for Large Electric Fans', '2025-11-25 03:03:55'),
(97, 'System', 'GenServe Administrator', 'Cleared return: Jenalyn Ytac returned 2 Chairs', '2025-11-25 03:04:28');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint(20) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_role` enum('genserve','faculty','admin') NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `receiver_role` enum('genserve','faculty','admin') NOT NULL,
  `message_content` text NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `sender_id`, `sender_role`, `receiver_id`, `receiver_role`, `message_content`, `timestamp`, `is_read`) VALUES
(1, 1, 'faculty', 2, 'admin', 'ddsd', '2025-11-23 15:31:42', 0),
(2, 1, 'faculty', 2, 'admin', 'ddsdd', '2025-11-23 15:31:55', 0),
(3, 1, 'genserve', 1, 'faculty', 'dsdsd', '2025-11-23 15:37:32', 1),
(4, 1, 'faculty', 1, 'genserve', 'dsdsd', '2025-11-23 15:37:42', 1),
(5, 1, 'genserve', 1, 'faculty', 'hi po', '2025-11-23 15:37:58', 1),
(6, 1, 'faculty', 1, 'genserve', 'hello', '2025-11-23 15:38:05', 1),
(7, 1, 'faculty', 1, 'admin', 'hi', '2025-11-23 15:38:16', 1),
(8, 1, 'admin', 1, 'faculty', 'hello', '2025-11-23 15:38:29', 1),
(11, 1, 'genserve', 1, 'faculty', 'naunsa ka?', '2025-11-23 15:39:00', 1),
(16, 1, 'admin', 1, 'faculty', 'te overtime nakas gym', '2025-11-23 15:47:07', 1),
(17, 1, 'faculty', 1, 'admin', 'ay sori', '2025-11-23 15:47:17', 1),
(18, 1, 'faculty', 1, 'genserve', 'wala', '2025-11-23 15:47:27', 1),
(19, 1, 'admin', 1, 'faculty', 'oki ra', '2025-11-23 15:47:35', 1),
(20, 1, 'admin', 1, 'faculty', 'hoy', '2025-11-23 15:47:56', 1),
(25, 1, 'faculty', 1, 'admin', 'tgfdf', '2025-11-23 15:57:59', 1),
(26, 1, 'faculty', 1, 'admin', 'naa koy iingon', '2025-11-23 15:58:21', 1),
(28, 1, 'admin', 1, 'faculty', 'unsa man?', '2025-11-23 15:58:46', 1),
(29, 1, 'faculty', 1, 'admin', 'wala', '2025-11-23 15:59:09', 1),
(30, 1, 'faculty', 1, 'admin', 'ambot', '2025-11-23 15:59:36', 1),
(31, 1, 'faculty', 1, 'genserve', 'hoyy', '2025-11-23 15:59:53', 1),
(32, 1, 'genserve', 1, 'faculty', 'unsa mna?', '2025-11-23 16:00:01', 1),
(33, 1, 'admin', 1, 'faculty', 'haaaa?', '2025-11-23 16:00:10', 1),
(34, 1, 'admin', 1, 'faculty', 'hoyyy', '2025-11-23 16:00:29', 1),
(38, 1, 'faculty', 1, 'admin', 'ojhhh', '2025-11-23 16:02:00', 1),
(40, 1, 'admin', 1, 'faculty', 'sakto na?', '2025-11-23 16:02:18', 1),
(44, 1, 'faculty', 1, 'admin', 'dili', '2025-11-23 16:03:23', 1),
(45, 1, 'faculty', 1, 'admin', 'dsdsds', '2025-11-23 16:05:10', 1),
(46, 1, 'faculty', 1, 'genserve', 'dsdsd', '2025-11-23 16:05:19', 1),
(47, 1, 'admin', 1, 'faculty', 'wa gyd', '2025-11-23 16:05:29', 1),
(48, 1, 'genserve', 1, 'faculty', 'na mabot lang', '2025-11-23 16:05:40', 1),
(51, 1, 'admin', 1, 'faculty', 'naguba ng imo nga sie', '2025-11-23 16:06:04', 1),
(52, 1, 'faculty', 1, 'genserve', 'way klaro', '2025-11-23 16:06:13', 1),
(53, 1, 'faculty', 1, 'genserve', 'dsdsds', '2025-11-23 16:11:00', 1),
(54, 1, 'faculty', 1, 'admin', 'dsdsds', '2025-11-23 16:11:15', 1),
(55, 1, 'admin', 1, 'faculty', 'na okay na?', '2025-11-23 16:37:54', 1),
(56, 1, 'faculty', 1, 'admin', 'opo', '2025-11-23 16:38:06', 1),
(57, 1, 'admin', 1, 'faculty', 'aww maayo', '2025-11-23 16:38:14', 1),
(58, 1, 'faculty', 1, 'admin', 'galo', '2025-11-23 16:38:35', 1),
(59, 1, 'admin', 1, 'faculty', 'oo', '2025-11-23 16:38:41', 1),
(60, 1, 'admin', 1, 'faculty', 'wa pa kaayo natarong', '2025-11-23 16:39:20', 1),
(61, 1, 'admin', 1, 'genserve', 'hoyyy', '2025-11-23 16:47:02', 1),
(62, 1, 'genserve', 1, 'admin', 'ohh', '2025-11-23 16:47:10', 1),
(63, 1, 'admin', 1, 'faculty', 'na oki na?', '2025-11-23 16:47:59', 1),
(64, 1, 'faculty', 1, 'admin', 'wapa', '2025-11-23 16:48:07', 1),
(65, 1, 'admin', 1, 'faculty', 'ay', '2025-11-23 16:48:13', 1),
(66, 1, 'genserve', 1, 'faculty', 'naboang na', '2025-11-23 16:48:34', 1),
(67, 1, 'faculty', 1, 'genserve', 'gali', '2025-11-23 16:48:46', 1),
(68, 1, 'admin', 1, 'faculty', 'kani', '2025-11-23 16:48:53', 1),
(69, 1, 'faculty', 1, 'admin', 'ay oki naman diay', '2025-11-23 16:49:07', 1),
(70, 1, 'genserve', 1, 'admin', 'sakto na?', '2025-11-23 19:42:28', 1),
(71, 1, 'genserve', 1, 'admin', 'nauli na?', '2025-11-23 19:42:34', 1),
(72, 1, 'admin', 1, 'genserve', 'oo', '2025-11-23 19:42:55', 1),
(73, 1, 'admin', 1, 'faculty', 'oooo', '2025-11-23 19:43:14', 1),
(74, 1, 'faculty', 1, 'admin', 'maayo', '2025-11-23 19:43:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `total` int(11) NOT NULL DEFAULT 0,
  `available` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `category_id`, `name`, `total`, `available`, `created_at`) VALUES
(1, 1, 'Speakers', 4, 4, '2025-11-23 07:08:57'),
(2, 1, 'Mics', 3, 3, '2025-11-23 07:08:57'),
(3, 1, 'Lights', 8, 7, '2025-11-23 07:08:57'),
(4, 1, 'LED', 30, 30, '2025-11-23 07:08:57'),
(5, 2, 'Chair Covers', 30, 30, '2025-11-23 07:08:57'),
(6, 2, 'Tela', 10, 10, '2025-11-23 07:08:57'),
(7, 2, 'Tables', 20, 20, '2025-11-23 07:08:57'),
(8, 2, 'Chairs', 50, 45, '2025-11-23 07:08:57'),
(9, 3, 'Large Electric Fans', 27, 10, '2025-11-23 07:08:57'),
(10, 3, 'Ceiling Fans', 6, 6, '2025-11-23 07:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `equipment_categories`
--

CREATE TABLE `equipment_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment_categories`
--

INSERT INTO `equipment_categories` (`id`, `name`) VALUES
(1, 'Audio & Visual'),
(2, 'Furniture & Decorations'),
(3, 'Power & Ventilation');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `fullname` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `username`, `password_hash`, `fullname`, `email`, `created_at`) VALUES
(1, 'joeljan', '44e171c5ffea1f83d37252430f30b23b02355403f7e4a9f7e17f4ad6c38bfb1a', 'Joel Jan Ytac', 'joeljan@csucc.edu.ph', '2025-11-23 07:24:06'),
(2, 'jena12345', '876ea0324f0b29a3060163045519dbcc9d706feb351e02c07325ef9738abd518', 'Jena', 'jenalyn@csucc.edu.ph', '2025-11-23 09:45:56'),
(3, 'joeljan1', '44e171c5ffea1f83d37252430f30b23b02355403f7e4a9f7e17f4ad6c38bfb1a', 'Joel Jan Ytac', 'joeljan1@csucc.edu.ph', '2025-11-23 12:38:02'),
(4, 'jenalyn12345', 'b3099fea819960439fec6a022b6b5e75350d95465a0d89dd825bb31b2bc237d7', 'Jenalyn Ytac', 'jenalynytacjen@csucc.edu.ph', '2025-11-25 02:33:49');

-- --------------------------------------------------------

--
-- Table structure for table `genserve`
--

CREATE TABLE `genserve` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `fullname` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `genserve`
--

INSERT INTO `genserve` (`id`, `username`, `password_hash`, `fullname`, `email`, `created_at`) VALUES
(1, 'genserve', '2c229c90cb2bfcf3cf5a3e41048178ca782a53ebfbe937a813934a873b4738cd', 'GenServe Administrator', 'genserve@csucc.edu', '2025-11-23 07:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `genserve_notifications`
--

CREATE TABLE `genserve_notifications` (
  `id` bigint(20) NOT NULL,
  `genserve_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `genserve_nstp_notifications`
--

CREATE TABLE `genserve_nstp_notifications` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_str` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `genserve_nstp_notifications`
--

INSERT INTO `genserve_nstp_notifications` (`id`, `date`, `date_str`, `message`, `is_read`, `created_at`) VALUES
(1, '2025-11-29', 'Saturday, November 29, 2025', 'Faculty has made a reservation for Saturday, November 29, 2025 (NSTP Saturday). Please prepare chairs and fans for NSTP classes.', 0, '2025-11-23 13:29:45'),
(2, '2025-11-29', 'Saturday, November 29, 2025', 'Faculty has made a reservation for Saturday, November 29, 2025 (NSTP Saturday). Please prepare chairs and fans for NSTP classes.', 0, '2025-11-23 13:30:16');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `faculty_id`, `type`, `title`, `message`, `is_read`, `created_at`) VALUES
(1, 1, 'announcement', '📢 New Announcement', 'GYM MAINTENANCE: DI MAGAMIT', 0, '2025-11-23 07:26:52');

-- --------------------------------------------------------

--
-- Table structure for table `nstp`
--

CREATE TABLE `nstp` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password_hash` varchar(64) NOT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `equipment_name` varchar(120) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Pending','Fixed') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `faculty_id`, `equipment_name`, `description`, `status`, `created_at`) VALUES
(1, 1, 'BANGKO', 'NAGUBA', 'Fixed', '2025-11-23 07:29:03');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` bigint(20) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `nstp_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `duration_days` int(11) NOT NULL DEFAULT 1,
  `time` varchar(10) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purpose` text NOT NULL,
  `status` enum('Pending','Approved','Declined') NOT NULL DEFAULT 'Pending',
  `return_status` enum('None','Pending','Cleared') NOT NULL DEFAULT 'None',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `return_requested_at` timestamp NULL DEFAULT NULL,
  `return_cleared_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `faculty_id`, `nstp_id`, `equipment_id`, `category_id`, `date`, `time`, `quantity`, `purpose`, `status`, `return_status`, `created_at`, `return_requested_at`, `return_cleared_at`) VALUES
(1, 1, NULL, 4, 1, '2025-11-25', '8:00-10:00', 1, 'KLASE', 'Approved', 'None', '2025-11-23 07:27:46', NULL, NULL),
(2, 1, NULL, 9, 3, '2025-11-24', '10:00-12:0', 2, 'MEETING', 'Approved', 'Cleared', '2025-11-23 09:01:00', '2025-11-23 11:29:25', '2025-11-23 11:29:35'),
(3, 2, NULL, 9, 3, '2025-11-24', '10:00-12:0', 10, 'wala ra', 'Approved', 'None', '2025-11-23 10:05:51', NULL, NULL),
(4, 2, NULL, 9, 3, '2025-11-24', '8:00-10:00', 15, 'dsds', 'Approved', 'None', '2025-11-23 10:14:10', NULL, NULL),
(5, 1, NULL, 4, 1, '2025-11-23', '6:50-6:53P', 1, 'testing', 'Approved', 'Cleared', '2025-11-23 10:50:26', '2025-11-23 11:28:16', '2025-11-23 11:28:31'),
(6, 1, NULL, 8, 2, '2025-11-23', '7:38-7:40P', 5, 'TEST', 'Pending', 'None', '2025-11-23 11:37:58', NULL, NULL),
(7, 4, NULL, 4, 1, '2025-11-25', '8:00-9:00P', 1, 'fdsffdfsdfd', 'Declined', 'None', '2025-11-25 02:34:22', NULL, NULL),
(8, 4, NULL, 4, 1, '2025-11-25', '8:00-9:00P', 15, 'fdsffdfsdfd', 'Declined', 'None', '2025-11-25 02:36:08', NULL, NULL),
(9, 4, NULL, 5, 2, '2025-11-25', '10:35-10:4', 2, 'As', 'Declined', 'None', '2025-11-25 02:37:28', NULL, NULL),
(10, 4, NULL, 4, 1, '2025-11-25', '7:00-9:00P', 3, 'Ambot', 'Declined', 'None', '2025-11-25 02:45:11', NULL, NULL),
(11, 4, NULL, 4, 1, '2025-11-25', '8:00-9:00P', 1, 'jhgjyh', 'Approved', 'None', '2025-11-25 02:48:47', NULL, NULL),
(12, 4, NULL, 3, 1, '2025-11-26', '8:00-9:00P', 1, 'dgf', 'Approved', 'None', '2025-11-25 02:49:07', NULL, NULL),
(13, 4, NULL, 2, 1, '2025-11-25', '8:00-9:00P', 1, 'redwtr', 'Declined', 'None', '2025-11-25 02:50:36', NULL, NULL),
(14, 4, NULL, 9, 3, '2025-11-25', '6:00-7:00P', 2, 'Ambot', 'Declined', 'None', '2025-11-25 03:02:33', NULL, NULL),
(15, 4, NULL, 8, 2, '2025-11-26', '2:00-3:00 ', 2, 'k3wrj', 'Approved', 'Cleared', '2025-11-25 03:03:31', '2025-11-25 03:03:52', '2025-11-25 03:04:28');

-- --------------------------------------------------------

--
-- Table structure for table `gym_reservations`
--

CREATE TABLE `gym_reservations` (
  `id` bigint(20) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `duration_days` int(11) NOT NULL DEFAULT 1,
  `time` varchar(50) NOT NULL,
  `equipment_items` text NOT NULL,
  `status` enum('Pending','Approved','Declined') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sender` (`sender_role`,`sender_id`),
  ADD KEY `idx_receiver` (`receiver_role`,`receiver_id`),
  ADD KEY `idx_pair` (`sender_role`,`sender_id`,`receiver_role`,`receiver_id`,`timestamp`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_equipment_category_name` (`category_id`,`name`);

--
-- Indexes for table `equipment_categories`
--
ALTER TABLE `equipment_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `genserve`
--
ALTER TABLE `genserve`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `genserve_notifications`
--
ALTER TABLE `genserve_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_genserve_notifications_genserve` (`genserve_id`);

--
-- Indexes for table `genserve_nstp_notifications`
--
ALTER TABLE `genserve_nstp_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_notifications_faculty` (`faculty_id`);

--
-- Indexes for table `nstp`
--
ALTER TABLE `nstp`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_reports_faculty` (`faculty_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_res_faculty` (`faculty_id`),
  ADD KEY `fk_res_equipment` (`equipment_id`),
  ADD KEY `fk_res_category` (`category_id`),
  ADD KEY `fk_res_nstp` (`nstp_id`);

--
-- Indexes for table `gym_reservations`
--
ALTER TABLE `gym_reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_gym_res_faculty` (`faculty_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16356;

--
-- AUTO_INCREMENT for table `equipment_categories`
--
ALTER TABLE `equipment_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4906;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `genserve`
--
ALTER TABLE `genserve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `genserve_notifications`
--
ALTER TABLE `genserve_notifications`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `genserve_nstp_notifications`
--
ALTER TABLE `genserve_nstp_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `nstp`
--
ALTER TABLE `nstp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `gym_reservations`
--
ALTER TABLE `gym_reservations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `fk_equipment_category` FOREIGN KEY (`category_id`) REFERENCES `equipment_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `genserve_notifications`
--
ALTER TABLE `genserve_notifications`
  ADD CONSTRAINT `fk_genserve_notifications_genserve` FOREIGN KEY (`genserve_id`) REFERENCES `genserve` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `fk_reports_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `fk_res_category` FOREIGN KEY (`category_id`) REFERENCES `equipment_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_res_equipment` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_res_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_res_nstp` FOREIGN KEY (`nstp_id`) REFERENCES `nstp` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `gym_reservations`
--
ALTER TABLE `gym_reservations`
  ADD CONSTRAINT `fk_gym_res_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
