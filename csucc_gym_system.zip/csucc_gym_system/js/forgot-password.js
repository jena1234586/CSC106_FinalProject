/* ===== Forgot Password Handler ===== */
document.getElementById('forgotPasswordForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('resetEmail').value.trim();
    
    // Validate email format
    if (!email) {
        showNotification('Please enter your email address', 'error');
        return;
    }
    
    // Check if email exists in faculty list
    const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
    const faculty = facultyList.find(f => f.email.toLowerCase() === email.toLowerCase());
    
    if (!faculty) {
        showNotification('No account found with this email address', 'error');
        return;
    }
    
    // Generate a simple reset token (in production, this should be done server-side)
    const resetToken = generateResetToken();
    const resetExpiry = Date.now() + (60 * 60 * 1000); // 1 hour from now
    
    // Store reset token
    const resetTokens = JSON.parse(localStorage.getItem('resetTokens') || '[]');
    resetTokens.push({
        email: email,
        token: resetToken,
        expiry: resetExpiry
    });
    localStorage.setItem('resetTokens', JSON.stringify(resetTokens));
    
    // In a real application, you would send an email with the reset link
    // For this demo, we'll show the reset link in a notification
    showNotification('Password reset instructions have been sent to your email', 'success', 5000);
    
    // Simulate email content (for demo purposes)
    console.log('=== PASSWORD RESET EMAIL ===');
    console.log('To:', email);
    console.log('Reset Link:', window.location.origin + window.location.pathname.replace('forgot-password.php', 'reset-password.php') + '?token=' + resetToken);
    console.log('This link will expire in 1 hour');
    console.log('===========================');
    
    // Redirect to reset password page after a short delay
    setTimeout(() => {
        window.location.href = 'reset-password.php?token=' + resetToken;
    }, 2000);
});

// Generate a random reset token
function generateResetToken() {
    return Array.from({length: 32}, () => 
        Math.floor(Math.random() * 16).toString(16)
    ).join('');
}
