/* ===== Registration Validation Script ===== */

// Password strength checker
function checkPasswordStrength(password) {
  let strength = 0;
  const feedback = [];
  
  if (password.length === 0) {
    return { strength: 'none', score: 0, feedback: [] };
  }
  
  // Length check
  if (password.length >= 8) {
    strength += 1;
  } else {
    feedback.push('');
  }
  
  // Contains lowercase
  if (/[a-z]/.test(password)) {
    strength += 1;
  } else {
    feedback.push('');
  }
  
  // Contains uppercase
  if (/[A-Z]/.test(password)) {
    strength += 1;
  } else {
    feedback.push('');
  }
  
  // Contains numbers
  if (/[0-9]/.test(password)) {
    strength += 1;
  } else {
    feedback.push('');
  }
  
  // Contains special characters
  if (/[^A-Za-z0-9]/.test(password)) {
    strength += 1;
  } else {
    feedback.push('');
  }
  
  // Determine strength level
  let strengthLevel = 'weak';
  if (strength >= 4) {
    strengthLevel = 'strong';
  } else if (strength >= 3) {
    strengthLevel = 'medium';
  }
  
  return {
    strength: strengthLevel,
    score: strength,
    feedback: feedback
  };
}

// Update password strength indicator
function updatePasswordStrength() {
  const password = document.getElementById('password').value;
  const strengthIndicator = document.getElementById('passwordStrength');
  const strengthText = document.getElementById('strengthText');
  const strengthFeedback = document.getElementById('strengthFeedback');
  
  if (!strengthIndicator || !strengthText) return;
  
  const result = checkPasswordStrength(password);
  
  // Remove all strength classes
  strengthIndicator.className = 'password-strength-bar';
  
  if (password.length > 0) {
    strengthIndicator.classList.add('show');
    strengthIndicator.classList.add(result.strength);
    
    // Update text
    strengthText.textContent = result.strength.charAt(0).toUpperCase() + result.strength.slice(1);
    
    // Update feedback
    if (strengthFeedback && result.feedback.length > 0) {
      strengthFeedback.innerHTML = '';
      strengthFeedback.style.display = 'block';
    } else if (strengthFeedback) {
      strengthFeedback.style.display = 'none';
    }
  } else {
    strengthIndicator.classList.remove('show');
    if (strengthFeedback) {
      strengthFeedback.style.display = 'none';
    }
  }
}

// Validate full name (first letter must be capital, no double spaces)
function validateFullName(name) {
  const errors = [];
  
  // Check if empty
  if (!name || name.trim() === '') {
    errors.push('Full name is required');
    return { valid: false, errors };
  }
  
  // Check for double spaces
  if (/\s{2,}/.test(name)) {
    errors.push('No double spaces allowed');
    return { valid: false, errors };
  }
  
  // Split into words and check each word starts with capital letter
  const words = name.trim().split(' ');
  for (let word of words) {
    if (word.length > 0 && !/^[A-Z]/.test(word)) {
      errors.push('Each word must start with a capital letter');
      return { valid: false, errors };
    }
  }
  
  // Check if contains only letters and spaces
  if (!/^[A-Za-z\s]+$/.test(name)) {
    errors.push('Name should contain only letters and spaces');
    return { valid: false, errors };
  }
  
  return { valid: true, errors: [] };
}

// Validate email (must be @csucc.edu.ph)
function validateEmail(email) {
  const errors = [];
  
  if (!email || email.trim() === '') {
    errors.push('Email is required');
    return { valid: false, errors };
  }
  
  // Check if email ends with @csucc.edu.ph
  if (!email.toLowerCase().endsWith('@csucc.edu.ph')) {
    errors.push('Only @csucc.edu.ph email addresses are allowed');
    return { valid: false, errors };
  }
  
  // Basic email format validation
  const emailRegex = /^[a-zA-Z0-9._-]+@csucc\.edu\.ph$/;
  if (!emailRegex.test(email.toLowerCase())) {
    errors.push('Invalid email format');
    return { valid: false, errors };
  }
  
  return { valid: true, errors: [] };
}

// Check if username already exists
async function checkUsernameExists(username) {
  if (!username || username.trim() === '') {
    return { exists: false, error: 'Username is required' };
  }
  
  // Check in localStorage first
  const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
  const existsLocally = facultyList.some(f => f.username.toLowerCase() === username.toLowerCase());
  
  if (existsLocally) {
    return { exists: true, error: 'Username already exists' };
  }
  
  // Optionally check with server (if API is available)
  try {
    const response = await fetch(`api.php?action=checkUsername&username=${encodeURIComponent(username)}`);
    if (response.ok) {
      const data = await response.json();
      if (data.exists) {
        return { exists: true, error: 'Username already exists' };
      }
    }
  } catch (e) {
    // Server check failed, rely on local check
    console.warn('Server username check failed, using local check only');
  }
  
  return { exists: false, error: null };
}

// Real-time validation for full name
function setupFullNameValidation() {
  const fullnameInput = document.getElementById('fullname');
  const fullnameError = document.getElementById('fullnameError');
  
  if (!fullnameInput) return;
  
  fullnameInput.addEventListener('input', function() {
    const value = this.value;
    const validation = validateFullName(value);
    
    if (fullnameError) {
      if (!validation.valid && value.length > 0) {
        fullnameError.textContent = validation.errors.join(', ');
        fullnameError.style.display = 'block';
        fullnameInput.classList.add('error');
        fullnameInput.classList.remove('success');
      } else if (validation.valid) {
        fullnameError.style.display = 'none';
        fullnameInput.classList.remove('error');
        fullnameInput.classList.add('success');
      } else {
        fullnameError.style.display = 'none';
        fullnameInput.classList.remove('error', 'success');
      }
    }
  });
  
  // Prevent double spaces while typing
  fullnameInput.addEventListener('keypress', function(e) {
    if (e.key === ' ' && this.value.slice(-1) === ' ') {
      e.preventDefault();
    }
  });
}

// Real-time validation for email
function setupEmailValidation() {
  const emailInput = document.getElementById('email');
  const emailError = document.getElementById('emailError');
  
  if (!emailInput) return;
  
  emailInput.addEventListener('blur', function() {
    const value = this.value;
    const validation = validateEmail(value);
    
    if (emailError) {
      if (!validation.valid && value.length > 0) {
        emailError.textContent = validation.errors.join(', ');
        emailError.style.display = 'block';
        emailInput.classList.add('error');
        emailInput.classList.remove('success');
      } else if (validation.valid) {
        emailError.style.display = 'none';
        emailInput.classList.remove('error');
        emailInput.classList.add('success');
      } else {
        emailError.style.display = 'none';
        emailInput.classList.remove('error', 'success');
      }
    }
  });
}

// Real-time validation for username
function setupUsernameValidation() {
  const usernameInput = document.getElementById('username');
  const usernameError = document.getElementById('usernameError');
  
  if (!usernameInput) return;
  
  let checkTimeout;
  
  usernameInput.addEventListener('input', function() {
    const value = this.value.trim();
    
    // Clear previous timeout
    clearTimeout(checkTimeout);
    
    if (value.length < 3) {
      if (usernameError && value.length > 0) {
        usernameError.textContent = 'Username must be at least 3 characters';
        usernameError.style.display = 'block';
        usernameInput.classList.add('error');
        usernameInput.classList.remove('success');
      }
      return;
    }
    
    // Check username after 500ms delay
    checkTimeout = setTimeout(async () => {
      const result = await checkUsernameExists(value);
      
      if (usernameError) {
        if (result.exists) {
          usernameError.textContent = result.error;
          usernameError.style.display = 'block';
          usernameInput.classList.add('error');
          usernameInput.classList.remove('success');
        } else {
          usernameError.textContent = 'Username is available';
          usernameError.style.display = 'block';
          usernameError.style.color = '#28a745';
          usernameInput.classList.remove('error');
          usernameInput.classList.add('success');
          
          // Hide success message after 2 seconds
          setTimeout(() => {
            if (usernameError.style.color === 'rgb(40, 167, 69)') {
              usernameError.style.display = 'none';
              usernameError.style.color = '';
            }
          }, 2000);
        }
      }
    }, 500);
  });
}

// Setup password strength indicator
function setupPasswordValidation() {
  const passwordInput = document.getElementById('password');
  
  if (!passwordInput) return;
  
  passwordInput.addEventListener('input', updatePasswordStrength);
}

// Enhanced form submission with all validations
function setupRegistrationForm() {
  const registerForm = document.getElementById('registerForm');
  
  if (!registerForm) return;
  
  registerForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const fullname = document.getElementById('fullname').value;
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    
    // Validate full name
    const nameValidation = validateFullName(fullname);
    if (!nameValidation.valid) {
      showNotification(nameValidation.errors.join(', '), 'error');
      return;
    }
    
    // Validate email
    const emailValidation = validateEmail(email);
    if (!emailValidation.valid) {
      showNotification(emailValidation.errors.join(', '), 'error');
      return;
    }
    
    // Validate username
    if (username.length < 3) {
      showNotification('Username must be at least 3 characters', 'error');
      return;
    }
    
    // Check if username exists
    const usernameCheck = await checkUsernameExists(username);
    if (usernameCheck.exists) {
      showNotification(usernameCheck.error, 'error');
      return;
    }
    
    // Validate password strength
    const passwordStrength = checkPasswordStrength(password);
    if (passwordStrength.score < 3) {
      showNotification('Password is too weak. Please use a stronger password.', 'error');
      return;
    }
    
    // Check if email already exists
    const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
    if (facultyList.some(f => f.email.toLowerCase() === email.toLowerCase())) {
      showNotification('Email already registered!', 'error');
      return;
    }
    
    // All validations passed, proceed with registration
    facultyList.push({ 
      fullname: fullname.trim(), 
      username, 
      email: email.toLowerCase(), 
      password,
      registeredAt: new Date().toISOString()
    });
    localStorage.setItem('facultyList', JSON.stringify(facultyList));
    
    // Sync to MySQL via API (and also to file as fallback)
    fetch('api.php?action=registerFaculty', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fullname: fullname.trim(), username, email: email.toLowerCase(), password })
    }).catch(() => {}).finally(() => {
      // Also sync to file-based backup
      syncFacultyToServer();
    });
    
    showNotification('Registration successful! Redirecting to login...', 'success');
    setTimeout(() => {
      window.location.href = 'login.php';
    }, 2000);
  });
}

// Sync faculty to server (from main script.js)
async function syncFacultyToServer() {
  try {
    const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
    await fetch('faculty-api.php?action=write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(facultyList)
    });
  } catch (e) {
    console.warn('Failed to sync faculty to server', e);
  }
}

// Toggle password visibility
function togglePasswordVisibility() {
  const passwordInput = document.getElementById('password');
  const toggleIcon = document.getElementById('togglePassword');
  
  if (!passwordInput || !toggleIcon) return;
  
  if (passwordInput.type === 'password') {
    passwordInput.type = 'text';
    toggleIcon.classList.remove('fa-eye');
    toggleIcon.classList.add('fa-eye-slash');
  } else {
    passwordInput.type = 'password';
    toggleIcon.classList.remove('fa-eye-slash');
    toggleIcon.classList.add('fa-eye');
  }
}

// Initialize all validations when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  setupFullNameValidation();
  setupEmailValidation();
  setupUsernameValidation();
  setupPasswordValidation();
  setupRegistrationForm();
});
