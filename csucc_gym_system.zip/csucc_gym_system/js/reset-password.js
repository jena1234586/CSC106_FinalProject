/* ===== Password Toggle Function ===== */
function togglePassword(inputId) {
    const passwordInput = document.getElementById(inputId);
    const toggleIcon = event.target;
    
    if (!passwordInput || !toggleIcon) return;
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

/* ===== Reset Password Handler ===== */
document.addEventListener('DOMContentLoaded', function() {
    // Get token from URL
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    
    if (!token) {
        showNotification('Invalid reset link', 'error');
        setTimeout(() => {
            window.location.href = 'index.php';
        }, 2000);
        return;
    }
    
    // Verify token
    const resetTokens = JSON.parse(localStorage.getItem('resetTokens') || '[]');
    const resetData = resetTokens.find(r => r.token === token);
    
    if (!resetData) {
        showNotification('Invalid or expired reset link', 'error');
        setTimeout(() => {
            window.location.href = 'index.php';
        }, 2000);
        return;
    }
    
    // Check if token is expired
    if (Date.now() > resetData.expiry) {
        showNotification('Reset link has expired', 'error');
        // Remove expired token
        const updatedTokens = resetTokens.filter(r => r.token !== token);
        localStorage.setItem('resetTokens', JSON.stringify(updatedTokens));
        setTimeout(() => {
            window.location.href = 'forgot-password.php';
        }, 2000);
        return;
    }
    
    // Handle form submission
    document.getElementById('resetPasswordForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        // Validate passwords
        if (newPassword.length < 8) {
            showNotification('Password must be at least 8 characters long', 'error');
            return;
        }
        
        if (newPassword !== confirmPassword) {
            showNotification('Passwords do not match', 'error');
            return;
        }
        
        // Update password in faculty list
        const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
        const facultyIndex = facultyList.findIndex(f => f.email.toLowerCase() === resetData.email.toLowerCase());
        
        if (facultyIndex === -1) {
            showNotification('Account not found', 'error');
            return;
        }
        
        // Update password
        facultyList[facultyIndex].password = newPassword;
        localStorage.setItem('facultyList', JSON.stringify(facultyList));
        
        // Remove used token
        const updatedTokens = resetTokens.filter(r => r.token !== token);
        localStorage.setItem('resetTokens', JSON.stringify(updatedTokens));
        
        showNotification('Password reset successfully! Redirecting to login...', 'success');
        
        setTimeout(() => {
            window.location.href = 'index.php';
        }, 2000);
    });
});
