/* ===== Notification System ===== */
function showNotification(message, type = 'info', duration = 3000) {
  const notification = document.getElementById('notification');
  if (!notification) return;
  
  notification.textContent = message;
  notification.className = `notification ${type} show`;
  
  setTimeout(() => {
    notification.classList.remove('show');
  }, duration);
}

// ===== Faculty Reservation Actions =====
let editingReservationId = null;

function editReservation(id, equipment, category, date, time, quantity, purpose) {
  editingReservationId = id;
  // Prefill fields
  const eqInput = document.getElementById('reservationEquipment');
  const catInput = document.getElementById('reservationCategory');
  const startInput = document.getElementById('reservationStartDate');
  const endInput = document.getElementById('reservationEndDate');
  const daysInput = document.getElementById('reservationDays');
  const timeInput = document.getElementById('reservationTime');
  const qtyInput = document.getElementById('reservationQuantity');
  const purposeInput = document.getElementById('reservationPurpose');
  if (eqInput) { eqInput.value = equipment; eqInput.readOnly = true; }
  if (catInput) { catInput.value = category; catInput.readOnly = true; }
  if (startInput) startInput.value = date;
  if (endInput) endInput.value = date;
  if (daysInput) {
    daysInput.value = 1;
    // Trigger recalculation so visibility/End Date follow the new rules
    const ev = new Event('input');
    daysInput.dispatchEvent(ev);
  }
  if (timeInput) timeInput.value = time;
  if (qtyInput) qtyInput.value = quantity;
  if (purposeInput) purposeInput.value = purpose || '';

  // Change submit button to Save
  const submitBtn = document.querySelector('#reservationModal .modal-footer button.btn-success');
  if (submitBtn) {
    submitBtn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
    submitBtn.onclick = saveReservationEdit;
  }
  openModal('reservationModal');
}

async function saveReservationEdit() {
  const startDate = document.getElementById('reservationStartDate').value;
  const endDate = document.getElementById('reservationEndDate').value || startDate;
  const time = document.getElementById('reservationTime').value;
  const quantity = document.getElementById('reservationQuantity').value;
  const purpose = document.getElementById('reservationPurpose').value;
  if (!editingReservationId) return;

  // Basic validation (reuse time format from submit flow)
  const timePattern = /^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}\s*(AM|PM|am|pm)$/i;
  if (!timePattern.test((time || '').trim())) {
    showNotification('Invalid time format! Use format like "8:00-10:00 AM"', 'error');
    return;
  }

  // Validate date range
  if (!startDate || !endDate) {
    showNotification('Please select both start and end dates', 'error');
    return;
  }

  const start = new Date(startDate + 'T00:00:00');
  const end = new Date(endDate + 'T00:00:00');
  if (end < start) {
    showNotification('End Date cannot be earlier than Start Date', 'error');
    return;
  }

  // Check each day in range for NSTP Saturday blocking
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const iso = d.toISOString().split('T')[0];
    if (isSaturdayBlocked(iso)) {
      showNotification('Reservations on Saturdays are not allowed due to NSTP activities.', 'error', 5000);
      return;
    }
  }

  const durationDays = Math.floor((end - start) / (1000 * 60 * 60 * 24)) + 1;

  try {
    const resp = await fetch('api.php?action=updateReservation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        id: editingReservationId, 
        date: startDate,
        startDate,
        endDate,
        durationDays,
        time, 
        quantity: parseInt(quantity,10), 
        purpose 
      })
    });
    const data = await resp.json();
    if (data.ok) {
      showNotification('Reservation updated.', 'success');
      closeModal('reservationModal');
      // Reset button back to Submit Reservation
      const submitBtn = document.querySelector('#reservationModal .modal-footer button.btn-success');
      if (submitBtn) {
        submitBtn.innerHTML = '<i class="fas fa-check"></i> Submit Reservation';
        submitBtn.onclick = submitReservation;
      }
      editingReservationId = null;
      populateFacultyReservations();
    } else {
      showNotification(data.error || 'Failed to update reservation', 'error');
    }
  } catch (e) {
    showNotification('Failed to update reservation', 'error');
  }
}


/* ===== Password Toggle for Login ===== */
function toggleLoginPassword() {
  const passwordInput = document.getElementById('loginPassword');
  const toggleIcon = event.target;
  
  if (!passwordInput || !toggleIcon) return;
  
  if (passwordInput.type === 'password') {
    passwordInput.type = 'text';
    toggleIcon.classList.remove('fa-eye');
    toggleIcon.classList.add('fa-eye-slash');
  } else {
    passwordInput.type = 'password';
    toggleIcon.classList.remove('fa-eye-slash');
    toggleIcon.classList.add('fa-eye');
  }
}

/* ===== Modal System ===== */
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('show');
    document.body.style.overflow = 'auto';
  }
}

let reasonModalState = {
  onConfirm: null,
  requireReason: true,
  minLength: 3,
  validationMessage: 'Please provide a brief reason.',
  confirmIcon: 'fas fa-paper-plane',
  confirmText: 'Submit',
  confirmClass: 'btn-danger'
};

function showReasonModal(options = {}) {
  const modal = document.getElementById('reasonModal');
  const onConfirm = options.onConfirm;

  if (!modal) {
    const fallback = window.prompt(options.description || 'Please provide a reason for this action.');
    if (fallback === null) {
      return;
    }
    const trimmed = fallback.trim();
    if (!trimmed) {
      showNotification('Reason is required to continue.', 'error');
      return;
    }
    if (typeof onConfirm === 'function') {
      onConfirm(trimmed);
    }
    return;
  }

  reasonModalState.onConfirm = typeof onConfirm === 'function' ? onConfirm : null;
  reasonModalState.requireReason = options.requireReason !== false;
  reasonModalState.minLength = options.minLength || 3;
  reasonModalState.validationMessage = options.validationMessage || 'Please provide a brief reason.';
  reasonModalState.confirmIcon = options.confirmIcon || 'fas fa-paper-plane';
  reasonModalState.confirmText = options.confirmText || 'Submit';
  reasonModalState.confirmClass = options.confirmClass || 'btn-danger';

  const titleEl = modal.querySelector('#reasonModalTitle');
  if (titleEl) {
    titleEl.textContent = options.title || 'Provide Reason';
  }

  const descEl = modal.querySelector('#reasonModalDescription');
  if (descEl) {
    descEl.textContent = options.description || 'Please tell us why you are performing this action.';
  }

  const textarea = modal.querySelector('#reasonModalInput');
  if (textarea) {
    textarea.value = '';
    textarea.placeholder = options.placeholder || 'Enter your reason...';
    setTimeout(() => textarea.focus(), 150);
  }

  const hintEl = modal.querySelector('#reasonModalHint');
  if (hintEl) {
    hintEl.textContent = options.hint || 'This note will be recorded for this request.';
  }

  const confirmBtn = modal.querySelector('.reason-confirm-btn');
  if (confirmBtn) {
    confirmBtn.innerHTML = `<i class="${reasonModalState.confirmIcon}"></i> ${reasonModalState.confirmText}`;
    confirmBtn.className = `btn ${reasonModalState.confirmClass} reason-confirm-btn`;
  }

  openModal('reasonModal');
}

function submitReasonModal() {
  const textarea = document.getElementById('reasonModalInput');
  const reason = textarea ? textarea.value.trim() : '';
  const minLen = reasonModalState.minLength || 1;

  if (reasonModalState.requireReason && reason.length < minLen) {
    showNotification(reasonModalState.validationMessage || `Please enter at least ${minLen} characters.`, 'error');
    return;
  }

  closeModal('reasonModal');
  const callback = reasonModalState.onConfirm;
  reasonModalState.onConfirm = null;

  if (typeof callback === 'function') {
    callback(reason);
  }
}

function cancelReasonModal() {
  reasonModalState.onConfirm = null;
  closeModal('reasonModal');
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal')) {
    e.target.classList.remove('show');
    document.body.style.overflow = 'auto';
    
    // Reset gym reservation form if closing gym reservation modal
    if (e.target.id === 'gymReservationModal') {
      document.getElementById('gymReservationForm').reset();
      document.getElementById('gymEquipmentItemsList').innerHTML = '';
      editingGymReservationId = null;
      gymEquipmentItems = [];
    }
  }
});

// Close modal with close button
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('close')) {
    const modal = e.target.closest('.modal');
    if (modal) {
      modal.classList.remove('show');
      document.body.style.overflow = 'auto';
      
      // Reset gym reservation form if closing gym reservation modal
      if (modal.id === 'gymReservationModal') {
        document.getElementById('gymReservationForm').reset();
        document.getElementById('gymEquipmentItemsList').innerHTML = '';
        editingGymReservationId = null;
        gymEquipmentItems = [];
      }
    }
  }
});

/* ===== Registration ===== */
// NOTE: Registration form handler is now in register-validation.js
// This old handler is kept for backward compatibility but won't run if register-validation.js is loaded

/* ===== Default Admin Accounts ===== */
const defaultAdminAccounts = [
  { username: 'admin', password: 'admin123', fullname: 'System Administrator', email: 'admin@csucc.edu' },
  { username: 'superadmin', password: 'super123', fullname: 'Super Administrator', email: 'superadmin@csucc.edu' }
];

// Initialize admin accounts if they don't exist
function initializeAdminAccounts() {
  const existingAdmins = JSON.parse(localStorage.getItem('adminAccounts') || '[]');
  if (existingAdmins.length === 0) {
    localStorage.setItem('adminAccounts', JSON.stringify(defaultAdminAccounts));
  }
}

/* ===== Faculty Persistence Sync (file-based fallback) ===== */
async function syncFacultyToServer() {
  try {
    const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
    await fetch('faculty-api.php?action=write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(facultyList)
    });
  } catch (e) {
    console.warn('Failed to sync faculty to server', e);
  }
}

async function loadFacultyFromServerIfEmpty() {
  try {
    const local = JSON.parse(localStorage.getItem('facultyList') || '[]');
    if (Array.isArray(local) && local.length > 0) return; // already present locally
    const resp = await fetch('faculty-api.php?action=read', { cache: 'no-store' });
    if (!resp.ok) return;
    const serverList = await resp.json();
    if (Array.isArray(serverList) && serverList.length > 0) {
      localStorage.setItem('facultyList', JSON.stringify(serverList));
    }
  } catch (e) {
    console.warn('Failed to load faculty from server', e);
  }
}

/* ===== Login ===== */
document.getElementById('loginForm')?.addEventListener('submit', function(e) {
  e.preventDefault();

  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;
  const role = document.getElementById('role').value;

  // Validation
  if (!username || !password || !role) {
    showNotification('Please fill in all fields', 'error');
    return;
  }

  // Authenticate via database API
  fetch('api.php?action=login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: username,
      password: password,
      role: role
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok && data.user) {
      const user = data.user;
      
      // Store user info in localStorage for session management
      if (role === 'faculty') {
        localStorage.setItem('loggedInFaculty', JSON.stringify({
          id: user.id,
          username: user.username,
          fullname: user.fullname,
          email: user.email
        }));
        // persist for chat system
        sessionStorage.setItem('currentUser', JSON.stringify({
          role: 'faculty',
          id: user.id,
          username: user.username,
          fullname: user.fullname,
          email: user.email
        }));
        showNotification('Login successful! Welcome back!', 'success');
        setTimeout(() => {
          window.location.href = 'faculty-dashboard.php';
        }, 1500);
      } else if (role === 'admin') {
        localStorage.setItem('loggedInAdmin', JSON.stringify({
          id: user.id,
          username: user.username,
          fullname: user.fullname,
          email: user.email
        }));
        // persist for chat system
        sessionStorage.setItem('currentUser', JSON.stringify({
          role: 'admin',
          id: user.id,
          username: user.username,
          fullname: user.fullname,
          email: user.email
        }));
        showNotification(`Welcome, ${user.fullname}!`, 'success');
        setTimeout(() => {
          window.location.href = 'admin-dashboard.php';
        }, 1500);
      } else if (role === 'genserve') {
        localStorage.setItem('loggedInGenServe', JSON.stringify({
          id: user.id,
          username: user.username,
          fullname: user.fullname,
          email: user.email
        }));
        // persist for chat system
        sessionStorage.setItem('currentUser', JSON.stringify({
          role: 'genserve',
          id: user.id,
          username: user.username,
          fullname: user.fullname,
          email: user.email
        }));
        showNotification(`Welcome, ${user.fullname}!`, 'success');
        setTimeout(() => {
          window.location.href = 'genserve-dashboard.php';
        }, 1500);
      }
    } else {
      showNotification(data.error || 'Invalid username or password!', 'error');
    }
  })
  .catch(err => {
    console.error('Login error:', err);
    showNotification('Failed to connect to server. Please try again.', 'error');
  });
});

/* ===== Logout ===== */
function logout() {
  localStorage.removeItem('loggedInFaculty');
  localStorage.removeItem('loggedInAdmin');
  localStorage.removeItem('loggedInGenServe');
  sessionStorage.removeItem('currentUser');
  showNotification('Logged out successfully!', 'info');
  setTimeout(() => {
    window.location.href = 'index.php';
  }, 1000);
}

/* ===== Faculty Dashboard ===== */
const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');

if (loggedFaculty && window.location.pathname.includes('faculty-dashboard.php')) {
  console.log('Welcome, ' + loggedFaculty.fullname);
  // Update faculty name in dashboard header
  const facultyNameElement = document.querySelector('.header-bar h2');
  if (facultyNameElement) {
    facultyNameElement.textContent = `Welcome, ${loggedFaculty.fullname}!`;
  }
  // Chat session fallback
  if (!sessionStorage.getItem('currentUser')) {
    sessionStorage.setItem('currentUser', JSON.stringify({
      role: 'faculty',
      id: loggedFaculty.id,
      username: loggedFaculty.username,
      fullname: loggedFaculty.fullname,
      email: loggedFaculty.email
    }));
  }
} else if (window.location.pathname.includes('faculty-dashboard.php')) {
  showNotification('Please login first!', 'error');
  setTimeout(() => {
    window.location.href = 'index.php';
  }, 1500);
}

/* ===== Admin Dashboard ===== */
const loggedAdmin = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null');

if (loggedAdmin && window.location.pathname.includes('admin-dashboard.php')) {
  console.log('Welcome, ' + loggedAdmin.fullname);
  // Update admin name in dashboard if element exists
  const adminNameElement = document.querySelector('.main-content h2');
  if (adminNameElement) {
    adminNameElement.textContent = `Welcome, ${loggedAdmin.fullname}!`;
  }
  // Chat session fallback
  if (!sessionStorage.getItem('currentUser')) {
    sessionStorage.setItem('currentUser', JSON.stringify({
      role: 'admin',
      id: loggedAdmin.id,
      username: loggedAdmin.username,
      fullname: loggedAdmin.fullname,
      email: loggedAdmin.email
    }));
  }
} else if (window.location.pathname.includes('admin-dashboard.php')) {
  showNotification('Please login as admin first!', 'error');
  setTimeout(() => {
    window.location.href = 'index.php';
  }, 1500);
}

/* ===== Faculty Equipment ===== */
const facultyEquipment = {
  "Audio & Visual": [
    { name: "LED", available: 5, total: 5 },
    { name: "Lights", available: 8, total: 8 },
    { name: "Mics", available: 3, total: 3 },
    { name: "Speakers", available: 4, total: 4 }
  ],
  "Furniture & Decorations": [
    { name: "Chairs", available: 50, total: 50 },
    { name: "Tables", available: 20, total: 20 },
    { name: "Tela", available: 10, total: 10 },
    { name: "Chair Covers", available: 30, total: 30 }
  ],
  "Power & Ventilation": [
    { name: "Ceiling Fans", available: 6, total: 6 },
    { name: "Large Electric Fans", available: 4, total: 4 }
  ],
  "Sports": [
    { name: "Basketball", available: 10, total: 10 },
    { name: "Volleyball", available: 8, total: 8 },
    { name: "Badminton Racket", available: 12, total: 12 }
  ]
};

// Remove disallowed items (e.g., RJ45, WiFi Router) and empty categories
function sanitizeCatalog(catalog) {
  const result = {};
  Object.entries(catalog || {}).forEach(([category, items]) => {
    const filtered = (items || []).filter(item => !/(\brj45\b|wifi\s*router)/i.test(item.name));
    if (filtered.length > 0) {
      result[category] = filtered;
    }
  });
  return result;
}

// Persistent equipment catalog helpers
async function ensureEquipmentCatalogInitialized() {
  // Always fetch from database first to ensure data persistence
  try {
    const response = await fetch('api.php?action=getCatalog');
    if (response.ok) {
      const dbCatalog = await response.json();
      if (dbCatalog && Object.keys(dbCatalog).length > 0) {
        // Use database catalog as source of truth
        localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
        return;
      }
    }
  } catch (e) {
    console.warn('Failed to fetch catalog from database, using local fallback', e);
  }
  
  // Fallback to localStorage if database fetch fails
  const existingStr = localStorage.getItem('equipmentCatalog');
  if (!existingStr) {
    const sanitized = sanitizeCatalog(facultyEquipment);
    localStorage.setItem('equipmentCatalog', JSON.stringify(sanitized));
    // Sync to database
    syncCatalogToDatabase();
    return;
  }
  
  try {
    let existing = JSON.parse(existingStr || '{}');
    let changed = false;

    // Merge missing categories/items from defaults
    Object.entries(facultyEquipment).forEach(([category, items]) => {
      if (!existing[category]) {
        existing[category] = JSON.parse(JSON.stringify(items));
        changed = true;
        return;
      }
      const names = new Set((existing[category] || []).map(i => i.name));
      items.forEach(defItem => {
        if (!names.has(defItem.name)) {
          (existing[category] = existing[category] || []).push({
            name: defItem.name,
            available: defItem.available,
            total: defItem.total
          });
          changed = true;
        }
      });
    });

    // Remove RJ45 and empty categories
    const cleaned = sanitizeCatalog(existing);
    if (JSON.stringify(cleaned) !== JSON.stringify(existing)) {
      existing = cleaned;
      changed = true;
    }

    if (changed) {
      localStorage.setItem('equipmentCatalog', JSON.stringify(existing));
      syncCatalogToDatabase();
    }
  } catch (_) {
    const sanitized = sanitizeCatalog(facultyEquipment);
    localStorage.setItem('equipmentCatalog', JSON.stringify(sanitized));
    syncCatalogToDatabase();
  }
}

function getEquipmentCatalog() {
  // Sync from database on first access
  ensureEquipmentCatalogInitialized().catch(() => {});
  const raw = JSON.parse(localStorage.getItem('equipmentCatalog') || '{}');
  const cleaned = sanitizeCatalog(raw);
  // Persist cleaned version if it changed
  if (JSON.stringify(cleaned) !== JSON.stringify(raw)) {
    localStorage.setItem('equipmentCatalog', JSON.stringify(cleaned));
  }
  return cleaned;
}

function setEquipmentCatalog(catalog) {
  localStorage.setItem('equipmentCatalog', JSON.stringify(catalog));
}

// Generate category cards dynamically
function generateCategoryCards() {
  const categoryCardsDiv = document.getElementById('categoryCards');
  if (!categoryCardsDiv) return;
  
  // Always fetch fresh data from database
  fetch('api.php?action=getCatalog', { cache: 'no-store' })
    .then(res => res.json())
    .then(dbCatalog => {
      if (dbCatalog && Object.keys(dbCatalog).length > 0) {
        localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
      }
      
      const catalog = getEquipmentCatalog();
      const categories = Object.keys(catalog);
      
      if (categories.length === 0) {
        categoryCardsDiv.innerHTML = '<p class="text-muted">No equipment categories available yet.</p>';
        return;
      }
      
      // Category icons mapping
      const categoryIcons = {
        'Audio & Visual': 'fa-tv',
        'Furniture & Decorations': 'fa-chair',
        'Power & Ventilation': 'fa-fan',
        'Sports': 'fa-basketball-ball',
        'Networking': 'fa-network-wired',
        'default': 'fa-box'
      };
      
      categoryCardsDiv.innerHTML = '';
      
      categories.forEach(category => {
        const items = catalog[category] || [];
        const equipmentNames = items.map(item => item.name).join(', ');
        const icon = categoryIcons[category] || categoryIcons['default'];
        
        const card = document.createElement('div');
        card.className = 'card';
        card.onclick = () => showEquipment(category);
        card.innerHTML = `
          <i class="fas ${icon}"></i>
          <h3>${category}</h3>
          <p>${equipmentNames || 'No equipment yet'}</p>
        `;
        categoryCardsDiv.appendChild(card);
      });
    })
    .catch(err => {
      console.error('Failed to fetch catalog from database:', err);
      // Fallback to cached catalog
      const catalog = getEquipmentCatalog();
      const categories = Object.keys(catalog);
      
      if (categories.length === 0) {
        categoryCardsDiv.innerHTML = '<p class="text-muted">No equipment categories available yet.</p>';
        return;
      }
      
      const categoryIcons = {
        'Audio & Visual': 'fa-tv',
        'Furniture & Decorations': 'fa-chair',
        'Power & Ventilation': 'fa-fan',
        'Sports': 'fa-basketball-ball',
        'Networking': 'fa-network-wired',
        'default': 'fa-box'
      };
      
      categoryCardsDiv.innerHTML = '';
      
      categories.forEach(category => {
        const items = catalog[category] || [];
        const equipmentNames = items.map(item => item.name).join(', ');
        const icon = categoryIcons[category] || categoryIcons['default'];
        
        const card = document.createElement('div');
        card.className = 'card';
        card.onclick = () => showEquipment(category);
        card.innerHTML = `
          <i class="fas ${icon}"></i>
          <h3>${category}</h3>
          <p>${equipmentNames || 'No equipment yet'}</p>
        `;
        categoryCardsDiv.appendChild(card);
      });
    });
}

function goBackToCategories() {
  const listDiv = document.getElementById('equipmentList');
  if (listDiv) {
    listDiv.innerHTML = '';
  }
}

function showEquipment(category) {
  const listDiv = document.getElementById('equipmentList');
  listDiv.innerHTML = `
    <div class="equipment-header">
      <div style="display:flex; align-items:center; gap:15px;">
        <button class="btn btn-sm" onclick="goBackToCategories()" style="background:#718096;">
          <i class="fas fa-arrow-left"></i> Back to Categories
        </button>
        <h3 style="margin:0;">${category} Equipment</h3>
      </div>
      <button class="btn btn-info" onclick="openModal('reservationModal')">
        <i class="fas fa-plus"></i> Make Reservation
      </button>
    </div>
  `;
  
  // Always fetch fresh data from database
  fetch('api.php?action=getCatalog', { cache: 'no-store' })
    .then(res => res.json())
    .then(dbCatalog => {
      if (dbCatalog && Object.keys(dbCatalog).length > 0) {
        localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
      }
      
      // Remove any existing grid to prevent duplicates
      const existingGrid = listDiv.querySelector('.equipment-grid');
      if (existingGrid) {
        existingGrid.remove();
      }
      
      const grid = document.createElement('div');
      grid.className = 'equipment-grid';
      
      const catalog = getEquipmentCatalog();
      // Remove duplicates by name to ensure each equipment shows only once
      const items = catalog[category] || [];
      const uniqueItems = [];
      const seenNames = new Set();
      items.forEach(item => {
        if (!seenNames.has(item.name)) {
          seenNames.add(item.name);
          uniqueItems.push(item);
        }
      });
      
      uniqueItems.forEach(item => {
        const equipmentCard = document.createElement('div');
        const isUnavailable = item.available === 0;
        equipmentCard.className = isUnavailable ? 'equipment-card unavailable' : 'equipment-card';
        const reserved = item.total - item.available;
        const reservedPercent = item.total > 0 ? (reserved / item.total) * 100 : 0;
        equipmentCard.innerHTML = `
          <div class="equipment-info">
            <h4 style="${isUnavailable ? 'color: #c53030;' : ''}">${item.name}</h4>
            <p class="availability">Reserved: <strong>${reserved}</strong> / ${item.total}</p>
            <p class="available-text" style="${isUnavailable ? 'color: #c53030; font-weight: bold;' : ''}">
              <small>Available: <strong>${item.available}</strong></small>
              ${isUnavailable ? '<span style="color: #c53030; margin-left: 8px;">⚠️ UNAVAILABLE</span>' : ''}
            </p>
            <div class="availability-bar">
              <div class="availability-fill" style="width: ${reservedPercent}%; ${isUnavailable ? 'background-color: #c53030;' : ''}"></div>
            </div>
          </div>
          <button class="btn btn-sm" onclick="reserveEquipment('${item.name}', '${category}')" 
                  ${isUnavailable ? 'disabled style="background-color: #c53030; color: white; cursor: not-allowed;"' : ''}>
            ${isUnavailable ? '❌ Unavailable' : 'Reserve'}
          </button>
        `;
        grid.appendChild(equipmentCard);
      });
      
      listDiv.appendChild(grid);
    })
    .catch(err => {
      console.error('Failed to fetch equipment from database:', err);
      // Fallback to cached catalog
      // Remove any existing grid to prevent duplicates
      const existingGrid = listDiv.querySelector('.equipment-grid');
      if (existingGrid) {
        existingGrid.remove();
      }
      
      const grid = document.createElement('div');
      grid.className = 'equipment-grid';
      const catalog = getEquipmentCatalog();
      // Remove duplicates by name to ensure each equipment shows only once
      const items = catalog[category] || [];
      const uniqueItems = [];
      const seenNames = new Set();
      items.forEach(item => {
        if (!seenNames.has(item.name)) {
          seenNames.add(item.name);
          uniqueItems.push(item);
        }
      });
      
      uniqueItems.forEach(item => {
        const equipmentCard = document.createElement('div');
        const isUnavailable = item.available === 0;
        equipmentCard.className = isUnavailable ? 'equipment-card unavailable' : 'equipment-card';
        const reserved = item.total - item.available;
        const reservedPercent = item.total > 0 ? (reserved / item.total) * 100 : 0;
        equipmentCard.innerHTML = `
          <div class="equipment-info">
            <h4 style="${isUnavailable ? 'color: #c53030;' : ''}">${item.name}</h4>
            <p class="availability">Reserved: <strong>${reserved}</strong> / ${item.total}</p>
            <p class="available-text" style="${isUnavailable ? 'color: #c53030; font-weight: bold;' : ''}">
              <small>Available: <strong>${item.available}</strong></small>
              ${isUnavailable ? '<span style="color: #c53030; margin-left: 8px;">⚠️ UNAVAILABLE</span>' : ''}
            </p>
            <div class="availability-bar">
              <div class="availability-fill" style="width: ${reservedPercent}%; ${isUnavailable ? 'background-color: #c53030;' : ''}"></div>
            </div>
          </div>
          <button class="btn btn-sm" onclick="reserveEquipment('${item.name}', '${category}')" 
                  ${isUnavailable ? 'disabled style="background-color: #c53030; color: white; cursor: not-allowed;"' : ''}>
            ${isUnavailable ? '❌ Unavailable' : 'Reserve'}
          </button>
        `;
        grid.appendChild(equipmentCard);
      });
      listDiv.appendChild(grid);
    });
}

function reserveEquipment(equipmentName, category) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    showNotification('Please login first!', 'error');
    return;
  }
  
  // Get available quantity for this equipment
  const catalog = getEquipmentCatalog();
  const equipmentItem = (catalog[category] || []).find(item => item.name === equipmentName);
  
  if (!equipmentItem) {
    showNotification('Equipment not found!', 'error');
    return;
  }
  
  // Open reservation modal with pre-filled equipment
  document.getElementById('reservationEquipment').value = equipmentName;
  document.getElementById('reservationCategory').value = category;
  
  // Set max quantity based on available equipment
  const quantityInput = document.getElementById('reservationQuantity');
  if (quantityInput) {
    quantityInput.setAttribute('max', equipmentItem.available);
    quantityInput.value = 1; // Reset to 1
    
    // Update the label to show available quantity
    const quantityLabel = document.querySelector('label[for="reservationQuantity"]');
    if (quantityLabel) {
      quantityLabel.innerHTML = `Quantity <span style="color: #2d7a2d;">(Available: ${equipmentItem.available})</span>`;
    }
  }
  
  openModal('reservationModal');
}

/* ===== Faculty Reservations ===== */
function populateFacultyReservations() {
  const table = document.querySelector('#myReservationTable tbody');
  if (!table) return;

  // Get logged-in faculty
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    table.innerHTML = '<tr><td colspan="7" class="text-center">Please login to view reservations</td></tr>';
    return;
  }

  table.innerHTML = '<tr><td colspan="7" class="text-center">Loading reservations...</td></tr>';
  
  // Fetch reservations from database
  fetch(`api.php?action=listFacultyReservations&username=${encodeURIComponent(loggedFaculty.username)}`)
    .then(res => res.json())
    .then(reservations => {
      table.innerHTML = '';
      
      // Show all reservations including cancelled/declined ones
      const activeReservations = reservations;
      
      if (activeReservations.length === 0) {
        table.innerHTML = '<tr><td colspan="7" class="text-center">No reservations found</td></tr>';
        return;
      }

      activeReservations.forEach(r => {
        const tr = document.createElement('tr');
        const safeEquipment = escapeHtml(r.equipment || '');
        const safeCategory = escapeHtml(r.category || '');
        const startDate = r.startDate || r.date;
        const endDate = r.endDate || startDate;
        const dateLabel = (startDate && endDate && startDate !== endDate)
          ? `${startDate} (${r.durationDays || 1} days)`
          : startDate || '';
        const safeDate = escapeHtml(dateLabel);
        const safeTime = escapeHtml(r.time || '');
        const safePurpose = escapeHtml(r.purpose || '');
        const returnStatus = r.returnStatus || 'None';
        
        let actions = '';
        if (r.status === 'Pending') {
          actions = `
              <button class="btn btn-info btn-sm" onclick="editReservation(${r.id}, '${safeEquipment}', '${safeCategory}', '${safeDate}', '${safeTime}', ${r.quantity}, '${safePurpose}')">
                <i class="fas fa-edit"></i> Edit
              </button>
              <button class="btn btn-danger btn-sm" style="margin-left:6px;" onclick="cancelReservation(${r.id})">
                <i class="fas fa-times"></i> Cancel
              </button>
            `;
        } else if (r.status === 'Approved') {
          if (returnStatus === 'None') {
            actions = `
              <button class="btn btn-warning btn-sm" onclick="initiateReturn(${r.id}, '${safeEquipment}', ${r.quantity})">
                <i class="fas fa-undo"></i> Return
              </button>
            `;
          } else if (returnStatus === 'Pending') {
            actions = '<span class="text-muted"><i class="fas fa-clock"></i> Return Pending</span>';
          } else if (returnStatus === 'Cleared') {
            actions = '<span class="text-success"><i class="fas fa-check-circle"></i> Returned</span>';
          }
        } else if (r.status === 'Cancellation Requested') {
          actions = '<span class="text-info"><i class="fas fa-hourglass-half"></i> Cancellation Pending</span>';
        } else if (r.status === 'Cancelled') {
          actions = '<span class="text-warning"><i class="fas fa-ban"></i> Cancelled</span>';
        } else if (r.status === 'Declined') {
          actions = '<span class="text-danger"><i class="fas fa-times-circle"></i> Declined</span>';
        } else {
          actions = '<span class="text-muted">No action</span>';
        }
        
        tr.innerHTML = `
            <td>${safeEquipment}</td>
            <td>${safeDate}</td>
            <td>${safeTime}</td>
            <td>${r.quantity}</td>
            <td><span class="status-badge status-${r.status.toLowerCase().replace(' ', '-')}">${r.status}</span></td>
            <td>${actions}</td>
        `;
        table.appendChild(tr);
      });
    })
    .catch(err => {
      console.error('Error fetching reservations:', err);
      table.innerHTML = '<tr><td colspan="6" class="text-center">Error loading reservations</td></tr>';
    });
}

/* ===== Saturday Blocking Check ===== */
// Check if a date is a Saturday and falls within NSTP blocked period
// Blocked: Saturdays from August 1 to 2nd week of December (excluding June and July)
function isSaturdayBlocked(dateStr) {
  if (!dateStr) return false;
  
  const date = new Date(dateStr + 'T00:00:00'); // Add time to avoid timezone issues
  const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
  
  // Check if it's a Saturday
  if (dayOfWeek !== 6) {
    return false;
  }
  
  const month = date.getMonth() + 1; // getMonth() returns 0-11, so add 1
  const year = date.getFullYear();
  
  // June (6) and July (7) are exempt - allow Saturday reservations
  if (month === 6 || month === 7) {
    return false;
  }
  
  // Check if date is between August 1 and 2nd week of December
  const august1 = new Date(year, 7, 1); // Month is 0-indexed, so 7 = August
  const december15 = new Date(year, 11, 15); // 11 = December, 15 = around 2nd week
  
  // If date is on or after August 1 and on or before December 15, it's blocked
  if (date >= august1 && date <= december15) {
    return true;
  }
  
  return false;
}

/* ===== Reservation Functionality ===== */
function submitReservation() {
  const equipment = document.getElementById('reservationEquipment').value;
  const category = document.getElementById('reservationCategory').value;
  const startDate = document.getElementById('reservationStartDate').value;
  const endDate = document.getElementById('reservationEndDate').value || startDate;
  const time = document.getElementById('reservationTime').value;
  const quantity = document.getElementById('reservationQuantity').value;
  const purpose = document.getElementById('reservationPurpose').value;

  if (!equipment || !category || !startDate || !endDate || !time || !quantity || !purpose) {
    showNotification('Please fill in all fields', 'error');
    return;
  }

  // Validate time format (should be like "8:00-10:00 AM" or "1:00-3:00 PM")
  const timePattern = /^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}\s*(AM|PM|am|pm)$/i;
  if (!timePattern.test(time.trim())) {
    showNotification('Invalid time format! Use format like "8:00-10:00 AM"', 'error');
    return;
  }

  // Validate date range
  const start = new Date(startDate);
  const end = new Date(endDate);
  if (end < start) {
    showNotification('End Date cannot be earlier than Start Date', 'error');
    return;
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (start < today) {
    showNotification('Cannot make reservations for past dates', 'error');
    return;
  }

  // Check each day in range for NSTP Saturday blocking
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const iso = d.toISOString().split('T')[0];
    if (isSaturdayBlocked(iso)) {
      showNotification('Reservations on Saturdays are not allowed due to NSTP activities.', 'error', 5000);
      return;
    }
  }

  const durationDays = Math.floor((end - start) / (1000 * 60 * 60 * 24)) + 1;

  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    showNotification('Please login first!', 'error');
    return;
  }

  // Check if enough equipment is available
  const requestedQuantity = parseInt(quantity);
  const catalog = getEquipmentCatalog();
  const equipmentItem = (catalog[category] || []).find(item => item.name === equipment);
  
  if (!equipmentItem) {
    showNotification('Equipment not found!', 'error');
    return;
  }

  if (equipmentItem.available < requestedQuantity) {
    showNotification(`Only ${equipmentItem.available} ${equipment} available!`, 'error');
    return;
  }

  // Helper to run after a successful reservation save (even if response JSON is a bit noisy)
  const handleReservationSuccess = () => {
    // Database already updated the available quantity, so refresh from database
    fetch('api.php?action=getCatalog', { cache: 'no-store' })
      .then(res => res.json())
      .then(dbCatalog => {
        if (dbCatalog && Object.keys(dbCatalog).length > 0) {
          localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
          window.dispatchEvent(new Event('equipmentUpdated'));
        }
      })
      .catch(err => console.error('Failed to refresh catalog:', err));
    
    // Add audit log
    addAuditLog(
      'Faculty',
      loggedFaculty.fullname,
      `Reserved ${requestedQuantity} ${equipment} for ${startDate}`
    );
    
    // Show success toast and redirect user to Equipment Request list
    showNotification('Successfully requested equipment!', 'success');
    closeModal('reservationModal');
    
    // Clear form
    document.getElementById('reservationForm').reset();
    
    // Refresh reservations table
    populateFacultyReservations();

    // Automatically switch to Equipment Request section so user can see it
    if (typeof showSection === 'function') {
      showSection('reservations');
    }
    
    // Refresh equipment display to show updated availability from database
    const currentCategory = document.querySelector('.equipment-header h3')?.textContent;
    if (currentCategory) {
      const cat = currentCategory.replace(' Equipment', '');
      fetch('api.php?action=getCatalog', { cache: 'no-store' })
        .then(res => res.json())
        .then(dbCatalog => {
          if (dbCatalog && Object.keys(dbCatalog).length > 0) {
            localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
          }
          showEquipment(cat);
        });
    }
  };

  // Save to database via API
  fetch('api.php?action=submitReservation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      facultyUsername: loggedFaculty.username,
      equipment: equipment,
      category: category,
      date: startDate,
      startDate: startDate,
      endDate: endDate,
      durationDays: durationDays,
      time: time,
      quantity: requestedQuantity,
      purpose: purpose
    })
  })
  .then(async res => {
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      console.error('submitReservation JSON parse error. Raw response:', text);
      // If server responded OK but with noisy output, still treat as success
      if (res.ok) {
        handleReservationSuccess();
        return null;
      }
      showNotification('Failed to submit reservation', 'error');
      return null;
    }
    return data;
  })
  .then(data => {
    if (!data) return;
    if (data.ok) {
      handleReservationSuccess();
    } else {
      showNotification(data.error || 'Failed to submit reservation', 'error');
    }
  })
  .catch(err => {
    console.error('Reservation error:', err);
    showNotification('Failed to submit reservation', 'error');
  });
}

document.getElementById('reportForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  
  const equipment = document.getElementById('reportEquipment').value;
  const description = document.getElementById('reportDesc').value;
  
  if (!equipment || !description) {
    showNotification('Please fill in all fields', 'error');
    return;
  }

  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    showNotification('Please login first!', 'error');
    return;
  }

  // Save to database via API
  fetch('api.php?action=createReport', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      facultyUsername: loggedFaculty.username,
      equipment: equipment,
      description: description
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      showNotification('Report submitted successfully!', 'success');
      document.getElementById('reportForm').reset();
      
      // Refresh report history
      populateFacultyReportHistory();
    } else {
      showNotification(data.error || 'Failed to submit report', 'error');
    }
  })
  .catch(err => {
    console.error('Report error:', err);
    showNotification('Failed to submit report', 'error');
  });
});

/* ===== Faculty Report History ===== */
function populateFacultyReportHistory() {
  const table = document.querySelector('#reportHistoryTable tbody');
  if (!table) return;

  // Get logged-in faculty
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    table.innerHTML = '<tr><td colspan="4" class="text-center">Please login to view report history</td></tr>';
    return;
  }

  table.innerHTML = '<tr><td colspan="4" class="text-center">Loading reports...</td></tr>';
  
  // Fetch reports from database
  fetch(`api.php?action=listFacultyReports&username=${encodeURIComponent(loggedFaculty.username)}`)
    .then(res => res.json())
    .then(reports => {
      table.innerHTML = '';
      
      if (reports.length === 0) {
        table.innerHTML = '<tr><td colspan="4" class="text-center">No reports submitted yet</td></tr>';
        return;
      }

      reports.forEach(r => {
        const tr = document.createElement('tr');
        const date = new Date(r.createdAt).toLocaleString();
        
        tr.innerHTML = `
          <td>${r.equipment}</td>
          <td>${r.description}</td>
          <td>${date}</td>
          <td><span class="status-badge status-${r.status.toLowerCase()}">${r.status}</span></td>
        `;
        table.appendChild(tr);
      });
    })
    .catch(err => {
      console.error('Error fetching reports:', err);
      table.innerHTML = '<tr><td colspan="4" class="text-center">Error loading reports</td></tr>';
    });
}

/* ===== Admin Dashboard ===== */
function updateAdminStats() {
  // Fetch stats from database API
  fetch('api.php?action=adminStats')
    .then(res => res.json())
    .then(stats => {
      // Update DOM elements with database values
      const pendingCountEl = document.getElementById('pendingCount');
      const availableEquipmentEl = document.getElementById('availableEquipment');
      const totalFacultyEl = document.getElementById('totalFaculty');
      
      if (pendingCountEl) pendingCountEl.textContent = stats.pendingCount || 0;
      if (availableEquipmentEl) availableEquipmentEl.textContent = stats.availableEquipment || 0;
      if (totalFacultyEl) totalFacultyEl.textContent = stats.totalFaculty || 0;
    })
    .catch(err => {
      console.error('Error fetching admin stats:', err);
      // Fallback to showing 0 if API fails
      const pendingCountEl = document.getElementById('pendingCount');
      const availableEquipmentEl = document.getElementById('availableEquipment');
      const totalFacultyEl = document.getElementById('totalFaculty');
      
      if (pendingCountEl) pendingCountEl.textContent = '0';
      if (availableEquipmentEl) availableEquipmentEl.textContent = '0';
      if (totalFacultyEl) totalFacultyEl.textContent = '0';
    });
}

// Equipment search functionality
function filterEquipmentTable() {
  const searchInput = document.getElementById('equipmentSearchInput');
  if (!searchInput) return;
  
  const searchTerm = searchInput.value.toLowerCase();
  const table = document.querySelector('#equipmentTable tbody');
  if (!table) return;
  
  const rows = table.getElementsByTagName('tr');
  
  for (let i = 0; i < rows.length; i++) {
    const nameCell = rows[i].getElementsByTagName('td')[0];
    const categoryCell = rows[i].getElementsByTagName('td')[1];
    
    if (nameCell && categoryCell) {
      const name = nameCell.textContent.toLowerCase();
      const category = categoryCell.textContent.toLowerCase();
      
      if (name.includes(searchTerm) || category.includes(searchTerm)) {
        rows[i].style.display = '';
      } else {
        rows[i].style.display = 'none';
      }
    }
  }
}

// Create equipment category filter buttons
function createEquipmentCategoryFilters(data) {
  const filterContainer = document.querySelector('.equipment-filters');
  if (!filterContainer) return;
  
  // Clear existing buttons except "All Equipment"
  const allBtn = filterContainer.querySelector('[data-category="all"]');
  filterContainer.innerHTML = '';
  if (allBtn) {
    filterContainer.appendChild(allBtn);
  }
  
  // Create buttons for each category
  for (const [category, items] of Object.entries(data)) {
    // Calculate totals for this category
    let totalAvailable = 0;
    let totalQuantity = 0;
    items.forEach(item => {
      totalAvailable += item.available;
      totalQuantity += item.total;
    });
    
    const btn = document.createElement('button');
    btn.className = 'equipment-filter-btn';
    btn.setAttribute('data-category', category);
    btn.onclick = () => filterEquipmentByCategory(category);
    
    // Get icon based on category name
    let icon = 'fas fa-boxes';
    if (category.toLowerCase().includes('audio') || category.toLowerCase().includes('visual')) {
      icon = 'fas fa-volume-up';
    } else if (category.toLowerCase().includes('furniture') || category.toLowerCase().includes('decoration')) {
      icon = 'fas fa-couch';
    } else if (category.toLowerCase().includes('power') || category.toLowerCase().includes('ventilation')) {
      icon = 'fas fa-plug';
    }
    
    btn.innerHTML = `<i class="${icon}"></i> ${escapeHtml(category)} <span style="margin-left: 8px; font-weight: 600;">(${totalAvailable} / ${totalQuantity})</span>`;
    filterContainer.appendChild(btn);
  }
}

// Filter equipment by category
function filterEquipmentByCategory(category) {
  // Update active button
  document.querySelectorAll('.equipment-filter-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`.equipment-filter-btn[data-category="${category}"]`)?.classList.add('active');
  
  const eqTable = document.querySelector('#equipmentTable tbody');
  const countElement = document.getElementById('equipmentCategoryCount');
  
  if (!eqTable || !window.allEquipmentData) return;
  
  eqTable.innerHTML = '';
  
  let filteredItems = [];
  
  if (category === 'all') {
    // Show all equipment
    for (const [cat, items] of Object.entries(window.allEquipmentData)) {
      items.forEach(item => {
        filteredItems.push({ ...item, category: cat });
      });
    }
  } else {
    // Show only items from selected category
    const items = window.allEquipmentData[category] || [];
    items.forEach(item => {
      filteredItems.push({ ...item, category: category });
    });
  }
  
  if (filteredItems.length === 0) {
    eqTable.innerHTML = '<tr><td colspan="4" class="text-center">No equipment found</td></tr>';
    if (countElement) {
      countElement.textContent = category === 'all' ? 'No equipment found' : `No equipment found in ${category}`;
    }
    return;
  }
  
  // Display items
  filteredItems.forEach(item => {
    const tr = document.createElement('tr');
    const isUnavailable = item.available === 0;
    const status = isUnavailable ? 'Unavailable' : 'Available';
    tr.style.backgroundColor = isUnavailable ? '#fed7d7' : '';
    tr.innerHTML = `
        <td style="${isUnavailable ? 'color: #c53030; font-weight: bold;' : ''}">${escapeHtml(item.name)}</td>
        <td>${escapeHtml(item.category)}</td>
        <td style="${isUnavailable ? 'color: #c53030; font-weight: bold;' : ''}"><strong>${item.available}</strong> / ${item.total}</td>
        <td><span class="badge ${isUnavailable ? 'badge-danger' : 'badge-success'}" style="${isUnavailable ? 'background-color: #c53030; color: white; font-weight: bold;' : ''}">${status}</span></td>
    `;
    eqTable.appendChild(tr);
  });
  
  // Update count
  if (countElement) {
    if (category === 'all') {
      let totalAvailable = 0;
      let totalQuantity = 0;
      for (const [cat, items] of Object.entries(window.allEquipmentData)) {
        items.forEach(item => {
          totalAvailable += item.available;
          totalQuantity += item.total;
        });
      }
      countElement.textContent = `Showing all equipment: ${totalAvailable} / ${totalQuantity} available`;
    } else {
      let totalAvailable = 0;
      let totalQuantity = 0;
      const items = window.allEquipmentData[category] || [];
      items.forEach(item => {
        totalAvailable += item.available;
        totalQuantity += item.total;
      });
      countElement.textContent = `Showing ${items.length} item${items.length !== 1 ? 's' : ''} in ${category}: ${totalAvailable} / ${totalQuantity} available`;
    }
  }
  
  // Re-apply search filter if there's a search term
  const searchInput = document.getElementById('equipmentSearchInput');
  if (searchInput && searchInput.value) {
    filterEquipmentTable();
  }
}

// Create reservation category filter buttons
function createReservationCategoryFilters(reservations) {
  const filterContainer = document.querySelector('.reservation-filters');
  if (!filterContainer) return;
  
  // For admin, we only show gym reservations, so no category filters needed
  // Just keep the "All Reservations" button
  const allBtn = filterContainer.querySelector('[data-category="all"]');
  if (allBtn) {
    filterContainer.innerHTML = '';
    filterContainer.appendChild(allBtn);
    // Update button text to reflect gym reservations only
    allBtn.innerHTML = '<i class="fas fa-list"></i> All Gym Reservations';
  }
}

// Filter reservations by category
function filterReservationsByCategory(category) {
  // Update active button
  document.querySelectorAll('.reservation-filter-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`.reservation-filter-btn[data-category="${category}"]`)?.classList.add('active');
  
  const resTable = document.querySelector('#reservationTable tbody');
  const countElement = document.getElementById('reservationCategoryCount');
  
  if (!resTable || !window.allReservationsData) return;
  
  resTable.innerHTML = '';
  
  let filteredReservations = [];
  
  if (category === 'all') {
    // Show all gym reservations including cancelled/declined ones
    filteredReservations = window.allReservationsData;
    // Sort: Cancellation Requested first, then Pending, then others
    filteredReservations.sort((a, b) => {
      const statusOrder = {
        'Cancellation Requested': 1,
        'Pending': 2,
        'Approved': 3,
        'Declined': 4,
        'Cancelled': 5
      };
      const aOrder = statusOrder[a.status] || 99;
      const bOrder = statusOrder[b.status] || 99;
      return aOrder - bOrder;
    });
  } else {
    // For admin, we only show gym reservations
    filteredReservations = window.allReservationsData;
  }
  
  if (filteredReservations.length === 0) {
    resTable.innerHTML = '<tr><td colspan="9" class="text-center">No reservations found</td></tr>';
    if (countElement) {
      countElement.textContent = category === 'all' ? 'No reservations found' : `No reservations found in ${category}`;
    }
    return;
  }
  
  // Display reservations
  filteredReservations.forEach(r => {
    const tr = document.createElement('tr');
    
    // Check if it's a gym reservation
    if (r.reservationType === 'gym') {
      // Format equipment items for gym reservation
      let equipmentText = '';
      if (r.equipmentItems && r.equipmentItems.length > 0) {
        equipmentText = r.equipmentItems.map(item => 
          `${item.quantity}x ${item.equipment} (${item.category})`
        ).join(', ');
      }
      
      // Format status badge class (handle spaces)
      const statusClass = r.status.toLowerCase().replace(/\s+/g, '-');
      
      // Show cancellation reason if available
      let cancellationInfo = '';
      if (r.status === 'Cancellation Requested' && r.cancel_reason) {
        cancellationInfo = `<br><small class="text-warning" style="font-style: italic;"><i class="fas fa-info-circle"></i> Reason: ${escapeHtml(r.cancel_reason)}</small>`;
      }
      
      tr.innerHTML = `
        <td>${escapeHtml(r.faculty)}</td>
        <td>
          <strong>${escapeHtml(r.title || 'Gym Reservation')}</strong>
          <br><small class="text-muted">Gym Reservation</small>
          ${cancellationInfo}
        </td>
        <td><span class="badge badge-info">Gym</span></td>
        <td>${r.date}</td>
        <td>${escapeHtml(r.time)}</td>
        <td>${escapeHtml(equipmentText || 'N/A')}</td>
        <td>
          <span class="status-badge status-${statusClass}" style="${r.status === 'Cancellation Requested' ? 'background-color: #f59e0b; color: white; font-weight: bold;' : ''}">
            ${r.status}
          </span>
        </td>
        <td>
            ${r.status === 'Pending' ? `
              <div class="action-buttons">
                <button class="btn btn-success btn-sm" onclick="approveGymReservation(${r.id})">
                  <i class="fas fa-check"></i> Approve
                </button>
                <button class="btn btn-danger btn-sm" style="margin-left:6px;" onclick="declineGymReservation(${r.id})">
                  <i class="fas fa-times"></i> Decline
                </button>
              </div>
            ` : r.status === 'Cancellation Requested' ? `
              <div class="action-buttons">
                <button class="btn btn-success btn-sm" onclick="approveGymCancellationRequest(${r.id})" style="background-color: #10b981; border-color: #10b981;">
                  <i class="fas fa-check"></i> Approve Cancellation
                </button>
                <button class="btn btn-danger btn-sm" style="margin-left:6px;" onclick="declineGymCancellationRequest(${r.id})">
                  <i class="fas fa-times"></i> Decline Cancellation
                </button>
              </div>
            ` : '<span class="text-muted">No action</span>'}
        </td>
      `;
    } else {
      // Regular equipment reservation
      tr.innerHTML = `
        <td>${escapeHtml(r.faculty)}</td>
        <td>${escapeHtml(r.equipment)}</td>
        <td><span class="badge badge-info">${escapeHtml(r.category || 'N/A')}</span></td>
        <td>${r.date}</td>
        <td>${escapeHtml(r.time)}</td>
        <td>${r.quantity}</td>
        <td><span class="status-badge status-${r.status.toLowerCase()}">${r.status}</span></td>
        <td>
            ${r.status === 'Pending' ? `
              <span class="text-muted">Pending GenServe approval</span>
            ` : '<span class="text-muted">No action</span>'}
        </td>
      `;
    }
    resTable.appendChild(tr);
  });
  
  // Update count
  if (countElement) {
    const pendingCount = filteredReservations.filter(r => r.status === 'Pending').length;
    const cancellationRequestedCount = filteredReservations.filter(r => r.status === 'Cancellation Requested').length;
    const approvedCount = filteredReservations.filter(r => r.status === 'Approved').length;
    
    let countText = `Showing all gym reservations: ${filteredReservations.length} total`;
    const statusCounts = [];
    if (pendingCount > 0) statusCounts.push(`${pendingCount} pending`);
    if (cancellationRequestedCount > 0) statusCounts.push(`<strong style="color: #f59e0b;">${cancellationRequestedCount} cancellation request${cancellationRequestedCount !== 1 ? 's' : ''}</strong>`);
    if (approvedCount > 0) statusCounts.push(`${approvedCount} approved`);
    
    if (statusCounts.length > 0) {
      countText += ` (${statusCounts.join(', ')})`;
    }
    countElement.innerHTML = countText;
  }
}

// Filter reservations by status
function filterReservationsByStatus(status) {
  // Update active button
  document.querySelectorAll('.reservation-filter-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`.reservation-filter-btn[data-status="${status}"]`)?.classList.add('active');
  
  const resTable = document.querySelector('#reservationTable tbody');
  const countElement = document.getElementById('reservationCategoryCount');
  
  if (!resTable || !window.allReservationsData) return;
  
  resTable.innerHTML = '';
  
  // Filter by status
  let filteredReservations = window.allReservationsData.filter(r => r.status === status);
  
  if (filteredReservations.length === 0) {
    resTable.innerHTML = `<tr><td colspan="9" class="text-center">No ${status} reservations found</td></tr>`;
    if (countElement) {
      countElement.textContent = `No ${status} reservations found`;
    }
    return;
  }
  
  // Display reservations (same display logic as filterReservationsByCategory)
  filteredReservations.forEach(r => {
    const tr = document.createElement('tr');
    
    // Check if it's a gym reservation
    if (r.reservationType === 'gym') {
      // Format equipment items for gym reservation
      let equipmentText = '';
      if (r.equipmentItems && r.equipmentItems.length > 0) {
        equipmentText = r.equipmentItems.map(item => 
          `${item.quantity}x ${item.equipment} (${item.category})`
        ).join(', ');
      }
      
      // Format status badge class (handle spaces)
      const statusClass = r.status.toLowerCase().replace(/\s+/g, '-');
      
      // Show cancellation reason if available
      let cancellationInfo = '';
      if (r.status === 'Cancellation Requested' && r.cancel_reason) {
        cancellationInfo = `<br><small class="text-warning" style="font-style: italic;"><i class="fas fa-info-circle"></i> Reason: ${escapeHtml(r.cancel_reason)}</small>`;
      }
      
      tr.innerHTML = `
        <td>${escapeHtml(r.faculty)}</td>
        <td>
          <strong>${escapeHtml(r.title || 'Gym Reservation')}</strong>
          <br><small class="text-muted">Gym Reservation</small>
          ${cancellationInfo}
        </td>
        <td><span class="badge badge-info">Gym</span></td>
        <td>${r.date}</td>
        <td>${escapeHtml(r.time)}</td>
        <td>${escapeHtml(equipmentText || 'N/A')}</td>
        <td>
          <span class="status-badge status-${statusClass}" style="${r.status === 'Cancellation Requested' ? 'background-color: #f59e0b; color: white; font-weight: bold;' : ''}">
            ${r.status}
          </span>
        </td>
        <td>
            ${r.status === 'Pending' ? `
              <div class="action-buttons">
                <button class="btn btn-success btn-sm" onclick="approveGymReservation(${r.id})">
                  <i class="fas fa-check"></i> Approve
                </button>
                <button class="btn btn-danger btn-sm" style="margin-left:6px;" onclick="declineGymReservation(${r.id})">
                  <i class="fas fa-times"></i> Decline
                </button>
              </div>
            ` : r.status === 'Cancellation Requested' ? `
              <div class="action-buttons">
                <button class="btn btn-success btn-sm" onclick="approveGymCancellationRequest(${r.id})" style="background-color: #10b981; border-color: #10b981;">
                  <i class="fas fa-check"></i> Approve Cancellation
                </button>
                <button class="btn btn-danger btn-sm" style="margin-left:6px;" onclick="declineGymCancellationRequest(${r.id})">
                  <i class="fas fa-times"></i> Decline Cancellation
                </button>
              </div>
            ` : '<span class="text-muted">No action</span>'}
        </td>
      `;
    } else {
      // Regular equipment reservation
      tr.innerHTML = `
        <td>${escapeHtml(r.faculty)}</td>
        <td>${escapeHtml(r.equipment)}</td>
        <td><span class="badge badge-info">${escapeHtml(r.category || 'N/A')}</span></td>
        <td>${r.date}</td>
        <td>${escapeHtml(r.time)}</td>
        <td>${r.quantity}</td>
        <td><span class="status-badge status-${r.status.toLowerCase()}">${r.status}</span></td>
        <td>
            ${r.status === 'Pending' ? `
              <span class="text-muted">Pending GenServe approval</span>
            ` : '<span class="text-muted">No action</span>'}
        </td>
      `;
    }
    resTable.appendChild(tr);
  });
  
  // Update count
  if (countElement) {
    countElement.textContent = `Showing ${filteredReservations.length} ${status} reservation${filteredReservations.length !== 1 ? 's' : ''}`;
  }
}

function populateAdminTables() {
  // Reservation Table - Only show gym reservations for admin
  const resTable = document.querySelector('#reservationTable tbody');
  if (resTable) {
    resTable.innerHTML = '<tr><td colspan="8" class="text-center">Loading reservations...</td></tr>';
    
    // Fetch only gym reservations
    fetch('api.php?action=listAllGymReservations')
      .then(res => res.json())
      .then(gymReservations => {
        // Mark gym reservations with type
        const formattedGymReservations = gymReservations.map(r => ({
          ...r,
          reservationType: 'gym'
        }));
        
        // Store gym reservations globally for filtering
        window.allReservationsData = formattedGymReservations;
        
        // Display all gym reservations by default (with cancellation requests prioritized)
        filterReservationsByCategory('all');
      })
      .catch(err => {
        console.error('Error fetching gym reservations:', err);
        resTable.innerHTML = '<tr><td colspan="8" class="text-center">Error loading reservations</td></tr>';
      });
  }

  // Equipment Table (Read-only view for Admin)
  const eqTable = document.querySelector('#equipmentTable tbody');
  if (eqTable && window.location.pathname.includes('admin-dashboard.php')) {
    eqTable.innerHTML = '<tr><td colspan="4" class="text-center">Loading equipment...</td></tr>';
    
    // Fetch from database
    fetch('api.php?action=getCatalog')
      .then(res => res.json())
      .then(data => {
        // Store equipment data globally
        window.allEquipmentData = data;
        
        // Create category filter buttons
        createEquipmentCategoryFilters(data);
        
        // Display all equipment by default
        filterEquipmentByCategory('all');
      })
      .catch(err => {
        console.error('Error fetching equipment:', err);
        eqTable.innerHTML = '<tr><td colspan="4" class="text-center">Error loading equipment</td></tr>';
      });
  }

  // Faculty Accounts Table - will be populated when Faculty filter is clicked
  populateFacultyAccountsTable();

  // Audit Logs
  const auditTable = document.querySelector('#auditTable tbody');
  const facultyContainer = document.getElementById('facultyAccountsContainer');
  
  // Ensure audit table is visible and faculty container is hidden by default
  if (auditTable && auditTable.closest('table')) {
    auditTable.closest('table').style.display = 'table';
  }
  if (facultyContainer) {
    facultyContainer.style.display = 'none';
  }
  
  if (auditTable) {
    auditTable.innerHTML = '<tr><td colspan="4" class="text-center">Loading audit logs...</td></tr>';
    
    // Fetch audit logs from database
    fetch('api.php?action=listAuditLogs')
      .then(res => res.json())
      .then(auditLogs => {
        // Store all logs globally for filtering
        window.allAuditLogs = auditLogs;
        
        // Display all logs by default
        displayAuditLogs(auditLogs);
      })
      .catch(err => {
        console.error('Error fetching audit logs:', err);
        auditTable.innerHTML = '<tr><td colspan="4" class="text-center">Error loading audit logs</td></tr>';
      });
  }
}

// Admin action functions
function approveReservation(id) {
  // Update reservation status in database
  fetch('api.php?action=updateReservationStatus', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      id: id,
      status: 'Approved'
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      // Fetch reservation details for audit log
      fetch('api.php?action=listAdminReservations')
        .then(res => res.json())
        .then(reservations => {
          const reservation = reservations.find(r => r.id === id);
          if (reservation) {
            // Add to audit log
            addAuditLog('Admin', 'Admin', `Approved reservation for ${reservation.quantity} ${reservation.equipment}`);
            
            // Create notification for faculty
            createFacultyNotification(
              reservation.facultyUsername || reservation.faculty,
              'Reservation Approved',
              `Your reservation for ${reservation.quantity} ${reservation.equipment} has been approved!`,
              'success'
            );
          }
          
          // Refresh from database to ensure all views are synced
          fetch('api.php?action=getCatalog', { cache: 'no-store' })
            .then(res => res.json())
            .then(dbCatalog => {
              if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                window.dispatchEvent(new Event('equipmentUpdated'));
              }
            })
            .catch(err => console.error('Failed to refresh catalog:', err));
        })
        .catch(() => {});
      
      showNotification(`Reservation approved!`, 'success');
      populateAdminTables();
      updateAdminStats();
      
      // Refresh equipment display if on faculty dashboard
      if (window.location.pathname.includes('faculty-dashboard.php')) {
        const currentCategory = document.querySelector('.equipment-header h3')?.textContent;
        if (currentCategory) {
          const cat = currentCategory.replace(' Equipment', '');
          fetch('api.php?action=getCatalog', { cache: 'no-store' })
            .then(res => res.json())
            .then(dbCatalog => {
              if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
              }
              showEquipment(cat);
            });
        }
      }
    } else {
      showNotification(data.error || 'Failed to approve reservation', 'error');
    }
  })
  .catch(err => {
    console.error('Error approving reservation:', err);
    showNotification('Failed to approve reservation', 'error');
  });
}

function declineReservation(id) {
  const proceedDecline = (reasonText) => {
    const trimmedReason = reasonText?.trim() || '';
    
    fetch('api.php?action=updateReservationStatus', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: id,
        status: 'Declined',
        reason: trimmedReason
      })
    })
    .then(res => res.json())
    .then(data => {
      if (data.ok) {
        fetch('api.php?action=listAdminReservations')
          .then(res => res.json())
          .then(reservations => {
            const reservation = reservations.find(r => r.id === id);
            if (reservation) {
              const actorName = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null')?.username || 'Admin';
              const reasonNote = trimmedReason ? ` - Reason: ${trimmedReason}` : '';
              addAuditLog('Admin', actorName, `Declined reservation for ${reservation.quantity} ${reservation.equipment}${reasonNote}`);
              
              const declineMessage = trimmedReason
                ? `Your reservation for ${reservation.quantity} ${reservation.equipment} has been declined. Reason: ${trimmedReason}`
                : `Your reservation for ${reservation.quantity} ${reservation.equipment} has been declined.`;
              
              createFacultyNotification(
                reservation.facultyUsername || reservation.faculty,
                'Reservation Declined',
                declineMessage,
                'error'
              );
            }
            
            fetch('api.php?action=getCatalog', { cache: 'no-store' })
              .then(res => res.json())
              .then(dbCatalog => {
                if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                  localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                  window.dispatchEvent(new Event('equipmentUpdated'));
                }
              })
              .catch(err => console.error('Failed to refresh catalog:', err));
          })
          .catch(() => {});
        
        showNotification('Reservation declined', 'info');
        populateAdminTables();
        updateAdminStats();
        
        if (window.location.pathname.includes('faculty-dashboard.php')) {
          const currentCategory = document.querySelector('.equipment-header h3')?.textContent;
          if (currentCategory) {
            const cat = currentCategory.replace(' Equipment', '');
            fetch('api.php?action=getCatalog', { cache: 'no-store' })
              .then(res => res.json())
              .then(dbCatalog => {
                if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                  localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                }
                showEquipment(cat);
              });
          }
        }
      } else {
        showNotification(data.error || 'Failed to decline reservation', 'error');
      }
    })
    .catch(err => {
      console.error('Error declining reservation:', err);
      showNotification('Failed to decline reservation', 'error');
    });
  };

  showReasonModal({
    title: 'Decline Reservation',
    description: 'Please provide a short note that will be shared with the faculty member.',
    placeholder: 'Reason for declining this reservation',
    confirmText: 'Decline Reservation',
    confirmIcon: 'fas fa-times',
    onConfirm: proceedDecline
  });
}

// Gym Reservation Functions for Admin
function approveGymReservation(id) {
  fetch('api.php?action=updateGymReservationStatus', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      id: id,
      status: 'Approved'
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      // Fetch gym reservation details for audit log and notification
      fetch('api.php?action=listAllGymReservations')
        .then(res => res.json())
        .then(reservations => {
          const reservation = reservations.find(r => r.id === id);
          if (reservation) {
            // Format equipment items for audit log
            const equipmentText = reservation.equipmentItems && reservation.equipmentItems.length > 0
              ? reservation.equipmentItems.map(item => `${item.quantity}x ${item.equipment}`).join(', ')
              : 'equipment';
            
            // Add to audit log
            addAuditLog('Admin', 'Admin', `Approved gym reservation: ${reservation.title} (${equipmentText})`);
            
            // Create notification for faculty in database
            if (reservation.facultyUsername) {
              fetch('api.php?action=createFacultyNotification', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  facultyUsername: reservation.facultyUsername,
                  title: 'Gym Reservation Approved',
                  message: `Your gym reservation "${reservation.title}" has been approved!`,
                  type: 'success'
                })
              }).catch(err => console.error('Failed to create database notification:', err));
            }
            
            // Also create localStorage notification for immediate display
            createFacultyNotification(
              reservation.facultyUsername || reservation.faculty,
              'Gym Reservation Approved',
              `Your gym reservation "${reservation.title}" has been approved!`,
              'success'
            );
          }
          
          // Refresh from database to ensure all views are synced
          fetch('api.php?action=getCatalog', { cache: 'no-store' })
            .then(res => res.json())
            .then(dbCatalog => {
              if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                window.dispatchEvent(new Event('equipmentUpdated'));
              }
            })
            .catch(err => console.error('Failed to refresh catalog:', err));
        })
        .catch(() => {});
      
      showNotification('Gym reservation approved!', 'success');
      populateAdminTables();
      updateAdminStats();
      
      // Trigger refresh for GenServe if they have the gym reservations section open
      // This will be handled by the auto-refresh interval, but we can also dispatch an event
      window.dispatchEvent(new CustomEvent('gymReservationUpdated', { detail: { reservationId: id, status: 'Approved' } }));
    } else {
      showNotification(data.error || 'Failed to approve gym reservation', 'error');
    }
  })
  .catch(err => {
    console.error('Error approving gym reservation:', err);
    showNotification('Failed to approve gym reservation', 'error');
  });
}

function declineGymReservation(id) {
  const proceedDecline = (reasonText) => {
    const trimmedReason = reasonText?.trim() || '';
    
    fetch('api.php?action=updateGymReservationStatus', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: id,
        status: 'Declined',
        reason: trimmedReason
      })
    })
    .then(res => res.json())
    .then(data => {
      if (data.ok) {
        fetch('api.php?action=listAllGymReservations')
          .then(res => res.json())
          .then(reservations => {
            const reservation = reservations.find(r => r.id === id);
            if (reservation) {
              const equipmentText = reservation.equipmentItems && reservation.equipmentItems.length > 0
                ? reservation.equipmentItems.map(item => `${item.quantity}x ${item.equipment}`).join(', ')
                : 'equipment';
              
              const actorName = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null')?.username || 'Admin';
              const reasonNote = trimmedReason ? ` - Reason: ${trimmedReason}` : '';
              addAuditLog('Admin', actorName, `Declined gym reservation: ${reservation.title} (${equipmentText})${reasonNote}`);
              
              const declineMessage = trimmedReason
                ? `Your gym reservation "${reservation.title}" has been declined. Reason: ${trimmedReason}`
                : `Your gym reservation "${reservation.title}" has been declined.`;
              
              if (reservation.facultyUsername) {
                fetch('api.php?action=createFacultyNotification', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    facultyUsername: reservation.facultyUsername,
                    title: 'Gym Reservation Declined',
                    message: declineMessage,
                    type: 'error'
                  })
                }).catch(err => console.error('Failed to create database notification:', err));
              }
              
              createFacultyNotification(
                reservation.facultyUsername || reservation.faculty,
                'Gym Reservation Declined',
                declineMessage,
                'error'
              );
            }
            
            fetch('api.php?action=getCatalog', { cache: 'no-store' })
              .then(res => res.json())
              .then(dbCatalog => {
                if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                  localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                  window.dispatchEvent(new Event('equipmentUpdated'));
                }
              })
              .catch(err => console.error('Failed to refresh catalog:', err));
          })
          .catch(() => {});
        
        showNotification('Gym reservation declined', 'info');
        populateAdminTables();
        updateAdminStats();
        window.dispatchEvent(new CustomEvent('gymReservationUpdated', { detail: { reservationId: id, status: 'Declined' } }));
      } else {
        showNotification(data.error || 'Failed to decline gym reservation', 'error');
      }
    })
    .catch(err => {
      console.error('Error declining gym reservation:', err);
      showNotification('Failed to decline gym reservation', 'error');
    });
  };

  showReasonModal({
    title: 'Decline Gym Reservation',
    description: 'Share why this gym reservation needs to be declined.',
    placeholder: 'Reason for declining this gym reservation',
    confirmText: 'Decline Gym Reservation',
    confirmIcon: 'fas fa-times',
    onConfirm: proceedDecline
  });
}

// Approve gym cancellation request (Admin)
function approveGymCancellationRequest(id) {
  fetch('api.php?action=listAllGymReservations')
    .then(res => res.json())
    .then(reservations => {
      const reservation = reservations.find(r => r.id === id);
      
      if (!reservation) {
        showNotification('Reservation not found', 'error');
        return;
      }
      
      const cancelReason = reservation.cancel_reason || 'No reason provided';
      
      fetch('api.php?action=updateGymReservationStatus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: id,
          status: 'Cancelled',
          reason: cancelReason
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data.ok) {
          const equipmentText = reservation.equipmentItems && reservation.equipmentItems.length > 0
            ? reservation.equipmentItems.map(item => `${item.quantity}x ${item.equipment}`).join(', ')
            : 'equipment';
          
          const actorName = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null')?.username || 'Admin';
          addAuditLog('Admin', actorName, `Approved cancellation request for gym reservation: ${reservation.title} (${equipmentText})`);
          
          if (reservation.facultyUsername) {
            fetch('api.php?action=createFacultyNotification', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                facultyUsername: reservation.facultyUsername,
                title: 'Cancellation Approved',
                message: `Your cancellation request for gym reservation "${reservation.title}" has been approved.`,
                type: 'success'
              })
            }).catch(err => console.error('Failed to create database notification:', err));
          }
          
          createFacultyNotification(
            reservation.facultyUsername || reservation.faculty,
            'Cancellation Approved',
            `Your cancellation request for gym reservation "${reservation.title}" has been approved.`,
            'success'
          );
          
          fetch('api.php?action=getCatalog', { cache: 'no-store' })
            .then(res => res.json())
            .then(dbCatalog => {
              if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                window.dispatchEvent(new Event('equipmentUpdated'));
              }
            })
            .catch(err => console.error('Failed to refresh catalog:', err));
          
          showNotification('Cancellation request approved!', 'success');
          populateAdminTables();
          updateAdminStats();
          window.dispatchEvent(new CustomEvent('gymReservationUpdated', { detail: { reservationId: id, status: 'Cancelled' } }));
        } else {
          showNotification(data.error || 'Failed to approve cancellation', 'error');
        }
      })
      .catch(err => {
        console.error('Error approving cancellation:', err);
        showNotification('Failed to approve cancellation', 'error');
      });
    })
    .catch(err => {
      console.error('Error fetching reservation:', err);
      showNotification('Failed to fetch reservation', 'error');
    });
}

// Decline gym cancellation request (Admin)
function declineGymCancellationRequest(id) {
  const proceedDecline = (reasonText) => {
    const trimmedReason = (reasonText || '').trim();
    
    fetch('api.php?action=listAllGymReservations')
      .then(res => res.json())
      .then(reservations => {
        const reservation = reservations.find(r => r.id === id);
        
        if (!reservation) {
          showNotification('Reservation not found', 'error');
          return;
        }
        
        // Restore to Approved status
        fetch('api.php?action=updateGymReservationStatus', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: id,
            status: 'Approved',
            reason: ''
          })
        })
        .then(res => res.json())
        .then(data => {
          if (data.ok) {
            const equipmentText = reservation.equipmentItems && reservation.equipmentItems.length > 0
              ? reservation.equipmentItems.map(item => `${item.quantity}x ${item.equipment}`).join(', ')
              : 'equipment';
            
            const actorName = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null')?.username || 'Admin';
            const reasonNote = trimmedReason ? ` - Reason: ${trimmedReason}` : '';
            addAuditLog('Admin', actorName, `Declined cancellation request for gym reservation: ${reservation.title} (${equipmentText})${reasonNote}`);
            
            const declineMessage = trimmedReason
              ? `Your cancellation request for gym reservation "${reservation.title}" has been declined. Reason: ${trimmedReason}`
              : `Your cancellation request for gym reservation "${reservation.title}" has been declined.`;
            
            if (reservation.facultyUsername) {
              fetch('api.php?action=createFacultyNotification', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  facultyUsername: reservation.facultyUsername,
                  title: 'Cancellation Declined',
                  message: declineMessage,
                  type: 'error'
                })
              }).catch(err => console.error('Failed to create database notification:', err));
            }
            
            createFacultyNotification(
              reservation.facultyUsername || reservation.faculty,
              'Cancellation Declined',
              declineMessage,
              'error'
            );
            
            showNotification('Cancellation request declined!', 'success');
            populateAdminTables();
            updateAdminStats();
            window.dispatchEvent(new CustomEvent('gymReservationUpdated', { detail: { reservationId: id, status: 'Approved' } }));
          } else {
            showNotification(data.error || 'Failed to decline cancellation', 'error');
          }
        })
        .catch(err => {
          console.error('Error declining cancellation:', err);
          showNotification('Failed to decline cancellation', 'error');
        });
      })
      .catch(err => {
        console.error('Error fetching reservation:', err);
        showNotification('Failed to fetch reservation', 'error');
      });
  };

  showReasonModal({
    title: 'Decline Cancellation Request',
    description: 'Please provide a reason for declining this cancellation request.',
    placeholder: 'Reason for declining the cancellation',
    confirmText: 'Decline Cancellation',
    confirmIcon: 'fas fa-times',
    onConfirm: proceedDecline
  });
}

function markReportFixed(id) {
  // Update report status in database
  fetch('api.php?action=updateReportStatus', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      id: id,
      status: 'Fixed'
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      // Fetch report details for audit log
      fetch('api.php?action=listAdminReports')
        .then(res => res.json())
        .then(reports => {
          const report = reports.find(r => r.id === id);
          if (report) {
            // Add to audit log
            addAuditLog('Admin', 'Admin', `Marked report as fixed: ${report.equipment}`);
            
            // Create notification for faculty (need to get faculty username from report)
            // This would require additional API endpoint or store faculty_id in report
            // For now, we'll skip the notification or add it later
          }
        })
        .catch(() => {});
      
      showNotification('Report marked as fixed!', 'success');
      populateAdminTables();
      updateAdminStats();
      
      // Refresh faculty report history if on faculty dashboard
      if (typeof populateFacultyReportHistory === 'function') {
        populateFacultyReportHistory();
      }
    } else {
      showNotification(data.error || 'Failed to update report', 'error');
    }
  })
  .catch(err => {
    console.error('Error updating report:', err);
    showNotification('Failed to update report', 'error');
  });
}

// Faculty management functions
function editFaculty(username) {
  const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
  const faculty = facultyList.find(f => f.username === username);
  
  if (faculty) {
    // Populate modal with faculty data
    document.getElementById('editFacultyUsername').value = faculty.username;
    document.getElementById('editFacultyUsernameDisplay').value = faculty.username;
    document.getElementById('editFacultyFullname').value = faculty.fullname;
    document.getElementById('editFacultyEmail').value = faculty.email;
    
    // Open modal
    openModal('editFacultyModal');
  }
}

function saveFacultyEdit() {
  const username = document.getElementById('editFacultyUsername').value;
  const newFullname = document.getElementById('editFacultyFullname').value.trim();
  const newEmail = document.getElementById('editFacultyEmail').value.trim();
  
  if (!newFullname || !newEmail) {
    showNotification('Please fill in all fields', 'error');
    return;
  }
  
  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(newEmail)) {
    showNotification('Please enter a valid email address', 'error');
    return;
  }
  
  const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
  const faculty = facultyList.find(f => f.username === username);
  
  if (faculty) {
    faculty.fullname = newFullname;
    faculty.email = newEmail;
    localStorage.setItem('facultyList', JSON.stringify(facultyList));
    
    // Sync to server
    fetch('faculty-api.php?action=write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(facultyList)
    }).catch(err => console.error('Failed to sync faculty data:', err));
    
    addAuditLog('Admin', 'Admin', `Edited faculty account: ${username}`);
    showNotification('Faculty account updated successfully!', 'success');
    
    // Close modal
    closeModal('editFacultyModal');
    
    // Refresh faculty accounts table if it's currently displayed
    const facultyContainer = document.getElementById('facultyAccountsContainer');
    if (facultyContainer && facultyContainer.style.display !== 'none') {
      populateFacultyAccountsTable();
    }
    populateAdminTables();
  }
}

function deleteFaculty(username) {
  const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
  const faculty = facultyList.find(f => f.username === username);
  
  if (!faculty) {
    showNotification('Faculty account not found', 'error');
    return;
  }
  
  // Confirm deletion
  if (!confirm(`Are you sure you want to delete the faculty account for "${faculty.fullname}" (${username})? This action cannot be undone.`)) {
    return;
  }
  
  // Remove from list
  const updatedList = facultyList.filter(f => f.username !== username);
  localStorage.setItem('facultyList', JSON.stringify(updatedList));
  
  // Sync to server
  fetch('faculty-api.php?action=write', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updatedList)
  }).catch(err => console.error('Failed to sync faculty data:', err));
  
  // Also delete from database if exists
  fetch('api.php?action=deleteFaculty', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: username })
  }).catch(err => console.error('Failed to delete from database:', err));
  
  addAuditLog('Admin', 'Admin', `Deleted faculty account: ${username} (${faculty.fullname})`);
  showNotification('Faculty account deleted successfully!', 'success');
  
  // Refresh faculty accounts table if it's currently displayed
  const facultyContainer = document.getElementById('facultyAccountsContainer');
  if (facultyContainer && facultyContainer.style.display !== 'none') {
    populateFacultyAccountsTable();
  }
  populateAdminTables();
}

// Delete conversation function
async function deleteConversation(contactRole, contactId, evt) {
  if (evt) {
    evt.stopPropagation(); // Prevent opening the chat
  }
  
  if (!confirm(`Are you sure you want to delete this conversation? This will permanently delete all messages.`)) {
    return;
  }
  
  if (!currentUserRole || !currentUserId) return;
  
  try {
    // Delete messages from database
    const response = await fetch('api.php?action=deleteConversation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userRole: currentUserRole,
        userId: currentUserId,
        withRole: contactRole,
        withId: contactId
      })
    });
    
    const data = await response.json();
    if (data.ok) {
      showNotification('Conversation deleted successfully!', 'success');
      
      // If this was the active chat, clear it
      if (currentChatTarget && 
          currentChatTarget.contactRole === contactRole && 
          currentChatTarget.contactId === contactId) {
        currentChatTarget = null;
        const messagesEl = document.getElementById('chatMessages');
        const header = document.getElementById('chatHeader');
        const inputWrap = document.getElementById('chatInputContainer');
        if (messagesEl) {
          messagesEl.innerHTML = `
            <div class="chat-empty-state">
              <i class="fas fa-comments"></i>
              <p>Select a conversation to start chatting</p>
            </div>
          `;
        }
        if (header) header.style.display = 'none';
        if (inputWrap) inputWrap.style.display = 'none';
      }
      
      // Reload conversations
      await loadChatContactsForCurrentUser();
    } else {
      showNotification(data.error || 'Failed to delete conversation', 'error');
    }
  } catch (error) {
    console.error('Error deleting conversation:', error);
    showNotification('Failed to delete conversation. Please try again.', 'error');
  }
}

// Equipment management functions
function editEquipment(name, category) {
  const catalog = getEquipmentCatalog();
  const current = (catalog[category] || []).find(item => item.name === name);
  
  if (!current) {
    showNotification('Equipment not found!', 'error');
    return;
  }
  
  // Populate modal with current values
  document.getElementById('editEquipmentName').value = name;
  document.getElementById('editEquipmentCategory').value = category;
  document.getElementById('displayEquipmentName').textContent = name;
  document.getElementById('displayEquipmentCategory').textContent = category;
  document.getElementById('displayCurrentAvailable').textContent = current.available;
  document.getElementById('additionalQuantity').value = 0;
  
  openModal('editEquipmentModal');
}

// Handle equipment edit form submission
document.getElementById('editEquipmentForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  
  const name = document.getElementById('editEquipmentName').value;
  const category = document.getElementById('editEquipmentCategory').value;
  const additionalQty = parseInt(document.getElementById('additionalQuantity').value);
  
  if (isNaN(additionalQty) || additionalQty < 0) {
    showNotification('Invalid quantity value!', 'error');
    return;
  }
  
  if (additionalQty === 0) {
    showNotification('Please enter a quantity to add!', 'error');
    return;
  }
  
  const catalog = getEquipmentCatalog();
  const item = (catalog[category] || []).find(item => item.name === name);
  
  if (item) {
    const oldAvailable = item.available;
    const oldTotal = item.total;
    
    // Add additional quantity to available and total
    item.available += additionalQty;
    item.total += additionalQty;
    
    setEquipmentCatalog(catalog);
    
    // Determine actor type based on current page
    let actorType = 'Admin';
    let actorName = 'Admin';
    if (window.location.pathname.includes('genserve-dashboard.php')) {
      actorType = 'GenServe';
      const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
      actorName = loggedGenServe?.fullname || 'GenServe';
    } else if (window.location.pathname.includes('admin-dashboard.php')) {
      actorType = 'Admin';
      const loggedAdmin = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null');
      actorName = loggedAdmin?.fullname || 'Admin';
    }
    
    // Backup entire catalog to MySQL - wait for response to ensure database is updated
    fetch('api.php?action=backupEquipment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(catalog)
    })
    .then(res => res.json())
    .then(result => {
      if (result.ok) {
        // Database updated successfully, now refresh all views from database
        return fetch('api.php?action=getCatalog', { cache: 'no-store' });
      } else {
        throw new Error(result.error || 'Failed to update database');
      }
    })
    .then(res => res.json())
    .then(dbCatalog => {
      if (dbCatalog && Object.keys(dbCatalog).length > 0) {
        // Update localStorage with fresh database data
        localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
        // Trigger storage event for real-time sync
        window.dispatchEvent(new Event('equipmentUpdated'));
      }
      
      // Add audit log with correct actor
      addAuditLog(actorType, actorName, `Added ${additionalQty} ${name} (${category}): ${oldAvailable}/${oldTotal} → ${item.available}/${item.total}`);
      
      showNotification(`Successfully added ${additionalQty} ${name}! New available: ${item.available} / ${item.total}`, 'success');
      
      closeModal('editEquipmentModal');
      
      // Refresh equipment tables based on current page
      if (window.location.pathname.includes('genserve-dashboard.php')) {
        // Refresh GenServe equipment inventory
        if (typeof window.loadEquipmentInventory === 'function') {
          window.loadEquipmentInventory();
        }
        // Refresh GenServe stats
        if (typeof window.loadGenServeStats === 'function') {
          window.loadGenServeStats();
        }
      } else if (window.location.pathname.includes('admin-dashboard.php')) {
        // Refresh Admin tables
        populateAdminTables();
        updateAdminStats();
      }
      
      // Refresh faculty equipment view
      if (window.location.pathname.includes('faculty-dashboard.php')) {
        const currentCategory = document.querySelector('.equipment-header h3')?.textContent;
        if (currentCategory) {
          const cat = currentCategory.replace(' Equipment', '');
          showEquipment(cat);
        } else {
          generateCategoryCards();
        }
      }
    })
    .catch(err => {
      console.error('Error updating equipment:', err);
      // Revert changes on error
      item.available = oldAvailable;
      item.total = oldTotal;
      setEquipmentCatalog(catalog);
      showNotification('Failed to update equipment in database. Please try again.', 'error');
    });
  }
});

// Faculty return management
function initiateReturn(reservationId, equipmentName, quantity) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    showNotification('Please login first!', 'error');
    return;
  }
  
  if (!confirm(`Are you sure you want to return ${quantity} ${equipmentName}? This will notify GenServe to verify the return.`)) {
    return;
  }
  
  fetch('api.php?action=initiateReturn', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reservationId: reservationId })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      // Create notification for GenServe (stored in localStorage)
      createGenServeNotification(
        `Return Request from ${loggedFaculty.fullname}`,
        `${loggedFaculty.fullname} is returning ${quantity} ${equipmentName}. Please verify the return.`,
        'return'
      );
      
      // Add audit log
      addAuditLog('Faculty', loggedFaculty.fullname, `Requested return of ${quantity} ${equipmentName}`);
      
      showNotification('Return request submitted! GenServe will verify your return.', 'success');
      populateFacultyReservations();
    } else {
      showNotification(data.error || 'Failed to submit return request', 'error');
    }
  })
  .catch(err => {
    console.error('Error initiating return:', err);
    showNotification('Failed to submit return request', 'error');
  });
}

// Faculty gym return management
function initiateGymReturn(reservationId, title, totalQuantity) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    showNotification('Please login first!', 'error');
    return;
  }
  
  if (!confirm(`Are you sure you want to return the gym reservation "${title}"? This will notify GenServe to verify the return.`)) {
    return;
  }
  
  fetch('api.php?action=initiateGymReturn', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reservationId: reservationId })
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      // Create notification for GenServe (stored in localStorage)
      createGenServeNotification(
        `Gym Return Request from ${loggedFaculty.fullname}`,
        `${loggedFaculty.fullname} is returning gym reservation: ${title}. Please verify the return.`,
        'return'
      );
      
      // Add audit log
      addAuditLog('Faculty', loggedFaculty.fullname, `Requested return of gym reservation: ${title}`);
      
      showNotification('Gym return request submitted! GenServe will verify your return.', 'success');
      populateGymReservations();
    } else {
      showNotification(data.error || 'Failed to submit gym return request', 'error');
    }
  })
  .catch(err => {
    console.error('Error initiating gym return:', err);
    showNotification('Failed to submit gym return request', 'error');
  });
}

// Faculty reservation management
function cancelReservation(id) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    showNotification('Please login first!', 'error');
    return;
  }

  const proceedCancellation = (reason) => {
    fetch(`api.php?action=listFacultyReservations&username=${encodeURIComponent(loggedFaculty.username)}`)
      .then(res => res.json())
      .then(reservations => {
        const reservation = reservations.find(r => r.id === id);
        
        if (!reservation) {
          showNotification('Reservation not found or you do not have permission!', 'error');
          return;
        }
        
        if (reservation.status !== 'Pending' && reservation.status !== 'Approved') {
          showNotification('Only pending or approved reservations can be cancelled!', 'error');
          return;
        }
        
        // Request cancellation - will be sent to GenServe for approval
        fetch('api.php?action=updateReservationStatus', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: id,
            status: 'Cancellation Requested',
            reason: reason
          })
        })
        .then(res => res.json())
        .then(data => {
          if (data.ok) {
            // Notify GenServe about cancellation request
            if (typeof createGenServeNotification === 'function') {
              createGenServeNotification(
                'Cancellation Request',
                `${loggedFaculty.fullname} requested to cancel reservation for ${reservation.quantity} ${reservation.equipment}. Reason: ${reason || 'No reason provided'}`,
                'warning'
              );
            }
            
            // Also create database notification for GenServe
            fetch('api.php?action=createGenServeNotification', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                type: 'cancellation_request',
                title: 'Cancellation Request',
                message: `${loggedFaculty.fullname} requested to cancel reservation for ${reservation.quantity} ${reservation.equipment}. Reason: ${reason || 'No reason provided'}`
              })
            }).catch(err => console.error('Failed to create GenServe notification:', err));
            
            const reasonNote = reason ? ` - Reason: ${reason}` : '';
            addAuditLog('Faculty', loggedFaculty.fullname, `Requested cancellation for reservation ${reservation.equipment}${reasonNote}`);
            
            showNotification('Cancellation request submitted! GenServe will review and approve/decline your request.', 'success');
            populateFacultyReservations();
            
            const currentCategory = document.querySelector('.equipment-header h3')?.textContent;
            if (currentCategory) {
              const cat = currentCategory.replace(' Equipment', '');
              showEquipment(cat);
            }
          } else {
            showNotification(data.error || 'Failed to submit cancellation request', 'error');
          }
        })
        .catch(err => {
          console.error('Error cancelling reservation:', err);
          showNotification('Failed to cancel reservation', 'error');
        });
      })
      .catch(err => {
        console.error('Error fetching reservation:', err);
        showNotification('Failed to verify reservation', 'error');
      });
  };

  showReasonModal({
    title: 'Cancel Reservation',
    description: 'Please tell us why you need to cancel this reservation.',
    placeholder: 'Reason for cancelling this reservation',
    confirmText: 'Cancel Reservation',
    confirmIcon: 'fas fa-times',
    onConfirm: proceedCancellation
  });
}

function addAuditLog(type, user, action) {
  // Save to database
  fetch('api.php?action=addAuditLog', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      actor_type: type,
      actor_name: user,
      action: action
    })
  }).catch(err => {
    console.error('Failed to save audit log:', err);
  });
  
  // Also keep in localStorage for immediate display (optional fallback)
  const auditLogs = JSON.parse(localStorage.getItem('auditLogs') || '[]');
  auditLogs.unshift({
    type,
    user,
    action,
    datetime: new Date().toLocaleString()
  });
  localStorage.setItem('auditLogs', JSON.stringify(auditLogs));
}

// Categorize audit log based on action text
function getAuditCategory(action) {
  const actionLower = action.toLowerCase();
  
  if (actionLower.includes('logged in') || actionLower.includes('login')) {
    return 'login';
  } else if (actionLower.includes('reserved') || actionLower.includes('reservation') || 
             actionLower.includes('approved reservation') || actionLower.includes('declined reservation') ||
             actionLower.includes('cancelled reservation') || actionLower.includes('cancel reservation')) {
    return 'reservation';
  } else if (actionLower.includes('return') || actionLower.includes('returned') || 
             actionLower.includes('cleared return') || actionLower.includes('requested return')) {
    return 'return';
  } else if (actionLower.includes('announcement')) {
    return 'announcement';
  } else if (actionLower.includes('equipment') || actionLower.includes('added equipment') || 
             actionLower.includes('edited equipment')) {
    return 'equipment';
  } else if (actionLower.includes('report') || actionLower.includes('marked report')) {
    return 'reports';
  } else if (actionLower.includes('faculty') || actionLower.includes('edited faculty')) {
    return 'faculty';
  }
  
  return 'other';
}

// Display audit logs in table
function displayAuditLogs(auditLogs) {
  const auditTable = document.querySelector('#auditTable tbody');
  const countElement = document.getElementById('auditLogsCount');
  
  if (!auditTable) return;
  
  auditTable.innerHTML = '';
  
  if (auditLogs.length === 0) {
    auditTable.innerHTML = '<tr><td colspan="4" class="text-center">No audit logs found</td></tr>';
    if (countElement) countElement.textContent = 'Showing 0 logs';
    return;
  }
  
  if (countElement) {
    countElement.textContent = `Showing ${auditLogs.length} log${auditLogs.length !== 1 ? 's' : ''}`;
  }
  
  auditLogs.forEach(a => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>${a.type}</td>
        <td>${a.user}</td>
        <td>${a.action}</td>
        <td>${a.datetime}</td>
    `;
    auditTable.appendChild(tr);
  });
}

// Populate Faculty Accounts Table
function populateFacultyAccountsTable() {
  const facTable = document.querySelector('#facultyTable tbody');
  if (facTable) {
    facTable.innerHTML = '<tr><td colspan="4" class="text-center">Loading faculty accounts...</td></tr>';
    
    // Fetch from database instead of localStorage
    fetch('api.php?action=listAllFaculty')
      .then(res => res.json())
      .then(facultyList => {
        facTable.innerHTML = '';
        
        if (!Array.isArray(facultyList) || facultyList.length === 0) {
          facTable.innerHTML = '<tr><td colspan="4" class="text-center">No faculty accounts found</td></tr>';
          return;
        }
        
        facultyList.forEach(f => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
              <td>${escapeHtml(f.fullname)}</td>
              <td>${escapeHtml(f.username)}</td>
              <td>${escapeHtml(f.email)}</td>
              <td>
                  <button class="btn btn-info btn-sm" onclick="editFaculty('${escapeHtml(f.username)}')" style="margin-right: 5px;">
                    <i class="fas fa-edit"></i> Edit
                  </button>
                  <button class="btn btn-danger btn-sm" onclick="deleteFaculty('${escapeHtml(f.username)}')">
                    <i class="fas fa-trash"></i> Delete
                  </button>
              </td>
          `;
          facTable.appendChild(tr);
        });
      })
      .catch(err => {
        console.error('Error fetching faculty accounts:', err);
        facTable.innerHTML = '<tr><td colspan="4" class="text-center">Error loading faculty accounts</td></tr>';
      });
  }
}

// Filter audit logs by category
function filterAuditLogs(category) {
  // Update active button
  document.querySelectorAll('.audit-filter-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`.audit-filter-btn[data-category="${category}"]`)?.classList.add('active');
  
  const auditTable = document.querySelector('#auditTable');
  const facultyContainer = document.getElementById('facultyAccountsContainer');
  const countElement = document.getElementById('auditLogsCount');
  
  // If Faculty category is selected, show faculty accounts table
  if (category === 'faculty') {
    if (auditTable) auditTable.style.display = 'none';
    if (facultyContainer) {
      facultyContainer.style.display = 'block';
      populateFacultyAccountsTable();
    }
    if (countElement) {
      // Fetch count from database to match dashboard
      fetch('api.php?action=adminStats')
        .then(res => res.json())
        .then(stats => {
          const count = stats.totalFaculty || 0;
          countElement.textContent = `Showing ${count} faculty account${count !== 1 ? 's' : ''}`;
        })
        .catch(err => {
          console.error('Error fetching faculty count:', err);
          countElement.textContent = 'Showing faculty accounts';
        });
    }
    return;
  }
  
  // For all other categories, show audit logs table
  if (auditTable) auditTable.style.display = 'table';
  if (facultyContainer) facultyContainer.style.display = 'none';
  
  // Get all logs
  const allLogs = window.allAuditLogs || [];
  
  // Filter logs
  let filteredLogs = [];
  if (category === 'all') {
    filteredLogs = allLogs;
  } else {
    filteredLogs = allLogs.filter(log => {
      const logCategory = getAuditCategory(log.action);
      return logCategory === category;
    });
  }
  
  // Display filtered logs
  displayAuditLogs(filteredLogs);
}

/* ===== Faculty Notification System ===== */
function createFacultyNotification(facultyUsername, title, message, type = 'info') {
  if (!facultyUsername) return;
  
  const notification = {
    id: Date.now() + Math.random(),
    type: type,
    title: title,
    message: message,
    createdAt: new Date().toISOString(),
    isRead: false
  };
  
  let facultyNotifications = JSON.parse(localStorage.getItem(`notifications_${facultyUsername}`) || '[]');
  facultyNotifications.unshift(notification);
  
  // Keep only last 50 notifications
  if (facultyNotifications.length > 50) {
    facultyNotifications = facultyNotifications.slice(0, 50);
  }
  
  localStorage.setItem(`notifications_${facultyUsername}`, JSON.stringify(facultyNotifications));
}

/* ===== GenServe Notification System ===== */
function createGenServeNotification(title, message, type = 'info') {
  const notification = {
    id: Date.now() + Math.random(),
    type: type,
    title: title,
    message: message,
    createdAt: new Date().toISOString(),
    isRead: false
  };
  
  let genserveNotifications = JSON.parse(localStorage.getItem('genserveNotifications') || '[]');
  genserveNotifications.unshift(notification);
  
  // Keep only last 50 notifications
  if (genserveNotifications.length > 50) {
    genserveNotifications = genserveNotifications.slice(0, 50);
  }
  
  localStorage.setItem('genserveNotifications', JSON.stringify(genserveNotifications));
}

// Load GenServe notifications from database
async function loadGenServeNotifications() {
  const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
  if (!loggedGenServe) return;
  
  const notificationContainer = document.getElementById('genserveNotifications');
  if (!notificationContainer) return;
  
  try {
    const resp = await fetch(`api.php?action=listGenServeNotifications&username=${encodeURIComponent(loggedGenServe.username)}`);
    const notifications = await resp.json();
    
    if (!Array.isArray(notifications) || notifications.length === 0) {
      notificationContainer.innerHTML = '<p class="text-muted">No notifications yet.</p>';
      updateGenServeNotificationBadge();
      return;
    }
    
    // Sort by date (newest first)
    notifications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Display notifications
    let html = '';
    notifications.forEach(notif => {
      const date = new Date(notif.createdAt);
      const dateStr = date.toLocaleDateString() + ', ' + date.toLocaleTimeString();
      const isRead = notif.isRead === 1 || notif.isRead === true;
      const borderColor = notif.type === 'nstp_reminder' ? '#f59e0b' : '#3b82f6'; // Yellow for NSTP, blue for others
      
      html += `
        <div class="notification-item ${isRead ? 'read' : 'unread'}" onclick="markGenServeNotificationAsRead(${notif.id})" style="
          padding: 15px;
          margin-bottom: 10px;
          background: ${isRead ? '#ffffff' : '#f8f9fa'};
          border-left: 4px solid ${borderColor};
          border-radius: 4px;
          cursor: pointer;
          opacity: ${isRead ? '0.7' : '1'};
          transition: all 0.2s;
        ">
          <div style="display: flex; justify-content: space-between; align-items: start;">
            <div style="flex: 1;">
              <h4 style="margin: 0 0 5px 0; color: #1f2937;">${escapeHtml(notif.title)}</h4>
              <p style="margin: 0; color: #6b7280;">${escapeHtml(notif.message)}</p>
              <small style="color: #9ca3af; display: block; margin-top: 8px;">${dateStr}</small>
            </div>
            ${!isRead ? '<span class="badge badge-success" style="margin-left: 10px;">New</span>' : ''}
          </div>
        </div>
      `;
    });
    
    notificationContainer.innerHTML = html;
    updateGenServeNotificationBadge();
  } catch (err) {
    console.error('Error loading GenServe notifications:', err);
    notificationContainer.innerHTML = '<p class="text-muted">Error loading notifications.</p>';
  }
}

// Mark GenServe notification as read
async function markGenServeNotificationAsRead(notificationId) {
  try {
    const resp = await fetch('api.php?action=markGenServeNotificationRead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: notificationId })
    });
    const data = await resp.json();
    if (data.ok) {
      // Reload notifications to update display
      loadGenServeNotifications();
    }
  } catch (err) {
    console.error('Error marking notification as read:', err);
  }
}

// Update GenServe notification badge
async function updateGenServeNotificationBadge() {
  const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
  if (!loggedGenServe) return;
  
  try {
    const resp = await fetch(`api.php?action=listGenServeNotifications&username=${encodeURIComponent(loggedGenServe.username)}`);
    const notifications = await resp.json();
    
    if (!Array.isArray(notifications)) return;
    
    const unreadCount = notifications.filter(n => !(n.isRead === 1 || n.isRead === true)).length;
    const badge = document.getElementById('notificationBadge');
    
    if (badge) {
      if (unreadCount > 0) {
        badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
    }
  } catch (err) {
    console.error('Error updating notification badge:', err);
  }
}

/* ===== Admin Notification System ===== */
function createAdminNotification(title, message, type = 'info') {
  const notification = {
    id: Date.now() + Math.random(),
    type: type,
    title: title,
    message: message,
    createdAt: new Date().toISOString(),
    isRead: false
  };
  
  let adminNotifications = JSON.parse(localStorage.getItem('adminNotifications') || '[]');
  adminNotifications.unshift(notification);
  
  // Keep only last 50 notifications
  if (adminNotifications.length > 50) {
    adminNotifications = adminNotifications.slice(0, 50);
  }
  
  localStorage.setItem('adminNotifications', JSON.stringify(adminNotifications));
}

function loadFacultyHomeNotifications() {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;
  
  const notificationContainer = document.getElementById('homeNotifications');
  if (!notificationContainer) return;
  
  const notifications = JSON.parse(localStorage.getItem(`notifications_${loggedFaculty.username}`) || '[]');
  
  if (notifications.length === 0) {
    notificationContainer.innerHTML = '<p class="text-muted">No notifications yet.</p>';
    return;
  }
  
  notificationContainer.innerHTML = '';
  
  // Show only unread notifications or last 5
  const displayNotifications = notifications.slice(0, 10);
  
  displayNotifications.forEach(notif => {
    const notifDiv = document.createElement('div');
    notifDiv.className = `notification-item ${notif.type} ${notif.isRead ? 'read' : 'unread'}`;
    
    const icon = notif.type === 'success' ? '✅' : 
                 notif.type === 'error' ? '❌' : 
                 notif.type === 'announcement' ? '📢' : 'ℹ️';
    
    const date = new Date(notif.createdAt).toLocaleString();
    
    notifDiv.innerHTML = `
      <div class="notif-icon">${icon}</div>
      <div class="notif-content">
        <h4>${notif.title}</h4>
        <p>${notif.message}</p>
        <small>${date}</small>
      </div>
      ${!notif.isRead ? '<span class="unread-badge">New</span>' : ''}
    `;
    
    notifDiv.addEventListener('click', () => markNotificationAsRead(notif.id));
    
    notificationContainer.appendChild(notifDiv);
  });
  
  // Update notification badge count
  updateNotificationBadge();
}

// ===== Calendar Functions for Faculty Dashboard =====

let currentCalendarMonth = new Date().getMonth();
let currentCalendarYear = new Date().getFullYear();
let reservationsByDate = {}; // Cache for reservations

// Load calendar
async function loadCalendar() {
  const calendarContainer = document.getElementById('calendar');
  if (!calendarContainer) return;
  
  // Fetch all reservations for the current month
  await fetchReservationsForMonth(currentCalendarYear, currentCalendarMonth);
  
  // Generate calendar
  generateCalendar(currentCalendarYear, currentCalendarMonth);
}

// Fetch reservations for a specific month
async function fetchReservationsForMonth(year, month) {
  try {
    // Get all approved reservations, gym reservations, and announcements
    const [equipmentResp, gymResp, announcementsResp] = await Promise.all([
      fetch('api.php?action=listAdminReservations'),
      fetch('api.php?action=listAllGymReservations'),
      fetch('api.php?action=listAnnouncements')
    ]);
    
    const equipmentData = await equipmentResp.json();
    const gymData = await gymResp.json();
    const announcementsData = await announcementsResp.json();
    
    // Reset cache
    reservationsByDate = {};
    
    // Process equipment reservations
    if (equipmentData && Array.isArray(equipmentData)) {
      equipmentData.forEach(res => {
        if (res.status === 'Approved' && res.date) {
          const resDate = new Date(res.date);
          if (resDate.getFullYear() === year && resDate.getMonth() === month) {
            const dateKey = res.date;
            if (!reservationsByDate[dateKey]) {
              reservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
            }
            reservationsByDate[dateKey].equipment.push({
              equipment: res.equipment,
              category: res.category,
              time: res.time,
              quantity: res.quantity
            });
          }
        }
      });
    }
    
    // Process gym reservations
    if (gymData && Array.isArray(gymData)) {
      gymData.forEach(res => {
        if (res.status === 'Approved' && res.date) {
          const resDate = new Date(res.date);
          if (resDate.getFullYear() === year && resDate.getMonth() === month) {
            const dateKey = res.date;
            if (!reservationsByDate[dateKey]) {
              reservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
            }
            reservationsByDate[dateKey].gym.push({
              title: res.title,
              time: res.time,
              equipmentItems: res.equipmentItems || []
            });
          }
        }
      });
    }
    
    // Process announcements (show on all dates between start_date and end_date)
    if (announcementsData && Array.isArray(announcementsData)) {
      announcementsData.forEach(ann => {
        if (ann.startDate && ann.endDate) {
          const startDate = new Date(ann.startDate);
          const endDate = new Date(ann.endDate);
          
          // Check if announcement overlaps with the current month
          const monthStart = new Date(year, month, 1);
          const monthEnd = new Date(year, month + 1, 0);
          
          if (endDate >= monthStart && startDate <= monthEnd) {
            // Add announcement to all dates in its range that are in this month
            const currentDate = new Date(Math.max(startDate, monthStart));
            const lastDate = new Date(Math.min(endDate, monthEnd));
            
            while (currentDate <= lastDate) {
              const dateKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
              if (!reservationsByDate[dateKey]) {
                reservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
              }
              reservationsByDate[dateKey].announcements.push({
                id: ann.id,
                title: ann.title,
                message: ann.message,
                startDate: ann.startDate,
                startTime: ann.startTime,
                endDate: ann.endDate,
                endTime: ann.endTime
              });
              currentDate.setDate(currentDate.getDate() + 1);
            }
          }
        }
      });
    }
  } catch (e) {
    console.error('Error fetching reservations:', e);
  }
}

// Generate calendar HTML
function generateCalendar(year, month) {
  const calendarContainer = document.getElementById('calendar');
  if (!calendarContainer) return;
  
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  let html = `
    <div style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <button class="btn btn-secondary" onclick="changeCalendarMonth(-1)">
          <i class="fas fa-chevron-left"></i> Previous
        </button>
        <h3 style="margin: 0; font-size: 24px; color: #1d4ed8;">${monthNames[month]} ${year}</h3>
        <button class="btn btn-secondary" onclick="changeCalendarMonth(1)">
          Next <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 8px;">
  `;
  
  // Day headers
  dayNames.forEach(day => {
    html += `<div style="text-align: center; font-weight: bold; padding: 10px; color: #666; background: #f8f9fa; border-radius: 5px;">${day}</div>`;
  });
  
  // Empty cells for days before month starts
  for (let i = 0; i < firstDay; i++) {
    html += `<div style="padding: 15px; min-height: 60px;"></div>`;
  }
  
  // Days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dateData = reservationsByDate[dateKey] || { equipment: [], gym: [], announcements: [] };
    const hasReservations = dateData.equipment.length > 0 || dateData.gym.length > 0;
    const hasAnnouncements = dateData.announcements && dateData.announcements.length > 0;
    const totalItems = dateData.equipment.length + dateData.gym.length + (dateData.announcements ? dateData.announcements.length : 0);
    
    const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
    
    // Determine border color - orange for announcements, blue for reservations, purple for both
    let borderColor = '#e5e7eb';
    let bgColor = 'white';
    if (hasAnnouncements && hasReservations) {
      borderColor = '#9333ea'; // Purple for both
      bgColor = '#faf5ff';
    } else if (hasAnnouncements) {
      borderColor = '#f59e0b'; // Orange for announcements
      bgColor = '#fffbeb';
    } else if (hasReservations) {
      borderColor = '#1d4ed8'; // Blue for reservations
      bgColor = '#eff6ff';
    }
    
    if (isToday) {
      bgColor = '#dbeafe';
    }
    
    html += `
      <div onclick="showDateDetails('${dateKey}')" 
           style="padding: 15px; min-height: 60px; border: 2px solid ${borderColor}; 
                  border-radius: 8px; cursor: pointer; background: ${bgColor};
                  transition: all 0.2s; position: relative;"
           onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.15)'"
           onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='none'">
        <div style="font-weight: ${isToday ? 'bold' : 'normal'}; font-size: 16px; color: ${isToday ? '#1d4ed8' : '#1f2937'};">
          ${day}
        </div>
        ${totalItems > 0 ? `
          <div style="margin-top: 5px; font-size: 11px; color: ${hasAnnouncements && hasReservations ? '#9333ea' : hasAnnouncements ? '#f59e0b' : '#1d4ed8'};">
            <i class="fas fa-circle" style="font-size: 6px;"></i>
            ${totalItems} item${totalItems !== 1 ? 's' : ''}
          </div>
        ` : ''}
      </div>
    `;
  }
  
  html += `
      </div>
    </div>
  `;
  
  calendarContainer.innerHTML = html;
}

// Change calendar month
async function changeCalendarMonth(direction) {
  currentCalendarMonth += direction;
  if (currentCalendarMonth < 0) {
    currentCalendarMonth = 11;
    currentCalendarYear--;
  } else if (currentCalendarMonth > 11) {
    currentCalendarMonth = 0;
    currentCalendarYear++;
  }
  
  await fetchReservationsForMonth(currentCalendarYear, currentCalendarMonth);
  generateCalendar(currentCalendarYear, currentCalendarMonth);
}

// Admin calendar functions (reuse same logic but different container)
let adminCalendarMonth = new Date().getMonth();
let adminCalendarYear = new Date().getFullYear();
let adminReservationsByDate = {};

async function loadAdminCalendar() {
  const calendarContainer = document.getElementById('adminCalendar');
  if (!calendarContainer) return;
  
  // Fetch all reservations for the current month
  await fetchAdminReservationsForMonth(adminCalendarYear, adminCalendarMonth);
  
  // Generate calendar
  generateAdminCalendar(adminCalendarYear, adminCalendarMonth);
}

async function fetchAdminReservationsForMonth(year, month) {
  try {
    // Get all approved reservations, gym reservations, and announcements
    const [equipmentResp, gymResp, announcementsResp] = await Promise.all([
      fetch('api.php?action=listAdminReservations'),
      fetch('api.php?action=listAllGymReservations'),
      fetch('api.php?action=listAnnouncements')
    ]);
    
    const equipmentData = await equipmentResp.json();
    const gymData = await gymResp.json();
    const announcementsData = await announcementsResp.json();
    
    // Reset cache
    adminReservationsByDate = {};
    
    // Process equipment reservations
    if (equipmentData && Array.isArray(equipmentData)) {
      equipmentData.forEach(res => {
        if (res.status === 'Approved' && res.date) {
          const resDate = new Date(res.date);
          if (resDate.getFullYear() === year && resDate.getMonth() === month) {
            const dateKey = res.date;
            if (!adminReservationsByDate[dateKey]) {
              adminReservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
            }
            adminReservationsByDate[dateKey].equipment.push({
              equipment: res.equipment,
              category: res.category,
              time: res.time,
              quantity: res.quantity
            });
          }
        }
      });
    }
    
    // Process gym reservations
    if (gymData && Array.isArray(gymData)) {
      gymData.forEach(res => {
        if (res.status === 'Approved' && res.date) {
          const resDate = new Date(res.date);
          if (resDate.getFullYear() === year && resDate.getMonth() === month) {
            const dateKey = res.date;
            if (!adminReservationsByDate[dateKey]) {
              adminReservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
            }
            adminReservationsByDate[dateKey].gym.push({
              title: res.title,
              time: res.time,
              equipmentItems: res.equipmentItems || []
            });
          }
        }
      });
    }
    
    // Process announcements (show on all dates between start_date and end_date)
    if (announcementsData && Array.isArray(announcementsData)) {
      announcementsData.forEach(ann => {
        if (ann.startDate && ann.endDate) {
          const startDate = new Date(ann.startDate);
          const endDate = new Date(ann.endDate);
          
          // Check if announcement overlaps with the current month
          const monthStart = new Date(year, month, 1);
          const monthEnd = new Date(year, month + 1, 0);
          
          if (endDate >= monthStart && startDate <= monthEnd) {
            // Add announcement to all dates in its range that are in this month
            const currentDate = new Date(Math.max(startDate, monthStart));
            const lastDate = new Date(Math.min(endDate, monthEnd));
            
            while (currentDate <= lastDate) {
              const dateKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
              if (!adminReservationsByDate[dateKey]) {
                adminReservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
              }
              adminReservationsByDate[dateKey].announcements.push({
                id: ann.id,
                title: ann.title,
                message: ann.message,
                startDate: ann.startDate,
                startTime: ann.startTime,
                endDate: ann.endDate,
                endTime: ann.endTime
              });
              currentDate.setDate(currentDate.getDate() + 1);
            }
          }
        }
      });
    }
  } catch (e) {
    console.error('Error fetching admin reservations:', e);
  }
}

function generateAdminCalendar(year, month) {
  const calendarContainer = document.getElementById('adminCalendar');
  if (!calendarContainer) return;
  
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  let html = `
    <div style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <button class="btn btn-secondary" onclick="changeAdminCalendarMonth(-1)">
          <i class="fas fa-chevron-left"></i> Previous
        </button>
        <h3 style="margin: 0; font-size: 24px; color: #1d4ed8;">${monthNames[month]} ${year}</h3>
        <button class="btn btn-secondary" onclick="changeAdminCalendarMonth(1)">
          Next <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 8px;">
  `;
  
  // Day headers
  dayNames.forEach(day => {
    html += `<div style="text-align: center; font-weight: bold; padding: 10px; color: #666; background: #f8f9fa; border-radius: 5px;">${day}</div>`;
  });
  
  // Empty cells for days before month starts
  for (let i = 0; i < firstDay; i++) {
    html += `<div style="padding: 15px; min-height: 60px;"></div>`;
  }
  
  // Days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dateData = adminReservationsByDate[dateKey] || { equipment: [], gym: [], announcements: [] };
    const hasReservations = dateData.equipment.length > 0 || dateData.gym.length > 0;
    const hasAnnouncements = dateData.announcements && dateData.announcements.length > 0;
    const totalItems = dateData.equipment.length + dateData.gym.length + (dateData.announcements ? dateData.announcements.length : 0);
    
    const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
    
    // Determine border color - orange for announcements, blue for reservations, purple for both
    let borderColor = '#e5e7eb';
    let bgColor = 'white';
    if (hasAnnouncements && hasReservations) {
      borderColor = '#9333ea'; // Purple for both
      bgColor = '#faf5ff';
    } else if (hasAnnouncements) {
      borderColor = '#f59e0b'; // Orange for announcements
      bgColor = '#fffbeb';
    } else if (hasReservations) {
      borderColor = '#1d4ed8'; // Blue for reservations
      bgColor = '#eff6ff';
    }
    
    if (isToday) {
      bgColor = '#dbeafe';
    }
    
    html += `
      <div onclick="showAdminDateDetails('${dateKey}')" 
           style="padding: 15px; min-height: 60px; border: 2px solid ${borderColor}; 
                  border-radius: 8px; cursor: pointer; background: ${bgColor};
                  transition: all 0.2s; position: relative;"
           onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.15)'"
           onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='none'">
        <div style="font-weight: ${isToday ? 'bold' : 'normal'}; font-size: 16px; color: ${isToday ? '#1d4ed8' : '#1f2937'};">
          ${day}
        </div>
        ${totalItems > 0 ? `
          <div style="margin-top: 5px; font-size: 11px; color: ${hasAnnouncements && hasReservations ? '#9333ea' : hasAnnouncements ? '#f59e0b' : '#1d4ed8'};">
            <i class="fas fa-circle" style="font-size: 6px;"></i>
            ${totalItems} item${totalItems !== 1 ? 's' : ''}
          </div>
        ` : ''}
      </div>
    `;
  }
  
  html += `
      </div>
    </div>
  `;
  
  calendarContainer.innerHTML = html;
}

async function changeAdminCalendarMonth(direction) {
  adminCalendarMonth += direction;
  if (adminCalendarMonth < 0) {
    adminCalendarMonth = 11;
    adminCalendarYear--;
  } else if (adminCalendarMonth > 11) {
    adminCalendarMonth = 0;
    adminCalendarYear++;
  }
  
  await fetchAdminReservationsForMonth(adminCalendarYear, adminCalendarMonth);
  generateAdminCalendar(adminCalendarYear, adminCalendarMonth);
}

async function showAdminDateDetails(dateKey) {
  const modal = document.getElementById('adminDateDetailsModal');
  const titleElement = document.getElementById('adminSelectedDateDisplay');
  const contentElement = document.getElementById('adminDateDetailsContent');
  
  if (!modal || !titleElement || !contentElement) return;
  
  // Format date for display
  const date = new Date(dateKey);
  const formattedDate = date.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  titleElement.textContent = formattedDate;
  
  contentElement.innerHTML = '<p class="text-muted">Loading...</p>';
  openModal('adminDateDetailsModal');
  
  try {
    // Use cached data or fetch if needed
    let reservations = adminReservationsByDate[dateKey];
    
    if (!reservations) {
      const resp = await fetch(`api.php?action=getReservationsByDate&date=${dateKey}`);
      const data = await resp.json();
      reservations = {
        equipment: data.equipmentReservations || [],
        gym: data.gymReservations || [],
        announcements: data.announcements || []
      };
    } else {
      // Ensure announcements are included
      if (!reservations.announcements) {
        reservations.announcements = [];
      }
    }
    
    let html = '';
    
    // Include announcements if available
    const announcements = reservations.announcements || [];
    const hasContent = reservations.equipment.length > 0 || reservations.gym.length > 0 || announcements.length > 0;
    
    if (!hasContent) {
      html = '<p class="text-muted">No reservations or announcements for this date.</p>';
    } else {
      // Show announcements first
      if (announcements.length > 0) {
        html += '<div style="margin-bottom: 30px;">';
        html += '<h4 style="color: #f59e0b; margin-bottom: 15px;"><i class="fas fa-bullhorn"></i> Announcements</h4>';
        announcements.forEach(ann => {
          html += '<div style="padding: 15px; background: #fffbeb; border-left: 4px solid #f59e0b; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(ann.title)}</div>`;
          html += `<div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;">${escapeHtml(ann.message)}</div>`;
          html += `<div style="color: #6b7280; font-size: 12px;"><i class="fas fa-calendar"></i> ${ann.startDate} ${ann.startTime} - ${ann.endDate} ${ann.endTime}</div>`;
          html += '</div>';
        });
        html += '</div>';
      }
      
      // Show gym reservations
      if (reservations.gym.length > 0) {
        html += '<div style="margin-bottom: 30px;">';
        html += '<h4 style="color: #1d4ed8; margin-bottom: 15px;"><i class="fas fa-dumbbell"></i> Gym Reservations</h4>';
        reservations.gym.forEach(gym => {
          html += '<div style="padding: 15px; background: #eff6ff; border-left: 4px solid #1d4ed8; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(gym.title)}</div>`;
          html += `<div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;"><i class="fas fa-clock"></i> ${escapeHtml(gym.time)}</div>`;
          if (gym.equipmentItems && gym.equipmentItems.length > 0) {
            const itemsText = gym.equipmentItems.map(item => 
              `${item.quantity}x ${item.equipment}`
            ).join(', ');
            html += `<div style="color: #6b7280; font-size: 14px;"><i class="fas fa-boxes"></i> ${escapeHtml(itemsText)}</div>`;
          }
          html += '</div>';
        });
        html += '</div>';
      }
      
      // Show equipment reservations
      if (reservations.equipment.length > 0) {
        html += '<div>';
        html += '<h4 style="color: #16a34a; margin-bottom: 15px;"><i class="fas fa-boxes"></i> Equipment Borrowed</h4>';
        reservations.equipment.forEach(eq => {
          html += '<div style="padding: 15px; background: #f0fdf4; border-left: 4px solid #16a34a; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(eq.equipment)} <span style="color: #6b7280; font-weight: normal;">(${escapeHtml(eq.category)})</span></div>`;
          html += `<div style="color: #6b7280; font-size: 14px;"><i class="fas fa-clock"></i> ${escapeHtml(eq.time)} | <i class="fas fa-hashtag"></i> Quantity: ${eq.quantity}</div>`;
          html += '</div>';
        });
        html += '</div>';
      }
    }
    
    contentElement.innerHTML = html;
  } catch (e) {
    console.error('Error loading admin date details:', e);
    contentElement.innerHTML = '<p class="text-muted">Error loading reservations for this date.</p>';
  }
}

// GenServe calendar functions (reuse same logic but different container)
let genserveCalendarMonth = new Date().getMonth();
let genserveCalendarYear = new Date().getFullYear();
let genserveReservationsByDate = {};

async function loadGenServeCalendar() {
  const calendarContainer = document.getElementById('genserveCalendar');
  if (!calendarContainer) return;
  
  // Fetch all reservations for the current month
  await fetchGenServeReservationsForMonth(genserveCalendarYear, genserveCalendarMonth);
  
  // Generate calendar
  generateGenServeCalendar(genserveCalendarYear, genserveCalendarMonth);
}

async function fetchGenServeReservationsForMonth(year, month) {
  try {
    // Get all approved reservations, gym reservations, and announcements
    const [equipmentResp, gymResp, announcementsResp] = await Promise.all([
      fetch('api.php?action=listAdminReservations'),
      fetch('api.php?action=listAllGymReservations'),
      fetch('api.php?action=listAnnouncements')
    ]);
    
    const equipmentData = await equipmentResp.json();
    const gymData = await gymResp.json();
    const announcementsData = await announcementsResp.json();
    
    // Reset cache
    genserveReservationsByDate = {};
    
    // Process equipment reservations
    if (equipmentData && Array.isArray(equipmentData)) {
      equipmentData.forEach(res => {
        if (res.status === 'Approved' && res.date) {
          const resDate = new Date(res.date);
          if (resDate.getFullYear() === year && resDate.getMonth() === month) {
            const dateKey = res.date;
            if (!genserveReservationsByDate[dateKey]) {
              genserveReservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
            }
            genserveReservationsByDate[dateKey].equipment.push({
              equipment: res.equipment,
              category: res.category,
              time: res.time,
              quantity: res.quantity
            });
          }
        }
      });
    }
    
    // Process gym reservations
    if (gymData && Array.isArray(gymData)) {
      gymData.forEach(res => {
        if (res.status === 'Approved' && res.date) {
          const resDate = new Date(res.date);
          if (resDate.getFullYear() === year && resDate.getMonth() === month) {
            const dateKey = res.date;
            if (!genserveReservationsByDate[dateKey]) {
              genserveReservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
            }
            genserveReservationsByDate[dateKey].gym.push({
              title: res.title,
              time: res.time,
              equipmentItems: res.equipmentItems || []
            });
          }
        }
      });
    }
    
    // Process announcements (show on all dates between start_date and end_date)
    if (announcementsData && Array.isArray(announcementsData)) {
      announcementsData.forEach(ann => {
        if (ann.startDate && ann.endDate) {
          const startDate = new Date(ann.startDate);
          const endDate = new Date(ann.endDate);
          
          // Check if announcement overlaps with the current month
          const monthStart = new Date(year, month, 1);
          const monthEnd = new Date(year, month + 1, 0);
          
          if (endDate >= monthStart && startDate <= monthEnd) {
            // Add announcement to all dates in its range that are in this month
            const currentDate = new Date(Math.max(startDate, monthStart));
            const lastDate = new Date(Math.min(endDate, monthEnd));
            
            while (currentDate <= lastDate) {
              const dateKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
              if (!genserveReservationsByDate[dateKey]) {
                genserveReservationsByDate[dateKey] = { equipment: [], gym: [], announcements: [] };
              }
              genserveReservationsByDate[dateKey].announcements.push({
                id: ann.id,
                title: ann.title,
                message: ann.message,
                startDate: ann.startDate,
                startTime: ann.startTime,
                endDate: ann.endDate,
                endTime: ann.endTime
              });
              currentDate.setDate(currentDate.getDate() + 1);
            }
          }
        }
      });
    }
  } catch (e) {
    console.error('Error fetching genserve reservations:', e);
  }
}

function generateGenServeCalendar(year, month) {
  const calendarContainer = document.getElementById('genserveCalendar');
  if (!calendarContainer) return;
  
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  let html = `
    <div style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <button class="btn btn-secondary" onclick="changeGenServeCalendarMonth(-1)">
          <i class="fas fa-chevron-left"></i> Previous
        </button>
        <h3 style="margin: 0; font-size: 24px; color: #1d4ed8;">${monthNames[month]} ${year}</h3>
        <button class="btn btn-secondary" onclick="changeGenServeCalendarMonth(1)">
          Next <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 8px;">
  `;
  
  // Day headers
  dayNames.forEach(day => {
    html += `<div style="text-align: center; font-weight: bold; padding: 10px; color: #666; background: #f8f9fa; border-radius: 5px;">${day}</div>`;
  });
  
  // Empty cells for days before month starts
  for (let i = 0; i < firstDay; i++) {
    html += `<div style="padding: 15px; min-height: 60px;"></div>`;
  }
  
  // Days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dateData = genserveReservationsByDate[dateKey] || { equipment: [], gym: [], announcements: [] };
    const hasReservations = dateData.equipment.length > 0 || dateData.gym.length > 0;
    const hasAnnouncements = dateData.announcements && dateData.announcements.length > 0;
    const totalItems = dateData.equipment.length + dateData.gym.length + (dateData.announcements ? dateData.announcements.length : 0);
    
    const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
    
    // Determine border color - orange for announcements, blue for reservations, purple for both
    let borderColor = '#e5e7eb';
    let bgColor = 'white';
    if (hasAnnouncements && hasReservations) {
      borderColor = '#9333ea'; // Purple for both
      bgColor = '#faf5ff';
    } else if (hasAnnouncements) {
      borderColor = '#f59e0b'; // Orange for announcements
      bgColor = '#fffbeb';
    } else if (hasReservations) {
      borderColor = '#1d4ed8'; // Blue for reservations
      bgColor = '#eff6ff';
    }
    
    if (isToday) {
      bgColor = '#dbeafe';
    }
    
    html += `
      <div onclick="showGenServeDateDetails('${dateKey}')" 
           style="padding: 15px; min-height: 60px; border: 2px solid ${borderColor}; 
                  border-radius: 8px; cursor: pointer; background: ${bgColor};
                  transition: all 0.2s; position: relative;"
           onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.15)'"
           onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='none'">
        <div style="font-weight: ${isToday ? 'bold' : 'normal'}; font-size: 16px; color: ${isToday ? '#1d4ed8' : '#1f2937'};">
          ${day}
        </div>
        ${totalItems > 0 ? `
          <div style="margin-top: 5px; font-size: 11px; color: ${hasAnnouncements && hasReservations ? '#9333ea' : hasAnnouncements ? '#f59e0b' : '#1d4ed8'};">
            <i class="fas fa-circle" style="font-size: 6px;"></i>
            ${totalItems} item${totalItems !== 1 ? 's' : ''}
          </div>
        ` : ''}
      </div>
    `;
  }
  
  html += `
      </div>
    </div>
  `;
  
  calendarContainer.innerHTML = html;
}

async function changeGenServeCalendarMonth(direction) {
  genserveCalendarMonth += direction;
  if (genserveCalendarMonth < 0) {
    genserveCalendarMonth = 11;
    genserveCalendarYear--;
  } else if (genserveCalendarMonth > 11) {
    genserveCalendarMonth = 0;
    genserveCalendarYear++;
  }
  
  await fetchGenServeReservationsForMonth(genserveCalendarYear, genserveCalendarMonth);
  generateGenServeCalendar(genserveCalendarYear, genserveCalendarMonth);
}

async function showGenServeDateDetails(dateKey) {
  const modal = document.getElementById('genserveDateDetailsModal');
  const titleElement = document.getElementById('genserveSelectedDateDisplay');
  const contentElement = document.getElementById('genserveDateDetailsContent');
  
  if (!modal || !titleElement || !contentElement) return;
  
  // Format date for display
  const date = new Date(dateKey);
  const formattedDate = date.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  titleElement.textContent = formattedDate;
  
  contentElement.innerHTML = '<p class="text-muted">Loading...</p>';
  openModal('genserveDateDetailsModal');
  
  try {
    // Use cached data or fetch if needed
    let reservations = genserveReservationsByDate[dateKey];
    
    if (!reservations) {
      const resp = await fetch(`api.php?action=getReservationsByDate&date=${dateKey}`);
      const data = await resp.json();
      reservations = {
        equipment: data.equipmentReservations || [],
        gym: data.gymReservations || [],
        announcements: data.announcements || []
      };
    } else {
      // Ensure announcements are included
      if (!reservations.announcements) {
        reservations.announcements = [];
      }
    }
    
    let html = '';
    
    // Include announcements if available
    const announcements = reservations.announcements || [];
    const hasContent = reservations.equipment.length > 0 || reservations.gym.length > 0 || announcements.length > 0;
    
    if (!hasContent) {
      html = '<p class="text-muted">No reservations or announcements for this date.</p>';
    } else {
      // Show announcements first
      if (announcements.length > 0) {
        html += '<div style="margin-bottom: 30px;">';
        html += '<h4 style="color: #f59e0b; margin-bottom: 15px;"><i class="fas fa-bullhorn"></i> Announcements</h4>';
        announcements.forEach(ann => {
          html += '<div style="padding: 15px; background: #fffbeb; border-left: 4px solid #f59e0b; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(ann.title)}</div>`;
          html += `<div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;">${escapeHtml(ann.message)}</div>`;
          html += `<div style="color: #6b7280; font-size: 12px;"><i class="fas fa-calendar"></i> ${ann.startDate} ${ann.startTime} - ${ann.endDate} ${ann.endTime}</div>`;
          html += '</div>';
        });
        html += '</div>';
      }
      
      // Show gym reservations
      if (reservations.gym.length > 0) {
        html += '<div style="margin-bottom: 30px;">';
        html += '<h4 style="color: #1d4ed8; margin-bottom: 15px;"><i class="fas fa-dumbbell"></i> Gym Reservations</h4>';
        reservations.gym.forEach(gym => {
          html += '<div style="padding: 15px; background: #eff6ff; border-left: 4px solid #1d4ed8; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(gym.title)}</div>`;
          html += `<div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;"><i class="fas fa-clock"></i> ${escapeHtml(gym.time)}</div>`;
          if (gym.equipmentItems && gym.equipmentItems.length > 0) {
            const itemsText = gym.equipmentItems.map(item => 
              `${item.quantity}x ${item.equipment}`
            ).join(', ');
            html += `<div style="color: #6b7280; font-size: 14px;"><i class="fas fa-boxes"></i> ${escapeHtml(itemsText)}</div>`;
          }
          html += '</div>';
        });
        html += '</div>';
      }
      
      // Show equipment reservations
      if (reservations.equipment.length > 0) {
        html += '<div>';
        html += '<h4 style="color: #16a34a; margin-bottom: 15px;"><i class="fas fa-boxes"></i> Equipment Borrowed</h4>';
        reservations.equipment.forEach(eq => {
          html += '<div style="padding: 15px; background: #f0fdf4; border-left: 4px solid #16a34a; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(eq.equipment)} <span style="color: #6b7280; font-weight: normal;">(${escapeHtml(eq.category)})</span></div>`;
          html += `<div style="color: #6b7280; font-size: 14px;"><i class="fas fa-clock"></i> ${escapeHtml(eq.time)} | <i class="fas fa-hashtag"></i> Quantity: ${eq.quantity}</div>`;
          html += '</div>';
        });
        html += '</div>';
      }
    }
    
    contentElement.innerHTML = html;
  } catch (e) {
    console.error('Error loading genserve date details:', e);
    contentElement.innerHTML = '<p class="text-muted">Error loading reservations for this date.</p>';
  }
}

// Show date details when clicked
async function showDateDetails(dateKey) {
  const modal = document.getElementById('dateDetailsModal');
  const titleElement = document.getElementById('selectedDateDisplay');
  const contentElement = document.getElementById('dateDetailsContent');
  
  if (!modal || !titleElement || !contentElement) return;
  
  // Format date for display
  const date = new Date(dateKey);
  const formattedDate = date.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  titleElement.textContent = formattedDate;
  
  contentElement.innerHTML = '<p class="text-muted">Loading...</p>';
  openModal('dateDetailsModal');
  
  try {
    // Use cached data or fetch if needed
    let reservations = reservationsByDate[dateKey];
    
    if (!reservations) {
      const resp = await fetch(`api.php?action=getReservationsByDate&date=${dateKey}`);
      const data = await resp.json();
      reservations = {
        equipment: data.equipmentReservations || [],
        gym: data.gymReservations || [],
        announcements: data.announcements || []
      };
    } else {
      // Ensure announcements are included
      if (!reservations.announcements) {
        reservations.announcements = [];
      }
    }
    
    let html = '';
    
    // Include announcements if available
    const announcements = reservations.announcements || [];
    const hasContent = reservations.equipment.length > 0 || reservations.gym.length > 0 || announcements.length > 0;
    
    if (!hasContent) {
      html = '<p class="text-muted">No reservations or announcements for this date.</p>';
    } else {
      // Show announcements first
      if (announcements.length > 0) {
        html += '<div style="margin-bottom: 30px;">';
        html += '<h4 style="color: #f59e0b; margin-bottom: 15px;"><i class="fas fa-bullhorn"></i> Announcements</h4>';
        announcements.forEach(ann => {
          html += '<div style="padding: 15px; background: #fffbeb; border-left: 4px solid #f59e0b; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(ann.title)}</div>`;
          html += `<div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;">${escapeHtml(ann.message)}</div>`;
          html += `<div style="color: #6b7280; font-size: 12px;"><i class="fas fa-calendar"></i> ${ann.startDate} ${ann.startTime} - ${ann.endDate} ${ann.endTime}</div>`;
          html += '</div>';
        });
        html += '</div>';
      }
      
      // Show gym reservations
      if (reservations.gym.length > 0) {
        html += '<div style="margin-bottom: 30px;">';
        html += '<h4 style="color: #1d4ed8; margin-bottom: 15px;"><i class="fas fa-dumbbell"></i> Gym Reservations</h4>';
        reservations.gym.forEach(gym => {
          html += '<div style="padding: 15px; background: #eff6ff; border-left: 4px solid #1d4ed8; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(gym.title)}</div>`;
          html += `<div style="color: #6b7280; font-size: 14px; margin-bottom: 8px;"><i class="fas fa-clock"></i> ${escapeHtml(gym.time)}</div>`;
          if (gym.equipmentItems && gym.equipmentItems.length > 0) {
            const itemsText = gym.equipmentItems.map(item => 
              `${item.quantity}x ${item.equipment}`
            ).join(', ');
            html += `<div style="color: #6b7280; font-size: 14px;"><i class="fas fa-boxes"></i> ${escapeHtml(itemsText)}</div>`;
          }
          html += '</div>';
        });
        html += '</div>';
      }
      
      // Show equipment reservations
      if (reservations.equipment.length > 0) {
        html += '<div>';
        html += '<h4 style="color: #16a34a; margin-bottom: 15px;"><i class="fas fa-boxes"></i> Equipment Borrowed</h4>';
        reservations.equipment.forEach(eq => {
          html += '<div style="padding: 15px; background: #f0fdf4; border-left: 4px solid #16a34a; border-radius: 5px; margin-bottom: 10px;">';
          html += `<div style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">${escapeHtml(eq.equipment)} <span style="color: #6b7280; font-weight: normal;">(${escapeHtml(eq.category)})</span></div>`;
          html += `<div style="color: #6b7280; font-size: 14px;"><i class="fas fa-clock"></i> ${escapeHtml(eq.time)} | <i class="fas fa-hashtag"></i> Quantity: ${eq.quantity}</div>`;
          html += '</div>';
        });
        html += '</div>';
      }
    }
    
    contentElement.innerHTML = html;
  } catch (e) {
    console.error('Error loading date details:', e);
    contentElement.innerHTML = '<p class="text-muted">Error loading reservations for this date.</p>';
  }
}

function markNotificationAsRead(notificationId) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;
  
  const notifications = JSON.parse(localStorage.getItem(`notifications_${loggedFaculty.username}`) || '[]');
  const notification = notifications.find(n => n.id === notificationId);
  
  if (notification && !notification.isRead) {
    notification.isRead = true;
    localStorage.setItem(`notifications_${loggedFaculty.username}`, JSON.stringify(notifications));
    loadFacultyHomeNotifications();
  }
}

function updateNotificationBadge() {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;
  
  const notifications = JSON.parse(localStorage.getItem(`notifications_${loggedFaculty.username}`) || '[]');
  const unreadCount = notifications.filter(n => !n.isRead).length;
  
  const badge = document.getElementById('notificationBadge');
  if (badge) {
    if (unreadCount > 0) {
      badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
      badge.style.display = 'inline-block';
    } else {
      badge.style.display = 'none';
    }
  }
}

/* ===== Announcement System ===== */
function createAnnouncement() {
  // Open the announcement modal
  openModal('announcementModal');
  
  // Set minimum dates to today
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('announcementStartDate').setAttribute('min', today);
  document.getElementById('announcementEndDate').setAttribute('min', today);
}

// Handle announcement form submission
document.getElementById('announcementForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  
  const title = document.getElementById('announcementTitle').value;
  const message = document.getElementById('announcementMessage').value;
  const startDate = document.getElementById('announcementStartDate').value;
  const startTime = document.getElementById('announcementStartTime').value;
  const endDate = document.getElementById('announcementEndDate').value;
  const endTime = document.getElementById('announcementEndTime').value;
  const duration = document.getElementById('announcementDuration').value;
  const isUrgent = document.getElementById('announcementUrgent').checked;

  if (!title || !message || !startDate || !startTime || !endDate || !endTime || !duration) {
    showNotification('Please fill in all fields', 'error');
    return;
  }

  // Validate dates
  const start = new Date(startDate);
  const end = new Date(endDate);
  
  if (end < start) {
    showNotification('End date cannot be before start date', 'error');
    return;
  }

  // Calculate duration in days
  const calculatedDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;
  
  const announcement = {
    id: Date.now(),
    title,
    message,
    startDate,
    startTime,
    endDate,
    endTime,
    duration: parseInt(duration),
    calculatedDays,
    createdAt: new Date().toISOString(),
    createdBy: 'Admin',
    isActive: true,
    isUrgent: isUrgent
  };

  let announcements = JSON.parse(localStorage.getItem('announcements') || '[]');
  announcements.unshift(announcement);
  localStorage.setItem('announcements', JSON.stringify(announcements));

  // Persist to MySQL
  fetch('api.php?action=createAnnouncement', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, message, startDate, startTime, endDate, endTime, duration, isUrgent })
  }).then(() => {
    // Log announcement creation
    addAuditLog('Admin', 'Admin', `Created announcement: ${title}`);
  }).catch(() => {});

  // Send immediate notification to all faculty
  const facultyList = JSON.parse(localStorage.getItem('facultyList') || '[]');
  facultyList.forEach(faculty => {
    addAuditLog('System', 'Admin', `Announcement sent to ${faculty.fullname}: ${title}`);
    
    // Create individual notification for each faculty with full details
    createFacultyNotification(
      faculty.username,
      isUrgent ? '🚨 URGENT: ' + title : '📢 ' + title,
      message,
      'announcement'
    );
  });

  showNotification('Announcement created and sent to all faculty!', 'success');
  populateAnnouncements();
  
  // Refresh calendar if it's loaded
  if (typeof loadAdminCalendar === 'function' && document.getElementById('adminCalendar')) {
    loadAdminCalendar();
  }
  
  closeModal('announcementModal');
  
  // Reset form
  document.getElementById('announcementForm').reset();
  
  // Show immediate notification to admin
  showNotification(`📢 Announcement sent to ${facultyList.length} faculty members!`, 'info', 5000);
});

// Helper function to check if announcement is expired
function isAnnouncementExpired(announcement) {
  if (!announcement.endDate || !announcement.endTime) {
    return false; // If no end date/time, consider it not expired
  }
  
  const now = new Date();
  const endDateTime = new Date(`${announcement.endDate}T${announcement.endTime}`);
  
  // Check if current date/time is past the end date/time
  return now > endDateTime;
}

async function populateAnnouncements() {
  const announcementList = document.getElementById('announcementList');
  
  if (!announcementList) return;
  
  const isAdminPage = window.location.pathname.includes('admin-dashboard.php') || !!document.querySelector('.announcement-controls');
  
  // Show loading state
  announcementList.innerHTML = '<p class="text-muted">Loading announcements...</p>';
  
  try {
    // Always fetch announcements from database first
    const response = await fetch('api.php?action=listAnnouncements');
    const announcements = await response.json();
    
    // Update localStorage with fetched announcements
    if (Array.isArray(announcements)) {
      localStorage.setItem('announcements', JSON.stringify(announcements));
    }
    
    // Clear the list
    announcementList.innerHTML = '';
    
    // Prepare announcements list (show all for all pages)
    const activeAnnouncements = Array.isArray(announcements)
      ? announcements
      : [];
    
    // Display announcements
    if (activeAnnouncements.length === 0) {
      announcementList.innerHTML = '<p class="text-muted">No active announcements yet.</p>';
      return;
    }

    activeAnnouncements.forEach(announcement => {
      const announcementDiv = document.createElement('div');
      announcementDiv.className = 'announcement-card';
      
      // Format dates
      const startDate = new Date(announcement.startDate || announcement.date).toLocaleDateString();
      const endDate = new Date(announcement.endDate || announcement.date).toLocaleDateString();
      
      let footerHtml = `<small>Posted by ${announcement.createdBy || 'Admin'} on ${new Date(announcement.createdAt).toLocaleString()}</small>`;
      if (isAdminPage) {
        footerHtml += ` <button class="btn btn-sm btn-danger" onclick="confirmDeleteAnnouncement(${announcement.id})">Delete</button>`;
      }

      announcementDiv.innerHTML = `
        <div class="announcement-header">
          <h4>${announcement.title}</h4>
          <div class="announcement-dates">
            <span class="announcement-date">${startDate} - ${endDate}</span>
            <span class="announcement-duration">${announcement.duration || announcement.calculatedDays || 1} day(s)</span>
          </div>
        </div>
        <div class="announcement-body">
          <p>${announcement.message}</p>
          <div class="announcement-details">
            <div class="announcement-time">
              <i class="fas fa-clock"></i>
              <span>${announcement.startTime} - ${announcement.endTime}</span>
            </div>
            <div class="announcement-duration-info">
              <i class="fas fa-calendar-alt"></i>
              <span>Duration: ${announcement.duration || announcement.calculatedDays || 1} day(s)</span>
            </div>
          </div>
        </div>
        <div class="announcement-footer">
          ${footerHtml}
        </div>
      `;
      announcementList.appendChild(announcementDiv);
    });
  } catch (error) {
    console.error('Error fetching announcements:', error);
    // Fallback to localStorage if API fails
    const announcements = JSON.parse(localStorage.getItem('announcements') || '[]');
    announcementList.innerHTML = '';
    
    // Prepare announcements list from localStorage (show all)
    const activeAnnouncements = announcements;
    
    if (activeAnnouncements.length === 0) {
      announcementList.innerHTML = '<p class="text-muted">No active announcements yet.</p>';
      return;
    }

    activeAnnouncements.forEach(announcement => {
      const announcementDiv = document.createElement('div');
      announcementDiv.className = 'announcement-card';
      
      // Format dates
      const startDate = new Date(announcement.startDate || announcement.date).toLocaleDateString();
      const endDate = new Date(announcement.endDate || announcement.date).toLocaleDateString();

      let footerHtml = `<small>Posted by ${announcement.createdBy || 'Admin'} on ${new Date(announcement.createdAt).toLocaleString()}</small>`;
      if (isAdminPage) {
        footerHtml += ` <button class="btn btn-sm btn-danger" onclick="confirmDeleteAnnouncement(${announcement.id})">Delete</button>`;
      }

      announcementDiv.innerHTML = `
        <div class="announcement-header">
          <h4>${announcement.title}</h4>
          <div class="announcement-dates">
            <span class="announcement-date">${startDate} - ${endDate}</span>
            <span class="announcement-duration">${announcement.duration || announcement.calculatedDays || 1} day(s)</span>
          </div>
        </div>
        <div class="announcement-body">
          <p>${announcement.message}</p>
          <div class="announcement-details">
            <div class="announcement-time">
              <i class="fas fa-clock"></i>
              <span>${announcement.startTime} - ${announcement.endTime}</span>
            </div>
            <div class="announcement-duration-info">
              <i class="fas fa-calendar-alt"></i>
              <span>Duration: ${announcement.duration || announcement.calculatedDays || 1} day(s)</span>
            </div>
          </div>
        </div>
        <div class="announcement-footer">
          ${footerHtml}
        </div>
      `;
      announcementList.appendChild(announcementDiv);
    });
  }
}

function confirmDeleteAnnouncement(id) {
  if (!window.confirm('Delete this announcement? This action cannot be undone.')) {
    return;
  }
  deleteAnnouncement(id);
}

async function deleteAnnouncement(id) {
  try {
    const resp = await fetch('api.php?action=deleteAnnouncement', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    const data = await resp.json();
    if (data.ok) {
      showNotification('Announcement deleted successfully.', 'success');
      // Refresh announcements everywhere
      populateAnnouncements();
      // Refresh admin calendar if present so badges/counts update
      if (typeof loadAdminCalendar === 'function' && document.getElementById('adminCalendar')) {
        loadAdminCalendar();
      }
    } else {
      showNotification(data.error || 'Failed to delete announcement.', 'error');
    }
  } catch (e) {
    console.error('Error deleting announcement:', e);
    showNotification('Error deleting announcement. Please try again.', 'error');
  }
}

async function checkForAnnouncements() {
  try {
    // Fetch latest announcements from database
    const response = await fetch('api.php?action=listAnnouncements');
    const announcements = await response.json();
    
    if (Array.isArray(announcements)) {
      // Update localStorage with fetched announcements
      localStorage.setItem('announcements', JSON.stringify(announcements));
      
      // Filter out expired announcements
      const activeAnnouncements = announcements.filter(announcement => !isAnnouncementExpired(announcement));
      
      const today = new Date().toISOString().split('T')[0];
      const currentTime = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
      
      activeAnnouncements.forEach(announcement => {
        const startDate = announcement.startDate || announcement.date;
        const endDate = announcement.endDate || announcement.date;
        
        // Check if today is within the announcement date range
        if (startDate && endDate && today >= startDate && today <= endDate) {
          const startTime = convertTo24Hour(announcement.startTime);
          const endTime = convertTo24Hour(announcement.endTime);
          
          if (currentTime >= startTime && currentTime <= endTime) {
            showNotification(`📢 ${announcement.title}: ${announcement.message}`, 'info', 10000);
          }
        }
      });
    }
  } catch (error) {
    console.error('Error checking announcements:', error);
    // Fallback to localStorage if API fails
    const announcements = JSON.parse(localStorage.getItem('announcements') || '[]');
    
    // Filter out expired announcements
    const activeAnnouncements = announcements.filter(announcement => !isAnnouncementExpired(announcement));
    
    const today = new Date().toISOString().split('T')[0];
    const currentTime = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    
    activeAnnouncements.forEach(announcement => {
      const startDate = announcement.startDate || announcement.date;
      const endDate = announcement.endDate || announcement.date;
      
      if (startDate && endDate && today >= startDate && today <= endDate) {
        const startTime = convertTo24Hour(announcement.startTime);
        const endTime = convertTo24Hour(announcement.endTime);
        
        if (currentTime >= startTime && currentTime <= endTime) {
          showNotification(`📢 ${announcement.title}: ${announcement.message}`, 'info', 10000);
        }
      }
    });
  }
}

/* ===== Faculty Notification System ===== */
function loadFacultyNotifications() {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;

  const notifications = JSON.parse(localStorage.getItem(`notifications_${loggedFaculty.username}`) || '[]');
  const unreadCount = notifications.filter(n => !n.isRead).length;
  
  // Update notification badge
  const notificationBadge = document.getElementById('notificationBadge');
  if (notificationBadge) {
    notificationBadge.textContent = unreadCount;
    notificationBadge.style.display = unreadCount > 0 ? 'block' : 'none';
  }

  // Sidebar badge as well
  const sidebarAnnBadge = document.getElementById('sidebarAnnBadge');
  if (sidebarAnnBadge) {
    sidebarAnnBadge.textContent = unreadCount;
    sidebarAnnBadge.style.display = unreadCount > 0 ? 'inline-block' : 'none';
  }

  // Do not auto-mark as read; only badge update here
}

function markNotificationAsRead(notificationId) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;

  let notifications = JSON.parse(localStorage.getItem(`notifications_${loggedFaculty.username}`) || '[]');
  const notification = notifications.find(n => n.id === notificationId);
  if (notification) {
    notification.isRead = true;
    localStorage.setItem(`notifications_${loggedFaculty.username}`, JSON.stringify(notifications));
    loadFacultyNotifications();
  }
}

// Mark all announcement notifications as read for the logged-in faculty
function markAllFacultyAnnouncementNotificationsAsRead() {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;

  let notifications = JSON.parse(localStorage.getItem(`notifications_${loggedFaculty.username}`) || '[]');
  let changed = false;
  notifications.forEach(n => {
    if (n.type === 'announcement' && !n.isRead) {
      n.isRead = true;
      changed = true;
    }
  });
  if (changed) {
    localStorage.setItem(`notifications_${loggedFaculty.username}`, JSON.stringify(notifications));
    loadFacultyNotifications();
  }
}

function showAllNotifications() {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;

  const notifications = JSON.parse(localStorage.getItem(`notifications_${loggedFaculty.username}`) || '[]');
  const notificationModal = document.getElementById('notificationModal');
  
  if (notificationModal) {
    const notificationList = document.getElementById('facultyNotificationList');
    notificationList.innerHTML = '';

    if (notifications.length === 0) {
      notificationList.innerHTML = '<p class="text-muted">No notifications yet.</p>';
    } else {
      notifications.forEach(notification => {
        const notificationDiv = document.createElement('div');
        notificationDiv.className = `notification-item ${notification.isRead ? 'read' : 'unread'}`;
        
        // Use fullMessage if available, otherwise use regular message
        const displayMessage = notification.fullMessage || notification.message;
        
        notificationDiv.innerHTML = `
          <div class="notification-content">
            <h5>${notification.title}</h5>
            <div class="notification-message">${displayMessage.replace(/\n/g, '<br>')}</div>
            ${notification.startDate && notification.endDate ? `
              <div class="notification-dates">
                <div class="notification-date-info">
                  <i class="fas fa-calendar"></i>
                  <span>${new Date(notification.startDate).toLocaleDateString()} - ${new Date(notification.endDate).toLocaleDateString()}</span>
                </div>
                <div class="notification-time-info">
                  <i class="fas fa-clock"></i>
                  <span>${notification.startTime} - ${notification.endTime}</span>
                </div>
                <div class="notification-duration-info">
                  <i class="fas fa-calendar-alt"></i>
                  <span>Duration: ${notification.duration || 1} day(s)</span>
                </div>
              </div>
            ` : ''}
            <small>Received: ${new Date(notification.createdAt).toLocaleString()}</small>
          </div>
          ${!notification.isRead ? `<button class="btn btn-sm btn-info" onclick="markNotificationAsRead(${notification.id})">Mark as Read</button>` : ''}
        `;
        notificationList.appendChild(notificationDiv);
      });
    }

    openModal('notificationModal');

    // When opening the notifications modal, mark all announcement notifications as read
    markAllFacultyAnnouncementNotificationsAsRead();
  }
}

function convertTo24Hour(time12h) {
  const [time, modifier] = time12h.split(' ');
  let [hours, minutes] = time.split(':');
  if (hours === '12') {
    hours = '00';
  }
  if (modifier === 'PM') {
    hours = parseInt(hours, 10) + 12;
  }
  return `${hours}:${minutes}`;
}

/* ===== Analytics Chart ===== */
function loadChart() {
  const ctx = document.getElementById('equipmentChart')?.getContext('2d');
  if (!ctx) return;

  new Chart(ctx, {
      type: 'bar',
      data: {
          labels: ['LED', 'Lights', 'Mics', 'Speakers', 'Chairs', 'Tables'],
          datasets: [{
              label: 'Most Reserved Equipment',
              data: [5, 3, 4, 2, 8, 6],
              backgroundColor: '#1d4ed8'
          }]
      },
      options: {
          responsive: true,
          plugins: {
              legend: { display: false },
              title: { display: true, text: 'Equipment Reservations' }
          }
      }
  });
}

/* ===== Utilities ===== */
function addEquipment() {
  // Open modal and populate categories (with an option for new category)
  const select = document.getElementById('equipmentCategory');
  const newCatGroup = document.getElementById('newCategoryGroup');
  const form = document.getElementById('addEquipmentForm');
  if (!select || !newCatGroup || !form) return;

  // Reset form
  form.reset();
  select.innerHTML = '';

  const catalog = getEquipmentCatalog();
  const categories = Object.keys(catalog);

  // Populate options
  const defaultOpt = document.createElement('option');
  defaultOpt.value = '';
  defaultOpt.textContent = 'Select category';
  select.appendChild(defaultOpt);

  categories.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat;
    opt.textContent = cat;
    select.appendChild(opt);
  });

  const newOpt = document.createElement('option');
  newOpt.value = '__new__';
  newOpt.textContent = 'Create new category…';
  select.appendChild(newOpt);

  // Toggle new category input
  select.onchange = function() {
    newCatGroup.style.display = this.value === '__new__' ? 'block' : 'none';
  };

  // Attach submit handler (one-time)
  form.onsubmit = function(e) {
    e.preventDefault();
    const name = document.getElementById('equipmentName').value.trim();
    const selected = select.value;
    const qty = parseInt(document.getElementById('equipmentQuantity').value || '0');
    const newCat = document.getElementById('newCategoryName').value.trim();

    if (!name || (!selected && !newCat)) {
      showNotification('Please complete all fields', 'error');
      return;
    }
    if (isNaN(qty) || qty < 0) {
      showNotification('Invalid quantity', 'error');
      return;
    }

    const category = selected === '__new__' ? newCat : selected;
    const currentCatalog = getEquipmentCatalog();
    if (!currentCatalog[category]) currentCatalog[category] = [];

    const exists = currentCatalog[category].some(i => i.name.toLowerCase() === name.toLowerCase());
    if (exists) {
      showNotification('Equipment already exists in this category', 'error');
      return;
    }

    currentCatalog[category].push({ name, available: qty, total: qty });
    setEquipmentCatalog(currentCatalog);

    addAuditLog('Admin', 'Admin', `Added equipment ${name} (${category}) x${qty}`);
    showNotification('New equipment added!', 'success');
    closeModal('addEquipmentModal');
    populateAdminTables();
    updateAdminStats();
  };

  openModal('addEquipmentModal');
}

function showSection(id) {
  document.querySelectorAll('section').forEach(sec => sec.classList.remove('active-section'));
  const s = document.getElementById(id);
  if (s) s.classList.add('active-section');

  // If faculty opens the home section, load calendar
  if (id === 'home' && window.location.pathname.includes('faculty-dashboard.php')) {
    if (typeof loadCalendar === 'function') {
      loadCalendar();
    }
  }

  // If faculty opens the browse section, regenerate category cards
  if (id === 'browse' && window.location.pathname.includes('faculty-dashboard.php')) {
    generateCategoryCards();
  }

  // If faculty opens the reservations section, reload their reservations
  if (id === 'reservations' && window.location.pathname.includes('faculty-dashboard.php')) {
    populateFacultyReservations();
  }

  // If faculty opens the gym reservations section, reload their gym reservations
  if (id === 'gymReservations' && window.location.pathname.includes('faculty-dashboard.php')) {
    populateGymReservations();
  }

  // If faculty opens the announcements section, ensure announcements are populated
  // and mark related announcement notifications as read to clear the red badge
  if (id === 'announcements' && window.location.pathname.includes('faculty-dashboard.php')) {
    populateAnnouncements();
    markAllFacultyAnnouncementNotificationsAsRead();
  }

  // If admin opens the announcements section, ensure announcements are populated and load calendar
  if (id === 'announcements' && window.location.pathname.includes('admin-dashboard.php')) {
    populateAnnouncements();
    if (typeof loadAdminCalendar === 'function') {
      loadAdminCalendar();
    }
  }

  // If admin opens the returns section, load pending gym returns
  if (id === 'returns' && window.location.pathname.includes('admin-dashboard.php')) {
    if (typeof loadAdminGymReturns === 'function') {
      loadAdminGymReturns();
    }
  }

  // If any dashboard opens the reasons section, load cancellation reasons
  if (id === 'reasons') {
    if (typeof loadCancellationReasons === 'function') {
      loadCancellationReasons();
    }
  }

  // If faculty opens the report section, load report history
  if (id === 'report' && window.location.pathname.includes('faculty-dashboard.php')) {
    populateFacultyReportHistory();
  }

  // If GenServe opens the notifications section, load notifications and calendar
  if (id === 'notifications' && window.location.pathname.includes('genserve-dashboard.php')) {
    loadGenServeNotifications();
    updateGenServeNotificationBadge();
    if (typeof loadGenServeCalendar === 'function') {
      loadGenServeCalendar();
    }
  }

  // If GenServe opens the gym reservations section, load gym reservations
  if (id === 'gymReservations' && window.location.pathname.includes('genserve-dashboard.php')) {
    if (typeof loadGymReservations === 'function') {
      loadGymReservations();
    }
  }

  // Initialize chat if messenger section is shown
  if (id === 'messenger') {
    if (window.location.pathname.includes('admin-dashboard.php')) {
      loadAdminConversations().then(() => {
        // If a chat is already open, mark it as read
        if (currentChatTarget) {
          markActiveChatAsRead();
        }
      });
      startChatPolling('admin');
    } else if (window.location.pathname.includes('faculty-dashboard.php')) {
      loadFacultyConversations().then(() => {
        // If a chat is already open, mark it as read
        if (currentChatTarget) {
          markActiveChatAsRead();
        }
      });
      startChatPolling('faculty');
    } else if (window.location.pathname.includes('genserve-dashboard.php')) {
      loadGenServeConversations().then(() => {
        // If a chat is already open, mark it as read
        if (currentChatTarget) {
          markActiveChatAsRead();
        }
      });
      startChatPolling('genserve');
    }
  }
}

/* ===== Role Selection Handler ===== */
document.getElementById('role')?.addEventListener('change', function() {
  const adminCredentials = document.getElementById('adminCredentials');
  const genserveCredentials = document.getElementById('genserveCredentials');
  if (this.value === 'admin') {
    adminCredentials.style.display = 'block';
    if (genserveCredentials) genserveCredentials.style.display = 'none';
  } else if (this.value === 'genserve') {
    if (adminCredentials) adminCredentials.style.display = 'none';
    if (genserveCredentials) genserveCredentials.style.display = 'block';
  } else {
    if (adminCredentials) adminCredentials.style.display = 'none';
    if (genserveCredentials) genserveCredentials.style.display = 'none';
  }
});

/* ===== On Page Load ===== */
window.onload = function() {
  // Initialize admin accounts
  initializeAdminAccounts();
  // Load faculty accounts from server file on first load if local is empty
  loadFacultyFromServerIfEmpty();
  
  // Ensure equipment catalog is synced from database on login
  ensureEquipmentCatalogInitialized().then(() => {
    syncCatalogToDatabase();
  }).catch(() => {});
  
  // Generate category cards for faculty
  generateCategoryCards();
  
  populateFacultyReservations();
  populateAdminTables();
  updateAdminStats();
  populateAnnouncements();
  loadFacultyNotifications();
  loadFacultyHomeNotifications();
  updateNotificationBadge();
  populateFacultyReportHistory();
  
  // Add search functionality for equipment table
  const equipmentSearchInput = document.getElementById('equipmentSearchInput');
  if (equipmentSearchInput) {
    equipmentSearchInput.addEventListener('input', filterEquipmentTable);
  }
  
  // Check for announcements every 5 minutes
  checkForAnnouncements();
  setInterval(checkForAnnouncements, 5 * 60 * 1000);
  
  // Set minimum date to today for reservation form
  const dateInput = document.getElementById('reservationDate');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
    
    // Add event listener to check for Saturday blocking
    dateInput.addEventListener('change', function() {
      const selectedDate = this.value;
      if (selectedDate && isSaturdayBlocked(selectedDate)) {
        showNotification('Reservations on Saturdays are not allowed due to NSTP activities.', 'error', 5000);
        // Optionally clear the date
        // this.value = '';
      }
    });
  }
  
  // Handle edit faculty form submission
  const editFacultyForm = document.getElementById('editFacultyForm');
  if (editFacultyForm) {
    editFacultyForm.addEventListener('submit', function(e) {
      e.preventDefault();
      saveFacultyEdit();
    });
  }
  
  // Listen for equipment updates (for real-time sync across tabs/windows)
  window.addEventListener('storage', function(e) {
    if (e.key === 'equipmentCatalog') {
      // Equipment catalog was updated in another tab
      if (window.location.pathname.includes('faculty-dashboard.php')) {
        generateCategoryCards(); // Refresh category cards
        const currentCategory = document.querySelector('.equipment-header h3')?.textContent;
        if (currentCategory) {
          const category = currentCategory.replace(' Equipment', '');
          showEquipment(category);
        }
      }
      if (window.location.pathname.includes('admin-dashboard.php')) {
        populateAdminTables();
        updateAdminStats();
      }
      // Also push updates to DB
      syncCatalogToDatabase();
    }
  });
  
  // Listen for custom equipment update event (same tab)
  window.addEventListener('equipmentUpdated', function() {
    if (window.location.pathname.includes('faculty-dashboard.php')) {
      generateCategoryCards(); // Refresh category cards
      const currentCategory = document.querySelector('.equipment-header h3')?.textContent;
      if (currentCategory) {
        const category = currentCategory.replace(' Equipment', '');
        showEquipment(category);
      }
    }
    // Also push updates to DB
    syncCatalogToDatabase();
  });

  // Initialize chat if messenger section is visible on load
  if (window.location.pathname.includes('admin-dashboard.php')) {
    const messengerSection = document.getElementById('messenger');
    if (messengerSection && messengerSection.classList.contains('active-section')) {
      loadAdminConversations();
      startChatPolling('admin');
    }
  } else if (window.location.pathname.includes('faculty-dashboard.php')) {
    const messengerSection = document.getElementById('messenger');
    if (messengerSection && messengerSection.classList.contains('active-section')) {
      loadFacultyConversations();
      startChatPolling('faculty');
    }
  } else if (window.location.pathname.includes('genserve-dashboard.php')) {
    const messengerSection = document.getElementById('messenger');
    if (messengerSection && messengerSection.classList.contains('active-section')) {
      loadGenServeConversations();
      startChatPolling('genserve');
    }
  }
};

/* ===== CHAT SYSTEM (ROLE-BASED) ===== */
let chatContacts = [];
let currentChatTarget = null;
let currentUserRole = null;
let currentUserId = null;
let chatPollingInterval = null;
let isChatLoading = false;
let isSendingMessage = false;
let lastMessagesHash = '';
let facultyAutoSelectInitialized = false;
let chatFilterRole = null;
let chatSearchTerm = '';
let previousUnreadCount = 0; // Track previous unread count for notifications

function getCurrentUser() {
  const userStr = sessionStorage.getItem('currentUser');
  return userStr ? JSON.parse(userStr) : null;
}

async function loadAdminConversations() {
  const user = getCurrentUser();
  if (!user || user.role !== 'admin') return;
  currentUserRole = 'admin';
  currentUserId = user.id;
  ensureChatFilter();
  updateChatTabUI();
  await loadChatContactsForCurrentUser();
}

async function loadFacultyConversations() {
  const user = getCurrentUser();
  if (!user || user.role !== 'faculty') return;
  currentUserRole = 'faculty';
  currentUserId = user.id;
  ensureChatFilter();
  updateChatTabUI();
  await loadChatContactsForCurrentUser();
}

async function loadGenServeConversations() {
  const user = getCurrentUser();
  if (!user || user.role !== 'genserve') {
    // Fallback: try to get from localStorage
    const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
    if (!loggedGenServe) return;
    currentUserRole = 'genserve';
    currentUserId = loggedGenServe.id;
  } else {
    currentUserRole = 'genserve';
    currentUserId = user.id;
  }
  ensureChatFilter();
  updateChatTabUI();
  await loadChatContactsForCurrentUser();
}

async function loadChatContactsForCurrentUser() {
  if (!currentUserRole || !currentUserId) return;
  try {
    const response = await fetch(`api.php?action=listChatContacts&userRole=${currentUserRole}&userId=${currentUserId}`);
    const data = await response.json();
    if (data.ok && Array.isArray(data.contacts)) {
      // Calculate current unread count
      const currentUnreadCount = data.contacts.reduce((sum, contact) => sum + (contact.unreadCount || 0), 0);
      
      // Show notification if new messages arrived (unread count increased)
      if (currentUnreadCount > previousUnreadCount && previousUnreadCount > 0) {
        const newMessagesCount = currentUnreadCount - previousUnreadCount;
        const senderName = data.contacts.find(c => c.unreadCount > 0)?.name || 'Someone';
        showNotification(`💬 New message${newMessagesCount > 1 ? 's' : ''} from ${senderName}`, 'info', 5000);
      }
      
      // Update previous unread count
      previousUnreadCount = currentUnreadCount;
      
      chatContacts = data.contacts;
      if (currentChatTarget) {
        const refreshedTarget = chatContacts.find(
          contact => contact.contactRole === currentChatTarget.contactRole && contact.contactId === currentChatTarget.contactId
        );
        if (refreshedTarget) {
          currentChatTarget = refreshedTarget;
        }
      }
      refreshConversationListUI();
      if (currentUserRole === 'faculty' && !facultyAutoSelectInitialized && !currentChatTarget && chatContacts.length > 0) {
        const preferred = chatContacts.find(c => c.hasHistory) ||
          chatContacts.find(c => c.contactRole === 'admin') ||
          chatContacts[0];
        if (preferred) {
          facultyAutoSelectInitialized = true;
          openChatContact(preferred.contactRole, preferred.contactId);
        }
      }
      updateChatBadge(chatContacts);
    }
  } catch (error) {
    console.error('Error loading chat contacts:', error);
  }
}

function renderChatContacts(elementId, emptyMessage) {
  const listEl = document.getElementById(elementId);
  if (!listEl) return;
  let filtered = chatContacts.slice();
  if (chatFilterRole) {
    filtered = filtered.filter(contact => contact.contactRole === chatFilterRole);
  }
  if (chatSearchTerm) {
    filtered = filtered.filter(contact => {
      const target = `${contact.name || ''} ${contact.email || ''}`.toLowerCase();
      return target.includes(chatSearchTerm);
    });
  }
  if (!filtered.length) {
    listEl.innerHTML = `<p class="text-muted">${emptyMessage || 'No conversations yet.'}</p>`;
    return;
  }
  listEl.innerHTML = filtered.map(contact => buildConversationItem(contact)).join('');
}

function refreshConversationListUI() {
  let elementId = null;
  if (currentUserRole === 'admin') {
    elementId = 'adminConversationsList';
  } else if (currentUserRole === 'faculty') {
    elementId = 'facultyConversationsList';
  } else if (currentUserRole === 'genserve') {
    // GenServe uses adminConversationsList for displaying conversations (same structure as Admin)
    elementId = 'adminConversationsList';
  }
  if (!elementId) return;
  renderChatContacts(elementId, getEmptyConversationMessage());
}

function getEmptyConversationMessage() {
  if (!chatFilterRole) return 'No conversations yet.';
  return `No ${formatRoleLabel(chatFilterRole)} conversations yet.`;
}

function formatRoleLabel(role) {
  if (role === 'genserve') return 'GenServe';
  if (role === 'faculty') return 'Faculty';
  return 'Admin';
}

function ensureChatFilter() {
  if (chatFilterRole) return;
  if (currentUserRole === 'admin') {
    chatFilterRole = 'faculty';
  } else if (currentUserRole === 'faculty') {
    chatFilterRole = 'admin';
  } else if (currentUserRole === 'genserve') {
    chatFilterRole = 'admin';
  }
}

function updateChatTabUI() {
  const tabButtons = document.querySelectorAll('[data-chat-filter]');
  tabButtons.forEach(btn => {
    const role = btn.getAttribute('data-chat-filter');
    btn.classList.toggle('active', role === chatFilterRole);
  });
  const searchInput = document.getElementById('chatSearchInput');
  if (searchInput) {
    searchInput.placeholder = getSearchPlaceholder();
  }
  
  // For GenServe: The shared system filters contacts by chatFilterRole
  // No need to show/hide lists - filtering is handled by renderChatContacts
}

function getSearchPlaceholder() {
  if (currentUserRole === 'admin') {
    return chatFilterRole === 'genserve' ? 'Search GenServe contacts...' : 'Search Faculty contacts...';
  }
  if (currentUserRole === 'faculty') {
    return chatFilterRole === 'genserve' ? 'Search GenServe contacts...' : 'Search Admin contacts...';
  }
  if (currentUserRole === 'genserve') {
    return chatFilterRole === 'faculty' ? 'Search Faculty contacts...' : 'Search Admin contacts...';
  }
  return 'Search contacts...';
}

function setChatFilter(role) {
  if (chatFilterRole === role) return;
  chatFilterRole = role;
  updateChatTabUI();
  refreshConversationListUI();
}

function buildConversationItem(contact) {
  const isActive = currentChatTarget &&
    currentChatTarget.contactRole === contact.contactRole &&
    currentChatTarget.contactId === contact.contactId;
  const unreadBadge = contact.unreadCount > 0
    ? `<span class="conversation-badge">${contact.unreadCount > 99 ? '99+' : contact.unreadCount}</span>`
    : '';
  const preview = contact.lastMessage ? contact.lastMessage.text : 'Start a conversation';
  const avatarIcon = contact.contactRole === 'admin'
    ? '<i class="fas fa-user-shield"></i>'
    : (contact.contactRole === 'genserve'
      ? '<i class="fas fa-users-cog"></i>'
      : '<i class="fas fa-user"></i>');
  const label = contact.contactRole === 'genserve'
    ? 'GenServe'
    : contact.contactRole.charAt(0).toUpperCase() + contact.contactRole.slice(1);
  const timeLabel = contact.lastMessageAt ? `<span class="conversation-time">${formatChatTime(contact.lastMessageAt)}</span>` : '';

  return `
    <div class="conversation-item ${isActive ? 'active' : ''}">
      <div class="conversation-main" onclick="openChatContact('${contact.contactRole}', ${contact.contactId}, event)">
        <div class="conversation-avatar">${avatarIcon}</div>
        <div class="conversation-content">
          <div class="conversation-header">
            <h4 class="conversation-name">${escapeHtml(contact.name || 'User')} (${label})</h4>
            ${unreadBadge}
            ${timeLabel}
          </div>
          <p class="conversation-preview">${escapeHtml(preview)}</p>
        </div>
      </div>
      <button class="conversation-delete-btn" onclick="deleteConversation('${contact.contactRole}', ${contact.contactId}, event)" title="Delete conversation">
        <i class="fas fa-trash"></i>
      </button>
    </div>
  `;
}

async function openChatContact(contactRole, contactId, evt) {
  const target = chatContacts.find(c => c.contactRole === contactRole && c.contactId === contactId);
  if (!target) return;
  if (chatFilterRole && chatFilterRole !== contactRole) {
    chatFilterRole = contactRole;
    updateChatTabUI();
    refreshConversationListUI();
  }
  currentChatTarget = target;
  lastMessagesHash = ''; // Reset hash to force fresh reload from database

  if (evt && evt.currentTarget) {
    // Find the parent conversation-item and mark it as active
    const conversationItem = evt.currentTarget.closest('.conversation-item');
    if (conversationItem) {
      document.querySelectorAll('.conversation-item').forEach(item => item.classList.remove('active'));
      conversationItem.classList.add('active');
    }
  }

  const header = document.getElementById('chatHeader');
  const inputWrap = document.getElementById('chatInputContainer');
  if (header) header.style.display = 'flex';
  if (inputWrap) inputWrap.style.display = 'block';
  document.getElementById('chatUserName').textContent = target.name || 'User';
  document.getElementById('chatUserEmail').textContent = target.email || '';

  // Always load fresh messages from database when opening conversation
  await loadChatHistory();
  await markActiveChatAsRead(); // Mark as read after loading
  await loadChatContactsForCurrentUser(); // Refresh to update unread counts
}

async function loadChatHistory() {
  if (!currentChatTarget || !currentUserRole || !currentUserId || isChatLoading) return;
  isChatLoading = true;
  try {
    // Always load from database - never use cached state
    const url = `api.php?action=getChatHistory&userRole=${currentUserRole}&userId=${currentUserId}&withRole=${currentChatTarget.contactRole}&withId=${currentChatTarget.contactId}`;
    const response = await fetch(url, { cache: 'no-store' }); // Force fresh data
    const data = await response.json();
    if (data.ok && Array.isArray(data.messages)) {
      // Create hash including message ID for better comparison
      const hash = data.messages.map(m => `${m.id}|${m.senderRole}|${m.senderId}|${m.timestamp}|${(m.message || '').length}`).join('~');
      
      // Only skip if hash is identical AND we have messages displayed
      const messagesEl = document.getElementById('chatMessages');
      const currentMessageCount = messagesEl ? messagesEl.querySelectorAll('.message').length : 0;
      
      // Check if there are unread messages (messages sent to current user that are not read)
      const hasUnreadMessages = data.messages.some(msg => 
        msg.receiverRole === currentUserRole && 
        msg.receiverId === currentUserId && 
        !msg.isRead
      );
      
      if (hash !== lastMessagesHash || currentMessageCount !== data.messages.length) {
        lastMessagesHash = hash;
        renderMessages(data.messages); // Always render to ensure persistence
        
        // If chat is open and there are unread messages, mark them as read
        if (hasUnreadMessages) {
          await markActiveChatAsRead();
        }
      } else if (hasUnreadMessages) {
        // Even if hash is same, if there are unread messages, mark them as read
        await markActiveChatAsRead();
      }
    }
  } catch (error) {
    console.error('Error loading chat history:', error);
  } finally {
    isChatLoading = false;
  }
}

async function markActiveChatAsRead() {
  if (!currentChatTarget || !currentUserRole || !currentUserId) return;
  try {
    const response = await fetch('api.php?action=markChatRead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userRole: currentUserRole,
        userId: currentUserId,
        withRole: currentChatTarget.contactRole,
        withId: currentChatTarget.contactId
      })
    });
    
    const result = await response.json();
    if (result.ok !== false) {
      // Update local state
      currentChatTarget.unreadCount = 0;
      const idx = chatContacts.findIndex(
        c => c.contactRole === currentChatTarget.contactRole && c.contactId === currentChatTarget.contactId
      );
      if (idx !== -1) {
        chatContacts[idx].unreadCount = 0;
      }
      
      // Refresh UI and badge immediately
      refreshConversationListUI();
      updateChatBadge(chatContacts);
      
      // Also reload contacts to get fresh unread counts from server
      await loadChatContactsForCurrentUser();
    }
  } catch (error) {
    console.error('Error marking chat as read:', error);
  }
}

function renderMessages(messages) {
  const messagesEl = document.getElementById('chatMessages');
  if (!messagesEl) return;
  if (!messages || messages.length === 0) {
    messagesEl.innerHTML = `
      <div class="chat-empty-state">
        <i class="fas fa-comments"></i>
        <p>No messages yet. Start the conversation!</p>
      </div>
    `;
    return;
  }

  messagesEl.innerHTML = messages.map(msg => {
    const isSent = msg.senderRole === currentUserRole;
    const time = formatChatTime(msg.timestamp);
    return `
      <div class="message ${isSent ? 'sent' : 'received'}">
        <div class="message-bubble">
          <div>${escapeHtml(msg.message || '')}</div>
          <div class="message-time">${time}</div>
        </div>
      </div>
    `;
  }).join('');
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function sendMessage() {
  const inputEl = document.getElementById('chatMessageInput');
  if (!inputEl) return;
  const message = inputEl.value.trim();
  if (!message || !currentChatTarget || !currentUserRole || !currentUserId) return;
  if (isSendingMessage) return;
  isSendingMessage = true;

  const chatForm = document.getElementById('chatMessageForm');
  const submitBtn = chatForm ? chatForm.querySelector('button[type="submit"]') : null;
  if (submitBtn) submitBtn.disabled = true;
  inputEl.disabled = true;

  try {
    const response = await fetch('api.php?action=sendChatMessage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        senderRole: currentUserRole,
        senderId: currentUserId,
        receiverRole: currentChatTarget.contactRole,
        receiverId: currentChatTarget.contactId,
        message
      })
    });
    const data = await response.json();
    if (data.ok) {
      inputEl.value = '';
      // Reset hash to force reload of all messages including the new one
      lastMessagesHash = '';
      await loadChatHistory(); // Reload to show the new message
      await loadChatContactsForCurrentUser(); // Update contact list
      // Success notification is implicit (message appears in chat)
    } else {
      showNotification(data.error || 'Unable to send message. Please try again.', 'error');
    }
  } catch (error) {
    console.error('Error sending message:', error);
    showNotification('Unable to send message. Please check your connection and try again.', 'error');
  } finally {
    isSendingMessage = false;
    if (submitBtn) submitBtn.disabled = false;
    inputEl.disabled = false;
  }
}

document.addEventListener('DOMContentLoaded', function() {
  // Helper: format Date object to yyyy-mm-dd without timezone shifts
  function formatDateForInput(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const chatForm = document.getElementById('chatMessageForm');
  if (chatForm) {
    chatForm.addEventListener('submit', function(e) {
      e.preventDefault();
      sendMessage();
    });
  }

  const chatSearch = document.getElementById('chatSearchInput');
  if (chatSearch) {
    chatSearch.addEventListener('input', function(e) {
      chatSearchTerm = (e.target.value || '').toLowerCase();
      refreshConversationListUI();
    });
  }
  
  // Load calendar if on faculty dashboard and home section is active
  if (window.location.pathname.includes('faculty-dashboard.php')) {
    const homeSection = document.getElementById('home');
    if (homeSection && homeSection.classList.contains('active-section')) {
      if (typeof loadCalendar === 'function') {
        loadCalendar();
      }
    }
  }

  // Set up date range inputs for equipment reservation
  const equipStart = document.getElementById('reservationStartDate');
  const equipEnd = document.getElementById('reservationEndDate');
  const equipDays = document.getElementById('reservationDays');
  const equipEndGroup = document.getElementById('reservationEndDateGroup');
  if (equipStart && equipEnd && equipDays && equipEndGroup) {
    const todayIso = new Date().toISOString().split('T')[0];
    equipStart.setAttribute('min', todayIso);
    equipEnd.setAttribute('min', todayIso);

    const updateEquipEnd = () => {
      const daysRaw = equipDays.value;
      const days = parseInt(daysRaw, 10);

      // If no valid number of days yet, hide End Date and clear it
      if (!days || days < 1) {
        equipEndGroup.style.display = 'none';
        equipEnd.value = '';
        return;
      }

      if (!equipStart.value) {
        // Number of days is given but no start date yet:
        // just show/hide the End Date field depending on single vs multi-day,
        // but do not compute a date until Start Date is chosen.
        if (days === 1) {
          equipEndGroup.style.display = 'none';
          equipEnd.value = '';
        } else {
          equipEndGroup.style.display = '';
          equipEnd.value = '';
        }
        return;
      }

      const startDate = new Date(equipStart.value + 'T00:00:00');

      if (days === 1) {
        // Single-day reservation: hide End Date and use Start Date internally
        equipEndGroup.style.display = 'none';
        equipEnd.value = equipStart.value;
      } else {
        // Multi-day reservation: show End Date and auto-calculate from days
        equipEndGroup.style.display = '';
        const endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() + days - 1);
        equipEnd.value = formatDateForInput(endDate);
      }
    };

    // Event listeners: Start Date or Days change drives End Date
    equipStart.addEventListener('change', updateEquipEnd);
    equipDays.addEventListener('input', updateEquipEnd);

    // Initial state: no days yet, hide End Date
    equipEndGroup.style.display = 'none';
    equipEnd.value = '';
  }

  // Set up date range inputs for gym reservation
  const gymStart = document.getElementById('gymReservationStartDate');
  const gymEnd = document.getElementById('gymReservationEndDate');
  const gymDays = document.getElementById('gymReservationDays');
  const gymEndGroup = document.getElementById('gymReservationEndDateGroup');
  if (gymStart && gymEnd && gymDays && gymEndGroup) {
    const todayIso = new Date().toISOString().split('T')[0];
    gymStart.setAttribute('min', todayIso);
    gymEnd.setAttribute('min', todayIso);

    // Helper: check with server if selected date range is still free
    const validateGymDateRange = (startStr, endStr) => {
      if (!startStr || !endStr) return;
      const idField = document.getElementById('gymReservationId');
      const excludeId = idField ? (idField.value || '') : '';

      const params = new URLSearchParams({
        action: 'checkGymDateAvailability',
        startDate: startStr,
        endDate: endStr
      });
      if (excludeId) {
        params.append('excludeId', excludeId);
      }

      fetch('api.php?' + params.toString())
        .then(res => res.json())
        .then(data => {
          if (!data || data.ok === false) {
            // If API returns error, just log but don't block user hard
            console.error('Gym availability check failed', data);
            return;
          }
          if (!data.available) {
            showNotification('This date range is already booked for the gym.', 'error');
            // Reset fields so user is forced to pick a new date
            gymStart.value = '';
            gymEnd.value = '';
            gymDays.value = '';
            gymEndGroup.style.display = 'none';
          }
        })
        .catch(err => {
          console.error('Error checking gym availability', err);
        });
    };

    const updateGymEnd = () => {
      const daysRaw = gymDays.value;
      const days = parseInt(daysRaw, 10);

      if (!days || days < 1) {
        gymEndGroup.style.display = 'none';
        gymEnd.value = '';
        return;
      }

      if (!gymStart.value) {
        if (days === 1) {
          gymEndGroup.style.display = 'none';
          gymEnd.value = '';
        } else {
          gymEndGroup.style.display = '';
          gymEnd.value = '';
        }
        return;
      }

      const startDate = new Date(gymStart.value + 'T00:00:00');

      if (days === 1) {
        gymEndGroup.style.display = 'none';
        const singleEnd = gymStart.value;
        gymEnd.value = singleEnd;
        // Also validate single-day range against server
        validateGymDateRange(gymStart.value, singleEnd);
      } else {
        gymEndGroup.style.display = '';
        const endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() + days - 1);
        const endStr = formatDateForInput(endDate);
        gymEnd.value = endStr;
        // After computing range, verify with server if it's still free
        validateGymDateRange(gymStart.value, endStr);
      }
    };

    gymStart.addEventListener('change', updateGymEnd);
    gymDays.addEventListener('input', updateGymEnd);

    // Initial state: hide End Date until user inputs valid days
    gymEndGroup.style.display = 'none';
    gymEnd.value = '';
  }
});

function startChatPolling(role) {
  if (chatPollingInterval) {
    clearInterval(chatPollingInterval);
  }
  chatPollingInterval = setInterval(async () => {
    if (!isSendingMessage) {
      // If a chat is open, load history first (which will mark as read if needed)
      if (currentChatTarget) {
        await loadChatHistory();
      }
      // Then refresh conversations to update unread counts
      if (role === 'admin') {
        await loadAdminConversations();
      } else if (role === 'faculty') {
        await loadFacultyConversations();
      } else if (role === 'genserve') {
        await loadGenServeConversations();
      }
      // Update badge after refreshing conversations
      updateChatBadge(chatContacts);
    }
  }, 4000);
}

function stopChatPolling() {
  if (chatPollingInterval) {
    clearInterval(chatPollingInterval);
    chatPollingInterval = null;
  }
}

function updateChatBadge(conversations = chatContacts) {
  const badgeEl = document.getElementById('chatBadge');
  if (!badgeEl) return;
  const totalUnread = (conversations || []).reduce((sum, conv) => sum + (conv.unreadCount || 0), 0);
  if (totalUnread > 0) {
    badgeEl.textContent = totalUnread > 99 ? '99+' : totalUnread;
    badgeEl.style.display = 'inline-block';
  } else {
    badgeEl.style.display = 'none';
  }
}

// Format chat time
function formatChatTime(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now - date;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (seconds < 60) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  
  return date.toLocaleDateString();
}

// Escape HTML helper
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/* ===== Gym Reservation Functions ===== */
let gymEquipmentItems = [];
let editingGymReservationId = null;

function openGymReservationModal(id = null) {
  editingGymReservationId = id;
  gymEquipmentItems = [];
  
  // Reset form
  document.getElementById('gymReservationForm').reset();
  document.getElementById('gymReservationId').value = id || '';
  document.getElementById('gymReservationModalTitle').textContent = id ? 'Edit Gym Reservation' : 'New Gym Reservation';
  
  // Clear equipment items list
  document.getElementById('gymEquipmentItemsList').innerHTML = '';
  
  // If editing, load existing data
  if (id) {
    loadGymReservationForEdit(id);
  } else {
    // Add one empty equipment item
    addEquipmentItem();
  }
  
  openModal('gymReservationModal');
}

function addEquipmentItem(item = null) {
  const container = document.getElementById('gymEquipmentItemsList');
  if (!container) return;
  
  const itemId = Date.now() + Math.random();
  const itemDiv = document.createElement('div');
  itemDiv.className = 'equipment-item-row';
  itemDiv.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px; align-items: flex-end;';
  
  const catalog = getEquipmentCatalog();
  const categories = Object.keys(catalog);
  
  // Category dropdown
  const categorySelect = document.createElement('select');
  categorySelect.className = 'form-control';
  categorySelect.style.flex = '1';
  categorySelect.required = true;
  categorySelect.innerHTML = '<option value="">Select Category</option>' + 
    categories.map(cat => `<option value="${escapeHtml(cat)}">${escapeHtml(cat)}</option>`).join('');
  categorySelect.onchange = function() {
    updateEquipmentDropdown(this, equipmentSelect);
  };
  
  // Equipment dropdown
  const equipmentSelect = document.createElement('select');
  equipmentSelect.className = 'form-control';
  equipmentSelect.style.flex = '1';
  equipmentSelect.required = true;
  equipmentSelect.innerHTML = '<option value="">Select Equipment</option>';
  
  // Quantity input
  const quantityInput = document.createElement('input');
  quantityInput.type = 'number';
  quantityInput.className = 'form-control';
  quantityInput.style.width = '100px';
  quantityInput.min = '1';
  quantityInput.value = item ? item.quantity : '1';
  quantityInput.required = true;
  
  // Remove button
  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.className = 'btn btn-danger btn-sm';
  removeBtn.innerHTML = '<i class="fas fa-times"></i>';
  removeBtn.onclick = function() {
    itemDiv.remove();
  };
  
  itemDiv.appendChild(categorySelect);
  itemDiv.appendChild(equipmentSelect);
  itemDiv.appendChild(quantityInput);
  itemDiv.appendChild(removeBtn);
  
  container.appendChild(itemDiv);
  
  // If editing, set values
  if (item) {
    categorySelect.value = item.category;
    updateEquipmentDropdown(categorySelect, equipmentSelect);
    setTimeout(() => {
      equipmentSelect.value = item.equipment;
    }, 100);
  }
}

function updateEquipmentDropdown(categorySelect, equipmentSelect) {
  const category = categorySelect.value;
  const catalog = getEquipmentCatalog();
  
  equipmentSelect.innerHTML = '<option value="">Select Equipment</option>';
  
  if (category && catalog[category]) {
    catalog[category].forEach(eq => {
      const option = document.createElement('option');
      option.value = eq.name;
      option.textContent = `${eq.name} (Available: ${eq.available})`;
      option.disabled = eq.available === 0;
      equipmentSelect.appendChild(option);
    });
  }
}

function loadGymReservationForEdit(id) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) return;
  
  fetch(`api.php?action=listFacultyGymReservations&username=${encodeURIComponent(loggedFaculty.username)}`)
    .then(res => res.json())
    .then(reservations => {
      const reservation = reservations.find(r => r.id === id);
      if (!reservation) {
        showNotification('Reservation not found', 'error');
        closeModal('gymReservationModal');
        return;
      }
      
      if (reservation.status !== 'Pending') {
        showNotification('Only pending reservations can be edited', 'error');
        closeModal('gymReservationModal');
        return;
      }
      
      document.getElementById('gymReservationTitle').value = reservation.title;
      const startInput = document.getElementById('gymReservationStartDate');
      const endInput = document.getElementById('gymReservationEndDate');
      const daysInput = document.getElementById('gymReservationDays');
      const startDate = reservation.startDate || reservation.date;
      const endDate = reservation.endDate || reservation.date;
      if (startInput) startInput.value = startDate;
      if (endInput) endInput.value = endDate;
      if (daysInput) {
        const s = new Date(startDate + 'T00:00:00');
        const e = new Date(endDate + 'T00:00:00');
        const diff = Math.floor((e - s) / (1000 * 60 * 60 * 24)) + 1;
        daysInput.value = diff;
        // Ensure End Date visibility and value reflect the new rules
        const ev = new Event('input');
        daysInput.dispatchEvent(ev);
      }
      document.getElementById('gymReservationTime').value = reservation.time;
      
      // Clear and add equipment items
      document.getElementById('gymEquipmentItemsList').innerHTML = '';
      if (reservation.equipmentItems && reservation.equipmentItems.length > 0) {
        reservation.equipmentItems.forEach(item => {
          addEquipmentItem(item);
        });
      }
    })
    .catch(err => {
      console.error('Error loading reservation:', err);
      showNotification('Failed to load reservation', 'error');
    });
}

function submitGymReservation() {
  const title = document.getElementById('gymReservationTitle').value.trim();
  const startDate = document.getElementById('gymReservationStartDate').value;
  const endDate = document.getElementById('gymReservationEndDate').value || startDate;
  const time = document.getElementById('gymReservationTime').value.trim();
  const id = document.getElementById('gymReservationId').value;
  
  if (!title || !startDate || !endDate || !time) {
    showNotification('Please fill in all required fields', 'error');
    return;
  }
  
  // Validate time format
  const timePattern = /^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}\s*(AM|PM|am|pm)$/i;
  if (!timePattern.test(time)) {
    showNotification('Invalid time format! Use format like "8:00-10:00 AM"', 'error');
    return;
  }

  // Validate date range
  const start = new Date(startDate);
  const end = new Date(endDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (start < today) {
    showNotification('Cannot make reservations for past dates', 'error');
    return;
  }

  if (end < start) {
    showNotification('End Date cannot be earlier than Start Date', 'error');
    return;
  }

  // Check each day in range for NSTP Saturday blocking
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const iso = d.toISOString().split('T')[0];
    if (isSaturdayBlocked(iso)) {
      showNotification('Reservations on Saturdays are not allowed due to NSTP activities.', 'error', 5000);
      return;
    }
  }

  const durationDays = Math.floor((end - start) / (1000 * 60 * 60 * 24)) + 1;
  
  // Collect equipment items (optional - can be empty)
  const equipmentItems = [];
  const itemRows = document.querySelectorAll('#gymEquipmentItemsList .equipment-item-row');
  
  let hasError = false;
  itemRows.forEach(row => {
    const category = row.querySelector('select').value;
    const equipment = row.querySelectorAll('select')[1].value;
    const quantity = parseInt(row.querySelector('input[type="number"]').value, 10);
    
    // Only validate if equipment fields are partially filled
    if (category || equipment || quantity) {
      if (!category || !equipment || !quantity || quantity <= 0) {
        hasError = true;
        return;
      }
      
      equipmentItems.push({
        category: category,
        equipment: equipment,
        quantity: quantity
      });
    }
  });
  
  if (hasError) {
    showNotification('Please fill in all equipment fields correctly or remove incomplete items', 'error');
    return;
  }
  
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    showNotification('Please login first!', 'error');
    return;
  }
  
  const url = id ? 'api.php?action=updateGymReservation' : 'api.php?action=submitGymReservation';
  const payload = {
    facultyUsername: loggedFaculty.username,
    title: title,
    date: startDate,
    startDate: startDate,
    endDate: endDate,
    durationDays: durationDays,
    time: time,
    equipmentItems: equipmentItems
  };
  
  if (id) {
    payload.id = parseInt(id, 10);
  }
  
  fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(res => res.json())
  .then(data => {
    if (data.ok) {
      showNotification(id ? 'Gym reservation updated successfully!' : 'Gym reservation submitted successfully!', 'success');
      closeModal('gymReservationModal');
      populateGymReservations();
      
      // Refresh equipment catalog
      fetch('api.php?action=getCatalog', { cache: 'no-store' })
        .then(res => res.json())
        .then(dbCatalog => {
          if (dbCatalog && Object.keys(dbCatalog).length > 0) {
            localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
            window.dispatchEvent(new Event('equipmentUpdated'));
          }
        })
        .catch(err => console.error('Failed to refresh catalog:', err));
    } else {
      showNotification(data.error || 'Failed to submit reservation', 'error');
    }
  })
  .catch(err => {
    console.error('Error:', err);
    showNotification('Failed to submit reservation', 'error');
  });
}

function populateGymReservations() {
  const table = document.querySelector('#gymReservationTable tbody');
  if (!table) return;
  
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty) {
    table.innerHTML = '<tr><td colspan="7" class="text-center">Please login to view reservations</td></tr>';
    return;
  }
  
  table.innerHTML = '<tr><td colspan="7" class="text-center">Loading reservations...</td></tr>';
  
  fetch(`api.php?action=listFacultyGymReservations&username=${encodeURIComponent(loggedFaculty.username)}`)
    .then(res => res.json())
    .then(reservations => {
      table.innerHTML = '';
      
      if (reservations.length === 0) {
        table.innerHTML = '<tr><td colspan="7" class="text-center">No gym reservations found</td></tr>';
        return;
      }
      
      reservations.forEach(r => {
        const tr = document.createElement('tr');
        const safeTitle = escapeHtml(r.title || '');
        const safeDate = escapeHtml(r.date || '');
        const safeTime = escapeHtml(r.time || '');
        
        // Format equipment items
        let equipmentText = '';
        if (r.equipmentItems && r.equipmentItems.length > 0) {
          equipmentText = r.equipmentItems.map(item => 
            `${item.quantity}x ${item.equipment} (${item.category})`
          ).join(', ');
        }
        
        const returnStatus = r.returnStatus || r.return_status || 'None';
        let actions = '';
        if (r.status === 'Pending') {
          actions = `
            <button class="btn btn-info btn-sm" onclick="openGymReservationModal(${r.id})">
              <i class="fas fa-edit"></i> Edit
            </button>
            <button class="btn btn-danger btn-sm" style="margin-left:6px;" onclick="cancelGymReservation(${r.id})">
              <i class="fas fa-times"></i> Cancel
            </button>
          `;
        } else if (r.status === 'Cancellation Requested') {
          actions = '<span class="text-info"><i class="fas fa-hourglass-half"></i> Cancellation Pending</span>';
        } else if (r.status === 'Approved') {
          if (returnStatus === 'None') {
            // Calculate total quantity for display
            const totalQuantity = r.equipmentItems ? r.equipmentItems.reduce((sum, item) => sum + (item.quantity || 0), 0) : 0;
            actions = `
              <button class="btn btn-warning btn-sm" onclick="initiateGymReturn(${r.id}, '${safeTitle}', ${totalQuantity})">
                <i class="fas fa-undo"></i> Return
              </button>
              <button class="btn btn-danger btn-sm" style="margin-left:6px;" onclick="cancelGymReservation(${r.id})">
                <i class="fas fa-times"></i> Cancel
              </button>
            `;
          } else if (returnStatus === 'Pending') {
            actions = '<span class="text-muted"><i class="fas fa-clock"></i> Return Pending</span>';
          } else if (returnStatus === 'Cleared') {
            actions = '<span class="text-success"><i class="fas fa-check-circle"></i> Returned</span>';
          }
        } else if (r.status === 'Cancelled') {
          actions = '<span class="text-warning"><i class="fas fa-ban"></i> Cancelled</span>';
        } else if (r.status === 'Declined') {
          actions = '<span class="text-danger"><i class="fas fa-times-circle"></i> Declined</span>';
        } else {
          actions = '<span class="text-muted">No action</span>';
        }
        
        tr.innerHTML = `
          <td>${safeTitle}</td>
          <td>${safeDate}</td>
          <td>${safeTime}</td>
          <td>${escapeHtml(equipmentText)}</td>
          <td><span class="status-badge status-${r.status.toLowerCase().replace(' ', '-')}">${r.status}</span></td>
          <td>${actions}</td>
        `;
        table.appendChild(tr);
      });
    })
    .catch(err => {
      console.error('Error fetching gym reservations:', err);
      table.innerHTML = '<tr><td colspan="6" class="text-center">Error loading reservations</td></tr>';
    });
}

function cancelGymReservation(id) {
  showReasonModal({
    title: 'Cancel Gym Reservation',
    description: 'Tell us why you are cancelling this gym reservation.',
    placeholder: 'Reason for cancelling this gym reservation',
    confirmText: 'Cancel Gym Reservation',
    confirmIcon: 'fas fa-times',
    onConfirm: (reason) => confirmCancelGymReservation(id, reason)
  });
}

function confirmCancelGymReservation(id, reason) {
  const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
  if (!loggedFaculty || !loggedFaculty.username) {
    showNotification('Please login first!', 'error');
    return;
  }
  
  const safeReason = reason?.trim() || '';

  // First, fetch the reservation to check if it was approved
  fetch(`api.php?action=listFacultyGymReservations&username=${encodeURIComponent(loggedFaculty.username)}`)
    .then(res => res.json())
    .then(reservations => {
      // Handle error response
      if (reservations && reservations.error) {
        showNotification(reservations.error || 'Failed to load reservation details', 'error');
        return;
      }
      
      // Handle array response
      if (!Array.isArray(reservations)) {
        showNotification('Invalid response from server', 'error');
        return;
      }
      
      const reservation = reservations.find(r => r.id === id || parseInt(r.id) === parseInt(id));
      if (!reservation) {
        showNotification('Reservation not found', 'error');
        return;
      }
      
      const wasApproved = reservation && reservation.status === 'Approved';
      const reservationTitle = reservation?.title || 'Gym Reservation';

      // Request cancellation - will be sent to Admin for approval
      return fetch('api.php?action=updateGymReservationStatus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          id: id, 
          status: 'Cancellation Requested',
          reason: safeReason
        })
      })
      .then(res => {
        if (!res.ok) {
          return res.json().then(err => Promise.reject(err));
        }
        return res.json();
      })
      .then(data => {
        if (data.ok) {
          // Notify Admin about cancellation request
          if (typeof createAdminNotification === 'function') {
            createAdminNotification(
              'Gym Cancellation Request',
              `${loggedFaculty.fullname} requested to cancel a gym reservation. Reason: ${safeReason || 'No reason provided'}`,
              'warning'
            );
          }
          
          // Also create database notification for Admin
          fetch('api.php?action=createAdminNotification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              type: 'cancellation_request',
              title: 'Gym Cancellation Request',
              message: `${loggedFaculty.fullname} requested to cancel a gym reservation. Reason: ${safeReason || 'No reason provided'}`
            })
          }).catch(err => console.error('Failed to create Admin notification:', err));
          
          // If reservation was approved, notify GenServe about the cancellation
          if (wasApproved) {
            const equipmentText = reservation.equipmentItems && reservation.equipmentItems.length > 0
              ? reservation.equipmentItems.map(item => `${item.quantity}x ${item.equipment}`).join(', ')
              : 'equipment';
            
            // Notify GenServe about cancellation of approved reservation
            if (typeof createGenServeNotification === 'function') {
              createGenServeNotification(
                'Gym Reservation Cancelled by User',
                `${loggedFaculty.fullname} cancelled an approved gym reservation: "${reservationTitle}"${equipmentText ? ` (${equipmentText})` : ''}. Reason: ${safeReason || 'No reason provided'}`,
                'warning'
              );
            }
            
            // Also create database notification for GenServe
            fetch('api.php?action=createGenServeNotification', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                type: 'gym_cancellation',
                title: 'Gym Reservation Cancelled by User',
                message: `${loggedFaculty.fullname} cancelled an approved gym reservation: "${reservationTitle}"${equipmentText ? ` (${equipmentText})` : ''}. Reason: ${safeReason || 'No reason provided'}`
              })
            }).catch(err => console.error('Failed to create GenServe notification:', err));
          }
          
          if (loggedFaculty) {
            const reasonNote = safeReason ? ` - Reason: ${safeReason}` : '';
            addAuditLog('Faculty', loggedFaculty.fullname, `Requested cancellation for gym reservation ID ${id}${reasonNote}`);
          }
          
          showNotification('Cancellation request submitted! Admin will review and approve/decline your request.', 'success');
          populateGymReservations();
          
          // Refresh equipment catalog
          fetch('api.php?action=getCatalog', { cache: 'no-store' })
            .then(res => res.json())
            .then(dbCatalog => {
              if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                window.dispatchEvent(new Event('equipmentUpdated'));
              }
            })
            .catch(err => console.error('Failed to refresh catalog:', err));
        } else {
          showNotification(data.error || 'Failed to submit cancellation request', 'error');
        }
      })
      .catch(err => {
        console.error('Error updating reservation status:', err);
        showNotification(err.error || err.message || 'Failed to submit cancellation request', 'error');
      });
    })
    .catch(err => {
      console.error('Error fetching reservation:', err);
      showNotification('Failed to load reservation details. Please try again.', 'error');
    });
}

// Sync local catalog to MySQL so API (submitReservation) can resolve IDs
async function syncCatalogToDatabase() {
  try {
    const catalog = getEquipmentCatalog();
    await fetch('api.php?action=backupEquipment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(catalog)
    });
  } catch (e) {
    console.warn('Catalog sync failed', e);
  }
}

// ===== Admin Gym Returns Management =====

// Load pending gym returns for Admin approval
async function loadAdminGymReturns() {
  const table = document.querySelector('#returnsTable tbody');
  const countElement = document.getElementById('returnsCategoryCount');
  const returnsBadge = document.getElementById('returnsBadge');
  
  if (!table) return;
  
  try {
    table.innerHTML = '<tr><td colspan="7" class="text-center">Loading returns...</td></tr>';
    
    const resp = await fetch('api.php?action=listPendingAdminGymReturns');
    const data = await resp.json();
    
    table.innerHTML = '';
    
    // Update badge
    if (returnsBadge) {
      const count = data && Array.isArray(data) ? data.length : 0;
      returnsBadge.textContent = count;
      returnsBadge.style.display = count > 0 ? 'inline-block' : 'none';
    }
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      table.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No pending gym returns for approval</td></tr>';
      if (countElement) {
        countElement.textContent = 'No pending gym returns';
      }
      return;
    }
    
    // Update count
    if (countElement) {
      countElement.textContent = `Showing ${data.length} gym return${data.length !== 1 ? 's' : ''} pending approval`;
    }
    
    data.forEach(returnItem => {
      const tr = document.createElement('tr');
      const faculty = returnItem.faculty || 'Unknown';
      const title = returnItem.title || 'Gym Reservation';
      const date = returnItem.date || 'N/A';
      const time = returnItem.time || 'N/A';
      const returnVerifiedAt = returnItem.returnVerifiedAt ? new Date(returnItem.returnVerifiedAt).toLocaleString() : 'N/A';
      
      // Format equipment items
      let equipmentHtml = '';
      if (returnItem.equipmentItems && Array.isArray(returnItem.equipmentItems) && returnItem.equipmentItems.length > 0) {
        // Group equipment by category
        const equipmentByCategory = {};
        returnItem.equipmentItems.forEach(item => {
          const cat = item.category || 'Other';
          if (!equipmentByCategory[cat]) {
            equipmentByCategory[cat] = [];
          }
          equipmentByCategory[cat].push(item);
        });
        
        // Build HTML grouped by category
        const categoryNames = Object.keys(equipmentByCategory).sort();
        categoryNames.forEach(cat => {
          const items = equipmentByCategory[cat];
          const itemsText = items.map(item => 
            `${item.quantity}x ${item.equipment}`
          ).join(', ');
          equipmentHtml += `<div style="margin-bottom: 5px;">`;
          equipmentHtml += `<span class="badge badge-info" style="margin-right: 5px;">${escapeHtml(cat)}</span>`;
          equipmentHtml += `<span>${escapeHtml(itemsText)}</span>`;
          equipmentHtml += `</div>`;
        });
      } else {
        equipmentHtml = '<span class="text-muted">N/A</span>';
      }
      
      tr.innerHTML = `
        <td>${escapeHtml(faculty)}</td>
        <td><strong>${escapeHtml(title)}</strong></td>
        <td>${date}</td>
        <td>${escapeHtml(time)}</td>
        <td>${equipmentHtml}</td>
        <td><small>${returnVerifiedAt}</small></td>
        <td>
          <button class="btn btn-success btn-sm approve-gym-return-btn" 
                  data-id="${returnItem.id}" 
                  data-faculty="${escapeHtml(faculty)}" 
                  data-title="${escapeHtml(title)}">
            <i class="fas fa-check"></i> Approve
          </button>
          <button class="btn btn-danger btn-sm decline-gym-return-btn" 
                  data-id="${returnItem.id}" 
                  data-faculty="${escapeHtml(faculty)}" 
                  data-title="${escapeHtml(title)}"
                  style="margin-left: 6px;">
            <i class="fas fa-times"></i> Decline
          </button>
        </td>
      `;
      table.appendChild(tr);
    });
    
    // Attach event listeners
    table.querySelectorAll('.approve-gym-return-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const id = parseInt(this.getAttribute('data-id'));
        const faculty = this.getAttribute('data-faculty');
        const title = this.getAttribute('data-title');
        approveAdminGymReturn(id, faculty, title);
      });
    });
    
    table.querySelectorAll('.decline-gym-return-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const id = parseInt(this.getAttribute('data-id'));
        const faculty = this.getAttribute('data-faculty');
        const title = this.getAttribute('data-title');
        declineAdminGymReturn(id, faculty, title);
      });
    });
    
  } catch (e) {
    console.error('Error loading admin gym returns:', e);
    table.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Error loading returns</td></tr>';
  }
}

// Admin approve gym return
async function approveAdminGymReturn(reservationId, facultyName, title) {
  if (!confirm(`Approve the gym return for "${title}" by ${facultyName}? This will restore equipment inventory and notify the faculty.`)) {
    return;
  }
  
  try {
    const resp = await fetch('api.php?action=approveAdminGymReturn', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reservationId: reservationId })
    });
    const data = await resp.json();
    
    if (data.ok && data.reservation) {
      // Create notification for faculty
      if (typeof createFacultyNotification === 'function') {
        createFacultyNotification(
          data.reservation.faculty_username,
          'Gym Return Approved',
          `Your gym return for "${title}" has been successfully approved and processed. Equipment inventory has been restored.`,
          'success'
        );
      }
      
      // Add audit log
      if (typeof addAuditLog === 'function') {
        const loggedAdmin = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null');
        addAuditLog('Admin', loggedAdmin?.username || 'Admin', `Approved gym return: ${facultyName} returned "${title}"`);
      }
      
      // Refresh equipment catalog
      fetch('api.php?action=getCatalog', { cache: 'no-store' })
        .then(res => res.json())
        .then(dbCatalog => {
          if (dbCatalog && Object.keys(dbCatalog).length > 0) {
            if (typeof setEquipmentCatalog === 'function') {
              setEquipmentCatalog(dbCatalog);
            } else {
              localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
            }
            window.dispatchEvent(new Event('equipmentUpdated'));
          }
        })
        .catch(err => console.error('Error refreshing catalog:', err));
      
      showNotification('Gym return approved! Inventory restored and faculty notified.', 'success');
      loadAdminGymReturns();
      
      // Refresh stats if function exists
      if (typeof updateAdminStats === 'function') {
        updateAdminStats();
      }
    } else {
      showNotification(data.error || 'Failed to approve gym return', 'error');
    }
  } catch (e) {
    console.error('Error approving gym return:', e);
    showNotification('Failed to approve gym return. Please try again.', 'error');
  }
}

// Load cancellation and decline reasons
async function loadCancellationReasons() {
  const table = document.querySelector('#reasonsTable tbody');
  const countElement = document.getElementById('reasonCategoryCount');
  
  if (!table) return;
  
  try {
    table.innerHTML = '<tr><td colspan="7" class="text-center">Loading reasons...</td></tr>';
    
    // Determine role and username
    let role = 'admin';
    let username = '';
    
    if (window.location.pathname.includes('faculty-dashboard.php')) {
      role = 'faculty';
      const loggedFaculty = JSON.parse(localStorage.getItem('loggedInFaculty') || 'null');
      username = loggedFaculty ? loggedFaculty.username : '';
    } else if (window.location.pathname.includes('genserve-dashboard.php')) {
      role = 'genserve';
    }
    
    const params = new URLSearchParams({ role });
    if (username) params.append('username', username);
    
    const resp = await fetch(`api.php?action=listCancellationReasons&${params.toString()}`);
    const data = await resp.json();
    
    table.innerHTML = '';
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      table.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No cancellation or decline reasons found</td></tr>';
      if (countElement) {
        countElement.textContent = 'No reasons found';
      }
      return;
    }
    
    // Store globally for filtering
    window.allReasonsData = data;
    
    // Display all reasons by default
    filterReasonsByType('all');
    
  } catch (e) {
    console.error('Error loading cancellation reasons:', e);
    table.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Error loading reasons</td></tr>';
  }
}

// Filter reasons by type (all, cancelled, declined)
function filterReasonsByType(type) {
  // Update active button
  document.querySelectorAll('.reason-filter-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`.reason-filter-btn[data-type="${type}"]`)?.classList.add('active');
  
  const table = document.querySelector('#reasonsTable tbody');
  const countElement = document.getElementById('reasonCategoryCount');
  
  if (!table || !window.allReasonsData) return;
  
  table.innerHTML = '';
  
  let filteredReasons = [];
  
  if (type === 'all') {
    filteredReasons = window.allReasonsData;
  } else if (type === 'cancelled') {
    filteredReasons = window.allReasonsData.filter(r => r.status === 'Cancelled');
  } else if (type === 'declined') {
    filteredReasons = window.allReasonsData.filter(r => r.status === 'Declined');
  }
  
  if (filteredReasons.length === 0) {
    table.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No reasons found for this filter</td></tr>';
    if (countElement) {
      countElement.textContent = `No ${type === 'all' ? '' : type} reasons found`;
    }
    return;
  }
  
  // Display reasons
  filteredReasons.forEach(reason => {
    const row = document.createElement('tr');
    const actionDate = new Date(reason.created_at).toLocaleString();
    const statusClass = reason.status.toLowerCase();
    const statusIcon = reason.status === 'Cancelled' ? 'fas fa-ban' : 'fas fa-times-circle';
    
    // For faculty dashboard, hide faculty column
    const isFaculty = window.location.pathname.includes('faculty-dashboard.php');
    
    row.innerHTML = `
      <td><span class="badge badge-info">${escapeHtml(reason.type)}</span></td>
      ${!isFaculty ? `<td>${escapeHtml(reason.faculty)}</td>` : ''}
      <td>
        <strong>${escapeHtml(reason.equipment)}</strong>
        <br><small class="text-muted">${escapeHtml(reason.category)}</small>
      </td>
      <td>${reason.date}<br><small class="text-muted">${escapeHtml(reason.time)}</small></td>
      <td>
        <span class="status-badge status-${statusClass}">
          <i class="${statusIcon}"></i> ${reason.status}
        </span>
      </td>
      <td style="max-width: 300px; word-wrap: break-word;">
        <em>"${escapeHtml(reason.reason)}"</em>
      </td>
      <td><small>${actionDate}</small></td>
    `;
    table.appendChild(row);
  });
  
  // Update count
  if (countElement) {
    const cancelledCount = filteredReasons.filter(r => r.status === 'Cancelled').length;
    const declinedCount = filteredReasons.filter(r => r.status === 'Declined').length;
    
    if (type === 'all') {
      countElement.textContent = `Showing all reasons: ${filteredReasons.length} total (${cancelledCount} cancelled, ${declinedCount} declined)`;
    } else {
      countElement.textContent = `Showing ${filteredReasons.length} ${type} reason${filteredReasons.length !== 1 ? 's' : ''}`;
    }
  }
}

// Admin decline gym return
async function declineAdminGymReturn(reservationId, facultyName, title) {
  const processDecline = async (reasonText) => {
    const trimmedReason = reasonText?.trim() || '';
    
    try {
      const resp = await fetch('api.php?action=declineAdminGymReturn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          reservationId: reservationId,
          reason: trimmedReason
        })
      });
      const data = await resp.json();
      
      if (data.ok && data.reservation) {
        if (typeof createFacultyNotification === 'function') {
          const declineMsg = trimmedReason
            ? `Your gym return for "${title}" has been declined. Reason: ${trimmedReason}`
            : `Your gym return for "${title}" has been declined. Please contact Admin for details.`;
          
          createFacultyNotification(
            data.reservation.faculty_username,
            'Gym Return Declined',
            declineMsg,
            'error'
          );
        }
        
        if (typeof addAuditLog === 'function') {
          const loggedAdmin = JSON.parse(localStorage.getItem('loggedInAdmin') || 'null');
          const reasonNote = trimmedReason ? ` - Reason: ${trimmedReason}` : '';
          addAuditLog('Admin', loggedAdmin?.username || 'Admin', `Declined gym return: ${facultyName} - "${title}"${reasonNote}`);
        }
        
        showNotification('Gym return declined. Faculty has been notified.', 'success');
        loadAdminGymReturns();
      } else {
        showNotification(data.error || 'Failed to decline gym return', 'error');
      }
    } catch (e) {
      console.error('Error declining gym return:', e);
      showNotification('Failed to decline gym return. Please try again.', 'error');
    }
  };

  showReasonModal({
    title: 'Decline Gym Return',
    description: `Provide a reason for declining the gym return for "${title}" by ${facultyName}.`,
    placeholder: 'Reason for decline',
    confirmText: 'Decline Gym Return',
    confirmIcon: 'fas fa-times',
    onConfirm: (reason) => processDecline(reason)
  });
}


