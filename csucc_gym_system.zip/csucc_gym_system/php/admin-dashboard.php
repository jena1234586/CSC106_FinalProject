<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <ul>
            <li onclick="showSection('dashboard')">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </li>
            <li onclick="showSection('reservations')">
                <i class="fas fa-calendar-check"></i>
                Reservation Requests
            </li>
            <li onclick="showSection('inventory')">
                <i class="fas fa-boxes"></i>
                Equipment Inventory
            </li>
            <li onclick="showSection('announcements')">
                <i class="fas fa-bullhorn"></i>
                Announcements
            </li>
            <li onclick="showSection('returns')">
                <i class="fas fa-undo"></i>
                Gym Returns
                <span id="returnsBadge" class="menu-badge" style="display:none;">0</span>
            </li>
            <li onclick="showSection('reasons')">
                <i class="fas fa-clipboard-list"></i>
                Cancellation Reasons
            </li>
            <li onclick="showSection('analytics')">
                <i class="fas fa-chart-bar"></i>
                Analytics
            </li>
            <li onclick="showSection('audit')">
                <i class="fas fa-history"></i>
                Audit Logs
            </li>
            <li onclick="showSection('messenger')">
                <i class="fas fa-comments"></i>
                Messenger
                <span id="chatBadge" class="menu-badge" style="display:none;">0</span>
            </li>
            <li onclick="logout()">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </li>
        </ul>
    </div>

    <div class="main-content">
        <section id="dashboard" class="active-section">
            <h2>Welcome, Admin!</h2>
            <div class="cards">
                <div class="card">
                    <i class="fas fa-clock"></i>
                    <h3>Pending Reservations</h3>
                    <p id="pendingCount">5</p>
                </div>
                <div class="card">
                    <i class="fas fa-boxes"></i>
                    <h3>Available Equipment</h3>
                    <p id="availableEquipment">20</p>
                </div>
                <div class="card">
                    <i class="fas fa-users"></i>
                    <h3>Faculty Accounts</h3>
                    <p id="totalFaculty">10</p>
                </div>
            </div>
        </section>

        <section id="reservations">
            <h2>Reservation Requests</h2>
            <div class="reservation-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="reservation-filter-btn active" data-category="all" onclick="filterReservationsByCategory('all')">
                    <i class="fas fa-list"></i> All Reservations
                </button>
                <button class="reservation-filter-btn" data-status="Pending" onclick="filterReservationsByStatus('Pending')">
                    <i class="fas fa-clock"></i> Pending
                </button>
                <button class="reservation-filter-btn" data-status="Cancellation Requested" onclick="filterReservationsByStatus('Cancellation Requested')">
                    <i class="fas fa-exclamation-triangle"></i> Cancellation Requests
                </button>
                <button class="reservation-filter-btn" data-status="Approved" onclick="filterReservationsByStatus('Approved')">
                    <i class="fas fa-check"></i> Approved
                </button>
            </div>
            <div id="reservationCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="reservationTable">
                <thead>
                    <tr>
                        <th>Faculty</th>
                        <th>Equipment</th>
                        <th>Category</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="inventory">
            <h2>Equipment Inventory</h2>
            <div class="equipment-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="equipment-filter-btn active" data-category="all" onclick="filterEquipmentByCategory('all')">
                    <i class="fas fa-list"></i> All Equipment
                </button>
            </div>
            <div id="equipmentCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <div style="position: relative; width: 300px; margin-bottom: 20px;">
                <input type="text" id="equipmentSearchInput" placeholder="Search equipment..." 
                       style="width: 100%; padding: 10px 40px 10px 15px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px;">
                <i class="fas fa-search" style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: #888;"></i>
            </div>
            <table id="equipmentTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="announcements">
            <h2>Announcements</h2>
            <div class="announcement-controls" style="margin-bottom: 20px;">
                <button class="btn btn-success" onclick="createAnnouncement()">
                    <i class="fas fa-plus"></i>
                    Create Announcement
                </button>
            </div>
            
            <!-- Calendar View -->
            <div style="margin-bottom: 30px;">
                <h3 style="margin-bottom: 15px; color: #1d4ed8;">📅 Calendar View</h3>
                <div id="adminCalendarContainer" style="margin-top: 20px;">
                    <div id="adminCalendar" style="max-width: 1000px; margin: 0 auto;">
                        <!-- Calendar will be generated here -->
                    </div>
                </div>
            </div>
            
            
            <!-- Date Details Modal -->
            <div id="adminDateDetailsModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="adminDateDetailsTitle">Reservations & Announcements for <span id="adminSelectedDateDisplay"></span></h3>
                        <span class="close" onclick="closeModal('adminDateDetailsModal')">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div id="adminDateDetailsContent">
                            <p class="text-muted">Loading...</p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="closeModal('adminDateDetailsModal')">Close</button>
                    </div>
                </div>
            </div>
        </section>

        <section id="returns">
            <h2>Gym Returns - Pending Approval</h2>
            <p style="color: #666; margin-bottom: 20px;">These gym returns have been verified by GenServe and are waiting for your final approval.</p>
            <div id="returnsCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="returnsTable">
                <thead>
                    <tr>
                        <th>Faculty</th>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Equipment Items</th>
                        <th>Verified By GenServe</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="reasons">
            <h2>Cancellation & Decline Reasons</h2>
            <p style="color: #666; margin-bottom: 20px;">View all cancellation and decline reasons with details.</p>
            <div class="reason-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="reason-filter-btn active" data-type="all" onclick="filterReasonsByType('all')">
                    <i class="fas fa-list"></i> All Reasons
                </button>
                <button class="reason-filter-btn" data-type="cancelled" onclick="filterReasonsByType('cancelled')">
                    <i class="fas fa-ban"></i> Cancelled (Faculty)
                </button>
                <button class="reason-filter-btn" data-type="declined" onclick="filterReasonsByType('declined')">
                    <i class="fas fa-times-circle"></i> Declined (Admin/GenServe)
                </button>
            </div>
            <div id="reasonCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="reasonsTable">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Faculty</th>
                        <th>Equipment/Title</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Reason</th>
                        <th>Action Date</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="audit">
            <h2>Audit Logs</h2>
            <div class="audit-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="audit-filter-btn active" data-category="all" onclick="filterAuditLogs('all')">
                    <i class="fas fa-list"></i> All Logs
                </button>
                <button class="audit-filter-btn" data-category="login" onclick="filterAuditLogs('login')">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
                <button class="audit-filter-btn" data-category="reservation" onclick="filterAuditLogs('reservation')">
                    <i class="fas fa-calendar-check"></i> Reservation
                </button>
                <button class="audit-filter-btn" data-category="return" onclick="filterAuditLogs('return')">
                    <i class="fas fa-undo"></i> Return
                </button>
                <button class="audit-filter-btn" data-category="announcement" onclick="filterAuditLogs('announcement')">
                    <i class="fas fa-bullhorn"></i> Announcement
                </button>
                <button class="audit-filter-btn" data-category="faculty" onclick="filterAuditLogs('faculty')">
                    <i class="fas fa-users"></i> Faculty
                </button>
            </div>
            <div id="auditLogsCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            
            <!-- Faculty Accounts Table (shown when Faculty filter is active) -->
            <div id="facultyAccountsContainer" style="display: none;">
                <h3 style="margin-bottom: 15px;">Faculty Accounts</h3>
                <table id="facultyTable">
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            
            <!-- Audit Logs Table (shown for all other filters) -->
            <table id="auditTable">
                <thead>
                    <tr>
                        <th>User Type</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Date/Time</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="analytics">
            <h2>Analytics</h2>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: 30px; margin-bottom: 30px;">
                <!-- Equipment Reservation Analytics (Pie Chart) -->
                <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <h3 style="color: #1d4ed8; margin-bottom: 10px;">Equipment Reservations</h3>
                    <p style="color: #666; font-size: 14px; margin-bottom: 20px;">Distribution of equipment reservations by category showing the number of pieces reserved.</p>
                    <canvas id="equipmentChart" width="400" height="400"></canvas>
                    <div id="equipmentBreakdown" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px; font-size: 14px; color: #495057;">
                        <strong>Breakdown:</strong> <span id="equipmentBreakdownText">Loading...</span>
                    </div>
                </div>
                
                <!-- Gym Combined Analytics (Reservations, Returns, Cancellations) -->
                <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <h3 style="color: #1d4ed8; margin-bottom: 10px;">Gym Analytics</h3>
                    <p style="color: #666; font-size: 14px; margin-bottom: 20px;">Monthly overview of gym reservations (blue), returns (orange), and cancellations (red).</p>
                    <div style="height: 400px; position: relative;">
                        <canvas id="gymCombinedChart"></canvas>
                    </div>
                    <div id="gymCombinedBreakdown" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px; font-size: 14px; color: #495057;">
                        <strong>Legend:</strong> <span style="color: rgba(29, 78, 216, 1);">●</span> Reservations <span style="color: rgba(245, 158, 11, 1); margin-left: 15px;">●</span> Returns <span style="color: rgba(220, 38, 38, 1); margin-left: 15px;">●</span> Cancellations
                    </div>
                </div>
                
                <!-- Equipment Returns (Pie Chart) -->
                <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <h3 style="color: #1d4ed8; margin-bottom: 10px;">Equipment Returns</h3>
                    <p style="color: #666; font-size: 14px; margin-bottom: 20px;">Distribution of equipment returns by category.</p>
                    <canvas id="equipmentReturnsChart" width="400" height="400"></canvas>
                    <div id="equipmentReturnsBreakdown" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px; font-size: 14px; color: #495057;">
                        <strong>Breakdown:</strong> <span id="equipmentReturnsBreakdownText">Loading...</span>
                    </div>
                </div>
                
                <!-- Equipment Cancellations (Pie Chart) -->
                <div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <h3 style="color: #1d4ed8; margin-bottom: 10px;">Equipment Cancellations</h3>
                    <p style="color: #666; font-size: 14px; margin-bottom: 20px;">Distribution of equipment cancellations by category.</p>
                    <canvas id="equipmentCancellationsChart" width="400" height="400"></canvas>
                    <div id="equipmentCancellationsBreakdown" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px; font-size: 14px; color: #495057;">
                        <strong>Breakdown:</strong> <span id="equipmentCancellationsBreakdownText">Loading...</span>
                    </div>
                </div>
            </div>
        </section>

        <section id="messenger">
            <h2>💬 Messenger</h2>
            <div class="messenger-container">
                <div class="messenger-sidebar">
                    <div class="messenger-header">
                        <h3>Conversations</h3>
                        <div class="messenger-tabs">
                            <button class="tab-btn active" data-chat-filter="faculty" onclick="setChatFilter('faculty')">Faculty</button>
                            <button class="tab-btn" data-chat-filter="genserve" onclick="setChatFilter('genserve')">GenServe</button>
                        </div>
                    </div>
                    <div class="messenger-search">
                        <input type="text" id="chatSearchInput" placeholder="Search Faculty contacts..." autocomplete="off">
                    </div>
                    <div class="conversations-list" id="adminConversationsList">
                        <p class="text-muted">Loading conversations...</p>
                    </div>
                </div>
                <div class="messenger-main">
                    <div class="chat-header" id="chatHeader" style="display:none;">
                        <div class="chat-user-info">
                            <div class="chat-avatar">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <h4 id="chatUserName"></h4>
                                <small id="chatUserEmail" class="text-muted"></small>
                            </div>
                        </div>
                    </div>
                    <div class="chat-messages" id="chatMessages">
                        <div class="chat-empty-state">
                            <i class="fas fa-comments"></i>
                            <p>Select a conversation to start chatting</p>
                        </div>
                    </div>
                    <div class="chat-input-container" id="chatInputContainer" style="display:none;">
                        <form id="chatMessageForm">
                            <input type="text" id="chatMessageInput" placeholder="Type a message..." autocomplete="off">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div id="notification" class="notification"></div>

    <!-- Reason Capture Modal -->
    <div id="reasonModal" class="modal">
        <div class="modal-content" style="max-width: 520px;">
            <div class="modal-header">
                <h3 id="reasonModalTitle">Provide Reason</h3>
                <span class="close" onclick="cancelReasonModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p id="reasonModalDescription" class="text-muted" style="margin-bottom: 12px;"></p>
                <textarea id="reasonModalInput" rows="4" style="width: 100%; padding: 10px;" placeholder="Enter your reason..."></textarea>
                <small id="reasonModalHint" class="hint-text">This note will be recorded for this action.</small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="cancelReasonModal()">Back</button>
                <button type="button" class="btn btn-danger reason-confirm-btn" onclick="submitReasonModal()">
                    <i class="fas fa-paper-plane"></i> Submit
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Faculty Modal -->
    <div id="editFacultyModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>✏️ Edit Faculty Account</h3>
                <span class="close" onclick="closeModal('editFacultyModal')">&times;</span>
            </div>
            <div class="modal-body">
                <form id="editFacultyForm" class="modal-form-grid">
                    <input type="hidden" id="editFacultyUsername" value="">
                    <div class="form-group">
                        <label for="editFacultyFullname">
                            <i class="fas fa-user"></i> Full Name
                        </label>
                        <input type="text" id="editFacultyFullname" placeholder="Enter full name" required>
                    </div>
                    <div class="form-group">
                        <label for="editFacultyEmail">
                            <i class="fas fa-envelope"></i> Email
                        </label>
                        <input type="email" id="editFacultyEmail" placeholder="Enter email address" required>
                    </div>
                    <div class="form-group">
                        <label for="editFacultyUsernameDisplay">
                            <i class="fas fa-user-tag"></i> Username
                        </label>
                        <input type="text" id="editFacultyUsernameDisplay" readonly style="background-color: #f5f5f5; cursor: not-allowed;">
                        <small class="hint-text">Username cannot be changed</small>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="closeModal('editFacultyModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="button" class="btn btn-success" onclick="saveFacultyEdit()">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </div>
    </div>

    <!-- Create Announcement Modal -->
    <div id="announcementModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>📢 Create New Announcement</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body">
                <form id="announcementForm" class="modal-form-grid">
                    <div class="form-group full-width">
                        <label for="announcementTitle">
                            <i class="fas fa-heading"></i> Title
                        </label>
                        <input type="text" id="announcementTitle" placeholder="e.g., Gym Maintenance Schedule" required>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="announcementMessage">
                            <i class="fas fa-comment-alt"></i> Message
                        </label>
                        <textarea id="announcementMessage" rows="4" placeholder="Enter announcement details..." required></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="announcementStartDate">
                                <i class="fas fa-calendar-day"></i> Start Date
                            </label>
                            <input type="date" id="announcementStartDate" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="announcementStartTime">
                                <i class="fas fa-clock"></i> Start Time
                            </label>
                            <input type="time" id="announcementStartTime" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="announcementEndDate">
                                <i class="fas fa-calendar-check"></i> End Date
                            </label>
                            <input type="date" id="announcementEndDate" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="announcementEndTime">
                                <i class="fas fa-clock"></i> End Time
                            </label>
                            <input type="time" id="announcementEndTime" required>
                        </div>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="announcementDuration">
                            <i class="fas fa-hourglass-half"></i> Duration (days)
                        </label>
                        <input type="number" id="announcementDuration" min="1" value="1" required>
                        <small class="hint-text">Number of days this announcement will be active</small>
                    </div>
                    
                    <div class="form-group full-width">
                        <label>
                            <input type="checkbox" id="announcementUrgent">
                            <i class="fas fa-exclamation-circle"></i> Mark as Urgent
                        </label>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="closeModal('announcementModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" form="announcementForm" class="btn btn-success">
                    <i class="fas fa-paper-plane"></i> Send to All Faculty
                </button>
            </div>
        </div>
    </div>

    <script src="../js/script.js"></script>
    <script>
        // Load analytics charts for Admin
        async function loadAdminAnalytics() {
            try {
                // Load equipment analytics - PIE CHART
                const equipmentResp = await fetch('api.php?action=getMonthlyReservationAnalytics');
                const equipmentData = await equipmentResp.json();
                
                if (equipmentData && equipmentData.categoryData) {
                    const categoryData = equipmentData.categoryData || {};
                    const allCategories = Object.keys(categoryData);
                    const totalByCategory = {};
                    
                    // Calculate total quantities per category
                    allCategories.forEach(category => {
                        let total = 0;
                        Object.values(categoryData[category] || {}).forEach(monthData => {
                            total += monthData.total_quantity || 0;
                        });
                        totalByCategory[category] = total;
                    });
                    
                    const categoryColors = [
                        'rgba(40, 167, 69, 0.8)',   // Green
                        'rgba(29, 78, 216, 0.8)',   // Blue
                        'rgba(220, 38, 38, 0.8)',   // Red
                        'rgba(245, 158, 11, 0.8)',  // Orange
                        'rgba(139, 92, 246, 0.8)',  // Purple
                        'rgba(236, 72, 153, 0.8)',  // Pink
                        'rgba(16, 185, 129, 0.8)',  // Teal
                        'rgba(251, 191, 36, 0.8)',  // Yellow
                        'rgba(59, 130, 246, 0.8)',  // Light Blue
                        'rgba(239, 68, 68, 0.8)'   // Light Red
                    ];
                    
                    const labels = Object.keys(totalByCategory);
                    const data = Object.values(totalByCategory);
                    const colors = labels.map((_, idx) => categoryColors[idx % categoryColors.length]);
                    
                    const equipmentCtx = document.getElementById('equipmentChart');
                    if (equipmentCtx) {
                        if (window.equipmentChartInstance) {
                            window.equipmentChartInstance.destroy();
                        }
                        
                        window.equipmentChartInstance = new Chart(equipmentCtx, {
                            type: 'pie',
                            data: {
                                labels: labels.length > 0 ? labels : ['No Data'],
                                datasets: [{
                                    data: data.length > 0 ? data : [1],
                                    backgroundColor: data.length > 0 ? colors : ['rgba(200, 200, 200, 0.8)'],
                                    borderColor: '#fff',
                                    borderWidth: 2
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        display: true,
                                        position: 'right'
                                    },
                                    tooltip: {
                                        callbacks: {
                                            label: function(context) {
                                                const label = context.label || '';
                                                const value = context.parsed || 0;
                                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                                return `${label}: ${value} pieces (${percentage}%)`;
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                    
                    // Generate equipment breakdown
                    const equipmentBreakdownText = document.getElementById('equipmentBreakdownText');
                    if (equipmentBreakdownText) {
                        const sortedCategories = Object.entries(totalByCategory)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 5); // Top 5 categories
                        
                        if (sortedCategories.length > 0) {
                            const breakdown = sortedCategories.map(([cat, total]) => 
                                `${cat}: ${total} pieces`
                            ).join(' • ');
                            equipmentBreakdownText.textContent = breakdown;
                        } else {
                            equipmentBreakdownText.textContent = 'No data available';
                        }
                    }
                }
                
                // Load gym combined analytics (reservations, returns, cancellations)
                const gymCombinedResp = await fetch('api.php?action=getGymCombinedAnalytics');
                const gymCombinedData = await gymCombinedResp.json();
                
                if (gymCombinedData && gymCombinedData.reservationData) {
                    const currentYear = gymCombinedData.year || new Date().getFullYear();
                    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    const allMonths = [];
                    
                    for (let i = 1; i <= 12; i++) {
                        const monthKey = `${currentYear}-${String(i).padStart(2, '0')}`;
                        allMonths.push({
                            key: monthKey,
                            label: monthNames[i - 1],
                            reservations: gymCombinedData.reservationData[monthKey] || 0,
                            returns: gymCombinedData.returnData[monthKey] || 0,
                            cancellations: gymCombinedData.cancellationData[monthKey] || 0
                        });
                    }
                    
                    const monthLabels = allMonths.map(m => m.label);
                    const reservationCounts = allMonths.map(m => m.reservations);
                    const returnCounts = allMonths.map(m => m.returns);
                    const cancellationCounts = allMonths.map(m => m.cancellations);
                    
                    const gymCombinedCtx = document.getElementById('gymCombinedChart');
                    if (gymCombinedCtx) {
                        if (window.gymCombinedChartInstance) {
                            window.gymCombinedChartInstance.destroy();
                        }
                        
                        window.gymCombinedChartInstance = new Chart(gymCombinedCtx, {
                            type: 'bar',
                            data: {
                                labels: monthLabels,
                                datasets: [
                                    {
                                        label: 'Gym Reservations',
                                        data: reservationCounts,
                                        backgroundColor: 'rgba(29, 78, 216, 0.7)',
                                        borderColor: 'rgba(29, 78, 216, 1)',
                                        borderWidth: 2
                                    },
                                    {
                                        label: 'Gym Returns',
                                        data: returnCounts,
                                        backgroundColor: 'rgba(245, 158, 11, 0.7)',
                                        borderColor: 'rgba(245, 158, 11, 1)',
                                        borderWidth: 2
                                    },
                                    {
                                        label: 'Gym Cancellations',
                                        data: cancellationCounts,
                                        backgroundColor: 'rgba(220, 38, 38, 0.7)',
                                        borderColor: 'rgba(220, 38, 38, 1)',
                                        borderWidth: 2
                                    }
                                ]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        display: true,
                                        position: 'top'
                                    },
                                    tooltip: {
                                        callbacks: {
                                            label: function(context) {
                                                const label = context.dataset.label || '';
                                                const value = context.parsed.y || 0;
                                                if (label.includes('Reservations')) {
                                                    return `${label}: ${value} reservation${value !== 1 ? 's' : ''}`;
                                                } else if (label.includes('Returns')) {
                                                    return `${label}: ${value} return${value !== 1 ? 's' : ''}`;
                                                } else {
                                                    return `${label}: ${value} cancellation${value !== 1 ? 's' : ''}`;
                                                }
                                            }
                                        }
                                    }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        max: 50,
                                        ticks: {
                                            stepSize: 1,
                                            font: {
                                                size: 13,
                                                weight: 'bold'
                                            },
                                            color: '#333',
                                            padding: 8,
                                            callback: function(value) {
                                                // Show only specific values: 0, 5, 10, 20, 50
                                                const allowedValues = [0, 5, 10, 20, 50];
                                                if (allowedValues.includes(value)) {
                                                    return value;
                                                }
                                                return '';
                                            }
                                        },
                                        afterBuildTicks: function(scale) {
                                            // Force specific tick values
                                            scale.ticks = [
                                                { value: 0 },
                                                { value: 5 },
                                                { value: 10 },
                                                { value: 20 },
                                                { value: 50 }
                                            ];
                                        },
                                        grid: {
                                            color: 'rgba(0, 0, 0, 0.1)',
                                            lineWidth: 1
                                        },
                                        title: {
                                            display: true,
                                            text: 'Count',
                                            font: {
                                                size: 14,
                                                weight: 'bold'
                                            },
                                            color: '#333'
                                        }
                                    },
                                    x: {
                                        ticks: {
                                            font: {
                                                size: 11
                                            }
                                        },
                                        title: {
                                            display: true,
                                            text: 'Month',
                                            font: {
                                                size: 14,
                                                weight: 'bold'
                                            },
                                            color: '#333'
                                        }
                                    }
                                }
                            }
                        });
                    }
                }
                
                // Load equipment returns by category (pie chart)
                const equipmentReturnsResp = await fetch('api.php?action=getEquipmentReturnsByCategory');
                const equipmentReturnsData = await equipmentReturnsResp.json();
                
                if (equipmentReturnsData && equipmentReturnsData.categoryData) {
                    const categoryData = equipmentReturnsData.categoryData || {};
                    const labels = Object.keys(categoryData);
                    const data = Object.values(categoryData);
                    
                    const categoryColors = [
                        'rgba(40, 167, 69, 0.8)',   // Green
                        'rgba(29, 78, 216, 0.8)',   // Blue
                        'rgba(220, 38, 38, 0.8)',   // Red
                        'rgba(245, 158, 11, 0.8)',  // Orange
                        'rgba(139, 92, 246, 0.8)',  // Purple
                        'rgba(236, 72, 153, 0.8)',  // Pink
                        'rgba(16, 185, 129, 0.8)',  // Teal
                        'rgba(251, 191, 36, 0.8)',  // Yellow
                        'rgba(59, 130, 246, 0.8)',  // Light Blue
                        'rgba(239, 68, 68, 0.8)'   // Light Red
                    ];
                    
                    const colors = labels.map((_, idx) => categoryColors[idx % categoryColors.length]);
                    
                    const equipmentReturnsCtx = document.getElementById('equipmentReturnsChart');
                    if (equipmentReturnsCtx) {
                        if (window.equipmentReturnsChartInstance) {
                            window.equipmentReturnsChartInstance.destroy();
                        }
                        
                        window.equipmentReturnsChartInstance = new Chart(equipmentReturnsCtx, {
                            type: 'pie',
                            data: {
                                labels: labels.length > 0 ? labels : ['No Data'],
                                datasets: [{
                                    data: data.length > 0 ? data : [1],
                                    backgroundColor: data.length > 0 ? colors : ['rgba(200, 200, 200, 0.8)'],
                                    borderColor: '#fff',
                                    borderWidth: 2
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        display: true,
                                        position: 'right'
                                    },
                                    tooltip: {
                                        callbacks: {
                                            label: function(context) {
                                                const label = context.label || '';
                                                const value = context.parsed || 0;
                                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                                return `${label}: ${value} return${value !== 1 ? 's' : ''} (${percentage}%)`;
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                    
                    // Generate equipment returns breakdown
                    const equipmentReturnsBreakdownText = document.getElementById('equipmentReturnsBreakdownText');
                    if (equipmentReturnsBreakdownText) {
                        const sortedCategories = Object.entries(categoryData)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 5);
                        
                        if (sortedCategories.length > 0) {
                            const breakdown = sortedCategories.map(([cat, count]) => 
                                `${cat}: ${count} return${count !== 1 ? 's' : ''}`
                            ).join(' • ');
                            equipmentReturnsBreakdownText.textContent = breakdown;
                        } else {
                            equipmentReturnsBreakdownText.textContent = 'No returns yet';
                        }
                    }
                }
                
                // Load equipment cancellations by category (pie chart)
                const equipmentCancellationsResp = await fetch('api.php?action=getEquipmentCancellationsByCategory');
                const equipmentCancellationsData = await equipmentCancellationsResp.json();
                
                if (equipmentCancellationsData && equipmentCancellationsData.categoryData) {
                    const categoryData = equipmentCancellationsData.categoryData || {};
                    const labels = Object.keys(categoryData);
                    const data = Object.values(categoryData);
                    
                    const categoryColors = [
                        'rgba(220, 38, 38, 0.8)',   // Red
                        'rgba(245, 158, 11, 0.8)',  // Orange
                        'rgba(139, 92, 246, 0.8)',  // Purple
                        'rgba(236, 72, 153, 0.8)',  // Pink
                        'rgba(40, 167, 69, 0.8)',   // Green
                        'rgba(29, 78, 216, 0.8)',   // Blue
                        'rgba(16, 185, 129, 0.8)',  // Teal
                        'rgba(251, 191, 36, 0.8)',  // Yellow
                        'rgba(59, 130, 246, 0.8)',  // Light Blue
                        'rgba(239, 68, 68, 0.8)'   // Light Red
                    ];
                    
                    const colors = labels.map((_, idx) => categoryColors[idx % categoryColors.length]);
                    
                    const equipmentCancellationsCtx = document.getElementById('equipmentCancellationsChart');
                    if (equipmentCancellationsCtx) {
                        if (window.equipmentCancellationsChartInstance) {
                            window.equipmentCancellationsChartInstance.destroy();
                        }
                        
                        window.equipmentCancellationsChartInstance = new Chart(equipmentCancellationsCtx, {
                            type: 'pie',
                            data: {
                                labels: labels.length > 0 ? labels : ['No Data'],
                                datasets: [{
                                    data: data.length > 0 ? data : [1],
                                    backgroundColor: data.length > 0 ? colors : ['rgba(200, 200, 200, 0.8)'],
                                    borderColor: '#fff',
                                    borderWidth: 2
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                plugins: {
                                    legend: {
                                        display: true,
                                        position: 'right'
                                    },
                                    tooltip: {
                                        callbacks: {
                                            label: function(context) {
                                                const label = context.label || '';
                                                const value = context.parsed || 0;
                                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                                return `${label}: ${value} cancellation${value !== 1 ? 's' : ''} (${percentage}%)`;
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    }
                    
                    // Generate equipment cancellations breakdown
                    const equipmentCancellationsBreakdownText = document.getElementById('equipmentCancellationsBreakdownText');
                    if (equipmentCancellationsBreakdownText) {
                        const sortedCategories = Object.entries(categoryData)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 5);
                        
                        if (sortedCategories.length > 0) {
                            const breakdown = sortedCategories.map(([cat, count]) => 
                                `${cat}: ${count} cancellation${count !== 1 ? 's' : ''}`
                            ).join(' • ');
                            equipmentCancellationsBreakdownText.textContent = breakdown;
                        } else {
                            equipmentCancellationsBreakdownText.textContent = 'No cancellations yet';
                        }
                    }
                }
            } catch (e) {
                console.error('Failed to load analytics:', e);
            }
        }
        
        // Load analytics when analytics section is shown
        const originalShowSection = window.showSection;
        window.showSection = function(id) {
            if (typeof originalShowSection === 'function') {
                originalShowSection(id);
            } else {
                // Fallback if showSection doesn't exist
                document.querySelectorAll('section').forEach(s => s.classList.remove('active-section'));
                const section = document.getElementById(id);
                if (section) {
                    section.classList.add('active-section');
                }
            }
            
            // Load analytics when section is shown
            if (id === 'analytics') {
                setTimeout(loadAdminAnalytics, 100);
            }
        };
    </script>
</body>
</html>
