<?php
require_once __DIR__ . '/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// Ensure admins table exists and has at least one admin (development safety)
function ensure_admin_exists($db) {
  $db->query('CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE,
    password_hash VARCHAR(64) NOT NULL,
    fullname VARCHAR(200),
    email VARCHAR(200)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  $res = $db->query('SELECT id FROM admins LIMIT 1');
  if ($res && $res->num_rows === 0) {
    // default admin: username admin, password admin123
    $hash = hash('sha256', 'admin123');
    $stmt = $db->prepare('INSERT INTO admins (username, password_hash, fullname, email) VALUES ("admin", ?, "System Administrator", "admin@csucc.edu")');
    $stmt->bind_param('s', $hash);
    $stmt->execute();
    $stmt->close();
  }
}

// Ensure genserve table exists
function ensure_genserve_exists($db) {
  $db->query('CREATE TABLE IF NOT EXISTS genserve (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE,
    password_hash VARCHAR(64) NOT NULL,
    fullname VARCHAR(200),
    email VARCHAR(200)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  $res = $db->query('SELECT id FROM genserve LIMIT 1');
  if ($res && $res->num_rows === 0) {
    // default genserve: username genserve, password genserve123
    $hash = hash('sha256', 'genserve123');
    $stmt = $db->prepare('INSERT INTO genserve (username, password_hash, fullname, email) VALUES ("genserve", ?, "GenServe Administrator", "genserve@csucc.edu")');
    $stmt->bind_param('s', $hash);
    $stmt->execute();
    $stmt->close();
  }
}

// Ensure genserve_notifications table exists
function ensure_genserve_notifications_exists($db) {
  $db->query('CREATE TABLE IF NOT EXISTS genserve_notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    genserve_id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_genserve_notifications_genserve FOREIGN KEY (genserve_id) REFERENCES genserve(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
}

// Check if a date is a Saturday and falls within NSTP blocked period
// Blocked: Saturdays from August 1 to 2nd week of December (excluding June and July)
function is_saturday_blocked($date_str) {
  if (empty($date_str)) return false;
  
  $date = new DateTime($date_str);
  $dayOfWeek = (int)$date->format('w'); // 0 = Sunday, 6 = Saturday
  
  // Check if it's a Saturday
  if ($dayOfWeek !== 6) {
    return false;
  }
  
  $month = (int)$date->format('n'); // 1-12
  $year = (int)$date->format('Y');
  
  // June (6) and July (7) are exempt - allow Saturday reservations
  if ($month === 6 || $month === 7) {
    return false;
  }
  
  // Check if date is between August 1 and 2nd week of December
  $august1 = new DateTime("{$year}-08-01");
  $december2ndWeek = new DateTime("{$year}-12-15"); // 2nd week of December (around Dec 8-15)
  
  // If date is on or after August 1 and on or before December 15, it's blocked
  if ($date >= $august1 && $date <= $december2ndWeek) {
    return true;
  }
  
  return false;
}

// Send notification to all GenServe users
function send_genserve_notification($db, $type, $title, $message) {
  ensure_genserve_notifications_exists($db);
  
  $result = $db->query('SELECT id FROM genserve');
  $ins = $db->prepare('INSERT INTO genserve_notifications (genserve_id, type, title, message, is_read) VALUES (?, ?, ?, ?, 0)');
  
  while ($row = $result->fetch_assoc()) {
    $gid = intval($row['id']);
    $ins->bind_param('isss', $gid, $type, $title, $message);
    $ins->execute();
  }
  $ins->close();
}

$action = isset($_GET['action']) ? $_GET['action'] : '';
$db = db_connect();

function json_input() {
  $raw = file_get_contents('php://input');
  return json_decode($raw, true);
}

// Login endpoint for both admin and faculty
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $username = trim($data['username'] ?? '');
  $password = trim($data['password'] ?? '');
  $role = trim($data['role'] ?? '');
  
  if ($username === '' || $password === '' || $role === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing fields']);
    exit;
  }
  
  if (!in_array($role, ['admin', 'faculty', 'genserve'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid role']);
    exit;
  }
  
  $passwordHash = hash('sha256', $password);
  $table = $role === 'admin' ? 'admins' : ($role === 'genserve' ? 'genserve' : 'faculty');
  
  $stmt = $db->prepare("SELECT id, username, fullname, email FROM {$table} WHERE username=? AND password_hash=?");
  $stmt->bind_param('ss', $username, $passwordHash);
  $stmt->execute();
  $result = $stmt->get_result();
  $user = $result->fetch_assoc();
  $stmt->close();
  
  if (!$user) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Invalid username or password']);
    exit;
  }
  
  // Create audit log entry for successful login
  $actorType = $role === 'admin' ? 'Admin' : ($role === 'genserve' ? 'GenServe' : 'Faculty');
  $actorName = $user['fullname'];
  $actionText = "Logged in successfully";
  
  $auditStmt = $db->prepare('INSERT INTO audit_logs (actor_type, actor_name, action) VALUES (?,?,?)');
  $auditStmt->bind_param('sss', $actorType, $actorName, $actionText);
  $auditStmt->execute();
  $auditStmt->close();
  
  echo json_encode([
    'ok' => true,
    'user' => [
      'id' => $user['id'],
      'username' => $user['username'],
      'fullname' => $user['fullname'],
      'email' => $user['email'],
      'role' => $role
    ]
  ]);
  exit;
}

if ($action === 'registerFaculty' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $fullname = trim($data['fullname'] ?? '');
  $username = trim($data['username'] ?? '');
  $email    = trim($data['email'] ?? '');
  $password = $data['password'] ?? '';
  if ($fullname === '' || $username === '' || $email === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing fields']);
    exit;
  }

  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=? OR email=?');
  $stmt->bind_param('ss', $username, $email);
  $stmt->execute();
  $stmt->store_result();
  if ($stmt->num_rows > 0) {
    echo json_encode(['ok' => false, 'error' => 'Username or email already exists']);
    exit;
  }
  $stmt->close();

  $hash = hash('sha256', $password);
  $stmt = $db->prepare('INSERT INTO faculty (username, password_hash, fullname, email) VALUES (?,?,?,?)');
  $stmt->bind_param('ssss', $username, $hash, $fullname, $email);
  $stmt->execute();

  echo json_encode(['ok' => true, 'id' => $stmt->insert_id]);
  exit;
}

if ($action === 'deleteFaculty' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $username = trim($data['username'] ?? '');
  
  if ($username === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Username required']);
    exit;
  }
  
  // Get faculty info before deletion for audit log
  $stmt = $db->prepare('SELECT fullname FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fullname);
  $stmt->fetch();
  $stmt->close();
  
  // Delete faculty from database
  $stmt = $db->prepare('DELETE FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $deleted = $stmt->affected_rows > 0;
  $stmt->close();
  
  if ($deleted) {
    echo json_encode(['ok' => true]);
  } else {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Faculty not found']);
  }
  exit;
}

if ($action === 'backupEquipment' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  // Accepts entire catalog object: { "Category": [ {name,total,available}, ... ] }
  $catalog = json_input();
  if (!is_array($catalog)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid catalog']); exit; }

  // Upsert categories and equipment
  foreach ($catalog as $categoryName => $items) {
    if (!is_array($items)) continue;
    // Ensure category
    $stmt = $db->prepare('INSERT INTO equipment_categories (name) VALUES (?) ON DUPLICATE KEY UPDATE name=name');
    $stmt->bind_param('s', $categoryName);
    $stmt->execute();

    // Get id
    $catId = 0;
    $stmt = $db->prepare('SELECT id FROM equipment_categories WHERE name=?');
    $stmt->bind_param('s', $categoryName);
    $stmt->execute();
    $stmt->bind_result($catId);
    $stmt->fetch();
    $stmt->close();

    foreach ($items as $it) {
      $name = $it['name'] ?? '';
      $total = intval($it['total'] ?? 0);
      $avail = intval($it['available'] ?? 0);
      if ($name === '') continue;
      $stmt = $db->prepare('INSERT INTO equipment (category_id, name, total, available) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE total=VALUES(total), available=VALUES(available)');
      $stmt->bind_param('isii', $catId, $name, $total, $avail);
      $stmt->execute();
    }
  }

  echo json_encode(['ok' => true]);
  exit;
}

if ($action === 'getCatalog' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  // Return catalog grouped by category
  $out = [];
  $res = $db->query('SELECT e.name, e.total, e.available, c.name AS category FROM equipment e JOIN equipment_categories c ON c.id=e.category_id ORDER BY c.name, e.name');
  while ($row = $res->fetch_assoc()) {
    $cat = $row['category'];
    if (!isset($out[$cat])) $out[$cat] = [];
    $out[$cat][] = [ 'name'=>$row['name'], 'total'=>intval($row['total']), 'available'=>intval($row['available']) ];
  }
  echo json_encode($out);
  exit;
}

if ($action === 'createAnnouncement' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $a = json_input();
  $title = trim($a['title'] ?? '');
  $message = trim($a['message'] ?? '');
  $start_date = trim($a['startDate'] ?? '');
  $start_time = trim($a['startTime'] ?? '');
  $end_date = trim($a['endDate'] ?? '');
  $end_time = trim($a['endTime'] ?? '');
  $duration_days = intval($a['duration'] ?? 1);
  $created_by = 'Admin';
  if ($title === '' || $message === '' || $start_date === '' || $start_time === '' || $end_date === '' || $end_time === '') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Missing fields']);
    exit;
  }

  // Insert announcement
  $stmt = $db->prepare('INSERT INTO announcements (title, message, start_date, start_time, end_date, end_time, duration_days, created_by) VALUES (?,?,?,?,?,?,?,?)');
  $stmt->bind_param('ssssssis', $title, $message, $start_date, $start_time, $end_date, $end_time, $duration_days, $created_by);
  $stmt->execute();
  $annId = $stmt->insert_id;
  $stmt->close();

  // Create per-faculty notifications
  $result = $db->query('SELECT id FROM faculty');
  $ins = $db->prepare('INSERT INTO notifications (faculty_id, type, title, message, is_read) VALUES (?,"announcement", ?, ?, 0)');
  $ntitle = '📢 New Announcement';
  $full = $title . ': ' . $message;
  while ($row = $result->fetch_assoc()) {
    $fid = intval($row['id']);
    $ins->bind_param('iss', $fid, $ntitle, $full);
    $ins->execute();
  }
  $ins->close();

  echo json_encode(['ok'=>true, 'announcement_id'=>$annId]);
  exit;
}

if ($action === 'listAnnouncements' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $res = $db->query('SELECT id, title, message, start_date AS startDate, start_time AS startTime, end_date AS endDate, end_time AS endTime, duration_days AS duration, created_by AS createdBy, created_at AS createdAt FROM announcements ORDER BY id DESC');
  $out = [];
  while ($row = $res->fetch_assoc()) { $out[] = $row; }
  echo json_encode($out);
  exit;
}

if ($action === 'deleteAnnouncement' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid announcement id']);
    exit;
  }

  $stmt = $db->prepare('DELETE FROM announcements WHERE id=?');
  $stmt->bind_param('i', $id);
  $stmt->execute();
  $affected = $stmt->affected_rows;
  $stmt->close();

  if ($affected > 0) {
    echo json_encode(['ok' => true]);
  } else {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Announcement not found']);
  }
  exit;
}

if ($action === 'listNotificationsByUsername' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $username = $_GET['username'] ?? '';
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) { echo json_encode([]); exit; }
  $stmt->close();
  $stmt2 = $db->prepare('SELECT id, type, title, message, is_read AS isRead, created_at AS createdAt FROM notifications WHERE faculty_id=? ORDER BY id DESC');
  $stmt2->bind_param('i', $fid);
  $stmt2->execute();
  $result = $stmt2->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) { $out[] = $row; }
  echo json_encode($out);
  exit;
}

if ($action === 'markNotificationRead' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  $stmt = $db->prepare('UPDATE notifications SET is_read=1 WHERE id=?');
  $stmt->bind_param('i', $id);
  $stmt->execute();
  echo json_encode(['ok'=>true]);
  exit;
}

// Create notification for a specific faculty member
if ($action === 'createFacultyNotification' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $username = trim($data['facultyUsername'] ?? '');
  $title = trim($data['title'] ?? '');
  $message = trim($data['message'] ?? '');
  $type = trim($data['type'] ?? 'info');
  
  if ($username === '' || $title === '' || $message === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing required fields']);
    exit;
  }
  
  // Get faculty id
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Faculty not found']);
    exit;
  }
  $stmt->close();
  
  // Insert notification
  $stmt = $db->prepare('INSERT INTO notifications (faculty_id, type, title, message, is_read) VALUES (?,?,?,?,0)');
  $stmt->bind_param('isss', $fid, $type, $title, $message);
  $stmt->execute();
  echo json_encode(['ok' => true, 'id' => $stmt->insert_id]);
  exit;
}

if ($action === 'submitReservation' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $r = json_input();
  $username = $r['facultyUsername'] ?? '';
  $equipment = $r['equipment'] ?? '';
  $category = $r['category'] ?? '';
  // Support date range (start/end) while keeping legacy single-date field
  $start_date = $r['startDate'] ?? ($r['date'] ?? '');
  $end_date = $r['endDate'] ?? $start_date;
  $time = $r['time'] ?? '';
  $quantity = intval($r['quantity'] ?? 0);
  $purpose = $r['purpose'] ?? '';
  $duration_days = intval($r['durationDays'] ?? 0);

  if ($start_date === '' || $end_date === '') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Start and end dates are required']);
    exit;
  }

  $startDateObj = new DateTime($start_date);
  $endDateObj = new DateTime($end_date);
  if ($endDateObj < $startDateObj) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'End Date cannot be earlier than Start Date']);
    exit;
  }

  if ($duration_days <= 0) {
    $duration_days = $startDateObj->diff($endDateObj)->days + 1;
  }

  // Check each day in the range for NSTP blocked Saturdays
  $rangeDate = clone $startDateObj;
  while ($rangeDate <= $endDateObj) {
    $rangeStr = $rangeDate->format('Y-m-d');
    if (is_saturday_blocked($rangeStr)) {
      http_response_code(400);
      echo json_encode(['ok'=>false,'error'=>'Reservations on Saturdays are not allowed due to NSTP activities.']);
      exit;
    }
    $rangeDate->modify('+1 day');
  }

  // Resolve faculty id
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Faculty not found']); exit; }
  $stmt->close();

  // Resolve category and equipment ids
  $stmt = $db->prepare('SELECT id FROM equipment_categories WHERE name=?');
  $stmt->bind_param('s', $category);
  $stmt->execute();
  $stmt->bind_result($catId);
  if (!$stmt->fetch()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Category not found']); exit; }
  $stmt->close();

  $stmt = $db->prepare('SELECT id, available FROM equipment WHERE name=? AND category_id=?');
  $stmt->bind_param('si', $equipment, $catId);
  $stmt->execute();
  $stmt->bind_result($eqId, $avail);
  if (!$stmt->fetch()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Equipment not found']); exit; }
  $stmt->close();

  // Check if enough quantity is available
  if ($avail < $quantity) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>"Only {$avail} available, but {$quantity} requested"]);
    exit;
  }

  // Deduct quantity from available inventory in database immediately
  $stmt = $db->prepare('UPDATE equipment SET available = available - ? WHERE id = ?');
  $stmt->bind_param('ii', $quantity, $eqId);
  $stmt->execute();
  $stmt->close();

  // Create reservation
  $stmt = $db->prepare('INSERT INTO reservations (faculty_id, equipment_id, category_id, date, start_date, end_date, duration_days, time, quantity, purpose, status) VALUES (?,?,?,?,?,?,?,?,?,?,"Pending")');
  $date_for_legacy = $start_date;
  $stmt->bind_param('iiisssssis', $fid, $eqId, $catId, $date_for_legacy, $start_date, $end_date, $duration_days, $time, $quantity, $purpose);
  $stmt->execute();
  echo json_encode(['ok'=>true, 'id'=>$stmt->insert_id]);
  exit;
}

// Allow editing a pending reservation's details
if ($action === 'updateReservation' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  $start_date = trim($data['startDate'] ?? ($data['date'] ?? ''));
  $end_date = trim($data['endDate'] ?? $start_date);
  $time = trim($data['time'] ?? '');
  $quantity = intval($data['quantity'] ?? 0);
  $purpose = trim($data['purpose'] ?? '');
  $duration_days = intval($data['durationDays'] ?? 0);

  if ($id <= 0 || $start_date === '' || $end_date === '' || $time === '' || $quantity <= 0 || $purpose === '') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Invalid fields']);
    exit;
  }

  // Fetch reservation and ensure still pending
  $res = $db->prepare('SELECT status FROM reservations WHERE id=?');
  $res->bind_param('i', $id);
  $res->execute();
  $res->bind_result($oldStatus);
  if (!$res->fetch()) {
    http_response_code(404);
    echo json_encode(['ok'=>false,'error'=>'Reservation not found']);
    exit;
  }
  $res->close();

  if ($oldStatus !== 'Pending') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Only pending reservations can be edited']);
    exit;
  }

  // Validate date range
  $startDateObj = new DateTime($start_date);
  $endDateObj = new DateTime($end_date);
  if ($endDateObj < $startDateObj) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'End Date cannot be earlier than Start Date']);
    exit;
  }

  if ($duration_days <= 0) {
    $duration_days = $startDateObj->diff($endDateObj)->days + 1;
  }

  // Check each day in range for NSTP blocked Saturdays
  $rangeDate = clone $startDateObj;
  while ($rangeDate <= $endDateObj) {
    $rangeStr = $rangeDate->format('Y-m-d');
    if (is_saturday_blocked($rangeStr)) {
      http_response_code(400);
      echo json_encode(['ok'=>false,'error'=>'Reservations on Saturdays are not allowed due to NSTP activities.']);
      exit;
    }
    $rangeDate->modify('+1 day');
  }

  $stmt = $db->prepare('UPDATE reservations SET date=?, start_date=?, end_date=?, duration_days=?, time=?, quantity=?, purpose=? WHERE id=?');
  $legacy_date = $start_date;
  $stmt->bind_param('sssisssi', $legacy_date, $start_date, $end_date, $duration_days, $time, $quantity, $purpose, $id);
  $stmt->execute();
  echo json_encode(['ok'=>true]);
  exit;
}

if ($action === 'listAdminReservations' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $res = $db->query('SELECT r.id, f.fullname AS faculty, f.username AS facultyUsername, e.name AS equipment, c.name AS category, r.date, r.start_date, r.end_date, r.duration_days, r.time, r.quantity, r.status, r.cancel_reason, r.decline_reason FROM reservations r JOIN faculty f ON f.id=r.faculty_id JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id ORDER BY r.id DESC');
  $out = [];
  while ($row = $res->fetch_assoc()) { $out[] = $row; }
  echo json_encode($out);
  exit;
}

if ($action === 'updateReservationStatus' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  $status = $data['status'] ?? 'Pending';
  $reason = trim($data['reason'] ?? '');
  if (!in_array($status, ['Approved','Declined','Pending','Cancelled','Cancellation Requested'])) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid status']); exit; }

  // Fetch reservation
  $res = $db->prepare('SELECT equipment_id, quantity, status FROM reservations WHERE id=?');
  $res->bind_param('i', $id);
  $res->execute();
  $res->bind_result($eqId, $qty, $oldStatus);
  if (!$res->fetch()) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Reservation not found']); exit; }
  $res->close();

  // Adjust availability if status changes
  // Note: Quantity is already deducted when reservation is submitted (status=Pending)
  // So we only need to restore if declining or cancelling (whether Pending or Approved)
  // Do NOT restore when requesting cancellation - only when it's approved/declined
  if ($status === 'Declined' || $status === 'Cancelled') {
    // Restore quantity back to available
    $stmt = $db->prepare('UPDATE equipment SET available = available + ? WHERE id = ?');
    $stmt->bind_param('ii', $qty, $eqId);
    $stmt->execute();
    $stmt->close();
  }
  // If approving, quantity was already deducted when reservation was submitted, so no change needed
  // If requesting cancellation, keep quantity reserved until approved

  // Update status and reason
  if ($status === 'Cancelled') {
    $stmt = $db->prepare('UPDATE reservations SET status=?, cancel_reason=? WHERE id=?');
    $stmt->bind_param('ssi', $status, $reason, $id);
  } else if ($status === 'Cancellation Requested') {
    $stmt = $db->prepare('UPDATE reservations SET status=?, cancel_reason=? WHERE id=?');
    $stmt->bind_param('ssi', $status, $reason, $id);
  } else if ($status === 'Declined') {
    $stmt = $db->prepare('UPDATE reservations SET status=?, decline_reason=? WHERE id=?');
    $stmt->bind_param('ssi', $status, $reason, $id);
  } else {
    $stmt = $db->prepare('UPDATE reservations SET status=? WHERE id=?');
    $stmt->bind_param('si', $status, $id);
  }
  $stmt->execute();
  $stmt->close();
  echo json_encode(['ok'=>true]);
  exit;
}

if ($action === 'createReport' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $r = json_input();
  $username = $r['facultyUsername'] ?? '';
  $equipment = $r['equipment'] ?? '';
  $description = $r['description'] ?? '';
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Faculty not found']); exit; }
  $stmt->close();
  $stmt = $db->prepare('INSERT INTO reports (faculty_id, equipment_name, description) VALUES (?,?,?)');
  $stmt->bind_param('iss', $fid, $equipment, $description);
  $stmt->execute();
  echo json_encode(['ok'=>true, 'id'=>$stmt->insert_id]);
  exit;
}

if ($action === 'adminStats' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $pending = $db->query("SELECT COUNT(*) c FROM reservations WHERE status='Pending'")->fetch_assoc()['c'];
  $faculty = $db->query('SELECT COUNT(*) c FROM faculty')->fetch_assoc()['c'];
  $activeReports = $db->query("SELECT COUNT(*) c FROM reports WHERE status='Pending'")->fetch_assoc()['c'];
  // Sum of available equipment quantities (items currently available for reservation)
  $availableEquipment = $db->query('SELECT COALESCE(SUM(available),0) c FROM equipment')->fetch_assoc()['c'];
  echo json_encode([ 'pendingCount'=>intval($pending), 'totalFaculty'=>intval($faculty), 'activeReports'=>intval($activeReports), 'availableEquipment'=>intval($availableEquipment) ]);
  exit;
}

// GenServe stats (approved reservations, available equipment, active reports)
if ($action === 'genserveStats' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $approvedReservations = $db->query("SELECT COUNT(*) c FROM reservations WHERE status='Approved'")->fetch_assoc()['c'];
  $activeReports = $db->query("SELECT COUNT(*) c FROM reports WHERE status='Pending'")->fetch_assoc()['c'];
  $availableEquipment = $db->query('SELECT COALESCE(SUM(available),0) c FROM equipment')->fetch_assoc()['c'];
  echo json_encode([ 'approvedReservations'=>intval($approvedReservations), 'activeReports'=>intval($activeReports), 'availableEquipment'=>intval($availableEquipment) ]);
  exit;
}

// Get reservations for GenServe (Pending for approval, and Approved for viewing)
if ($action === 'listGenServeReservations' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $res = $db->query("SELECT r.id, f.fullname AS faculty, f.username AS facultyUsername, e.name AS equipment, c.name AS category, r.date, r.start_date, r.end_date, r.duration_days, r.time, r.quantity, r.purpose, r.status, r.cancel_reason, r.decline_reason, r.created_at AS createdAt FROM reservations r JOIN faculty f ON f.id=r.faculty_id JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id ORDER BY r.id DESC");
  $out = [];
  while ($row = $res->fetch_assoc()) {
    // Ensure correct field mapping
    $out[] = [
      'id' => $row['id'],
      'faculty' => $row['faculty'] ?? '',
      'facultyUsername' => $row['facultyUsername'] ?? '',
      'equipment' => $row['equipment'] ?? '',
      'category' => $row['category'] ?? '',
      'date' => $row['date'] ?? '',
      'startDate' => $row['start_date'] ?? $row['date'],
      'endDate' => $row['end_date'] ?? $row['date'],
      'durationDays' => intval($row['duration_days'] ?? 1),
      'time' => $row['time'] ?? '',
      'quantity' => intval($row['quantity'] ?? 0),
      'purpose' => $row['purpose'] ?? '',
      'status' => $row['status'] ?? '',
      'cancel_reason' => $row['cancel_reason'] ?? '',
      'decline_reason' => $row['decline_reason'] ?? ''
    ];
  }
  echo json_encode($out);
  exit;
}

// Get monthly reservation analytics for GenServe
if ($action === 'getMonthlyReservationAnalytics' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  // Get all approved reservations with detailed information
  $res = $db->query("SELECT 
    DATE_FORMAT(r.created_at, '%Y-%m') AS month,
    DATE_FORMAT(COALESCE(r.start_date, r.date), '%Y-%m-%d') AS reservation_date,
    e.name AS equipment,
    c.name AS category,
    f.fullname AS faculty_name,
    r.quantity,
    r.purpose,
    r.time,
    r.id AS reservation_id
    FROM reservations r 
    JOIN faculty f ON f.id=r.faculty_id 
    JOIN equipment e ON e.id=r.equipment_id 
    JOIN equipment_categories c ON c.id=r.category_id 
    WHERE r.status='Approved' 
    ORDER BY r.created_at DESC, e.name ASC");
  
  $monthlyData = [];
  $equipmentData = [];
  $categoryData = [];
  $equipmentTrends = [];
  
  while ($row = $res->fetch_assoc()) {
    $month = $row['month'];
    $equipment = $row['equipment'];
    $category = $row['category'];
    $quantity = intval($row['quantity']);
    $reservationDate = $row['reservation_date'];
    $facultyName = $row['faculty_name'];
    $purpose = $row['purpose'];
    $time = $row['time'];
    $reservationId = $row['reservation_id'];
    
    // Monthly totals
    if (!isset($monthlyData[$month])) {
      $monthlyData[$month] = 0;
    }
    $monthlyData[$month] += $quantity;
    
    // Equipment trends (for graph)
    if (!isset($equipmentTrends[$equipment])) {
      $equipmentTrends[$equipment] = [];
    }
    if (!isset($equipmentTrends[$equipment][$month])) {
      $equipmentTrends[$equipment][$month] = 0;
    }
    $equipmentTrends[$equipment][$month] += $quantity;
    
    // Equipment details by month
    if (!isset($equipmentData[$month])) {
      $equipmentData[$month] = [];
    }
    if (!isset($equipmentData[$month][$equipment])) {
      $equipmentData[$month][$equipment] = [
        'equipment' => $equipment,
        'category' => $category,
        'total_quantity' => 0,
        'reservation_count' => 0,
        'details' => []
      ];
    }
    $equipmentData[$month][$equipment]['total_quantity'] += $quantity;
    $equipmentData[$month][$equipment]['reservation_count'] += 1;
    $equipmentData[$month][$equipment]['details'][] = [
      'faculty' => $facultyName,
      'quantity' => $quantity,
      'date' => $reservationDate,
      'time' => $time,
      'purpose' => $purpose,
      'id' => $reservationId
    ];
    
    // Category data
    if (!isset($categoryData[$category])) {
      $categoryData[$category] = [];
    }
    if (!isset($categoryData[$category][$month])) {
      $categoryData[$category][$month] = [
        'total_quantity' => 0,
        'reservation_count' => 0,
        'items' => []
      ];
    }
    $categoryData[$category][$month]['total_quantity'] += $quantity;
    $categoryData[$category][$month]['reservation_count'] += 1;
    
    if (!isset($categoryData[$category][$month]['items'][$equipment])) {
      $categoryData[$category][$month]['items'][$equipment] = [
        'equipment' => $equipment,
        'total_quantity' => 0,
        'reservation_count' => 0,
        'reservations' => []
      ];
    }
    $categoryData[$category][$month]['items'][$equipment]['total_quantity'] += $quantity;
    $categoryData[$category][$month]['items'][$equipment]['reservation_count'] += 1;
    $categoryData[$category][$month]['items'][$equipment]['reservations'][] = [
      'faculty' => $facultyName,
      'quantity' => $quantity,
      'date' => $reservationDate,
      'time' => $time,
      'purpose' => $purpose
    ];
  }
  
  echo json_encode([
    'monthlyTotals' => $monthlyData,
    'equipmentDetails' => $equipmentData,
    'categoryData' => $categoryData,
    'equipmentTrends' => $equipmentTrends
  ]);
  exit;
}

// Get monthly gym reservation analytics
if ($action === 'getMonthlyGymAnalytics' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  // Get current year
  $currentYear = date('Y');
  
  // Get all approved gym reservations - use reservation date, not created_at
  $res = $db->query("SELECT 
    DATE_FORMAT(gr.date, '%Y-%m') AS month,
    DATE_FORMAT(gr.date, '%Y-%m-%d') AS reservation_date,
    gr.title,
    gr.time,
    gr.equipment_items,
    f.fullname AS faculty_name,
    gr.id AS reservation_id
    FROM gym_reservations gr 
    JOIN faculty f ON f.id=gr.faculty_id 
    WHERE gr.status='Approved' 
    AND YEAR(gr.date) = $currentYear
    ORDER BY gr.date DESC");
  
  // Initialize all months for current year with 0
  $monthlyData = [];
  for ($i = 1; $i <= 12; $i++) {
    $monthKey = sprintf('%d-%02d', $currentYear, $i);
    $monthlyData[$monthKey] = 0;
  }
  
  $categoryData = [];
  
  while ($row = $res->fetch_assoc()) {
    $month = $row['month'];
    $equipmentItems = json_decode($row['equipment_items'], true);
    
    // Count total equipment pieces in this reservation
    $totalQuantity = 0;
    $categories = [];
    if (is_array($equipmentItems)) {
      foreach ($equipmentItems as $item) {
        $totalQuantity += intval($item['quantity'] ?? 0);
        if (isset($item['category'])) {
          $categories[] = $item['category'];
        }
      }
    }
    
    // Monthly totals - count reservations
    if (isset($monthlyData[$month])) {
      $monthlyData[$month] += 1;
    } else {
      $monthlyData[$month] = 1;
    }
    
    // Category data
    foreach ($categories as $category) {
      if (!isset($categoryData[$category])) {
        $categoryData[$category] = [];
      }
      if (!isset($categoryData[$category][$month])) {
        $categoryData[$category][$month] = [
          'reservation_count' => 0,
          'total_quantity' => 0
        ];
      }
      $categoryData[$category][$month]['reservation_count'] += 1;
      $categoryData[$category][$month]['total_quantity'] += $totalQuantity;
    }
  }
  
  echo json_encode([
    'monthlyTotals' => $monthlyData,
    'categoryData' => $categoryData,
    'year' => $currentYear
  ]);
  exit;
}

// Get gym analytics (reservations, returns, cancellations combined)
if ($action === 'getGymCombinedAnalytics' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $currentYear = date('Y');
  
  $reservationData = [];
  $returnData = [];
  $cancellationData = [];
  
  // Initialize all months
  for ($i = 1; $i <= 12; $i++) {
    $monthKey = sprintf('%d-%02d', $currentYear, $i);
    $reservationData[$monthKey] = 0;
    $returnData[$monthKey] = 0;
    $cancellationData[$monthKey] = 0;
  }
  
  // Get all approved gym reservations
  $res = $db->query("SELECT 
    DATE_FORMAT(gr.date, '%Y-%m') AS month,
    COUNT(*) AS reservation_count
    FROM gym_reservations gr 
    WHERE gr.status='Approved' 
    AND YEAR(gr.date) = $currentYear
    GROUP BY month
    ORDER BY month");
  
  while ($row = $res->fetch_assoc()) {
    $month = $row['month'];
    $count = intval($row['reservation_count']);
    if (isset($reservationData[$month])) {
      $reservationData[$month] = $count;
    }
  }
  
  // Get all cleared gym returns
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  if ($hasReturnStatus) {
    $res = $db->query("SELECT 
      DATE_FORMAT(gr.return_cleared_at, '%Y-%m') AS month,
      COUNT(*) AS return_count
      FROM gym_reservations gr 
      WHERE gr.return_status='Cleared' 
      AND YEAR(gr.return_cleared_at) = $currentYear
      GROUP BY month
      ORDER BY month");
    
    while ($row = $res->fetch_assoc()) {
      $month = $row['month'];
      $count = intval($row['return_count']);
      if (isset($returnData[$month])) {
        $returnData[$month] = $count;
      }
    }
  }
  
  // Get all cancelled gym reservations
  $res = $db->query("SELECT 
    DATE_FORMAT(gr.created_at, '%Y-%m') AS month,
    COUNT(*) AS cancellation_count
    FROM gym_reservations gr 
    WHERE gr.status='Cancelled' 
    AND YEAR(gr.created_at) = $currentYear
    GROUP BY month
    ORDER BY month");
  
  while ($row = $res->fetch_assoc()) {
    $month = $row['month'];
    $count = intval($row['cancellation_count']);
    if (isset($cancellationData[$month])) {
      $cancellationData[$month] = $count;
    }
  }
  
  echo json_encode([
    'reservationData' => $reservationData,
    'returnData' => $returnData,
    'cancellationData' => $cancellationData,
    'year' => $currentYear
  ]);
  exit;
}

// Get equipment returns by category (for pie chart)
if ($action === 'getEquipmentReturnsByCategory' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $currentYear = date('Y');
  
  $categoryData = [];
  
  // Get all cleared equipment returns with category breakdown
  $res = $db->query("SELECT 
    c.name AS category,
    COUNT(*) AS return_count
    FROM reservations r 
    JOIN equipment e ON e.id=r.equipment_id 
    JOIN equipment_categories c ON c.id=r.category_id 
    WHERE r.return_status='Cleared' 
    AND YEAR(r.return_cleared_at) = $currentYear
    GROUP BY category
    ORDER BY return_count DESC");
  
  while ($row = $res->fetch_assoc()) {
    $category = $row['category'];
    $count = intval($row['return_count']);
    $categoryData[$category] = $count;
  }
  
  echo json_encode([
    'categoryData' => $categoryData,
    'year' => $currentYear
  ]);
  exit;
}

// Get equipment cancellations by category (for pie chart)
if ($action === 'getEquipmentCancellationsByCategory' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $currentYear = date('Y');
  
  $categoryData = [];
  
  // Get all cancelled equipment reservations with category breakdown
  $res = $db->query("SELECT 
    c.name AS category,
    COUNT(*) AS cancellation_count
    FROM reservations r 
    JOIN equipment e ON e.id=r.equipment_id 
    JOIN equipment_categories c ON c.id=r.category_id 
    WHERE r.status='Cancelled' 
    AND YEAR(r.created_at) = $currentYear
    GROUP BY category
    ORDER BY cancellation_count DESC");
  
  while ($row = $res->fetch_assoc()) {
    $category = $row['category'];
    $count = intval($row['cancellation_count']);
    $categoryData[$category] = $count;
  }
  
  echo json_encode([
    'categoryData' => $categoryData,
    'year' => $currentYear
  ]);
  exit;
}

// Fetch reservations by faculty username
if ($action === 'listFacultyReservations' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $username = $_GET['username'] ?? '';
  if ($username === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Username required']);
    exit;
  }
  
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) {
    echo json_encode([]);
    exit;
  }
  $stmt->close();
  
  $stmt = $db->prepare('SELECT r.id, e.name AS equipment, c.name AS category, r.date, r.start_date, r.end_date, r.duration_days, r.time, r.quantity, r.purpose, r.status, r.cancel_reason, r.decline_reason, r.return_status AS returnStatus, r.created_at AS createdAt FROM reservations r JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id WHERE r.faculty_id=? ORDER BY r.id DESC');
  $stmt->bind_param('i', $fid);
  $stmt->execute();
  $result = $stmt->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) {
    $row['startDate'] = $row['start_date'] ?? $row['date'];
    $row['endDate'] = $row['end_date'] ?? $row['date'];
    $row['durationDays'] = intval($row['duration_days'] ?? 1);
    $out[] = $row;
  }
  echo json_encode($out);
  exit;
}

// Fetch reports by faculty username
if ($action === 'listFacultyReports' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $username = $_GET['username'] ?? '';
  if ($username === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Username required']);
    exit;
  }
  
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) {
    echo json_encode([]);
    exit;
  }
  $stmt->close();
  
  $stmt = $db->prepare('SELECT id, equipment_name AS equipment, description, status, created_at AS createdAt FROM reports WHERE faculty_id=? ORDER BY id DESC');
  $stmt->bind_param('i', $fid);
  $stmt->execute();
  $result = $stmt->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) {
    $out[] = $row;
  }
  echo json_encode($out);
  exit;
}

if ($action === 'listAdmins' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  ensure_admin_exists($db);
  $res = $db->query('SELECT id, fullname, email FROM admins ORDER BY fullname ASC');
  $out = [];
  while ($row = $res->fetch_assoc()) {
    $out[] = [
      'id' => intval($row['id']),
      'fullname' => $row['fullname'] ?? 'Administrator',
      'email' => $row['email'] ?? ''
    ];
  }
  echo json_encode($out);
  exit;
}

if ($action === 'listFacultyContacts' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $res = $db->query('SELECT id, fullname, email FROM faculty ORDER BY fullname ASC');
  $out = [];
  while ($row = $res->fetch_assoc()) {
    $out[] = [
      'id' => intval($row['id']),
      'fullname' => $row['fullname'] ?? 'Faculty Member',
      'email' => $row['email'] ?? ''
    ];
  }
  echo json_encode($out);
  exit;
}

// Fetch all faculty accounts for admin (with username)
if ($action === 'listAllFaculty' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $res = $db->query('SELECT id, username, fullname, email FROM faculty ORDER BY fullname ASC');
  $out = [];
  while ($row = $res->fetch_assoc()) {
    $out[] = [
      'id' => intval($row['id']),
      'username' => $row['username'] ?? '',
      'fullname' => $row['fullname'] ?? 'Faculty Member',
      'email' => $row['email'] ?? ''
    ];
  }
  echo json_encode($out);
  exit;
}

// Fetch all reports for admin
if ($action === 'listAdminReports' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $res = $db->query('SELECT r.id, COALESCE(f.fullname, "Unknown") AS faculty, r.equipment_name AS equipment, r.description, r.status, r.created_at AS createdAt FROM reports r LEFT JOIN faculty f ON f.id=r.faculty_id ORDER BY r.id DESC');
  $out = [];
  while ($row = $res->fetch_assoc()) {
    $out[] = $row;
  }
  echo json_encode($out);
  exit;
}

// Add audit log
if ($action === 'addAuditLog' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $actor_type = $data['actor_type'] ?? 'System';
  $actor_name = $data['actor_name'] ?? 'System';
  $action_text = $data['action'] ?? '';
  
  if ($action_text === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Action required']);
    exit;
  }
  
  if (!in_array($actor_type, ['Admin', 'Faculty', 'System'])) {
    $actor_type = 'System';
  }
  
  $stmt = $db->prepare('INSERT INTO audit_logs (actor_type, actor_name, action) VALUES (?,?,?)');
  $stmt->bind_param('sss', $actor_type, $actor_name, $action_text);
  $stmt->execute();
  echo json_encode(['ok' => true, 'id' => $stmt->insert_id]);
  exit;
}

// Fetch all audit logs for admin
if ($action === 'listAuditLogs' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 1000;
  $stmt = $db->prepare('SELECT actor_type, actor_name, action, created_at FROM audit_logs ORDER BY id DESC LIMIT ?');
  $stmt->bind_param('i', $limit);
  $stmt->execute();
  $result = $stmt->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) {
    $out[] = [
      'type' => $row['actor_type'],
      'user' => $row['actor_name'],
      'action' => $row['action'],
      'datetime' => $row['created_at']
    ];
  }
  echo json_encode($out);
  exit;
}

// Update report status
if ($action === 'updateReportStatus' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  $status = $data['status'] ?? 'Pending';
  if (!in_array($status, ['Pending','Fixed'])) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Invalid status']);
    exit;
  }
  
  $stmt = $db->prepare('UPDATE reports SET status=? WHERE id=?');
  $stmt->bind_param('si', $status, $id);
  $stmt->execute();
  echo json_encode(['ok'=>true]);
  exit;
}

// ====== CHAT / MESSAGING ENDPOINTS (ROLE-BASED) ======
function ensure_chat_messages_table($db) {
  $db->query("CREATE TABLE IF NOT EXISTS chat_messages (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    sender_role ENUM('genserve','faculty','admin') NOT NULL,
    receiver_id INT NOT NULL,
    receiver_role ENUM('genserve','faculty','admin') NOT NULL,
    message_content TEXT NOT NULL,
    `timestamp` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    INDEX idx_sender (sender_role, sender_id),
    INDEX idx_receiver (receiver_role, receiver_id),
    INDEX idx_pair (sender_role, sender_id, receiver_role, receiver_id, `timestamp`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function chat_user_exists($db, $role, $id) {
  if ($id <= 0) return false;
  switch ($role) {
    case 'admin':
      $table = 'admins';
      break;
    case 'faculty':
      $table = 'faculty';
      break;
    case 'genserve':
      $table = 'genserve';
      break;
    default:
      return false;
  }
  $stmt = $db->prepare("SELECT id FROM {$table} WHERE id=? LIMIT 1");
  $stmt->bind_param('i', $id);
  $stmt->execute();
  $stmt->store_result();
  $exists = $stmt->num_rows > 0;
  $stmt->close();
  return $exists;
}

function chat_pair_allowed($roleA, $roleB) {
  $validRoles = ['admin','faculty','genserve'];
  if (!in_array($roleA, $validRoles, true) || !in_array($roleB, $validRoles, true)) {
    return false;
  }
  $pair = [$roleA, $roleB];
  sort($pair);
  $allowedPairs = [
    'admin_faculty',
    'admin_genserve',
    'faculty_genserve'
  ];
  return in_array(implode('_', $pair), $allowedPairs, true);
}

function chat_contact_defaults($role) {
  switch ($role) {
    case 'admin': return ['name' => 'System Administrator', 'email' => ''];
    case 'faculty': return ['name' => 'Faculty Member', 'email' => ''];
    case 'genserve': return ['name' => 'GenServe Team', 'email' => ''];
    default: return ['name' => 'User', 'email' => ''];
  }
}

function chat_fetch_role_contacts($db, $role) {
  $contacts = [];
  switch ($role) {
    case 'admin':
      // Exclude Super Administrator from admin contacts
      $result = $db->query("SELECT id, fullname, email FROM admins WHERE username != 'superadmin' ORDER BY fullname ASC");
      break;
    case 'faculty':
      $result = $db->query('SELECT id, fullname, email FROM faculty ORDER BY fullname ASC');
      break;
    case 'genserve':
      $result = $db->query('SELECT id, fullname, email FROM genserve ORDER BY fullname ASC');
      break;
    default:
      return $contacts;
  }
  if ($result instanceof mysqli_result) {
    while ($row = $result->fetch_assoc()) {
      $defaults = chat_contact_defaults($role);
      $contacts[] = [
        'contactRole' => $role,
        'contactId' => intval($row['id']),
        'name' => $row['fullname'] ? $row['fullname'] : $defaults['name'],
        'email' => $row['email'] ?? $defaults['email']
      ];
    }
    $result->free();
  }
  return $contacts;
}

function chat_contact_candidates($db, $viewerRole) {
  $candidates = [];
  if ($viewerRole === 'admin') {
    $candidates = array_merge(
      chat_fetch_role_contacts($db, 'faculty'),
      chat_fetch_role_contacts($db, 'genserve')
    );
  } elseif ($viewerRole === 'faculty') {
    $candidates = array_merge(
      chat_fetch_role_contacts($db, 'admin'),
      chat_fetch_role_contacts($db, 'genserve')
    );
  } elseif ($viewerRole === 'genserve') {
    $candidates = array_merge(
      chat_fetch_role_contacts($db, 'admin'),
      chat_fetch_role_contacts($db, 'faculty')
    );
  }
  return $candidates;
}

function chat_thread_meta($db, $viewerRole, $viewerId, $contactRole, $contactId) {
  $meta = [
    'lastMessage' => null,
    'lastMessageAt' => null,
    'unreadCount' => 0,
    'hasHistory' => false
  ];

  $stmt = $db->prepare("SELECT sender_role, message_content, `timestamp`
    FROM chat_messages
    WHERE (sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=?)
       OR (sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=?)
    ORDER BY `timestamp` DESC, id DESC LIMIT 1");
  $stmt->bind_param(
    'sisisisi',
    $viewerRole, $viewerId, $contactRole, $contactId,
    $contactRole, $contactId, $viewerRole, $viewerId
  );
  $stmt->execute();
  $res = $stmt->get_result();
  if ($row = $res->fetch_assoc()) {
    $meta['lastMessage'] = [
      'text' => $row['message_content'],
      'senderRole' => $row['sender_role']
    ];
    $meta['lastMessageAt'] = $row['timestamp'];
    $meta['hasHistory'] = true;
  }
  $stmt->close();

  $stmt = $db->prepare("SELECT COUNT(*) AS unread_total
    FROM chat_messages
    WHERE sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=? AND is_read=0");
  $stmt->bind_param('sisi', $contactRole, $contactId, $viewerRole, $viewerId);
  $stmt->execute();
  $stmt->bind_result($unreadCount);
  if ($stmt->fetch()) {
    $meta['unreadCount'] = intval($unreadCount ?? 0);
  }
  $stmt->close();

  return $meta;
}

function chat_fetch_history($db, $roleA, $idA, $roleB, $idB) {
  $stmt = $db->prepare("SELECT id, sender_id, sender_role, receiver_id, receiver_role, message_content, `timestamp`, is_read
    FROM chat_messages
    WHERE (sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=?)
       OR (sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=?)
    ORDER BY `timestamp` ASC, id ASC");
  $stmt->bind_param(
    'sisisisi',
    $roleA, $idA, $roleB, $idB,
    $roleB, $idB, $roleA, $idA
  );
  $stmt->execute();
  $res = $stmt->get_result();
  $messages = [];
  while ($row = $res->fetch_assoc()) {
    $messages[] = [
      'id' => intval($row['id']),
      'senderId' => intval($row['sender_id']),
      'senderRole' => $row['sender_role'],
      'receiverId' => intval($row['receiver_id']),
      'receiverRole' => $row['receiver_role'],
      'message' => $row['message_content'],
      'timestamp' => $row['timestamp'],
      'isRead' => intval($row['is_read']) === 1
    ];
  }
  $stmt->close();
  return $messages;
}

if ($action === 'listChatContacts' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  ensure_chat_messages_table($db);
  ensure_admin_exists($db);
  ensure_genserve_exists($db);
  $userRole = $_GET['userRole'] ?? '';
  $userId = intval($_GET['userId'] ?? 0);
  if (!in_array($userRole, ['admin','faculty','genserve'], true) || $userId <= 0) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Invalid user context']);
    exit;
  }
  if (!chat_user_exists($db, $userRole, $userId)) {
    http_response_code(404);
    echo json_encode(['ok'=>false,'error'=>'User not found']);
    exit;
  }

  $contacts = [];
  foreach (chat_contact_candidates($db, $userRole) as $contact) {
    if (!chat_pair_allowed($userRole, $contact['contactRole'])) {
      continue;
    }
    $meta = chat_thread_meta($db, $userRole, $userId, $contact['contactRole'], $contact['contactId']);
    $contacts[] = array_merge($contact, $meta);
  }

  usort($contacts, function($a, $b) {
    $timeA = $a['lastMessageAt'] ?? '';
    $timeB = $b['lastMessageAt'] ?? '';
    if ($timeA === $timeB) {
      return strcmp(strtolower($a['name']), strtolower($b['name']));
    }
    return strcmp($timeB, $timeA);
  });

  echo json_encode(['ok'=>true,'contacts'=>$contacts]);
  exit;
}

if ($action === 'getChatHistory' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  ensure_chat_messages_table($db);
  $userRole = $_GET['userRole'] ?? '';
  $userId = intval($_GET['userId'] ?? 0);
  $withRole = $_GET['withRole'] ?? '';
  $withId = intval($_GET['withId'] ?? 0);

  if ($userId<=0 || $withId<=0 || !chat_pair_allowed($userRole, $withRole)) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Invalid chat participants']);
    exit;
  }
  if (!chat_user_exists($db, $userRole, $userId) || !chat_user_exists($db, $withRole, $withId)) {
    http_response_code(404);
    echo json_encode(['ok'=>false,'error'=>'User not found']);
    exit;
  }

  $messages = chat_fetch_history($db, $userRole, $userId, $withRole, $withId);
  echo json_encode(['ok'=>true,'messages'=>$messages]);
  exit;
}

if ($action === 'sendChatMessage' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  ensure_chat_messages_table($db);
  $data = json_input();
  $senderRole = $data['senderRole'] ?? '';
  $senderId = intval($data['senderId'] ?? 0);
  $receiverRole = $data['receiverRole'] ?? '';
  $receiverId = intval($data['receiverId'] ?? 0);
  $message = trim($data['message'] ?? '');

  if ($senderId<=0 || $receiverId<=0 || $message==='') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Missing fields']);
    exit;
  }
  if (!chat_pair_allowed($senderRole, $receiverRole)) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'Interaction not allowed']);
    exit;
  }
  if (!chat_user_exists($db, $senderRole, $senderId) || !chat_user_exists($db, $receiverRole, $receiverId)) {
    http_response_code(404);
    echo json_encode(['ok'=>false,'error'=>'User not found']);
    exit;
  }

  $stmt = $db->prepare('INSERT INTO chat_messages (sender_id, sender_role, receiver_id, receiver_role, message_content) VALUES (?,?,?,?,?)');
  $stmt->bind_param('isiss', $senderId, $senderRole, $receiverId, $receiverRole, $message);
  $stmt->execute();
  $insertId = $stmt->insert_id;
  $stmt->close();

  echo json_encode(['ok'=>true,'id'=>$insertId]);
  exit;
}

if ($action === 'markChatRead' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  ensure_chat_messages_table($db);
  $data = json_input();
  $userRole = $data['userRole'] ?? '';
  $userId = intval($data['userId'] ?? 0);
  $withRole = $data['withRole'] ?? '';
  $withId = intval($data['withId'] ?? 0);

  if ($userId<=0 || $withId<=0 || !chat_pair_allowed($userRole, $withRole)) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Invalid payload']);
    exit;
  }

  $stmt = $db->prepare("UPDATE chat_messages SET is_read=1
    WHERE sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=? AND is_read=0");
  $stmt->bind_param('sisi', $withRole, $withId, $userRole, $userId);
  $stmt->execute();
  $affected = $stmt->affected_rows;
  $stmt->close();

  echo json_encode(['ok'=>true,'updated'=>$affected]);
  exit;
}

// Delete conversation (all messages between two users)
if ($action === 'deleteConversation' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  ensure_chat_messages_table($db);
  $data = json_input();
  $userRole = $data['userRole'] ?? '';
  $userId = intval($data['userId'] ?? 0);
  $withRole = $data['withRole'] ?? '';
  $withId = intval($data['withId'] ?? 0);

  if ($userId<=0 || $withId<=0 || !chat_pair_allowed($userRole, $withRole)) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Invalid payload']);
    exit;
  }

  // Delete all messages between these two users (bidirectional)
  $stmt = $db->prepare("DELETE FROM chat_messages
    WHERE ((sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=?)
       OR (sender_role=? AND sender_id=? AND receiver_role=? AND receiver_id=?))");
  $stmt->bind_param(
    'sisisisi',
    $userRole, $userId, $withRole, $withId,
    $withRole, $withId, $userRole, $userId
  );
  $stmt->execute();
  $affected = $stmt->affected_rows;
  $stmt->close();

  echo json_encode(['ok'=>true,'deleted'=>$affected]);
  exit;
}

// Initiate return request by faculty
if ($action === 'initiateReturn' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $reservationId = intval($data['reservationId'] ?? 0);
  
  if ($reservationId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid reservation ID']);
    exit;
  }
  
  // Check if reservation exists and is approved
  $stmt = $db->prepare('SELECT r.id, r.status, r.return_status, f.fullname AS faculty_name, f.username AS faculty_username, e.name AS equipment, r.quantity FROM reservations r JOIN faculty f ON f.id=r.faculty_id JOIN equipment e ON e.id=r.equipment_id WHERE r.id=?');
  $stmt->bind_param('i', $reservationId);
  $stmt->execute();
  $result = $stmt->get_result();
  $reservation = $result->fetch_assoc();
  $stmt->close();
  
  if (!$reservation) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Reservation not found']);
    exit;
  }
  
  if ($reservation['status'] !== 'Approved') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Only approved reservations can be returned']);
    exit;
  }
  
  if ($reservation['return_status'] === 'Pending' || $reservation['return_status'] === 'Cleared') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Return already requested or cleared']);
    exit;
  }
  
  // Update reservation return status
  $stmt = $db->prepare('UPDATE reservations SET return_status=?, return_requested_at=NOW() WHERE id=?');
  $returnStatus = 'Pending';
  $stmt->bind_param('si', $returnStatus, $reservationId);
  $stmt->execute();
  $stmt->close();
  
  // Create notification for GenServe (store in localStorage via client-side)
  // We'll handle this in the JavaScript
  
  echo json_encode(['ok' => true, 'message' => 'Return request submitted successfully']);
  exit;
}

// Initiate gym return request by faculty
if ($action === 'initiateGymReturn' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $reservationId = intval($data['reservationId'] ?? 0);
  
  if ($reservationId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid reservation ID']);
    exit;
  }
  
  // Check if gym_reservations has return_status column
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  if (!$hasReturnStatus) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Gym return feature is not available yet. Please contact administrator.']);
    exit;
  }
  
  // Check if gym reservation exists and is approved
  $stmt = $db->prepare('SELECT gr.id, gr.status, gr.return_status, f.fullname AS faculty_name, f.username AS faculty_username, gr.title FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE gr.id=?');
  $stmt->bind_param('i', $reservationId);
  $stmt->execute();
  $result = $stmt->get_result();
  $reservation = $result->fetch_assoc();
  $stmt->close();
  
  if (!$reservation) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Gym reservation not found']);
    exit;
  }
  
  if ($reservation['status'] !== 'Approved') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Only approved gym reservations can be returned']);
    exit;
  }
  
  if ($reservation['return_status'] === 'Pending' || $reservation['return_status'] === 'Cleared') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Return already requested or cleared']);
    exit;
  }
  
  // Update gym reservation return status
  $stmt = $db->prepare('UPDATE gym_reservations SET return_status=?, return_requested_at=NOW() WHERE id=?');
  $returnStatus = 'Pending';
  $stmt->bind_param('si', $returnStatus, $reservationId);
  $stmt->execute();
  $stmt->close();
  
  echo json_encode(['ok' => true, 'message' => 'Gym return request submitted successfully']);
  exit;
}

// List pending returns for GenServe
if ($action === 'listPendingReturns' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $stmt = $db->prepare('SELECT r.id, f.fullname AS faculty, f.username AS facultyUsername, e.name AS equipment, c.name AS category, r.date, r.time, r.quantity, r.purpose, r.return_requested_at AS returnRequestedAt FROM reservations r JOIN faculty f ON f.id=r.faculty_id JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id WHERE r.status=? AND r.return_status=? ORDER BY r.return_requested_at DESC');
  $status = 'Approved';
  $returnStatus = 'Pending';
  $stmt->bind_param('ss', $status, $returnStatus);
  $stmt->execute();
  $result = $stmt->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) {
    $out[] = $row;
  }
  $stmt->close();
  echo json_encode($out);
  exit;
}

// Clear return by GenServe
if ($action === 'clearReturn' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $reservationId = intval($data['reservationId'] ?? 0);
  
  if ($reservationId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid reservation ID']);
    exit;
  }
  
  // Get reservation details
  $stmt = $db->prepare('SELECT r.id, r.equipment_id, r.quantity, r.return_status, f.fullname AS faculty_name, f.username AS faculty_username, e.name AS equipment, c.name AS category FROM reservations r JOIN faculty f ON f.id=r.faculty_id JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id WHERE r.id=?');
  $stmt->bind_param('i', $reservationId);
  $stmt->execute();
  $result = $stmt->get_result();
  $reservation = $result->fetch_assoc();
  $stmt->close();
  
  if (!$reservation) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Reservation not found']);
    exit;
  }
  
  if ($reservation['return_status'] !== 'Pending') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Return is not pending']);
    exit;
  }
  
  // Start transaction
  $db->begin_transaction();
  
  try {
    // Update return status to Cleared
    $stmt = $db->prepare('UPDATE reservations SET return_status=?, return_cleared_at=NOW() WHERE id=?');
    $returnStatus = 'Cleared';
    $stmt->bind_param('si', $returnStatus, $reservationId);
    $stmt->execute();
    $stmt->close();
    
    // Update equipment inventory - add back the quantity
    $stmt = $db->prepare('UPDATE equipment SET available = available + ? WHERE id=?');
    $stmt->bind_param('ii', $reservation['quantity'], $reservation['equipment_id']);
    $stmt->execute();
    $stmt->close();
    
    // Commit transaction
    $db->commit();
    
    // Create notifications (handled in JavaScript)
    echo json_encode([
      'ok' => true,
      'message' => 'Return cleared successfully',
      'reservation' => $reservation
    ]);
  } catch (Exception $e) {
    $db->rollback();
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Failed to clear return: ' . $e->getMessage()]);
  }
  
  exit;
}

// Send NSTP setup reminder to GenServe every Friday for upcoming Saturday
// This endpoint should be called every Friday (can be scheduled via cron job)
if ($action === 'sendNSTPReminder' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  ensure_genserve_exists($db);
  ensure_genserve_notifications_exists($db);
  
  $today = new DateTime();
  $dayOfWeek = (int)$today->format('w'); // 0 = Sunday, 5 = Friday
  
  // Only send on Fridays
  if ($dayOfWeek !== 5) {
    echo json_encode(['ok' => false, 'error' => 'This reminder should only be sent on Fridays']);
    exit;
  }
  
  // Calculate next Saturday
  $nextSaturday = clone $today;
  $nextSaturday->modify('+1 day'); // Tomorrow (Saturday)
  
  $saturdayDate = $nextSaturday->format('F j, Y'); // e.g., "December 14, 2024"
  
  // Check if this Saturday is in the blocked period
  if (!is_saturday_blocked($nextSaturday->format('Y-m-d'))) {
    echo json_encode(['ok' => false, 'error' => 'Next Saturday is not in NSTP blocked period']);
    exit;
  }
  
  $title = '📋 NSTP Setup Reminder';
  $message = "Please prepare chairs and fans for NSTP setup this Saturday, {$saturdayDate}. The venue will be used for NSTP activities.";
  
  send_genserve_notification($db, 'nstp_reminder', $title, $message);
  
  echo json_encode(['ok' => true, 'message' => 'NSTP reminder sent to all GenServe staff']);
  exit;
}

// Get GenServe notifications by username
if ($action === 'listGenServeNotifications' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  ensure_genserve_notifications_exists($db);
  
  $username = $_GET['username'] ?? '';
  $stmt = $db->prepare('SELECT id FROM genserve WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($gid);
  if (!$stmt->fetch()) { 
    echo json_encode([]); 
    exit; 
  }
  $stmt->close();
  
  $stmt2 = $db->prepare('SELECT id, type, title, message, is_read AS isRead, created_at AS createdAt FROM genserve_notifications WHERE genserve_id=? ORDER BY id DESC');
  $stmt2->bind_param('i', $gid);
  $stmt2->execute();
  $result = $stmt2->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) { 
    $out[] = $row; 
  }
  echo json_encode($out);
  exit;
}

// Mark GenServe notification as read
if ($action === 'markGenServeNotificationRead' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  ensure_genserve_notifications_exists($db);
  
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  $stmt = $db->prepare('UPDATE genserve_notifications SET is_read=1 WHERE id=?');
  $stmt->bind_param('i', $id);
  $stmt->execute();
  echo json_encode(['ok'=>true]);
  exit;
}

// Create GenServe notification
if ($action === 'createGenServeNotification' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  ensure_genserve_notifications_exists($db);
  
  $data = json_input();
  $type = trim($data['type'] ?? 'info');
  $title = trim($data['title'] ?? '');
  $message = trim($data['message'] ?? '');
  
  if ($title === '' || $message === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing required fields']);
    exit;
  }
  
  // Send notification to all GenServe users
  send_genserve_notification($db, $type, $title, $message);
  echo json_encode(['ok' => true]);
  exit;
}

// ====== GYM RESERVATION ENDPOINTS ======

// Check if an equipment date range is available for a specific equipment item
if ($action === 'checkEquipmentDateAvailability' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $equipment = trim($_GET['equipment'] ?? '');
  $category = trim($_GET['category'] ?? '');
  $start_date = trim($_GET['startDate'] ?? '');
  $end_date = trim($_GET['endDate'] ?? $start_date);
  $exclude_id = intval($_GET['excludeId'] ?? 0);

  if ($equipment === '' || $category === '' || $start_date === '' || $end_date === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing fields']);
    exit;
  }

  $startObj = new DateTime($start_date);
  $endObj = new DateTime($end_date);
  if ($endObj < $startObj) {
    $tmp = $startObj;
    $startObj = $endObj;
    $endObj = $tmp;
  }
  $startNorm = $startObj->format('Y-m-d');
  $endNorm = $endObj->format('Y-m-d');

  // Resolve category and equipment ids
  $stmt = $db->prepare('SELECT id FROM equipment_categories WHERE name=?');
  $stmt->bind_param('s', $category);
  $stmt->execute();
  $stmt->bind_result($catId);
  if (!$stmt->fetch()) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Category not found']);
    exit;
  }
  $stmt->close();

  $stmt = $db->prepare('SELECT id FROM equipment WHERE name=? AND category_id=?');
  $stmt->bind_param('si', $equipment, $catId);
  $stmt->execute();
  $stmt->bind_result($eqId);
  if (!$stmt->fetch()) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Equipment not found']);
    exit;
  }
  $stmt->close();

  $statusPending = 'Pending';
  $statusApproved = 'Approved';

  if ($exclude_id > 0) {
    $stmt = $db->prepare('SELECT COUNT(*) FROM reservations WHERE id <> ? AND equipment_id=? AND status IN (?, ?) AND NOT (COALESCE(end_date, date) < ? OR COALESCE(start_date, date) > ?)');
    $stmt->bind_param('iissss', $exclude_id, $eqId, $statusPending, $statusApproved, $startNorm, $endNorm);
  } else {
    $stmt = $db->prepare('SELECT COUNT(*) FROM reservations WHERE equipment_id=? AND status IN (?, ?) AND NOT (COALESCE(end_date, date) < ? OR COALESCE(start_date, date) > ?)');
    $stmt->bind_param('issss', $eqId, $statusPending, $statusApproved, $startNorm, $endNorm);
  }

  $stmt->execute();
  $stmt->bind_result($cnt);
  $stmt->fetch();
  $stmt->close();

  $available = ($cnt == 0);
  echo json_encode(['ok' => true, 'available' => $available]);
  exit;
}

// Check if a gym date range is available (no overlapping reservations)
if ($action === 'checkGymDateAvailability' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $start_date = trim($_GET['startDate'] ?? '');
  $end_date = trim($_GET['endDate'] ?? $start_date);
  $exclude_id = intval($_GET['excludeId'] ?? 0);

  if ($start_date === '' || $end_date === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Start and end dates are required']);
    exit;
  }

  // Normalize order if needed
  $startObj = new DateTime($start_date);
  $endObj = new DateTime($end_date);
  if ($endObj < $startObj) {
    $tmp = $startObj;
    $startObj = $endObj;
    $endObj = $tmp;
  }
  $startNorm = $startObj->format('Y-m-d');
  $endNorm = $endObj->format('Y-m-d');

  // Consider reservations that are Pending or Approved as blocking
  $statuses = ['Pending', 'Approved'];

  if ($exclude_id > 0) {
    $stmt = $db->prepare('SELECT COUNT(*) FROM gym_reservations WHERE id <> ? AND status IN (?, ?) AND NOT (COALESCE(end_date, date) < ? OR COALESCE(start_date, date) > ?)');
    $stmt->bind_param('issss', $exclude_id, $statuses[0], $statuses[1], $startNorm, $endNorm);
  } else {
    $stmt = $db->prepare('SELECT COUNT(*) FROM gym_reservations WHERE status IN (?, ?) AND NOT (COALESCE(end_date, date) < ? OR COALESCE(start_date, date) > ?)');
    $stmt->bind_param('ssss', $statuses[0], $statuses[1], $startNorm, $endNorm);
  }

  $stmt->execute();
  $stmt->bind_result($cnt);
  $stmt->fetch();
  $stmt->close();

  $available = ($cnt == 0);
  echo json_encode(['ok' => true, 'available' => $available]);
  exit;
}

// Submit gym reservation
if ($action === 'submitGymReservation' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $username = trim($data['facultyUsername'] ?? '');
  $title = trim($data['title'] ?? '');
  $start_date = trim($data['startDate'] ?? ($data['date'] ?? ''));
  $end_date = trim($data['endDate'] ?? $start_date);
  $time = trim($data['time'] ?? '');
  $equipmentItems = $data['equipmentItems'] ?? [];
  $duration_days = intval($data['durationDays'] ?? 0);
  
  if ($username === '' || $title === '' || $start_date === '' || $end_date === '' || $time === '' || !is_array($equipmentItems)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing required fields']);
    exit;
  }

  // Normalize date order
  $startObj = new DateTime($start_date);
  $endObj = new DateTime($end_date);
  if ($endObj < $startObj) {
    $tmp = $startObj;
    $startObj = $endObj;
    $endObj = $tmp;
  }
  $startNorm = $startObj->format('Y-m-d');
  $endNorm = $endObj->format('Y-m-d');

  // Block if there is any overlapping gym reservation (Pending or Approved)
  $statusPending = 'Pending';
  $statusApproved = 'Approved';
  $stmt = $db->prepare('SELECT COUNT(*) FROM gym_reservations WHERE status IN (?, ?) AND NOT (COALESCE(end_date, date) < ? OR COALESCE(start_date, date) > ?)');
  $stmt->bind_param('ssss', $statusPending, $statusApproved, $startNorm, $endNorm);
  $stmt->execute();
  $stmt->bind_result($overlapCount);
  $stmt->fetch();
  $stmt->close();

  if ($overlapCount > 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'This gym date range is already booked. Please choose another date.']);
    exit;
  }
  
  // Resolve faculty id
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Faculty not found']);
    exit;
  }
  $stmt->close();
  
  // Validate and check equipment availability
  $validatedItems = [];
  foreach ($equipmentItems as $item) {
    $category = trim($item['category'] ?? '');
    $equipment = trim($item['equipment'] ?? '');
    $quantity = intval($item['quantity'] ?? 0);
    
    if ($category === '' || $equipment === '' || $quantity <= 0) {
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => 'Invalid equipment item']);
      exit;
    }
    
    // Get category id
    $stmt = $db->prepare('SELECT id FROM equipment_categories WHERE name=?');
    $stmt->bind_param('s', $category);
    $stmt->execute();
    $stmt->bind_result($catId);
    if (!$stmt->fetch()) {
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => "Category '{$category}' not found"]);
      exit;
    }
    $stmt->close();
    
    // Get equipment id and availability
    $stmt = $db->prepare('SELECT id, available FROM equipment WHERE name=? AND category_id=?');
    $stmt->bind_param('si', $equipment, $catId);
    $stmt->execute();
    $stmt->bind_result($eqId, $avail);
    if (!$stmt->fetch()) {
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => "Equipment '{$equipment}' not found"]);
      exit;
    }
    $stmt->close();
    
    // Check availability
    if ($avail < $quantity) {
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => "Only {$avail} {$equipment} available, but {$quantity} requested"]);
      exit;
    }
    
    $validatedItems[] = [
      'category_id' => $catId,
      'category' => $category,
      'equipment_id' => $eqId,
      'equipment' => $equipment,
      'quantity' => $quantity
    ];
  }
  
  // Validate date range
  $startDateObj = new DateTime($start_date);
  $endDateObj = new DateTime($end_date);
  if ($endDateObj < $startDateObj) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'End Date cannot be earlier than Start Date']);
    exit;
  }

  if ($duration_days <= 0) {
    $duration_days = $startDateObj->diff($endDateObj)->days + 1;
  }

  // Check each day in the range for NSTP blocked Saturdays
  $rangeDate = clone $startDateObj;
  while ($rangeDate <= $endDateObj) {
    $rangeStr = $rangeDate->format('Y-m-d');
    if (is_saturday_blocked($rangeStr)) {
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => 'Reservations on Saturdays are not allowed due to NSTP activities.']);
      exit;
    }
    $rangeDate->modify('+1 day');
  }
  
  // Start transaction
  $db->begin_transaction();
  
  try {
    // Deduct quantities from available inventory
    foreach ($validatedItems as $item) {
      $stmt = $db->prepare('UPDATE equipment SET available = available - ? WHERE id = ?');
      $stmt->bind_param('ii', $item['quantity'], $item['equipment_id']);
      $stmt->execute();
      $stmt->close();
    }
    
    // Create gym reservation
    $equipmentItemsJson = json_encode($validatedItems);
    $stmt = $db->prepare('INSERT INTO gym_reservations (faculty_id, title, date, start_date, end_date, duration_days, time, equipment_items, status) VALUES (?,?,?,?,?,?,?,?,"Pending")');
    $legacy_date = $start_date;
    $stmt->bind_param('issssiss', $fid, $title, $legacy_date, $start_date, $end_date, $duration_days, $time, $equipmentItemsJson);
    $stmt->execute();
    $reservationId = $stmt->insert_id;
    $stmt->close();
    
    $db->commit();
    
    echo json_encode(['ok' => true, 'id' => $reservationId]);
  } catch (Exception $e) {
    $db->rollback();
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Failed to create reservation: ' . $e->getMessage()]);
  }
  
  exit;
}

// List gym reservations for faculty
if ($action === 'listFacultyGymReservations' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $username = $_GET['username'] ?? '';
  if ($username === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Username required']);
    exit;
  }
  
  $stmt = $db->prepare('SELECT id FROM faculty WHERE username=?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $stmt->bind_result($fid);
  if (!$stmt->fetch()) {
    echo json_encode([]);
    exit;
  }
  $stmt->close();
  
  // Check if return_status column exists
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  if ($hasReturnStatus) {
    $stmt = $db->prepare('SELECT id, title, date, start_date, end_date, duration_days, time, equipment_items, status, cancel_reason, decline_reason, return_status, created_at, updated_at, return_requested_at FROM gym_reservations WHERE faculty_id=? ORDER BY id DESC');
  } else {
    $stmt = $db->prepare('SELECT id, title, date, start_date, end_date, duration_days, time, equipment_items, status, cancel_reason, decline_reason, created_at, updated_at FROM gym_reservations WHERE faculty_id=? ORDER BY id DESC');
  }
  $stmt->bind_param('i', $fid);
  $stmt->execute();
  $result = $stmt->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) {
    $reservation = [
      'id' => intval($row['id']),
      'title' => $row['title'],
      'date' => $row['date'],
      'startDate' => $row['start_date'] ?? $row['date'],
      'endDate' => $row['end_date'] ?? $row['date'],
      'durationDays' => intval($row['duration_days'] ?? 1),
      'time' => $row['time'],
      'equipmentItems' => json_decode($row['equipment_items'], true),
      'status' => $row['status'],
      'createdAt' => $row['created_at'],
      'updatedAt' => $row['updated_at']
    ];
    if ($hasReturnStatus) {
      $reservation['returnStatus'] = $row['return_status'] ?? 'None';
      $reservation['return_status'] = $row['return_status'] ?? 'None';
      if (isset($row['return_requested_at'])) {
        $reservation['returnRequestedAt'] = $row['return_requested_at'];
      }
    } else {
      $reservation['returnStatus'] = 'None';
      $reservation['return_status'] = 'None';
    }
    $out[] = $reservation;
  }
  $stmt->close();
  echo json_encode($out);
  exit;
}

// List all gym reservations for admin
if ($action === 'listAllGymReservations' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $res = $db->query('SELECT gr.id, f.fullname AS faculty, f.username AS facultyUsername, gr.title, gr.date, gr.time, gr.equipment_items, gr.status, gr.cancel_reason, gr.decline_reason, gr.created_at, gr.updated_at FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id ORDER BY gr.id DESC');
  $out = [];
  while ($row = $res->fetch_assoc()) {
    $out[] = [
      'id' => intval($row['id']),
      'faculty' => $row['faculty'],
      'facultyUsername' => $row['facultyUsername'],
      'title' => $row['title'],
      'date' => $row['date'],
      'time' => $row['time'],
      'equipmentItems' => json_decode($row['equipment_items'], true),
      'status' => $row['status'],
      'cancel_reason' => $row['cancel_reason'] ?? '',
      'decline_reason' => $row['decline_reason'] ?? '',
      'createdAt' => $row['created_at'],
      'updatedAt' => $row['updated_at']
    ];
  }
  echo json_encode($out);
  exit;
}

// Get reservations by date for calendar view (without faculty names)
if ($action === 'getReservationsByDate' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $date = $_GET['date'] ?? '';
  
  if ($date === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Date required']);
    exit;
  }
  
  $out = [
    'date' => $date,
    'equipmentReservations' => [],
    'gymReservations' => [],
    'announcements' => []
  ];
  
  // Get equipment reservations for the date (approved only), including date ranges
  $stmt = $db->prepare('SELECT e.name AS equipment, c.name AS category, r.time, r.quantity FROM reservations r JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id WHERE ? BETWEEN COALESCE(r.start_date, r.date) AND COALESCE(r.end_date, r.date) AND r.status=? ORDER BY r.time');
  $status = 'Approved';
  $stmt->bind_param('ss', $date, $status);
  $stmt->execute();
  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
    $out['equipmentReservations'][] = [
      'equipment' => $row['equipment'],
      'category' => $row['category'],
      'time' => $row['time'],
      'quantity' => intval($row['quantity'])
    ];
  }
  $stmt->close();
  
  // Get gym reservations for the date (approved only), including date ranges
  $stmt = $db->prepare('SELECT gr.title, gr.time, gr.equipment_items FROM gym_reservations gr WHERE ? BETWEEN COALESCE(gr.start_date, gr.date) AND COALESCE(gr.end_date, gr.date) AND gr.status=? ORDER BY gr.time');
  $status = 'Approved';
  $stmt->bind_param('ss', $date, $status);
  $stmt->execute();
  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
    $equipmentItems = json_decode($row['equipment_items'], true);
    $out['gymReservations'][] = [
      'title' => $row['title'],
      'time' => $row['time'],
      'equipmentItems' => $equipmentItems || []
    ];
  }
  $stmt->close();
  
  // Get announcements for the date (where date is between start_date and end_date)
  $stmt = $db->prepare('SELECT id, title, message, start_date, start_time, end_date, end_time FROM announcements WHERE ? BETWEEN start_date AND end_date ORDER BY start_date, start_time');
  $stmt->bind_param('s', $date);
  $stmt->execute();
  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
    $out['announcements'][] = [
      'id' => intval($row['id']),
      'title' => $row['title'],
      'message' => $row['message'],
      'startDate' => $row['start_date'],
      'startTime' => $row['start_time'],
      'endDate' => $row['end_date'],
      'endTime' => $row['end_time']
    ];
  }
  $stmt->close();
  
  echo json_encode($out);
  exit;
}

// Update gym reservation (edit)
if ($action === 'updateGymReservation' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  $title = trim($data['title'] ?? '');
  $date = trim($data['date'] ?? '');
  $time = trim($data['time'] ?? '');
  $equipmentItems = $data['equipmentItems'] ?? [];
  
  if ($id <= 0 || $title === '' || $date === '' || $time === '' || !is_array($equipmentItems)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid fields']);
    exit;
  }
  
  // Fetch reservation and ensure still pending
  $stmt = $db->prepare('SELECT status, equipment_items FROM gym_reservations WHERE id=?');
  $stmt->bind_param('i', $id);
  $stmt->execute();
  $stmt->bind_result($oldStatus, $oldEquipmentItems);
  if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Reservation not found']);
    exit;
  }
  $stmt->close();
  
  if ($oldStatus !== 'Pending') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Only pending reservations can be edited']);
    exit;
  }
  
  // Check if date is a Saturday during NSTP blocked period
  if (is_saturday_blocked($date)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Reservations on Saturdays are not allowed due to NSTP activities.']);
    exit;
  }
  
  // Validate and check equipment availability
  $oldItems = json_decode($oldEquipmentItems, true) ?? [];
  $validatedItems = [];
  
  // First, restore old quantities (if any)
  if (is_array($oldItems)) {
    foreach ($oldItems as $oldItem) {
      if (isset($oldItem['quantity']) && isset($oldItem['equipment_id'])) {
        $stmt = $db->prepare('UPDATE equipment SET available = available + ? WHERE id = ?');
        $stmt->bind_param('ii', $oldItem['quantity'], $oldItem['equipment_id']);
        $stmt->execute();
        $stmt->close();
      }
    }
  }
  
  // Then validate and deduct new quantities
  foreach ($equipmentItems as $item) {
    $category = trim($item['category'] ?? '');
    $equipment = trim($item['equipment'] ?? '');
    $quantity = intval($item['quantity'] ?? 0);
    
    if ($category === '' || $equipment === '' || $quantity <= 0) {
      // Restore all if validation fails
      if (is_array($oldItems)) {
        foreach ($oldItems as $oldItem) {
          if (isset($oldItem['quantity']) && isset($oldItem['equipment_id'])) {
            $stmt = $db->prepare('UPDATE equipment SET available = available - ? WHERE id = ?');
            $stmt->bind_param('ii', $oldItem['quantity'], $oldItem['equipment_id']);
            $stmt->execute();
            $stmt->close();
          }
        }
      }
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => 'Invalid equipment item']);
      exit;
    }
    
    // Get category id
    $stmt = $db->prepare('SELECT id FROM equipment_categories WHERE name=?');
    $stmt->bind_param('s', $category);
    $stmt->execute();
    $stmt->bind_result($catId);
    if (!$stmt->fetch()) {
      // Restore all if validation fails
      if (is_array($oldItems)) {
        foreach ($oldItems as $oldItem) {
          if (isset($oldItem['quantity']) && isset($oldItem['equipment_id'])) {
            $stmt = $db->prepare('UPDATE equipment SET available = available - ? WHERE id = ?');
            $stmt->bind_param('ii', $oldItem['quantity'], $oldItem['equipment_id']);
            $stmt->execute();
            $stmt->close();
          }
        }
      }
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => "Category '{$category}' not found"]);
      exit;
    }
    $stmt->close();
    
    // Get equipment id and availability
    $stmt = $db->prepare('SELECT id, available FROM equipment WHERE name=? AND category_id=?');
    $stmt->bind_param('si', $equipment, $catId);
    $stmt->execute();
    $stmt->bind_result($eqId, $avail);
    if (!$stmt->fetch()) {
      // Restore all if validation fails
      if (is_array($oldItems)) {
        foreach ($oldItems as $oldItem) {
          if (isset($oldItem['quantity']) && isset($oldItem['equipment_id'])) {
            $stmt = $db->prepare('UPDATE equipment SET available = available - ? WHERE id = ?');
            $stmt->bind_param('ii', $oldItem['quantity'], $oldItem['equipment_id']);
            $stmt->execute();
            $stmt->close();
          }
        }
      }
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => "Equipment '{$equipment}' not found"]);
      exit;
    }
    $stmt->close();
    
    // Check availability
    if ($avail < $quantity) {
      // Restore all if validation fails
      if (is_array($oldItems)) {
        foreach ($oldItems as $oldItem) {
          if (isset($oldItem['quantity']) && isset($oldItem['equipment_id'])) {
            $stmt = $db->prepare('UPDATE equipment SET available = available - ? WHERE id = ?');
            $stmt->bind_param('ii', $oldItem['quantity'], $oldItem['equipment_id']);
            $stmt->execute();
            $stmt->close();
          }
        }
      }
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => "Only {$avail} {$equipment} available, but {$quantity} requested"]);
      exit;
    }
    
    // Deduct new quantity
    $stmt = $db->prepare('UPDATE equipment SET available = available - ? WHERE id = ?');
    $stmt->bind_param('ii', $quantity, $eqId);
    $stmt->execute();
    $stmt->close();
    
    $validatedItems[] = [
      'category_id' => $catId,
      'category' => $category,
      'equipment_id' => $eqId,
      'equipment' => $equipment,
      'quantity' => $quantity
    ];
  }
  
  // Update gym reservation
  $equipmentItemsJson = json_encode($validatedItems);
  $stmt = $db->prepare('UPDATE gym_reservations SET title=?, date=?, time=?, equipment_items=?, updated_at=NOW() WHERE id=?');
  $stmt->bind_param('ssssi', $title, $date, $time, $equipmentItemsJson, $id);
  $stmt->execute();
  $stmt->close();
  
  echo json_encode(['ok' => true]);
  exit;
}

// Update gym reservation status (approve/decline)
if ($action === 'updateGymReservationStatus' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $id = intval($data['id'] ?? 0);
  $status = trim($data['status'] ?? '');
  $reason = trim($data['reason'] ?? '');
  
  if ($id <= 0 || !in_array($status, ['Approved', 'Declined', 'Pending', 'Cancelled', 'Cancellation Requested'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid status']);
    exit;
  }
  
  // Fetch reservation
  $stmt = $db->prepare('SELECT equipment_items, status FROM gym_reservations WHERE id=?');
  $stmt->bind_param('i', $id);
  $stmt->execute();
  $stmt->bind_result($equipmentItemsJson, $oldStatus);
  if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Reservation not found']);
    exit;
  }
  $stmt->close();
  
  // If declining or cancelling, restore equipment quantities
  // Do NOT restore when requesting cancellation - only when it's approved/declined
  if (($status === 'Declined' || $status === 'Cancelled') && $oldStatus !== 'Declined' && $oldStatus !== 'Cancelled' && $oldStatus !== 'Cancellation Requested') {
    $equipmentItems = json_decode($equipmentItemsJson, true);
    foreach ($equipmentItems as $item) {
      $stmt = $db->prepare('UPDATE equipment SET available = available + ? WHERE id = ?');
      $stmt->bind_param('ii', $item['quantity'], $item['equipment_id']);
      $stmt->execute();
      $stmt->close();
    }
  }
  
  // Update status and reason
  if ($status === 'Cancelled') {
    $stmt = $db->prepare('UPDATE gym_reservations SET status=?, cancel_reason=?, updated_at=NOW() WHERE id=?');
    $stmt->bind_param('ssi', $status, $reason, $id);
  } else if ($status === 'Cancellation Requested') {
    $stmt = $db->prepare('UPDATE gym_reservations SET status=?, cancel_reason=?, updated_at=NOW() WHERE id=?');
    $stmt->bind_param('ssi', $status, $reason, $id);
  } else if ($status === 'Declined') {
    $stmt = $db->prepare('UPDATE gym_reservations SET status=?, decline_reason=?, updated_at=NOW() WHERE id=?');
    $stmt->bind_param('ssi', $status, $reason, $id);
  } else {
    $stmt = $db->prepare('UPDATE gym_reservations SET status=?, updated_at=NOW() WHERE id=?');
    $stmt->bind_param('si', $status, $id);
  }
  $stmt->execute();
  $stmt->close();
  
  echo json_encode(['ok' => true]);
  exit;
}

// List pending gym returns for GenServe
// Only shows gym reservations where faculty has initiated a return (return_status = 'Pending')
if ($action === 'listPendingGymReturns' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  // Check if gym_reservations has return_status column
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  if (!$hasReturnStatus) {
    // If return_status column doesn't exist, return empty array
    // Faculty can't return gym reservations yet until database is updated
    echo json_encode([]);
    exit;
  }
  
  // Only show gym reservations where faculty has initiated return (return_status = 'Pending')
  // Exclude PendingAdminApproval - those are handled by Admin
  $stmt = $db->prepare('SELECT gr.id, f.fullname AS faculty, f.username AS facultyUsername, gr.title, gr.date, gr.time, gr.equipment_items, gr.return_requested_at AS returnRequestedAt FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE gr.status=? AND gr.return_status=? ORDER BY gr.return_requested_at DESC');
  $status = 'Approved';
  $returnStatus = 'Pending';
  $stmt->bind_param('ss', $status, $returnStatus);
  
  $stmt->execute();
  $result = $stmt->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) {
    // Parse equipment_items JSON
    $equipmentItems = json_decode($row['equipment_items'], true);
    if ($equipmentItems && is_array($equipmentItems)) {
      // Get category for each item
      foreach ($equipmentItems as &$item) {
        if (isset($item['equipment_id'])) {
          $catStmt = $db->prepare('SELECT c.name FROM equipment e JOIN equipment_categories c ON c.id=e.category_id WHERE e.id=?');
          $catStmt->bind_param('i', $item['equipment_id']);
          $catStmt->execute();
          $catStmt->bind_result($categoryName);
          if ($catStmt->fetch()) {
            $item['category'] = $categoryName;
          }
          $catStmt->close();
        }
      }
      $row['equipmentItems'] = $equipmentItems;
      // Set a default category (use first item's category or 'Gym Equipment')
      $row['category'] = $equipmentItems[0]['category'] ?? 'Gym Equipment';
      // Calculate total quantity
      $row['quantity'] = array_sum(array_column($equipmentItems, 'quantity'));
    } else {
      $row['equipmentItems'] = [];
      $row['category'] = 'Gym Equipment';
      $row['quantity'] = 0;
    }
    // Set equipment field to title for consistency with equipment returns
    $row['equipment'] = $row['title'];
    $out[] = $row;
  }
  $stmt->close();
  echo json_encode($out);
  exit;
}

// Clear gym return by GenServe
if ($action === 'clearGymReturn' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $reservationId = intval($data['reservationId'] ?? 0);
  
  if ($reservationId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid reservation ID']);
    exit;
  }
  
  // Check if gym_reservations has return_status column
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  // Get gym reservation details
  $stmt = $db->prepare('SELECT gr.id, gr.equipment_items, gr.status, f.fullname AS faculty_name, f.username AS faculty_username, gr.title FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE gr.id=?');
  $stmt->bind_param('i', $reservationId);
  $stmt->execute();
  $result = $stmt->get_result();
  $reservation = $result->fetch_assoc();
  $stmt->close();
  
  if (!$reservation) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Gym reservation not found']);
    exit;
  }
  
  if ($hasReturnStatus) {
    // Check return status if column exists
    $stmt = $db->prepare('SELECT return_status FROM gym_reservations WHERE id=?');
    $stmt->bind_param('i', $reservationId);
    $stmt->execute();
    $stmt->bind_result($returnStatus);
    $stmt->fetch();
    $stmt->close();
    
    if ($returnStatus !== 'Pending') {
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => 'Return is not pending']);
      exit;
    }
  }
  
  if ($reservation['status'] !== 'Approved') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Only approved gym reservations can be cleared']);
    exit;
  }
  
  // Start transaction
  $db->begin_transaction();
  
  try {
    if ($hasReturnStatus) {
      // Update return status to PendingAdminApproval (GenServe verified, waiting for Admin approval)
      $stmt = $db->prepare('UPDATE gym_reservations SET return_status=?, return_verified_at=NOW() WHERE id=?');
      $returnStatus = 'PendingAdminApproval';
      $stmt->bind_param('si', $returnStatus, $reservationId);
      $stmt->execute();
      $stmt->close();
    } else {
      // Otherwise, just update the updated_at timestamp
      $stmt = $db->prepare('UPDATE gym_reservations SET updated_at=NOW() WHERE id=?');
      $stmt->bind_param('i', $reservationId);
      $stmt->execute();
      $stmt->close();
    }
    
    // DO NOT update equipment inventory yet - wait for Admin approval
    // Equipment will be restored only after Admin approves
    
    // Commit transaction
    $db->commit();
    
    // Prepare reservation data for response
    $reservation['equipment'] = $reservation['title'];
    $reservation['category'] = 'Gym Equipment';
    
    echo json_encode([
      'ok' => true,
      'message' => 'Gym return verified by GenServe. Waiting for Admin approval.',
      'reservation' => $reservation
    ]);
  } catch (Exception $e) {
    $db->rollback();
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Failed to clear gym return: ' . $e->getMessage()]);
  }
  
  exit;
}

// List pending gym returns for Admin approval (status = PendingAdminApproval)
if ($action === 'listPendingAdminGymReturns' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  // Check if gym_reservations has return_status column
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  if (!$hasReturnStatus) {
    echo json_encode([]);
    exit;
  }
  
  // Only show gym reservations where GenServe has verified (PendingAdminApproval)
  $stmt = $db->prepare('SELECT gr.id, f.fullname AS faculty, f.username AS facultyUsername, gr.title, gr.date, gr.time, gr.equipment_items, gr.return_verified_at AS returnVerifiedAt FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE gr.status=? AND gr.return_status=? ORDER BY gr.return_verified_at DESC');
  $status = 'Approved';
  $returnStatus = 'PendingAdminApproval';
  $stmt->bind_param('ss', $status, $returnStatus);
  
  $stmt->execute();
  $result = $stmt->get_result();
  $out = [];
  while ($row = $result->fetch_assoc()) {
    // Parse equipment_items JSON
    $equipmentItems = json_decode($row['equipment_items'], true);
    if ($equipmentItems && is_array($equipmentItems)) {
      // Get category for each item
      foreach ($equipmentItems as &$item) {
        if (isset($item['equipment_id'])) {
          $catStmt = $db->prepare('SELECT c.name FROM equipment e JOIN equipment_categories c ON c.id=e.category_id WHERE e.id=?');
          $catStmt->bind_param('i', $item['equipment_id']);
          $catStmt->execute();
          $catStmt->bind_result($categoryName);
          if ($catStmt->fetch()) {
            $item['category'] = $categoryName;
          }
          $catStmt->close();
        }
      }
      $row['equipmentItems'] = $equipmentItems;
      // Set a default category (use first item's category or 'Gym Equipment')
      $row['category'] = $equipmentItems[0]['category'] ?? 'Gym Equipment';
      // Calculate total quantity
      $row['quantity'] = array_sum(array_column($equipmentItems, 'quantity'));
    } else {
      $row['equipmentItems'] = [];
      $row['category'] = 'Gym Equipment';
      $row['quantity'] = 0;
    }
    // Set equipment field to title for consistency
    $row['equipment'] = $row['title'];
    $out[] = $row;
  }
  $stmt->close();
  echo json_encode($out);
  exit;
}

// Admin approve gym return (final approval - restore inventory and notify faculty)
if ($action === 'approveAdminGymReturn' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $reservationId = intval($data['reservationId'] ?? 0);
  
  if ($reservationId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid reservation ID']);
    exit;
  }
  
  // Check if gym_reservations has return_status column
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  if (!$hasReturnStatus) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Gym return feature is not available']);
    exit;
  }
  
  // Get gym reservation details
  $stmt = $db->prepare('SELECT gr.id, gr.equipment_items, gr.status, gr.return_status, f.fullname AS faculty_name, f.username AS faculty_username, gr.title FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE gr.id=?');
  $stmt->bind_param('i', $reservationId);
  $stmt->execute();
  $result = $stmt->get_result();
  $reservation = $result->fetch_assoc();
  $stmt->close();
  
  if (!$reservation) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Gym reservation not found']);
    exit;
  }
  
  if ($reservation['return_status'] !== 'PendingAdminApproval') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Gym return is not pending admin approval']);
    exit;
  }
  
  if ($reservation['status'] !== 'Approved') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Only approved gym reservations can be processed']);
    exit;
  }
  
  // Start transaction
  $db->begin_transaction();
  
  try {
    // Update return status to Cleared (final approval)
    $stmt = $db->prepare('UPDATE gym_reservations SET return_status=?, return_cleared_at=NOW() WHERE id=?');
    $returnStatus = 'Cleared';
    $stmt->bind_param('si', $returnStatus, $reservationId);
    $stmt->execute();
    $stmt->close();
    
    // Update equipment inventory - restore quantities for all equipment items
    $equipmentItems = json_decode($reservation['equipment_items'], true);
    if ($equipmentItems && is_array($equipmentItems)) {
      foreach ($equipmentItems as $item) {
        if (isset($item['equipment_id']) && isset($item['quantity'])) {
          $stmt = $db->prepare('UPDATE equipment SET available = available + ? WHERE id=?');
          $stmt->bind_param('ii', $item['quantity'], $item['equipment_id']);
          $stmt->execute();
          $stmt->close();
        }
      }
    }
    
    // Commit transaction
    $db->commit();
    
    // Prepare reservation data for response
    $reservation['equipment'] = $reservation['title'];
    $reservation['category'] = 'Gym Equipment';
    
    echo json_encode([
      'ok' => true,
      'message' => 'Gym return approved successfully. Inventory restored and faculty notified.',
      'reservation' => $reservation
    ]);
  } catch (Exception $e) {
    $db->rollback();
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Failed to approve gym return: ' . $e->getMessage()]);
  }
  
  exit;
}

// Admin decline gym return
if ($action === 'declineAdminGymReturn' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_input();
  $reservationId = intval($data['reservationId'] ?? 0);
  $reason = trim($data['reason'] ?? '');
  
  if ($reservationId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid reservation ID']);
    exit;
  }
  
  // Check if gym_reservations has return_status column
  $checkColumn = $db->query("SHOW COLUMNS FROM gym_reservations LIKE 'return_status'");
  $hasReturnStatus = $checkColumn && $checkColumn->num_rows > 0;
  
  if (!$hasReturnStatus) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Gym return feature is not available']);
    exit;
  }
  
  // Get gym reservation details
  $stmt = $db->prepare('SELECT gr.id, gr.equipment_items, gr.status, gr.return_status, f.fullname AS faculty_name, f.username AS faculty_username, gr.title FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE gr.id=?');
  $stmt->bind_param('i', $reservationId);
  $stmt->execute();
  $result = $stmt->get_result();
  $reservation = $result->fetch_assoc();
  $stmt->close();
  
  if (!$reservation) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Gym reservation not found']);
    exit;
  }
  
  if ($reservation['return_status'] !== 'PendingAdminApproval') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Gym return is not pending admin approval']);
    exit;
  }
  
  // Update return status to Declined
  $stmt = $db->prepare('UPDATE gym_reservations SET return_status=? WHERE id=?');
  $returnStatus = 'Declined';
  $stmt->bind_param('si', $returnStatus, $reservationId);
  $stmt->execute();
  $stmt->close();
  
  // Prepare reservation data for response
  $reservation['equipment'] = $reservation['title'];
  $reservation['category'] = 'Gym Equipment';
  $reservation['declineReason'] = $reason;
  
  echo json_encode([
    'ok' => true,
    'message' => 'Gym return declined. Faculty will be notified.',
    'reservation' => $reservation
  ]);
  
  exit;
}

// List all cancellation and decline reasons
if ($action === 'listCancellationReasons' && $_SERVER['REQUEST_METHOD'] === 'GET') {
  $username = $_GET['username'] ?? '';
  $role = $_GET['role'] ?? 'admin'; // admin, genserve, faculty
  
  $reasons = [];
  
  // Get equipment reservations with reasons
  if ($role === 'faculty' && $username) {
    // Faculty can only see their own reservations
    $stmt = $db->prepare('SELECT r.id, f.fullname AS faculty, e.name AS equipment, c.name AS category, r.date, r.time, r.status, r.cancel_reason, r.decline_reason, r.created_at FROM reservations r JOIN faculty f ON f.id=r.faculty_id JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id WHERE f.username=? AND (r.status="Cancelled" OR r.status="Declined") ORDER BY r.created_at DESC');
    $stmt->bind_param('s', $username);
  } else {
    // Admin and GenServe can see all reservations
    $stmt = $db->prepare('SELECT r.id, f.fullname AS faculty, e.name AS equipment, c.name AS category, r.date, r.time, r.status, r.cancel_reason, r.decline_reason, r.created_at FROM reservations r JOIN faculty f ON f.id=r.faculty_id JOIN equipment e ON e.id=r.equipment_id JOIN equipment_categories c ON c.id=r.category_id WHERE (r.status="Cancelled" OR r.status="Declined") ORDER BY r.created_at DESC');
  }
  
  $stmt->execute();
  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
    $reason = '';
    if ($row['status'] === 'Cancelled' && $row['cancel_reason']) {
      $reason = $row['cancel_reason'];
    } elseif ($row['status'] === 'Declined' && $row['decline_reason']) {
      $reason = $row['decline_reason'];
    }
    
    if ($reason) {
      $reasons[] = [
        'id' => $row['id'],
        'type' => 'Equipment',
        'faculty' => $row['faculty'],
        'equipment' => $row['equipment'],
        'category' => $row['category'],
        'date' => $row['date'],
        'time' => $row['time'],
        'status' => $row['status'],
        'reason' => $reason,
        'created_at' => $row['created_at']
      ];
    }
  }
  $stmt->close();
  
  // Get gym reservations with reasons
  if ($role === 'faculty' && $username) {
    // Faculty can only see their own gym reservations
    $stmt = $db->prepare('SELECT gr.id, f.fullname AS faculty, gr.title, gr.date, gr.time, gr.status, gr.cancel_reason, gr.decline_reason, gr.created_at FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE f.username=? AND (gr.status="Cancelled" OR gr.status="Declined") ORDER BY gr.created_at DESC');
    $stmt->bind_param('s', $username);
  } else {
    // Admin and GenServe can see all gym reservations
    $stmt = $db->prepare('SELECT gr.id, f.fullname AS faculty, gr.title, gr.date, gr.time, gr.status, gr.cancel_reason, gr.decline_reason, gr.created_at FROM gym_reservations gr JOIN faculty f ON f.id=gr.faculty_id WHERE (gr.status="Cancelled" OR gr.status="Declined") ORDER BY gr.created_at DESC');
  }
  
  $stmt->execute();
  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
    $reason = '';
    if ($row['status'] === 'Cancelled' && $row['cancel_reason']) {
      $reason = $row['cancel_reason'];
    } elseif ($row['status'] === 'Declined' && $row['decline_reason']) {
      $reason = $row['decline_reason'];
    }
    
    if ($reason) {
      $reasons[] = [
        'id' => $row['id'],
        'type' => 'Gym',
        'faculty' => $row['faculty'],
        'equipment' => $row['title'],
        'category' => 'Gym Reservation',
        'date' => $row['date'],
        'time' => $row['time'],
        'status' => $row['status'],
        'reason' => $reason,
        'created_at' => $row['created_at']
      ];
    }
  }
  $stmt->close();
  
  // Sort by created_at descending
  usort($reasons, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
  });
  
  echo json_encode($reasons);
  exit;
}

echo json_encode(['ok' => false, 'error' => 'Unknown action']);
?>
