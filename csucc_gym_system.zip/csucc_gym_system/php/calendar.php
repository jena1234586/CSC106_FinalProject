<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar - CSUCC Gym Reservation System</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
      body.page-wrap { display:flex; flex-direction:column; min-height:100vh; margin:0; padding:0; background:linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #f1f5f9 100%); }
      .content-container { width:100%; margin:0; padding:0; flex:1 0 auto; }
      
      /* Header */
      .top-mini-header { display:flex; align-items:center; justify-content:space-between; padding:10px 16px; background:#0d5016; color:#fff; }
      .top-mini-header .brand { display:flex; align-items:center; gap:10px; font-weight:700; }
      .top-mini-header img { width:28px; height:28px; border-radius:50%; object-fit:cover; object-position:center; margin:0; padding:0; display:block; }
      .top-mini-header .back-btn { background:#2d7a2d; color:#fff; border:none; padding:6px 12px; border-radius:8px; cursor:pointer; font-size:13px; text-decoration:none; display:inline-flex; align-items:center; gap:6px; }
      .top-mini-header .back-btn:hover { background:#38a169; }
      
      .calendar-page-header { background:#0a5d0a; color:#fff; padding:20px 16px; text-align:center; }
      .calendar-page-header h1 { font-size:24px; margin:0 0 8px; }
      .calendar-page-header p { opacity:.9; margin:0; font-size:14px; }
      
      .calendar-main-content { max-width: 1200px; margin: 30px auto 40px; padding: 0 16px; }
      .calendar-section { background:#fff; padding:30px; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
      .calendar-section h2 { margin:0 0 20px; color:#1d4ed8; font-size:22px; }
    </style>
</head>
<body class="page-wrap">
    <div class="content-container">
        <div class="top-mini-header">
            <div class="brand">
                <img src="../images/logo.webp" alt="CSUCC Logo">
                <span>CSUCC</span>
            </div>
            <a class="back-btn" href="index.php"><i class="fas fa-arrow-left"></i> Back to Home</a>
        </div>

        <div class="calendar-page-header">
            <h1>📅 Reservation Calendar</h1>
            <p>View gym reservations and announcements</p>
        </div>

        <div class="calendar-main-content">
            <div class="calendar-section">
                <h2>Calendar View</h2>
                <div id="calendarContainer" style="margin-top: 20px;">
                    <div id="calendar" style="max-width: 1000px; margin: 0 auto;">
                        <!-- Calendar will be generated here -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Date Details Modal -->
        <div id="dateDetailsModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="dateDetailsTitle">Reservations &amp; Announcements for <span id="selectedDateDisplay"></span></h3>
                    <span class="close" onclick="closeModal('dateDetailsModal')">&times;</span>
                </div>
                <div class="modal-body">
                    <div id="dateDetailsContent">
                        <p class="text-muted">Loading...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" onclick="closeModal('dateDetailsModal')">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div id="notification" class="notification"></div>

    <script src="../js/script.js"></script>
    <script>
        // Custom calendar loader for public calendar page - only shows gym reservations and announcements
        let publicCalendarMonth = new Date().getMonth();
        let publicCalendarYear = new Date().getFullYear();
        let publicReservationsByDate = {};

        async function loadPublicCalendar() {
            const calendarContainer = document.getElementById('calendar');
            if (!calendarContainer) return;
            
            await fetchPublicReservationsForMonth(publicCalendarYear, publicCalendarMonth);
            generatePublicCalendar(publicCalendarYear, publicCalendarMonth);
        }

        async function fetchPublicReservationsForMonth(year, month) {
            try {
                // Only fetch gym reservations and announcements (exclude equipment reservations)
                const [gymResp, announcementsResp] = await Promise.all([
                    fetch('api.php?action=listAllGymReservations'),
                    fetch('api.php?action=listAnnouncements')
                ]);
                
                const gymData = await gymResp.json();
                const announcementsData = await announcementsResp.json();
                
                // Reset cache
                publicReservationsByDate = {};
                
                // Process gym reservations only
                if (gymData && Array.isArray(gymData)) {
                    gymData.forEach(res => {
                        if (res.status === 'Approved' && res.date) {
                            const resDate = new Date(res.date);
                            if (resDate.getFullYear() === year && resDate.getMonth() === month) {
                                const dateKey = res.date;
                                if (!publicReservationsByDate[dateKey]) {
                                    publicReservationsByDate[dateKey] = { gym: [], announcements: [] };
                                }
                                publicReservationsByDate[dateKey].gym.push({
                                    id: res.id,
                                    title: res.title,
                                    time: res.time,
                                    equipmentItems: res.equipmentItems || []
                                });
                            }
                        }
                    });
                }
                
                // Process announcements
                if (announcementsData && Array.isArray(announcementsData)) {
                    announcementsData.forEach(ann => {
                        if (ann.startDate && ann.endDate) {
                            const startDate = new Date(ann.startDate);
                            const endDate = new Date(ann.endDate);
                            
                            // Check if announcement overlaps with the current month
                            const monthStart = new Date(year, month, 1);
                            const monthEnd = new Date(year, month + 1, 0);
                            
                            if (endDate >= monthStart && startDate <= monthEnd) {
                                // Add announcement to all dates in its range that are in this month
                                const currentDate = new Date(Math.max(startDate, monthStart));
                                const lastDate = new Date(Math.min(endDate, monthEnd));
                                
                                while (currentDate <= lastDate) {
                                    const dateKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
                                    if (!publicReservationsByDate[dateKey]) {
                                        publicReservationsByDate[dateKey] = { gym: [], announcements: [] };
                                    }
                                    publicReservationsByDate[dateKey].announcements.push({
                                        id: ann.id,
                                        title: ann.title,
                                        message: ann.message,
                                        startDate: ann.startDate,
                                        startTime: ann.startTime,
                                        endDate: ann.endDate,
                                        endTime: ann.endTime
                                    });
                                    currentDate.setDate(currentDate.getDate() + 1);
                                }
                            }
                        }
                    });
                }
            } catch (e) {
                console.error('Error fetching public reservations:', e);
            }
        }

        function generatePublicCalendar(year, month) {
            const calendarContainer = document.getElementById('calendar');
            if (!calendarContainer) return;
            
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const firstDay = new Date(year, month, 1).getDay();
            const today = new Date();
            const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;
            
            let html = `
                <div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
                    <button class="btn btn-secondary" onclick="changePublicCalendarMonth(-1)">
                        <i class="fas fa-chevron-left"></i> Previous
                    </button>
                    <h3 style="margin: 0; color: #1d4ed8;">${monthNames[month]} ${year}</h3>
                    <button class="btn btn-secondary" onclick="changePublicCalendarMonth(1)">
                        Next <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
                <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 8px; margin-bottom: 10px;">
                    <div style="text-align: center; font-weight: bold; color: #1d4ed8; padding: 8px;">Sun</div>
                    <div style="text-align: center; font-weight: bold; color: #1d4ed8; padding: 8px;">Mon</div>
                    <div style="text-align: center; font-weight: bold; color: #1d4ed8; padding: 8px;">Tue</div>
                    <div style="text-align: center; font-weight: bold; color: #1d4ed8; padding: 8px;">Wed</div>
                    <div style="text-align: center; font-weight: bold; color: #1d4ed8; padding: 8px;">Thu</div>
                    <div style="text-align: center; font-weight: bold; color: #1d4ed8; padding: 8px;">Fri</div>
                    <div style="text-align: center; font-weight: bold; color: #1d4ed8; padding: 8px;">Sat</div>
                </div>
                <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 8px;">
            `;
            
            // Empty cells for days before the first day of the month
            for (let i = 0; i < firstDay; i++) {
                html += `<div style="padding: 15px; min-height: 60px;"></div>`;
            }
            
            // Days of the month
            for (let day = 1; day <= daysInMonth; day++) {
                const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const dateData = publicReservationsByDate[dateKey] || { gym: [], announcements: [] };
                const gymCount = dateData.gym ? dateData.gym.length : 0;
                const announcementCount = dateData.announcements ? dateData.announcements.length : 0;
                const totalItems = gymCount + announcementCount;
                
                const isToday = isCurrentMonth && day === today.getDate();
                let borderColor = '#e5e7eb';
                let bgColor = '#ffffff';
                
                if (totalItems > 0) {
                    borderColor = '#9333ea';
                }
                
                if (isToday) {
                    bgColor = '#dbeafe';
                }
                
                html += `
                    <div onclick="showPublicDateDetails('${dateKey}')" 
                         style="padding: 15px; min-height: 60px; border: 2px solid ${borderColor}; 
                                border-radius: 8px; cursor: pointer; background: ${bgColor};
                                transition: all 0.2s; position: relative;"
                         onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.15)'"
                         onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='none'">
                        <div style="font-weight: ${isToday ? 'bold' : 'normal'}; font-size: 16px; color: ${isToday ? '#1d4ed8' : '#1f2937'};">
                            ${day}
                        </div>
                        ${totalItems > 0 ? `
                            <div style="margin-top: 5px; font-size: 11px; color: ${announcementCount > 0 && gymCount > 0 ? '#9333ea' : announcementCount > 0 ? '#f59e0b' : '#1d4ed8'};">
                                <i class="fas fa-circle" style="font-size: 6px;"></i>
                                ${totalItems} item${totalItems !== 1 ? 's' : ''}
                            </div>
                        ` : ''}
                    </div>
                `;
            }
            
            html += `</div>`;
            calendarContainer.innerHTML = html;
        }

        async function changePublicCalendarMonth(direction) {
            publicCalendarMonth += direction;
            if (publicCalendarMonth < 0) {
                publicCalendarMonth = 11;
                publicCalendarYear--;
            } else if (publicCalendarMonth > 11) {
                publicCalendarMonth = 0;
                publicCalendarYear++;
            }
            
            await fetchPublicReservationsForMonth(publicCalendarYear, publicCalendarMonth);
            generatePublicCalendar(publicCalendarYear, publicCalendarMonth);
        }

        async function showPublicDateDetails(dateKey) {
            const modal = document.getElementById('dateDetailsModal');
            const titleElement = document.getElementById('selectedDateDisplay');
            const contentElement = document.getElementById('dateDetailsContent');
            
            if (!modal || !titleElement || !contentElement) return;
            
            // Format date for display
            const date = new Date(dateKey);
            const formattedDate = date.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            titleElement.textContent = formattedDate;
            
            contentElement.innerHTML = '<p class="text-muted">Loading...</p>';
            openModal('dateDetailsModal');
            
            try {
                // Use cached data or fetch if needed
                let reservations = publicReservationsByDate[dateKey];
                
                if (!reservations) {
                    // Fetch for this specific date
                    const resp = await fetch(`api.php?action=getReservationsByDate&date=${dateKey}`);
                    const data = await resp.json();
                    reservations = {
                        gym: data.gymReservations || [],
                        announcements: data.announcements || []
                    };
                } else {
                    // Ensure structure
                    if (!reservations.gym) reservations.gym = [];
                    if (!reservations.announcements) reservations.announcements = [];
                }
                
                let html = '';
                
                // Only show gym reservations and announcements
                const announcements = reservations.announcements || [];
                const gymReservations = reservations.gym || [];
                const hasContent = gymReservations.length > 0 || announcements.length > 0;
                
                if (!hasContent) {
                    html = '<p class="text-muted">No gym reservations or announcements for this date.</p>';
                } else {
                    // Show announcements first
                    if (announcements.length > 0) {
                        html += '<div style="margin-bottom: 20px;"><h4 style="color: #f59e0b; margin-bottom: 10px;"><i class="fas fa-bullhorn"></i> Announcements</h4>';
                        announcements.forEach(ann => {
                            html += `
                                <div style="padding: 15px; background: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 4px; margin-bottom: 10px;">
                                    <strong style="color: #92400e;">${escapeHtml(ann.title)}</strong>
                                    <p style="margin: 8px 0 0; color: #78350f;">${escapeHtml(ann.message)}</p>
                                    ${ann.startTime ? `<small style="color: #92400e;"><i class="fas fa-clock"></i> ${escapeHtml(ann.startTime)}</small>` : ''}
                                </div>
                            `;
                        });
                        html += '</div>';
                    }
                    
                    // Show gym reservations
                    if (gymReservations.length > 0) {
                        html += '<div><h4 style="color: #1d4ed8; margin-bottom: 10px;"><i class="fas fa-dumbbell"></i> Gym Reservations</h4>';
                        gymReservations.forEach(res => {
                            const equipmentText = res.equipmentItems && res.equipmentItems.length > 0
                                ? res.equipmentItems.map(item => `${item.quantity}x ${item.equipment}`).join(', ')
                                : 'No equipment listed';
                            html += `
                                <div style="padding: 15px; background: #dbeafe; border-left: 4px solid #1d4ed8; border-radius: 4px; margin-bottom: 10px;">
                                    <strong style="color: #1e40af;">${escapeHtml(res.title || 'Gym Reservation')}</strong>
                                    <p style="margin: 8px 0; color: #1e3a8a;"><i class="fas fa-clock"></i> ${escapeHtml(res.time)}</p>
                                    <p style="margin: 0; color: #1e3a8a;"><i class="fas fa-boxes"></i> ${escapeHtml(equipmentText)}</p>
                                </div>
                            `;
                        });
                        html += '</div>';
                    }
                }
                
                contentElement.innerHTML = html;
            } catch (e) {
                console.error('Error loading date details:', e);
                contentElement.innerHTML = '<p class="text-muted">Error loading reservations for this date.</p>';
            }
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Initialize calendar when page loads
        if (document.getElementById('calendar')) {
            loadPublicCalendar();
        }
    </script>
</body>
</html>

