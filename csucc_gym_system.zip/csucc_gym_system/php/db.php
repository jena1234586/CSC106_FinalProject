<?php
// Basic MySQL connection helper for XAMPP
// Adjust credentials if you have a custom setup

function db_connect() {
    $host = '127.0.0.1';
    $user = 'root';
    $pass = '';
    $db   = 'database';

    $mysqli = new mysqli($host, $user, $pass, $db);
    if ($mysqli->connect_errno) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'DB connection failed: '.$mysqli->connect_error]);
        exit;
    }
    $mysqli->set_charset('utf8mb4');
    return $mysqli;
}

?>


