<?php
// Simple file-based persistence for faculty accounts
// Endpoints:
//   GET  faculty-api.php?action=read  -> returns JSON array of faculty
//   POST faculty-api.php?action=write (body: raw JSON array) -> saves and returns {ok:true}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : 'read';
$dataDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data';
$dataFile = $dataDir . DIRECTORY_SEPARATOR . 'faculty.json';

if (!file_exists($dataDir)) {
    @mkdir($dataDir, 0777, true);
}

if ($action === 'read') {
    if (!file_exists($dataFile)) {
        echo json_encode([]);
        exit;
    }
    $json = file_get_contents($dataFile);
    if ($json === false) {
        echo json_encode([]);
        exit;
    }
    echo $json;
    exit;
}

if ($action === 'write' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    // Basic validation: must be a JSON array
    $decoded = json_decode($input, true);
    if (!is_array($decoded)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
        exit;
    }
    file_put_contents($dataFile, json_encode($decoded, JSON_PRETTY_PRINT));
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
?>


