<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <h2>Faculty Dashboard</h2>
        <ul>
            <li onclick="showSection('home')">
                <i class="fas fa-home"></i>
                Home
            </li>
            <li onclick="showSection('browse')">
                <i class="fas fa-search"></i>
                Browse Equipment
            </li>
            <li onclick="showSection('reservations')">
                <i class="fas fa-calendar-check"></i>
                Equipment Request
            </li>
            <li onclick="showSection('gymReservations')">
                <i class="fas fa-dumbbell"></i>
                Gym Reservations
            </li>
            <li onclick="showSection('announcements')" id="sidebarAnnouncementsItem">
                <i class="fas fa-bullhorn"></i>
                Announcements
                <span id="sidebarAnnBadge" class="menu-badge" style="display:none;">0</span>
            </li>
            <li onclick="showSection('report')">
                <i class="fas fa-exclamation-triangle"></i>
                Submit Report
            </li>
            <li onclick="showSection('reasons')">
                <i class="fas fa-clipboard-list"></i>
                Cancellation Reasons
            </li>
            <li onclick="showSection('messenger')">
                <i class="fas fa-comments"></i>
                Messenger
                <span id="chatBadge" class="menu-badge" style="display:none;">0</span>
            </li>
            <li onclick="logout()">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div class="header-bar">
            <h2>Welcome, Faculty!</h2>
            <div class="notification-bell" onclick="showAllNotifications()">
                <i class="fas fa-bell"></i>
                <span id="notificationBadge" class="notification-badge" style="display: none;">0</span>
            </div>
        </div>
        
        <section id="home" class="active-section">
            <h2>📅 Calendar View</h2>
            <div id="calendarContainer" style="margin-top: 20px;">
                <div id="calendar" style="max-width: 1000px; margin: 0 auto;">
                    <!-- Calendar will be generated here -->
                </div>
            </div>
            
            <!-- Date Details Modal -->
            <div id="dateDetailsModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="dateDetailsTitle">Reservations for <span id="selectedDateDisplay"></span></h3>
                        <span class="close" onclick="closeModal('dateDetailsModal')">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div id="dateDetailsContent">
                            <p class="text-muted">Loading...</p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="closeModal('dateDetailsModal')">Close</button>
                    </div>
                </div>
            </div>
        </section>

        <section id="browse">
            <h2>Browse Equipment by Category</h2>
            <div class="categories" id="categoryCards">
                <!-- Categories will be dynamically generated here -->
            </div>
            <div id="equipmentList"></div>
        </section>

        <section id="reservations">
            <h2>My Reservations</h2>
            <table id="myReservationTable">
                <thead>
                    <tr>
                        <th>Equipment</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="gymReservations">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Gym Reservations</h2>
                <button class="btn btn-primary" onclick="openGymReservationModal()">
                    <i class="fas fa-plus"></i>
                    New Gym Reservation
                </button>
            </div>
            <table id="gymReservationTable">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Equipment</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="announcements">
            <h2>Announcements</h2>
            <div id="announcementList" class="announcement-list"></div>
        </section>

        <section id="report">
            <h2>Submit Report</h2>
            <form id="reportForm">
                <div class="form-group">
                    <label for="reportEquipment">Equipment Name</label>
                    <input type="text" placeholder="Enter equipment name" id="reportEquipment" required>
                </div>
                <div class="form-group">
                    <label for="reportDesc">Issue Description</label>
                    <textarea placeholder="Describe the issue in detail" id="reportDesc" required></textarea>
                </div>
                <button type="submit" class="btn btn-warning">
                    <i class="fas fa-paper-plane"></i>
                    Submit Report
                </button>
            </form>
            
            <div class="report-history-section">
                <h3>📋 My Report History</h3>
                <table id="reportHistoryTable">
                    <thead>
                        <tr>
                            <th>Equipment</th>
                            <th>Description</th>
                            <th>Date Submitted</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </section>

        <section id="reasons">
            <h2>Cancellation & Decline Reasons</h2>
            <p style="color: #666; margin-bottom: 20px;">View all your cancellation and decline reasons with details.</p>
            <div class="reason-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="reason-filter-btn active" data-type="all" onclick="filterReasonsByType('all')">
                    <i class="fas fa-list"></i> All Reasons
                </button>
                <button class="reason-filter-btn" data-type="cancelled" onclick="filterReasonsByType('cancelled')">
                    <i class="fas fa-ban"></i> My Cancellations
                </button>
                <button class="reason-filter-btn" data-type="declined" onclick="filterReasonsByType('declined')">
                    <i class="fas fa-times-circle"></i> Admin/GenServe Declines
                </button>
            </div>
            <div id="reasonCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="reasonsTable">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Equipment/Title</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Reason</th>
                        <th>Action Date</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="messenger">
            <h2>💬 Messenger</h2>
            <div class="messenger-container">
                <div class="messenger-sidebar">
                    <div class="messenger-header">
                        <h3>Conversations</h3>
                        <div class="messenger-tabs">
                            <button class="tab-btn active" data-chat-filter="admin" onclick="setChatFilter('admin')">Admin</button>
                            <button class="tab-btn" data-chat-filter="genserve" onclick="setChatFilter('genserve')">GenServe</button>
                        </div>
                    </div>
                    <div class="messenger-search">
                        <input type="text" id="chatSearchInput" placeholder="Search Admin contacts..." autocomplete="off">
                    </div>
                    <div class="conversations-list" id="facultyConversationsList">
                        <p class="text-muted">Loading conversations...</p>
                    </div>
                </div>
                <div class="messenger-main">
                    <div class="chat-header" id="chatHeader" style="display:none;">
                        <div class="chat-user-info">
                            <div class="chat-avatar">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <h4 id="chatUserName"></h4>
                                <small id="chatUserEmail" class="text-muted"></small>
                            </div>
                        </div>
                    </div>
                    <div class="chat-messages" id="chatMessages">
                        <div class="chat-empty-state">
                            <i class="fas fa-comments"></i>
                            <p>Select a conversation to start chatting</p>
                        </div>
                    </div>
                    <div class="chat-input-container" id="chatInputContainer" style="display:none;">
                        <form id="chatMessageForm">
                            <input type="text" id="chatMessageInput" placeholder="Type a message..." autocomplete="off">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Reservation Modal -->
    <div id="reservationModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Make Equipment Reservation</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body">
                <form id="reservationForm" class="modal-form-grid">
                    <div class="form-group">
                        <label for="reservationEquipment">Equipment</label>
                        <input type="text" id="reservationEquipment" readonly>
                    </div>
                    <div class="form-group">
                        <label for="reservationCategory">Category</label>
                        <input type="text" id="reservationCategory" readonly>
                    </div>
                    <div class="form-group">
                        <label for="reservationStartDate">Start Date</label>
                        <input type="date" id="reservationStartDate" required>
                    </div>
                    <div class="form-group" id="reservationEndDateGroup">
                        <label for="reservationEndDate">End Date</label>
                        <input type="date" id="reservationEndDate" required>
                    </div>
                    <div class="form-group">
                        <label for="reservationDays">Number of Days</label>
                        <input type="number" id="reservationDays" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="reservationTime">Time Range</label>
                        <input type="text" id="reservationTime" placeholder="e.g., 8:00-10:00 AM" required>
                        <small class="hint-text">Enter time range (e.g., 8:00-10:00 AM, 1:00-3:00 PM)</small>
                    </div>
                    <div class="form-group">
                        <label for="reservationQuantity">Quantity</label>
                        <input type="number" id="reservationQuantity" min="1" max="10" value="1" required>
                    </div>
                    <div class="form-group full-width">
                        <label for="reservationPurpose">Purpose</label>
                        <textarea id="reservationPurpose" placeholder="Describe the purpose of this reservation" required></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="closeModal('reservationModal')">Cancel</button>
                <button type="button" class="btn btn-success" onclick="submitReservation()">
                    <i class="fas fa-check"></i>
                    Submit Reservation
                </button>
            </div>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="notificationModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Notifications</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body">
                <div id="facultyNotificationList" class="notification-list"></div>
            </div>
        </div>
    </div>

    <!-- Gym Reservation Modal -->
    <div id="gymReservationModal" class="modal">
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h3 id="gymReservationModalTitle">New Gym Reservation</h3>
                <span class="close" onclick="closeModal('gymReservationModal')">&times;</span>
            </div>
            <div class="modal-body">
                <form id="gymReservationForm" class="modal-form-grid">
                    <input type="hidden" id="gymReservationId" value="">
                    <div class="form-group full-width">
                        <label for="gymReservationTitle">Title / Purpose</label>
                        <input type="text" id="gymReservationTitle" placeholder="Enter title or purpose" required>
                    </div>
                    <div class="form-group">
                        <label for="gymReservationStartDate">Start Date</label>
                        <input type="date" id="gymReservationStartDate" required>
                    </div>
                    <div class="form-group" id="gymReservationEndDateGroup">
                        <label for="gymReservationEndDate">End Date</label>
                        <input type="date" id="gymReservationEndDate" required>
                    </div>
                    <div class="form-group">
                        <label for="gymReservationDays">Number of Days</label>
                        <input type="number" id="gymReservationDays" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="gymReservationTime">Time Range</label>
                        <input type="text" id="gymReservationTime" placeholder="e.g., 8:00-10:00 AM" required>
                        <small class="hint-text">Enter time range (e.g., 8:00-10:00 AM, 1:00-3:00 PM)</small>
                    </div>
                    <div class="form-group full-width">
                        <label>Equipment Items</label>
                        <div id="gymEquipmentItemsList"></div>
                        <button type="button" class="btn btn-secondary" onclick="addEquipmentItem()" style="margin-top: 10px;">
                            <i class="fas fa-plus"></i>
                            Add Equipment
                        </button>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="closeModal('gymReservationModal')">Cancel</button>
                <button type="button" class="btn btn-success" onclick="submitGymReservation()">
                    <i class="fas fa-check"></i>
                    Submit Reservation
                </button>
            </div>
        </div>
    </div>

    <!-- Reason Capture Modal -->
    <div id="reasonModal" class="modal">
        <div class="modal-content" style="max-width: 520px;">
            <div class="modal-header">
                <h3 id="reasonModalTitle">Provide Reason</h3>
                <span class="close" onclick="cancelReasonModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p id="reasonModalDescription" class="text-muted" style="margin-bottom: 12px;"></p>
                <textarea id="reasonModalInput" rows="4" style="width: 100%; padding: 10px;" placeholder="Enter your reason..."></textarea>
                <small id="reasonModalHint" class="hint-text">This note will be recorded for this action.</small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="cancelReasonModal()">Back</button>
                <button type="button" class="btn btn-danger reason-confirm-btn" onclick="submitReasonModal()">
                    <i class="fas fa-paper-plane"></i> Submit
                </button>
            </div>
        </div>
    </div>

    <div id="notification" class="notification"></div>

    <script src="../js/script.js"></script>
</body>
</html>
