<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GenServe Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="sidebar">
        <h2>GenServe Dashboard</h2>
        <ul>
            <li onclick="showSection('dashboard')">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </li>
            <li onclick="showSection('reservation')">
                <i class="fas fa-calendar-check"></i>
                Equipment Requests
            </li>
            <li onclick="showSection('gymReservations')">
                <i class="fas fa-dumbbell"></i>
                Gym Reserved Details
            </li>
            <li onclick="showSection('returns')">
                <i class="fas fa-undo"></i>
                Returns
                <span id="returnsBadge" class="menu-badge" style="display:none;">0</span>
            </li>
            <li onclick="showSection('inventory')">
                <i class="fas fa-boxes"></i>
                Equipment Inventory
            </li>
            <li onclick="showSection('reports')">
                <i class="fas fa-exclamation-triangle"></i>
                Reports
            </li>
            <li onclick="showSection('notifications')">
                <i class="fas fa-bell"></i>
                Notifications
                <span id="notificationBadge" class="menu-badge" style="display:none;">0</span>
            </li>
            <li onclick="showSection('reasons')">
                <i class="fas fa-clipboard-list"></i>
                Cancellation Reasons
            </li>
            <li onclick="showSection('messenger')">
                <i class="fas fa-comments"></i>
                Messenger
                <span id="chatBadge" class="menu-badge" style="display:none;">0</span>
            </li>
            <li onclick="logout()">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </li>
        </ul>
    </div>

    <div class="main-content">
        <section id="dashboard" class="active-section">
            <h2>Welcome, System Administrator!</h2>
            <div class="cards">
                <div class="card">
                    <i class="fas fa-boxes"></i>
                    <h3>Available Equipment</h3>
                    <p id="availableEquipment">0</p>
                </div>
                <div class="card">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Active Reports</h3>
                    <p id="activeReports">0</p>
                </div>
            </div>
        </section>

        <section id="reservation">
            <h2>Reservation Requests</h2>
            <div class="reservation-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="reservation-filter-btn active" data-category="all" onclick="filterGenServeReservationsByCategory('all')">
                    <i class="fas fa-list"></i> All Reservations
                </button>
            </div>
            <div id="reservationCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="reservationTable">
                <thead>
                    <tr>
                        <th>Faculty</th>
                        <th>Equipment Item</th>
                        <th>Category</th>
                        <th>Reservation Date</th>
                        <th>Time</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="gymReservations">
            <h2>Gym Reservations</h2>
            <div class="reservation-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="reservation-filter-btn active" data-category="all" onclick="filterGymReservationsByCategory('all')">
                    <i class="fas fa-list"></i> All Gym Reservations
                </button>
            </div>
            <div id="gymReservationCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="gymReservationTable">
                <thead>
                    <tr>
                        <th>Faculty</th>
                        <th>Title/Purpose</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Equipment Items</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="returns">
            <h2>Pending Returns</h2>
            <div class="reservation-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="reservation-filter-btn active" data-return-type="all" onclick="filterReturnsByType('all')">
                    <i class="fas fa-list"></i> All Returns
                </button>
                <button class="reservation-filter-btn" data-return-type="equipment" onclick="filterReturnsByType('equipment')">
                    <i class="fas fa-boxes"></i> Equipment Returns
                </button>
                <button class="reservation-filter-btn" data-return-type="gym" onclick="filterReturnsByType('gym')">
                    <i class="fas fa-dumbbell"></i> Gym Returns
                </button>
            </div>
            <div id="returnsCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="returnsTable">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Faculty</th>
                        <th>Equipment Item / Title</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Reservation Date</th>
                        <th>Time</th>
                        <th>Return Requested</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="inventory">
            <h2>Equipment Inventory</h2>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <button class="btn" onclick="addEquipment()">Add New Equipment</button>
                <div style="position: relative; width: 300px;">
                    <input type="text" id="equipmentSearchInput" placeholder="Search equipment..." 
                           style="width: 100%; padding: 10px 40px 10px 15px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px;">
                    <i class="fas fa-search" style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: #888;"></i>
                </div>
            </div>
            <div class="equipment-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="equipment-filter-btn active" data-category="all" onclick="filterGenServeEquipmentByCategory('all')">
                    <i class="fas fa-list"></i> All Equipment
                </button>
            </div>
            <div id="equipmentCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="equipmentTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="reports">
            <h2>Damage/Loss Reports</h2>
            <table id="reportTable">
                <thead>
                    <tr>
                        <th>Faculty</th>
                        <th>Equipment</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="notifications">
            <h2>📬 Notifications</h2>
            
            <!-- Calendar View -->
            <div style="margin-bottom: 30px;">
                <h3 style="margin-bottom: 15px; color: #1d4ed8;">📅 Calendar View</h3>
                <div id="genserveCalendarContainer" style="margin-top: 20px;">
                    <div id="genserveCalendar" style="max-width: 1000px; margin: 0 auto;">
                        <!-- Calendar will be generated here -->
                    </div>
                </div>
            </div>
            
            <!-- Date Details Modal -->
            <div id="genserveDateDetailsModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="genserveDateDetailsTitle">Reservations & Announcements for <span id="genserveSelectedDateDisplay"></span></h3>
                        <span class="close" onclick="closeModal('genserveDateDetailsModal')">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div id="genserveDateDetailsContent">
                            <p class="text-muted">Loading...</p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" onclick="closeModal('genserveDateDetailsModal')">Close</button>
                    </div>
                </div>
            </div>
        </section>

        <section id="reasons">
            <h2>Cancellation & Decline Reasons</h2>
            <p style="color: #666; margin-bottom: 20px;">View all cancellation and decline reasons with details.</p>
            <div class="reason-filters" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="reason-filter-btn active" data-type="all" onclick="filterReasonsByType('all')">
                    <i class="fas fa-list"></i> All Reasons
                </button>
                <button class="reason-filter-btn" data-type="cancelled" onclick="filterReasonsByType('cancelled')">
                    <i class="fas fa-ban"></i> Cancelled (Faculty)
                </button>
                <button class="reason-filter-btn" data-type="declined" onclick="filterReasonsByType('declined')">
                    <i class="fas fa-times-circle"></i> Declined (GenServe)
                </button>
            </div>
            <div id="reasonCategoryCount" style="margin-bottom: 10px; color: #666; font-size: 14px;"></div>
            <table id="reasonsTable">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Faculty</th>
                        <th>Equipment/Title</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Reason</th>
                        <th>Action Date</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </section>

        <section id="messenger">
            <h2>💬 Messenger</h2>
            <div class="messenger-container">
                <div class="messenger-sidebar">
                    <div class="messenger-header">
                        <h3>Conversations</h3>
                        <div class="messenger-tabs">
                            <button class="tab-btn active" data-chat-filter="admin" onclick="setChatFilter('admin')">Admin</button>
                            <button class="tab-btn" data-chat-filter="faculty" onclick="setChatFilter('faculty')">Faculty</button>
                        </div>
                    </div>
                    <div class="messenger-search">
                        <input type="text" id="chatSearchInput" placeholder="Search Admin contacts..." autocomplete="off">
                    </div>
                    <div class="conversations-list" id="adminConversationsList">
                        <p class="text-muted">Loading conversations...</p>
                    </div>
                </div>
                <div class="messenger-main">
                    <div class="chat-header" id="chatHeader" style="display:none;">
                        <div class="chat-user-info">
                            <div class="chat-avatar">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <h4 id="chatUserName"></h4>
                                <small id="chatUserEmail" class="text-muted"></small>
                            </div>
                        </div>
                    </div>
                    <div class="chat-messages" id="chatMessages">
                        <div class="chat-empty-state">
                            <i class="fas fa-comments"></i>
                            <p>Select a conversation to start chatting</p>
                        </div>
                    </div>
                    <div class="chat-input-container" id="chatInputContainer" style="display:none;">
                        <form id="chatMessageForm">
                            <input type="text" id="chatMessageInput" placeholder="Type a message..." autocomplete="off">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div id="notification" class="notification"></div>

    <!-- Add Equipment Modal -->
    <div id="addEquipmentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add New Equipment</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body">
                <form id="addEquipmentForm" class="modal-form-grid">
                    <div class="form-group">
                        <label for="equipmentName">Equipment Name</label>
                        <input type="text" id="equipmentName" placeholder="e.g., Projector" required>
                    </div>
                    <div class="form-group">
                        <label for="equipmentCategory">Category</label>
                        <select id="equipmentCategory" required></select>
                    </div>
                    <div class="form-group" id="newCategoryGroup" style="display: none;">
                        <label for="newCategoryName">New Category Name</label>
                        <input type="text" id="newCategoryName" placeholder="e.g., Networking" />
                    </div>
                    <div class="form-group">
                        <label for="equipmentQuantity">Available Quantity</label>
                        <input type="number" id="equipmentQuantity" min="0" value="0" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="closeModal('addEquipmentModal')">Cancel</button>
                <button type="submit" form="addEquipmentForm" class="btn btn-success">
                    <i class="fas fa-check"></i>
                    Save Equipment
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Equipment Modal -->
    <div id="editEquipmentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add Equipment Quantity</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body">
                <form id="editEquipmentForm">
                    <input type="hidden" id="editEquipmentName">
                    <input type="hidden" id="editEquipmentCategory">
                    
                    <div class="form-group">
                        <label><strong>Equipment:</strong> <span id="displayEquipmentName"></span></label>
                    </div>
                    
                    <div class="form-group">
                        <label><strong>Category:</strong> <span id="displayEquipmentCategory"></span></label>
                    </div>
                    
                    <div class="form-group">
                        <label><strong>Current Available:</strong> <span id="displayCurrentAvailable"></span></label>
                    </div>
                    
                    <div class="form-group">
                        <label for="additionalQuantity"><strong>Additional Quantity</strong></label>
                        <input type="number" id="additionalQuantity" min="0" value="0" required>
                        <small class="hint-text">Enter the number of equipment to add</small>
                    </div>
                    
                    <div class="info-box">
                        <i class="fas fa-info-circle"></i>
                        <p><strong>Note:</strong> The additional quantity will be added to the current available quantity. Faculty will see the changes immediately.</p>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" onclick="closeModal('editEquipmentModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" form="editEquipmentForm" class="btn btn-success">
                    <i class="fas fa-plus"></i> Add Quantity
                </button>
            </div>
        </div>
    </div>

    <!-- Reason Capture Modal -->
    <div id="reasonModal" class="modal">
        <div class="modal-content" style="max-width: 520px;">
            <div class="modal-header">
                <h3 id="reasonModalTitle">Provide Reason</h3>
                <span class="close" onclick="cancelReasonModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p id="reasonModalDescription" class="text-muted" style="margin-bottom: 12px;"></p>
                <textarea id="reasonModalInput" rows="4" style="width: 100%; padding: 10px;" placeholder="Enter your reason..."></textarea>
                <small id="reasonModalHint" class="hint-text">This note will be recorded for this action.</small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="cancelReasonModal()">Back</button>
                <button type="button" class="btn btn-danger reason-confirm-btn" onclick="submitReasonModal()">
                    <i class="fas fa-paper-plane"></i> Submit
                </button>
            </div>
        </div>
    </div>

    <script src="../js/script.js"></script>
    <script>
        // Ensure escapeHtml is available (fallback if script.js doesn't load)
        if (typeof escapeHtml === 'undefined') {
            function escapeHtml(text) {
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
        }
        
        // Ensure formatChatTime is available (fallback if script.js doesn't load)
        if (typeof formatChatTime === 'undefined') {
            function formatChatTime(timestamp) {
                const date = new Date(timestamp);
                const now = new Date();
                const diff = now - date;
                const seconds = Math.floor(diff / 1000);
                const minutes = Math.floor(seconds / 60);
                const hours = Math.floor(minutes / 60);
                const days = Math.floor(hours / 24);
                
                if (seconds < 60) return 'Just now';
                if (minutes < 60) return `${minutes}m ago`;
                if (hours < 24) return `${hours}h ago`;
                if (days < 7) return `${days}d ago`;
                
                return date.toLocaleDateString();
            }
        }
        
        // GenServe Dashboard JavaScript
        const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
        if (!loggedGenServe) {
            window.location.href = 'login.php';
        }
        
        // Set currentUser in sessionStorage for shared chat system (same as Admin)
        if (loggedGenServe) {
            sessionStorage.setItem('currentUser', JSON.stringify({
                role: 'genserve',
                id: loggedGenServe.id,
                username: loggedGenServe.username,
                fullname: loggedGenServe.fullname,
                email: loggedGenServe.email
            }));
        }

        // Update welcome message
        const welcomeElement = document.querySelector('#dashboard h2');
        if (welcomeElement && loggedGenServe) {
            welcomeElement.textContent = `Welcome, ${loggedGenServe.fullname || 'System Administrator'}!`;
        }

        // Load stats
        async function loadGenServeStats() {
            try {
                const resp = await fetch('api.php?action=genserveStats');
                const data = await resp.json();
                if (data) {
                    document.getElementById('availableEquipment').textContent = data.availableEquipment || 0;
                    document.getElementById('activeReports').textContent = data.activeReports || 0;
                }
            } catch (e) {
                console.error('Failed to load stats:', e);
            }
        }

        // Load pending returns (both equipment and gym)
        async function loadPendingReturns() {
            try {
                // Fetch equipment returns
                const equipmentResp = await fetch('api.php?action=listPendingReturns');
                const equipmentData = await equipmentResp.json();
                
                // Fetch gym returns
                const gymResp = await fetch('api.php?action=listPendingGymReturns');
                let gymData = [];
                try {
                    gymData = await gymResp.json();
                    if (!Array.isArray(gymData)) {
                        gymData = [];
                    }
                } catch (e) {
                    console.log('Gym returns not available yet');
                    gymData = [];
                }
                
                // Combine and mark types
                const allReturns = [];
                if (equipmentData && Array.isArray(equipmentData)) {
                    equipmentData.forEach(item => {
                        allReturns.push({ ...item, returnType: 'equipment' });
                    });
                }
                if (gymData && Array.isArray(gymData)) {
                    gymData.forEach(item => {
                        allReturns.push({ ...item, returnType: 'gym' });
                    });
                }
                
                // Store globally for filtering
                window.allReturnsData = allReturns;
                
                // Update badge
                const returnsBadge = document.getElementById('returnsBadge');
                if (returnsBadge) {
                    const count = allReturns.length;
                    returnsBadge.textContent = count;
                    returnsBadge.style.display = count > 0 ? 'inline-block' : 'none';
                }
                
                // Display all returns by default
                filterReturnsByType('all');
            } catch (e) {
                console.error('Failed to load returns:', e);
                const tbody = document.querySelector('#returnsTable tbody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="9" class="text-muted">Error loading returns</td></tr>';
                }
            }
        }
        
        // Filter returns by type (all, equipment, gym)
        function filterReturnsByType(type) {
            // Update active button
            document.querySelectorAll('#returns .reservation-filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`#returns .reservation-filter-btn[data-return-type="${type}"]`)?.classList.add('active');
            
            const tbody = document.querySelector('#returnsTable tbody');
            const countElement = document.getElementById('returnsCategoryCount');
            
            if (!tbody || !window.allReturnsData) return;
            
            tbody.innerHTML = '';
            
            let filteredReturns = [];
            
            if (type === 'all') {
                filteredReturns = window.allReturnsData;
            } else {
                filteredReturns = window.allReturnsData.filter(r => r.returnType === type);
            }
            
            if (filteredReturns.length === 0) {
                tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No pending returns</td></tr>';
                if (countElement) {
                    countElement.textContent = type === 'all' ? 'No pending returns' : `No pending ${type} returns`;
                }
                return;
            }
            
            // Display returns
            filteredReturns.forEach(returnItem => {
                const row = document.createElement('tr');
                const returnType = returnItem.returnType || 'equipment';
                const faculty = returnItem.faculty || 'Unknown';
                const equipment = returnItem.equipment || returnItem.title || 'N/A';
                const category = returnItem.category || 'N/A';
                const quantity = returnItem.quantity || 0;
                const date = returnItem.date || 'N/A';
                const time = returnItem.time || 'N/A';
                const returnRequestedAt = returnItem.returnRequestedAt ? new Date(returnItem.returnRequestedAt).toLocaleString() : 'N/A';
                
                // For gym returns, show equipment items if available
                let equipmentDisplay = escapeHtml(equipment);
                if (returnType === 'gym' && returnItem.equipmentItems && Array.isArray(returnItem.equipmentItems)) {
                    const itemsText = returnItem.equipmentItems.map(item => 
                        `${item.quantity}x ${item.equipment}`
                    ).join(', ');
                    equipmentDisplay = `<strong>${escapeHtml(equipment)}</strong><br><small>${escapeHtml(itemsText)}</small>`;
                } else {
                    equipmentDisplay = `<strong>${equipmentDisplay}</strong>`;
                }
                
                row.innerHTML = `
                    <td>
                        <span class="badge ${returnType === 'equipment' ? 'badge-info' : 'badge-warning'}">
                            ${returnType === 'equipment' ? '<i class="fas fa-boxes"></i> Equipment' : '<i class="fas fa-dumbbell"></i> Gym'}
                        </span>
                    </td>
                    <td>${escapeHtml(faculty)}</td>
                    <td>${equipmentDisplay}</td>
                    <td><span class="badge badge-info">${escapeHtml(category)}</span></td>
                    <td><strong>${quantity}</strong> ${quantity === 1 ? 'piece' : 'pieces'}</td>
                    <td>${date}</td>
                    <td>${escapeHtml(time)}</td>
                    <td><small>${returnRequestedAt}</small></td>
                    <td>
                        <button class="btn btn-success btn-sm clear-return-btn" 
                                data-id="${returnItem.id}" 
                                data-faculty="${escapeHtml(faculty)}" 
                                data-equipment="${escapeHtml(equipment)}" 
                                data-quantity="${quantity}" 
                                data-type="${returnType}">
                            <i class="fas fa-check"></i> Clear Return
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            // Update count
            if (countElement) {
                const equipmentCount = filteredReturns.filter(r => r.returnType === 'equipment').length;
                const gymCount = filteredReturns.filter(r => r.returnType === 'gym').length;
                if (type === 'all') {
                    countElement.textContent = `Showing all returns: ${filteredReturns.length} total (${equipmentCount} equipment, ${gymCount} gym)`;
                } else {
                    countElement.textContent = `Showing ${filteredReturns.length} ${type} return${filteredReturns.length !== 1 ? 's' : ''}`;
                }
            }
            
            // Attach event listeners to clear return buttons
            tbody.querySelectorAll('.clear-return-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = parseInt(this.getAttribute('data-id'));
                    const faculty = this.getAttribute('data-faculty');
                    const equipment = this.getAttribute('data-equipment');
                    const quantity = parseInt(this.getAttribute('data-quantity'));
                    const returnType = this.getAttribute('data-type') || 'equipment';
                    clearReturn(id, faculty, equipment, quantity, returnType);
                });
            });
        }

        // Clear return (handles both equipment and gym returns)
        async function clearReturn(reservationId, facultyName, equipmentName, quantity, returnType = 'equipment') {
            if (!confirm(`Verify that ${facultyName} has returned ${quantity} ${equipmentName} in correct quantity and complete condition. Clear this return?`)) {
                return;
            }
            
            try {
                const action = returnType === 'gym' ? 'clearGymReturn' : 'clearReturn';
                const resp = await fetch(`api.php?action=${action}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ reservationId: reservationId })
                });
                const data = await resp.json();
                
                if (data.ok && data.reservation) {
                    if (returnType === 'gym') {
                        // For gym returns, notify Admin (not faculty yet - wait for Admin approval)
                        if (typeof createAdminNotification === 'function') {
                            createAdminNotification(
                                'Gym Return Pending Approval',
                                `GenServe verified gym return: ${facultyName} returned "${equipmentName}". Please review and approve/decline.`,
                                'warning'
                            );
                        }
                    } else {
                        // For equipment returns, notify faculty directly
                        if (typeof createFacultyNotification === 'function') {
                            createFacultyNotification(
                                data.reservation.faculty_username || data.reservation.facultyUsername,
                                'Return Cleared',
                                `Your return of ${quantity} ${equipmentName} has been successfully processed and cleared.`,
                                'success'
                            );
                        }
                        
                        // Create notification for admin
                        if (typeof createAdminNotification === 'function') {
                            createAdminNotification(
                                'Return Transaction Cleared',
                                `${facultyName} returned ${quantity} ${equipmentName}. Transaction has been cleared by GenServe.`,
                                'info'
                            );
                        }
                    }
                    
                    // Add audit log
                    if (typeof addAuditLog === 'function') {
                        const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
                        addAuditLog('GenServe', loggedGenServe?.fullname || 'GenServe', `Cleared ${returnType} return: ${facultyName} returned ${quantity} ${equipmentName}`);
                    }
                    
                    // Refresh equipment catalog to reflect inventory update (only for equipment returns)
                    if (returnType === 'equipment') {
                        fetch('api.php?action=getCatalog', { cache: 'no-store' })
                            .then(res => res.json())
                            .then(dbCatalog => {
                                if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                                    // Update localStorage with fresh database data
                                    if (typeof setEquipmentCatalog === 'function') {
                                        setEquipmentCatalog(dbCatalog);
                                    } else {
                                        localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                                    }
                                    // Trigger storage event for real-time sync
                                    window.dispatchEvent(new Event('equipmentUpdated'));
                                }
                            })
                            .catch(err => console.error('Error refreshing catalog:', err));
                        
                        if (typeof window.loadEquipmentInventory === 'function') {
                            window.loadEquipmentInventory();
                        }
                    }
                    
                    // Refresh stats
                    loadGenServeStats();
                    
                    if (returnType === 'gym') {
                        showNotification('Gym return verified! Sent to Admin for final approval.', 'success');
                    } else {
                        showNotification('Return cleared successfully! Inventory updated and notifications sent.', 'success');
                    }
                    loadPendingReturns();
                } else {
                    showNotification(data.error || 'Failed to clear return', 'error');
                }
            } catch (e) {
                console.error('Failed to clear return:', e);
                showNotification('Failed to clear return. Please try again.', 'error');
            }
        }

        // Create reservation category filter buttons for GenServe
        function createGenServeReservationCategoryFilters(reservations) {
            const filterContainer = document.querySelector('#reservation .reservation-filters');
            if (!filterContainer) return;
            
            // Get unique categories from reservations (including all statuses)
            const validReservations = reservations;
            const categories = [...new Set(validReservations.map(r => r.category).filter(c => c))];
            
            // Clear existing buttons except "All Reservations"
            const allBtn = filterContainer.querySelector('[data-category="all"]');
            filterContainer.innerHTML = '';
            if (allBtn) {
                filterContainer.appendChild(allBtn);
            }
            
            // Create buttons for each category
            categories.sort().forEach(category => {
                const count = reservations.filter(r => r.category === category).length;
                const btn = document.createElement('button');
                btn.className = 'reservation-filter-btn';
                btn.setAttribute('data-category', category);
                btn.onclick = () => filterGenServeReservationsByCategory(category);
                
                // Get icon based on category name
                let icon = 'fas fa-boxes';
                if (category.toLowerCase().includes('audio') || category.toLowerCase().includes('visual')) {
                    icon = 'fas fa-volume-up';
                } else if (category.toLowerCase().includes('furniture') || category.toLowerCase().includes('decoration')) {
                    icon = 'fas fa-couch';
                } else if (category.toLowerCase().includes('power') || category.toLowerCase().includes('ventilation')) {
                    icon = 'fas fa-plug';
                }
                
                btn.innerHTML = `<i class="${icon}"></i> ${escapeHtml(category)} <span style="margin-left: 8px; font-weight: 600;">(${count})</span>`;
                filterContainer.appendChild(btn);
            });
        }

        // Filter GenServe reservations by category
        function filterGenServeReservationsByCategory(category) {
            // Update active button
            document.querySelectorAll('#reservation .reservation-filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`#reservation .reservation-filter-btn[data-category="${category}"]`)?.classList.add('active');
            
            const tbody = document.querySelector('#reservationTable tbody');
            const countElement = document.getElementById('reservationCategoryCount');
            
            if (!tbody || !window.allGenServeReservationsData) return;
            
            tbody.innerHTML = '';
            
            let filteredReservations = [];
            
            if (category === 'all') {
                // Show all reservations including cancelled/declined ones
                filteredReservations = window.allGenServeReservationsData;
            } else {
                // Show only reservations from selected category
                filteredReservations = window.allGenServeReservationsData.filter(r => r.category === category);
            }
            
            if (filteredReservations.length === 0) {
                tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No reservations found</td></tr>';
                if (countElement) {
                    countElement.textContent = category === 'all' ? 'No reservations found' : `No reservations found in ${category}`;
                }
                return;
            }
            
            // Display reservations
            filteredReservations.forEach(res => {
                const row = document.createElement('tr');
                const faculty = res.faculty || 'Unknown';
                const equipment = res.equipment || 'N/A';
                const category = res.category || 'N/A';
                const quantity = res.quantity || 0;
                const date = res.date || 'N/A';
                const time = res.time || 'N/A';
                const status = res.status || 'Pending';
                
                row.innerHTML = `
                    <td>${escapeHtml(faculty)}</td>
                    <td><strong>${escapeHtml(equipment)}</strong></td>
                    <td><span class="badge badge-info">${escapeHtml(category)}</span></td>
                    <td>${date}</td>
                    <td>${escapeHtml(time)}</td>
                    <td><strong>${quantity}</strong> ${quantity === 1 ? 'piece' : 'pieces'}</td>
                    <td><span class="status-badge status-${status.toLowerCase().replace(' ', '-')}">${status}</span></td>
                    <td>
                        ${status === 'Pending' ? `
                            <button class="btn btn-success btn-sm" onclick="approveGenServeReservation(${res.id})">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="declineGenServeReservation(${res.id})">
                                <i class="fas fa-times"></i> Decline
                            </button>
                        ` : status === 'Cancellation Requested' ? `
                            <button class="btn btn-success btn-sm" onclick="approveCancellationRequest(${res.id})">
                                <i class="fas fa-check"></i> Approve Cancellation
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="declineCancellationRequest(${res.id})">
                                <i class="fas fa-times"></i> Decline Cancellation
                            </button>
                        ` : '<span class="text-muted">No action</span>'}
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            // Update count
            if (countElement) {
                if (category === 'all') {
                    const pendingCount = filteredReservations.filter(r => r.status === 'Pending').length;
                    countElement.textContent = `Showing all reservations: ${filteredReservations.length} total (${pendingCount} pending)`;
                } else {
                    const pendingCount = filteredReservations.filter(r => r.status === 'Pending').length;
                    countElement.textContent = `Showing ${filteredReservations.length} reservation${filteredReservations.length !== 1 ? 's' : ''} in ${category}: ${pendingCount} pending`;
                }
            }
        }

        // GenServe approve reservation function
        async function approveGenServeReservation(id) {
            try {
                const resp = await fetch('api.php?action=updateReservationStatus', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        id: id,
                        status: 'Approved'
                    })
                });
                const data = await resp.json();
                
                if (data.ok) {
                    // Fetch reservation details for audit log and notification
                    const resResp = await fetch('api.php?action=listGenServeReservations');
                    const reservations = await resResp.json();
                    const reservation = reservations.find(r => r.id === id);
                    
                    if (reservation) {
                        // Add to audit log
                        if (typeof addAuditLog === 'function') {
                            const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
                            addAuditLog('GenServe', loggedGenServe?.fullname || 'GenServe', `Approved reservation for ${reservation.quantity} ${reservation.equipment}`);
                        }
                        
                        // Create notification for faculty
                        if (typeof createFacultyNotification === 'function') {
                            createFacultyNotification(
                                reservation.facultyUsername || reservation.faculty,
                                'Reservation Approved',
                                `Your reservation for ${reservation.quantity} ${reservation.equipment} has been approved!`,
                                'success'
                            );
                        }
                    }
                    
                    // Refresh equipment catalog
                    fetch('api.php?action=getCatalog', { cache: 'no-store' })
                        .then(res => res.json())
                        .then(dbCatalog => {
                            if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                                localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                                window.dispatchEvent(new Event('equipmentUpdated'));
                            }
                        })
                        .catch(err => console.error('Failed to refresh catalog:', err));
                    
                    showNotification('Reservation approved!', 'success');
                    loadApprovedReservations();
                    loadGenServeStats();
                } else {
                    showNotification(data.error || 'Failed to approve reservation', 'error');
                }
            } catch (e) {
                console.error('Error approving reservation:', e);
                showNotification('Failed to approve reservation', 'error');
            }
        }

        // GenServe decline reservation function
        async function declineGenServeReservation(id) {
            const processDecline = async (reasonText) => {
                const trimmedReason = (reasonText || '').trim();
                try {
                    const resp = await fetch('api.php?action=updateReservationStatus', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            id: id,
                            status: 'Declined',
                            reason: trimmedReason
                        })
                    });
                    const data = await resp.json();
                    
                    if (data.ok) {
                        const resResp = await fetch('api.php?action=listGenServeReservations');
                        const reservations = await resResp.json();
                        const reservation = reservations.find(r => r.id === id);
                        
                        if (reservation) {
                            if (typeof addAuditLog === 'function') {
                                const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
                                const reasonNote = trimmedReason ? ` - Reason: ${trimmedReason}` : '';
                                addAuditLog('GenServe', loggedGenServe?.fullname || 'GenServe', `Declined reservation for ${reservation.quantity} ${reservation.equipment}${reasonNote}`);
                            }
                            
                            if (typeof createFacultyNotification === 'function') {
                                const declineMessage = trimmedReason
                                    ? `Your reservation for ${reservation.quantity} ${reservation.equipment} has been declined. Reason: ${trimmedReason}`
                                    : `Your reservation for ${reservation.quantity} ${reservation.equipment} has been declined.`;
                                
                                createFacultyNotification(
                                    reservation.facultyUsername || reservation.faculty,
                                    'Reservation Declined',
                                    declineMessage,
                                    'error'
                                );
                            }
                        }
                        
                        fetch('api.php?action=getCatalog', { cache: 'no-store' })
                            .then(res => res.json())
                            .then(dbCatalog => {
                                if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                                    localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                                    window.dispatchEvent(new Event('equipmentUpdated'));
                                }
                            })
                            .catch(err => console.error('Failed to refresh catalog:', err));
                        
                        showNotification('Reservation declined!', 'success');
                        loadApprovedReservations();
                        loadGenServeStats();
                    } else {
                        showNotification(data.error || 'Failed to decline reservation', 'error');
                    }
                } catch (e) {
                    console.error('Error declining reservation:', e);
                    showNotification('Failed to decline reservation', 'error');
                }
            };

            showReasonModal({
                title: 'Decline Reservation',
                description: 'Please provide a reason for declining this reservation.',
                placeholder: 'Reason for declining this reservation',
                confirmText: 'Decline Reservation',
                confirmIcon: 'fas fa-times',
                onConfirm: processDecline
            });
        }

        // Approve cancellation request (GenServe)
        async function approveCancellationRequest(id) {
            try {
                // Use cached data if available, otherwise fetch
                let reservations = window.allGenServeReservationsData;
                if (!reservations || reservations.length === 0) {
                    const resResp = await fetch('api.php?action=listGenServeReservations');
                    reservations = await resResp.json();
                }
                
                // Ensure ID comparison works (handle both string and number)
                const reservation = reservations.find(r => parseInt(r.id) === parseInt(id));
                
                if (!reservation) {
                    showNotification('Reservation not found', 'error');
                    return;
                }
                
                const cancelReason = reservation.cancel_reason || 'No reason provided';
                
                const resp = await fetch('api.php?action=updateReservationStatus', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        id: id,
                        status: 'Cancelled',
                        reason: cancelReason
                    })
                });
                const data = await resp.json();
                
                if (data.ok) {
                    // Add to audit log
                    if (typeof addAuditLog === 'function') {
                        const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
                        addAuditLog('GenServe', loggedGenServe?.fullname || 'GenServe', `Approved cancellation request for ${reservation.quantity} ${reservation.equipment}`);
                    }
                    
                    // Create notification for faculty
                    if (typeof createFacultyNotification === 'function') {
                        createFacultyNotification(
                            reservation.facultyUsername || reservation.faculty,
                            'Cancellation Approved',
                            `Your cancellation request for ${reservation.quantity} ${reservation.equipment} has been approved.`,
                            'success'
                        );
                    }
                    
                    // Refresh equipment catalog
                    fetch('api.php?action=getCatalog', { cache: 'no-store' })
                        .then(res => res.json())
                        .then(dbCatalog => {
                            if (dbCatalog && Object.keys(dbCatalog).length > 0) {
                                localStorage.setItem('equipmentCatalog', JSON.stringify(dbCatalog));
                                window.dispatchEvent(new Event('equipmentUpdated'));
                            }
                        })
                        .catch(err => console.error('Failed to refresh catalog:', err));
                    
                    showNotification('Cancellation request approved!', 'success');
                    loadApprovedReservations();
                    loadGenServeStats();
                } else {
                    showNotification(data.error || 'Failed to approve cancellation', 'error');
                }
            } catch (e) {
                console.error('Error approving cancellation:', e);
                showNotification('Failed to approve cancellation', 'error');
            }
        }

        // Decline cancellation request (GenServe)
        async function declineCancellationRequest(id) {
            const processDecline = async (reasonText) => {
                const trimmedReason = (reasonText || '').trim();
                try {
                    // Use cached data if available, otherwise fetch
                    let reservations = window.allGenServeReservationsData;
                    if (!reservations || reservations.length === 0) {
                        const resResp = await fetch('api.php?action=listGenServeReservations');
                        reservations = await resResp.json();
                    }
                    
                    // Ensure ID comparison works (handle both string and number)
                    const reservation = reservations.find(r => parseInt(r.id) === parseInt(id));
                    
                    if (!reservation) {
                        showNotification('Reservation not found', 'error');
                        return;
                    }
                    
                    // Restore to Approved status (since faculty can cancel both Pending and Approved)
                    // We'll restore to Approved as the most common case
                    const resp = await fetch('api.php?action=updateReservationStatus', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            id: id,
                            status: 'Approved',
                            reason: ''
                        })
                    });
                    const data = await resp.json();
                    
                    if (data.ok) {
                        // Cancel reason will be cleared when status is updated
                        if (typeof addAuditLog === 'function') {
                            const loggedGenServe = JSON.parse(localStorage.getItem('loggedInGenServe') || 'null');
                            const reasonNote = trimmedReason ? ` - Reason: ${trimmedReason}` : '';
                            addAuditLog('GenServe', loggedGenServe?.fullname || 'GenServe', `Declined cancellation request for ${reservation.quantity} ${reservation.equipment}${reasonNote}`);
                        }
                        
                        if (typeof createFacultyNotification === 'function') {
                            const declineMessage = trimmedReason
                                ? `Your cancellation request for ${reservation.quantity} ${reservation.equipment} has been declined. Reason: ${trimmedReason}`
                                : `Your cancellation request for ${reservation.quantity} ${reservation.equipment} has been declined.`;
                            
                            createFacultyNotification(
                                reservation.facultyUsername || reservation.faculty,
                                'Cancellation Declined',
                                declineMessage,
                                'error'
                            );
                        }
                        
                        showNotification('Cancellation request declined!', 'success');
                        loadApprovedReservations();
                        loadGenServeStats();
                    } else {
                        showNotification(data.error || 'Failed to decline cancellation', 'error');
                    }
                } catch (e) {
                    console.error('Error declining cancellation:', e);
                    showNotification('Failed to decline cancellation', 'error');
                }
            };

            showReasonModal({
                title: 'Decline Cancellation Request',
                description: 'Please provide a reason for declining this cancellation request.',
                placeholder: 'Reason for declining the cancellation',
                confirmText: 'Decline Cancellation',
                confirmIcon: 'fas fa-times',
                onConfirm: processDecline
            });
        }

        // Load reservations with complete details (Pending for approval, Approved for viewing)
        async function loadApprovedReservations() {
            try {
                const resp = await fetch('api.php?action=listGenServeReservations');
                const data = await resp.json();
                const tbody = document.querySelector('#reservationTable tbody');
                if (!tbody) return;
                
                // Store all reservations globally for filtering
                window.allGenServeReservationsData = data;
                
                // Create category filter buttons
                createGenServeReservationCategoryFilters(data);
                
                // Display all reservations by default
                filterGenServeReservationsByCategory('all');
            } catch (e) {
                console.error('Failed to load reservations:', e);
                const tbody = document.querySelector('#reservationTable tbody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="8" class="text-muted">Error loading reservations</td></tr>';
                }
            }
        }

        // Create equipment category filter buttons for GenServe
        function createGenServeEquipmentCategoryFilters(data) {
            const filterContainer = document.querySelector('#inventory .equipment-filters');
            if (!filterContainer) return;
            
            // Clear existing buttons except "All Equipment"
            const allBtn = filterContainer.querySelector('[data-category="all"]');
            filterContainer.innerHTML = '';
            if (allBtn) {
                filterContainer.appendChild(allBtn);
            }
            
            // Create buttons for each category
            for (const [category, items] of Object.entries(data)) {
                // Calculate totals for this category
                let totalAvailable = 0;
                let totalQuantity = 0;
                items.forEach(item => {
                    totalAvailable += item.available;
                    totalQuantity += item.total;
                });
                
                const btn = document.createElement('button');
                btn.className = 'equipment-filter-btn';
                btn.setAttribute('data-category', category);
                btn.onclick = () => filterGenServeEquipmentByCategory(category);
                
                // Get icon based on category name
                let icon = 'fas fa-boxes';
                if (category.toLowerCase().includes('audio') || category.toLowerCase().includes('visual')) {
                    icon = 'fas fa-volume-up';
                } else if (category.toLowerCase().includes('furniture') || category.toLowerCase().includes('decoration')) {
                    icon = 'fas fa-couch';
                } else if (category.toLowerCase().includes('power') || category.toLowerCase().includes('ventilation')) {
                    icon = 'fas fa-plug';
                }
                
                btn.innerHTML = `<i class="${icon}"></i> ${escapeHtml(category)} <span style="margin-left: 8px; font-weight: 600;">(${totalAvailable} / ${totalQuantity})</span>`;
                filterContainer.appendChild(btn);
            }
        }

        // Filter GenServe equipment by category
        function filterGenServeEquipmentByCategory(category) {
            // Update active button
            document.querySelectorAll('#inventory .equipment-filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`#inventory .equipment-filter-btn[data-category="${category}"]`)?.classList.add('active');
            
            const tbody = document.querySelector('#equipmentTable tbody');
            const countElement = document.getElementById('equipmentCategoryCount');
            
            if (!tbody || !window.allGenServeEquipmentData) return;
            
            tbody.innerHTML = '';
            
            let filteredItems = [];
            
            if (category === 'all') {
                // Show all equipment
                for (const [cat, items] of Object.entries(window.allGenServeEquipmentData)) {
                    items.forEach(item => {
                        filteredItems.push({ ...item, category: cat });
                    });
                }
            } else {
                // Show only items from selected category
                const items = window.allGenServeEquipmentData[category] || [];
                items.forEach(item => {
                    filteredItems.push({ ...item, category: category });
                });
            }
            
            if (filteredItems.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No equipment found</td></tr>';
                if (countElement) {
                    countElement.textContent = category === 'all' ? 'No equipment found' : `No equipment found in ${category}`;
                }
                return;
            }
            
            // Display items
            filteredItems.forEach(item => {
                const row = document.createElement('tr');
                const reserved = item.total - item.available;
                const isUnavailable = item.available === 0;
                const status = isUnavailable ? 'Unavailable' : 'Available';
                row.style.backgroundColor = isUnavailable ? '#fed7d7' : '';
                row.innerHTML = `
                    <td style="${isUnavailable ? 'color: #c53030; font-weight: bold;' : ''}">${escapeHtml(item.name)}</td>
                    <td>${escapeHtml(item.category)}</td>
                    <td style="${isUnavailable ? 'color: #c53030; font-weight: bold;' : ''}"><strong>${item.available}</strong> <small>(Reserved: ${reserved})</small></td>
                    <td><span class="status-badge ${isUnavailable ? 'status-declined' : 'status-approved'}" style="${isUnavailable ? 'background-color: #c53030; color: white; font-weight: bold;' : ''}">${status}</span></td>
                    <td>
                        <button class="btn btn-info btn-sm" onclick="editEquipment('${item.name}', '${item.category}')">
                          <i class="fas fa-edit"></i> Edit
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            // Update count
            if (countElement) {
                if (category === 'all') {
                    let totalAvailable = 0;
                    let totalQuantity = 0;
                    for (const [cat, items] of Object.entries(window.allGenServeEquipmentData)) {
                        items.forEach(item => {
                            totalAvailable += item.available;
                            totalQuantity += item.total;
                        });
                    }
                    countElement.textContent = `Showing all equipment: ${totalAvailable} / ${totalQuantity} available`;
                } else {
                    let totalAvailable = 0;
                    let totalQuantity = 0;
                    const items = window.allGenServeEquipmentData[category] || [];
                    items.forEach(item => {
                        totalAvailable += item.available;
                        totalQuantity += item.total;
                    });
                    countElement.textContent = `Showing ${items.length} item${items.length !== 1 ? 's' : ''} in ${category}: ${totalAvailable} / ${totalQuantity} available`;
                }
            }
            
            // Re-apply search filter if there's a search term
            const searchInput = document.getElementById('equipmentSearchInput');
            if (searchInput && searchInput.value) {
                const searchTerm = searchInput.value.toLowerCase();
                const rows = tbody.querySelectorAll('tr');
                rows.forEach(row => {
                    const nameCell = row.cells[0];
                    const categoryCell = row.cells[1];
                    if (!nameCell || !categoryCell) return;
                    
                    const name = nameCell.textContent.toLowerCase();
                    const category = categoryCell.textContent.toLowerCase();
                    
                    if (name.includes(searchTerm) || category.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }
        }

        // Load equipment inventory (with management functions for GenServe)
        async function loadEquipmentInventory() {
            try {
                const resp = await fetch('api.php?action=getCatalog');
                const data = await resp.json();
                const tbody = document.querySelector('#equipmentTable tbody');
                if (!tbody) return;
                
                // Store all equipment data globally for filtering
                window.allGenServeEquipmentData = data;
                
                // Sync catalog to localStorage for management functions
                if (typeof setEquipmentCatalog === 'function') {
                    setEquipmentCatalog(data);
                }
                
                // Create category filter buttons
                createGenServeEquipmentCategoryFilters(data);
                
                // Display all equipment by default
                filterGenServeEquipmentByCategory('all');
            } catch (e) {
                console.error('Failed to load equipment:', e);
                const tbody = document.querySelector('#equipmentTable tbody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="5" class="text-center">Error loading equipment</td></tr>';
                }
            }
        }

        // Load reports
        async function loadReports() {
            try {
                const resp = await fetch('api.php?action=listAdminReports');
                const data = await resp.json();
                const tbody = document.querySelector('#reportTable tbody');
                tbody.innerHTML = '';
                
                if (data && data.length > 0) {
                    data.forEach(report => {
                        const row = document.createElement('tr');
                        const statusBadge = report.status === 'Fixed' ? 'badge-success' : 'badge-warning';
                        row.innerHTML = `
                            <td>${escapeHtml(report.faculty || 'Unknown')}</td>
                            <td>${escapeHtml(report.equipment)}</td>
                            <td>${escapeHtml(report.description)}</td>
                            <td><span class="badge ${statusBadge}">${report.status}</span></td>
                            <td>
                                ${report.status === 'Pending' ? 
                                    `<button class="btn btn-sm btn-success" onclick="updateReportStatus(${report.id}, 'Fixed')">Mark as Fixed</button>` : 
                                    '<span class="text-muted">Fixed</span>'
                                }
                            </td>
                        `;
                        tbody.appendChild(row);
                    });
                } else {
                    tbody.innerHTML = '<tr><td colspan="5" class="text-muted">No reports</td></tr>';
                }
            } catch (e) {
                console.error('Failed to load reports:', e);
            }
        }

        // Update report status
        async function updateReportStatus(id, status) {
            try {
                const resp = await fetch('api.php?action=updateReportStatus', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, status })
                });
                const data = await resp.json();
                if (data.ok) {
                    showNotification('Report status updated successfully', 'success');
                    loadReports();
                    loadGenServeStats();
                    // Reload damage reports in analytics section
                    const categoryDiv = document.getElementById('categoryReports');
                    if (categoryDiv) {
                        loadDamageReports(categoryDiv);
                    }
                } else {
                    showNotification(data.error || 'Unable to update report status. Please try again.', 'error');
                }
            } catch (e) {
                showNotification('Unable to update report status. Please check your connection and try again.', 'error');
            }
        }

        // Load damage reports for analytics section
        async function loadDamageReports(container) {
            try {
                const resp = await fetch('api.php?action=listAdminReports');
                const data = await resp.json();
                
                if (!data || data.length === 0) {
                    container.innerHTML = '<p class="text-muted">No damage reports available</p>';
                    return;
                }
                
                // Group reports by equipment name
                const reportsByEquipment = {};
                data.forEach(report => {
                    const equipment = report.equipment || 'Unknown Equipment';
                    if (!reportsByEquipment[equipment]) {
                        reportsByEquipment[equipment] = [];
                    }
                    reportsByEquipment[equipment].push(report);
                });
                
                let html = '';
                const equipmentNames = Object.keys(reportsByEquipment).sort();
                
                equipmentNames.forEach(equipment => {
                    const reports = reportsByEquipment[equipment];
                    const pendingCount = reports.filter(r => r.status === 'Pending').length;
                    const fixedCount = reports.filter(r => r.status === 'Fixed').length;
                    
                    html += `<div style="margin-bottom: 25px; padding: 20px; border: 2px solid #dc2626; border-radius: 8px; background: #fef2f2;">`;
                    html += `<h3 style="color: #dc2626; margin-bottom: 15px;">${escapeHtml(equipment)}</h3>`;
                    html += `<p style="margin-bottom: 15px;"><strong>Total Reports:</strong> ${reports.length} | `;
                    html += `<span style="color: #dc2626;"><strong>Pending:</strong> ${pendingCount}</span> | `;
                    html += `<span style="color: #16a34a;"><strong>Fixed:</strong> ${fixedCount}</span></p>`;
                    
                    reports.forEach(report => {
                        const statusColor = report.status === 'Fixed' ? '#16a34a' : '#dc2626';
                        const statusBg = report.status === 'Fixed' ? '#dcfce7' : '#fee2e2';
                        const date = new Date(report.createdAt).toLocaleString();
                        
                        html += `<div style="margin-top: 15px; padding: 15px; background: ${statusBg}; border-radius: 5px; border-left: 4px solid ${statusColor};">`;
                        html += `<div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">`;
                        html += `<div style="flex: 1;">`;
                        html += `<p style="margin: 0; font-weight: 600; color: #1f2937;">Reported by: <strong>${escapeHtml(report.faculty || 'Unknown')}</strong></p>`;
                        html += `<p style="margin: 5px 0; color: #6b7280; font-size: 14px;">Date: ${date}</p>`;
                        html += `</div>`;
                        html += `<span class="badge ${report.status === 'Fixed' ? 'badge-success' : 'badge-warning'}" style="margin-left: 10px;">${report.status}</span>`;
                        html += `</div>`;
                        html += `<div style="margin-top: 10px; padding: 10px; background: white; border-radius: 3px;">`;
                        html += `<p style="margin: 0; color: #374151;"><strong>Description:</strong> ${escapeHtml(report.description)}</p>`;
                        html += `</div>`;
                        html += `</div>`;
                    });
                    
                    html += `</div>`;
                });
                
                container.innerHTML = html;
            } catch (e) {
                console.error('Failed to load damage reports:', e);
                container.innerHTML = '<p class="text-muted">Error loading damage reports</p>';
            }
        }

        // Load gym reservations (only show Approved status)
        async function loadGymReservations() {
            try {
                const resp = await fetch('api.php?action=listAllGymReservations');
                const data = await resp.json();
                const tbody = document.querySelector('#gymReservationTable tbody');
                if (!tbody) return;
                
                // Filter to show only Approved gym reservations
                const approvedReservations = data.filter(r => r.status === 'Approved');
                
                // Store filtered gym reservations globally for filtering
                window.allGymReservationsData = approvedReservations;
                
                // Create category filter buttons based on equipment categories
                createGymReservationCategoryFilters(approvedReservations);
                
                // Display all approved gym reservations by default
                filterGymReservationsByCategory('all');
            } catch (e) {
                console.error('Failed to load gym reservations:', e);
                const tbody = document.querySelector('#gymReservationTable tbody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="6" class="text-muted">Error loading gym reservations</td></tr>';
                }
            }
        }

        // Create gym reservation category filter buttons based on equipment categories
        function createGymReservationCategoryFilters(reservations) {
            const filterContainer = document.querySelector('#gymReservations .reservation-filters');
            if (!filterContainer) return;
            
            // Get all unique equipment categories from all gym reservations
            const categorySet = new Set();
            reservations.forEach(reservation => {
                if (reservation.equipmentItems && Array.isArray(reservation.equipmentItems)) {
                    reservation.equipmentItems.forEach(item => {
                        if (item.category) {
                            categorySet.add(item.category);
                        }
                    });
                }
            });
            
            const categories = Array.from(categorySet).sort();
            
            // Clear existing buttons except "All Gym Reservations"
            const allBtn = filterContainer.querySelector('[data-category="all"]');
            filterContainer.innerHTML = '';
            if (allBtn) {
                filterContainer.appendChild(allBtn);
            }
            
            // Create buttons for each category
            categories.forEach(category => {
                // Count reservations that have equipment from this category (including approved)
                const count = reservations.filter(r => {
                    if (!r.equipmentItems || !Array.isArray(r.equipmentItems)) return false;
                    return r.equipmentItems.some(item => item.category === category);
                }).length;
                
                const btn = document.createElement('button');
                btn.className = 'reservation-filter-btn';
                btn.setAttribute('data-category', category);
                btn.onclick = () => filterGymReservationsByCategory(category);
                
                // Get icon based on category name
                let icon = 'fas fa-boxes';
                if (category.toLowerCase().includes('audio') || category.toLowerCase().includes('visual')) {
                    icon = 'fas fa-volume-up';
                } else if (category.toLowerCase().includes('furniture') || category.toLowerCase().includes('decoration')) {
                    icon = 'fas fa-couch';
                } else if (category.toLowerCase().includes('power') || category.toLowerCase().includes('ventilation')) {
                    icon = 'fas fa-plug';
                }
                
                btn.innerHTML = `<i class="${icon}"></i> ${escapeHtml(category)} <span style="margin-left: 8px; font-weight: 600;">(${count})</span>`;
                filterContainer.appendChild(btn);
            });
        }

        // Filter gym reservations by category
        function filterGymReservationsByCategory(category) {
            // Update active button
            document.querySelectorAll('#gymReservations .reservation-filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`#gymReservations .reservation-filter-btn[data-category="${category}"]`)?.classList.add('active');
            
            const tbody = document.querySelector('#gymReservationTable tbody');
            const countElement = document.getElementById('gymReservationCategoryCount');
            
            if (!tbody || !window.allGymReservationsData) return;
            
            tbody.innerHTML = '';
            
            let filteredReservations = [];
            
            if (category === 'all') {
                // Show all approved gym reservations only
                filteredReservations = window.allGymReservationsData.filter(r => r.status === 'Approved');
            } else {
                // Show only approved gym reservations that have equipment from selected category
                filteredReservations = window.allGymReservationsData.filter(r => {
                    if (r.status !== 'Approved') return false;
                    if (!r.equipmentItems || !Array.isArray(r.equipmentItems)) return false;
                    return r.equipmentItems.some(item => item.category === category);
                });
            }
            
            if (filteredReservations.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No gym reservations found</td></tr>';
                if (countElement) {
                    countElement.textContent = category === 'all' ? 'No gym reservations found' : `No gym reservations found with ${category} equipment`;
                }
                return;
            }
            
            // Display gym reservations
            filteredReservations.forEach(reservation => {
                const row = document.createElement('tr');
                const faculty = reservation.faculty || 'Unknown';
                const title = reservation.title || 'Gym Reservation';
                const date = reservation.date || 'N/A';
                const time = reservation.time || 'N/A';
                const status = reservation.status || 'Pending';
                
                // Format equipment items grouped by category
                let equipmentHtml = '';
                if (reservation.equipmentItems && Array.isArray(reservation.equipmentItems) && reservation.equipmentItems.length > 0) {
                    // Group equipment by category
                    const equipmentByCategory = {};
                    reservation.equipmentItems.forEach(item => {
                        const cat = item.category || 'Other';
                        if (!equipmentByCategory[cat]) {
                            equipmentByCategory[cat] = [];
                        }
                        equipmentByCategory[cat].push(item);
                    });
                    
                    // Build HTML grouped by category
                    const categoryNames = Object.keys(equipmentByCategory).sort();
                    categoryNames.forEach(cat => {
                        const items = equipmentByCategory[cat];
                        const itemsText = items.map(item => 
                            `${item.quantity}x ${item.equipment}`
                        ).join(', ');
                        equipmentHtml += `<div style="margin-bottom: 5px;">`;
                        equipmentHtml += `<span class="badge badge-info" style="margin-right: 5px;">${escapeHtml(cat)}</span>`;
                        equipmentHtml += `<span>${escapeHtml(itemsText)}</span>`;
                        equipmentHtml += `</div>`;
                    });
                } else {
                    equipmentHtml = '<span class="text-muted">N/A</span>';
                }
                
                row.innerHTML = `
                    <td>${escapeHtml(faculty)}</td>
                    <td><strong>${escapeHtml(title)}</strong></td>
                    <td>${date}</td>
                    <td>${escapeHtml(time)}</td>
                    <td>${equipmentHtml}</td>
                    <td><span class="status-badge status-${status.toLowerCase()}">${status}</span></td>
                `;
                tbody.appendChild(row);
            });
            
            // Update count
            if (countElement) {
                if (category === 'all') {
                    countElement.textContent = `Showing ${filteredReservations.length} approved gym reservation${filteredReservations.length !== 1 ? 's' : ''}`;
                } else {
                    countElement.textContent = `Showing ${filteredReservations.length} approved gym reservation${filteredReservations.length !== 1 ? 's' : ''} with ${category} equipment`;
                }
            }
        }

        // GenServe uses the shared chat system from script.js (same behavior as Admin)
        // All chat functionality is handled by the shared system for consistency
        
        // Listen for gym reservation updates from admin
        window.addEventListener('gymReservationUpdated', function(event) {
            // Reload gym reservations when admin approves/declines
            if (typeof loadGymReservations === 'function') {
                loadGymReservations();
            }
        });
        
        // Equipment search
        document.getElementById('equipmentSearchInput')?.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#equipmentTable tbody tr');
            rows.forEach(row => {
                const nameCell = row.cells[0];
                const categoryCell = row.cells[1];
                if (!nameCell || !categoryCell) return;
                
                const name = nameCell.textContent.toLowerCase();
                const category = categoryCell.textContent.toLowerCase();
                
                if (name.includes(searchTerm) || category.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        window.addEventListener('load', function() {
            loadGenServeStats();
            loadApprovedReservations();
            loadGymReservations();
            loadPendingReturns();
            loadEquipmentInventory();
            loadReports();
            
            // Load GenServe notifications and update badge
            if (typeof loadGenServeNotifications === 'function') {
                loadGenServeNotifications();
            }
            if (typeof updateGenServeNotificationBadge === 'function') {
                updateGenServeNotificationBadge();
            }
            
            // Chat initialization will be handled by showSection('messenger') 
            // using the shared chat system from script.js (same as Admin)
            
            // Refresh stats every 30 seconds
            setInterval(loadGenServeStats, 30000);
            setInterval(loadApprovedReservations, 30000);
            setInterval(loadGymReservations, 30000);
            setInterval(loadPendingReturns, 30000);
            setInterval(loadReports, 30000);
            
            // Refresh notifications badge every 60 seconds
            if (typeof updateGenServeNotificationBadge === 'function') {
                setInterval(updateGenServeNotificationBadge, 60000);
            }
        });

    </script>
</body>
</html>

