<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSUCC Gym Reservation System</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
      /* Layout */
      body.page-wrap { display:flex; flex-direction:column; min-height:100vh; margin:0; padding:0; }
      .content-container { width:100%; margin:0; padding:0; flex:1 0 auto; }
      img { max-width:100%; height:auto; display:block; }
      /* Header */
      .top-mini-header { display:flex; align-items:center; justify-content:space-between; padding:10px 16px; background:#0d5016; color:#fff; }
      .top-mini-header .brand { display:flex; align-items:center; gap:10px; font-weight:700; }
      .top-mini-header img { width:28px; height:28px; border-radius:50%; object-fit:cover; object-position:center; margin:0; padding:0; display:block; }
      .top-mini-header .login-btn-mini { background:#2d7a2d; color:#fff; border:none; padding:6px 12px; border-radius:8px; cursor:pointer; font-size:13px; }
      .landing-hero { background:#0a5d0a; color:#fff; padding:30px 16px; text-align:center; }
      .landing-hero h1 { font-size:28px; margin-bottom:6px; }
      .landing-hero p { opacity:.9; }
      .announcement-bar { display:flex; align-items:center; gap:12px; background:#0d5016; color:#fff; padding:8px 12px; transition: background 0.3s ease; }
      .announcement-bar:hover { background:#0f5a1a; }
      .announcement-bar .label { background:#093d0f; padding:4px 10px; border-radius:999px; font-weight:700; font-size:12px; letter-spacing:.5px; }
      .banner-wrap { width:100%; position:relative; overflow:hidden; margin:0; padding:0; line-height:0; display:block; }
      .banner-wrap img { width:100%; height:100%; display:block; object-fit:cover; object-position:center; opacity:1; transition: opacity .6s ease; margin:0; padding:0; vertical-align:top; }
      .page-wrap { background:linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #f1f5f9 100%); }
      /* Ensure public homepage sections are visible (override global section display:none) */
      .public-main section { display:block; }
      /* Footer */
      .site-footer { background:linear-gradient(180deg,#0d5016 0%, #0a4512 100%); color:#e6ffed; padding:12px 16px; margin-top:auto; position:relative; }
      .site-footer::before { content:''; position:absolute; top:0; left:0; right:0; height:4px; background:linear-gradient(90deg, #2d7a2d, #38a169, #48bb78); }
      .site-footer .footer-inner { max-width:1200px; margin:0 auto; display:flex; flex-direction:column; gap:10px; }
      .footer-columns { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:12px; align-items:flex-start; }
      .footer-columns h4 { margin:0 0 6px; font-size:12px; color:#c7ffd6; letter-spacing:.5px; text-transform:uppercase; }
      .footer-columns a, .footer-columns span { display:block; font-size:12px; color:#d4f5d4; margin:2px 0; text-decoration:none; opacity:.95; }
      .footer-columns a:hover { color:#ffffff; text-decoration:underline; }
      .footer-brand small { display:block; opacity:.8; margin-top:6px; }
      .social-links { display:flex; gap:8px; margin-top:4px; }
      .social-links a { width:28px; height:28px; display:inline-flex; align-items:center; justify-content:center; border-radius:6px; background:rgba(255,255,255,.08); color:#e6ffed; }
      .social-links a:hover { background:rgba(255,255,255,.15); }
      .footer-sep { height:1px; background:rgba(255,255,255,.15); margin-top:2px; }
      .footer-bottom { opacity:.8; font-size:11px; text-align:center; }
      .site-footer a { color:#d4f5d4; text-decoration:none; font-weight:600; }
    </style>
    </head>
<body class="page-wrap">
    <div class="content-container">
        <div class="top-mini-header">
            <div class="brand">
                <img src="../images/logo.webp" alt="CSUCC Logo">
                <span>CSUCC</span>
            </div>
            <a class="login-btn-mini" href="login.php"><i class="fa fa-user"></i> Log in</a>
        </div>

        <div class="landing-hero">
            <h1>CSUCC Gym Reservation System</h1>
            <p>Equipment Reservation Management</p>
        </div>

        <div class="announcement-bar" onclick="window.location.href='calendar.php'" style="cursor: pointer;">
            <span class="label">IMPORTANT DETAILS</span>
        </div>

        <div class="banner-wrap">
            <img id="homepageSlider" src="../images/headercsu.png" alt="CSUCC Header">
        </div>

        <!-- Public read-only calendar and announcements (visible without login) -->

    <footer class="site-footer">
      <div class="footer-inner">
        <div class="footer-columns">
          <div>
            <div style="display:flex; align-items:center; gap:10px; font-weight:700;">
              <img src="../images/logo.webp" alt="CSUCC Logo" style="width:28px;height:28px;border-radius:50%;object-fit:cover;object-position:center;margin:0;padding:0;display:block;">
              <span>CSUCC Gym Reservation System</span>
            </div>
            <span style="opacity:.8; margin-top:6px;">Equipment Reservation Management</span>
          </div>
          <div>
            <h4>Quick Links</h4>
            <a href="login.php">Log in</a>
            <a href="register.php">Register</a>
          </div>
          <div>
            <h4>Contact</h4>
            <span><i class="fas fa-envelope"></i> csucc@example.edu.ph</span>
          </div>
        </div>
        <div class="footer-bottom">© 2025 CSUCC Gym Reservation System</div>
      </div>
    </footer>

    

    <div id="notification" class="notification"></div>

    <script src="../js/script.js"></script>
    <script>
      (function(){
        const slider = document.getElementById('homepageSlider');
        const bannerWrap = document.querySelector('.banner-wrap');
        if (!slider || !bannerWrap) return;
        
        const slides = [
          '../images/headercsu.png',
          '../images/slide2.jpg',
          '../images/slide3.jpg',
          '../images/slide4.jpg'
        ];
        let idx = 0;
        let fixedHeight = null;

        // Set container height based on first image
        function setContainerHeight() {
          if (slider.complete && slider.naturalHeight > 0) {
            const aspectRatio = slider.naturalHeight / slider.naturalWidth;
            const containerWidth = bannerWrap.offsetWidth;
            const calculatedHeight = containerWidth * aspectRatio;
            
            if (!fixedHeight) {
              fixedHeight = calculatedHeight;
            }
            
            // Update height based on current width but maintain aspect ratio
            bannerWrap.style.height = calculatedHeight + 'px';
          }
        }

        // Set height when first image loads
        if (slider.complete) {
          setContainerHeight();
        } else {
          slider.addEventListener('load', function() {
            setContainerHeight();
            // Lock the aspect ratio after first load
            if (slider.naturalHeight > 0) {
              const aspectRatio = slider.naturalHeight / slider.naturalWidth;
              fixedHeight = bannerWrap.offsetWidth * aspectRatio;
            }
          });
        }

        // Also set on window resize (maintain aspect ratio)
        window.addEventListener('resize', function() {
          if (slider.complete && slider.naturalHeight > 0) {
            const aspectRatio = slider.naturalHeight / slider.naturalWidth;
            const containerWidth = bannerWrap.offsetWidth;
            bannerWrap.style.height = (containerWidth * aspectRatio) + 'px';
          }
        });

        // Preload all images
        slides.forEach(src => { const i = new Image(); i.src = src; });

        // Fade to next slide every 5s
        function goNext() {
          slider.style.opacity = 0;
          setTimeout(() => {
            idx = (idx + 1) % slides.length;
            const img = new Image();
            img.onload = () => {
              slider.src = img.src;
              requestAnimationFrame(() => { slider.style.opacity = 1; });
            };
            img.src = slides[idx];
          }, 300);
        }

        setInterval(goNext, 5000);

        // Initialize public calendar if available
        if (typeof loadCalendar === 'function' && document.getElementById('calendar')) {
          loadCalendar();
        }

        // Initialize public announcements list (read-only)
        if (typeof populateAnnouncements === 'function' && document.getElementById('announcementList')) {
          populateAnnouncements();
        }

        // Update top announcement bar with the latest announcement from the database
        (async function updateAnnouncementBar() {
          const barTextSpan = document.querySelector('.announcement-bar span:nth-child(2)');
          if (!barTextSpan) return;
          try {
            const resp = await fetch('api.php?action=listAnnouncements');
            const data = await resp.json();
            const announcements = Array.isArray(data) ? data : [];
            if (announcements.length === 0) {
              barTextSpan.textContent = 'No news items to display';
              return;
            }
            const latest = announcements[0];
            barTextSpan.textContent = `${latest.title} — ${latest.message}`;
          } catch (e) {
            // Keep default text on error
          }
        })();
      })();
    </script>
</body>
</html>
