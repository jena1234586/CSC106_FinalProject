<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CSUCC Gym Reservation System</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="login-body">
    <div class="login-background">
        <div class="login-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
    </div>
    
    <div class="login-container">
        <div class="login-header">
            <div class="logo">
                <i class="fas fa-dumbbell"></i>
                <h1>CSUCC Gym System</h1>
            </div>
            <p class="login-subtitle">Equipment Reservation Management</p>
        </div>
        
        <form id="loginForm" class="login-form">
            <div class="form-group">
                <i class="fas fa-user form-icon"></i>
                <input type="text" placeholder="Username" id="loginUsername" required>
            </div>
            
            <div class="form-group">
                <i class="fas fa-lock form-icon"></i>
                <input type="password" placeholder="Password" id="loginPassword" required>
                <i class="fas fa-eye toggle-password" onclick="toggleLoginPassword()"></i>
            </div>
            
            <div class="forgot-password-link">
                <a href="forgot-password.php">Forgot Password?</a>
            </div>
            
            <div class="form-group">
                <i class="fas fa-user-tag form-icon"></i>
                <select id="role" required>
                    <option value="">Select Role</option>
                    <option value="faculty">Faculty</option>
                    <option value="admin">Admin</option>
                    <option value="genserve">GenServe</option>
                </select>
            </div>
            
            <div id="adminCredentials" class="admin-credentials" style="display: none;">
                <div class="credentials-box">
                    <h4><i class="fas fa-shield-alt"></i> Admin Access</h4>
                    <p>Admin credentials are provided by the system administrator.</p>
                    <p class="admin-contact">Contact your IT department for access.</p>
                </div>
            </div>
            
            <div id="genserveCredentials" class="admin-credentials" style="display: none;">
                <div class="credentials-box">
                    <h4><i class="fas fa-shield-alt"></i> GenServe Access</h4>
                    <p>GenServe credentials are provided by the system administrator.</p>
                    <p class="admin-contact">Contact your IT department for access.</p>
                </div>
            </div>
            
            <button type="submit" class="login-btn">
                <span>Login</span>
                <i class="fas fa-arrow-right"></i>
            </button>
        </form>
        
        <div class="login-footer">
            <p>Faculty member? <a href="register.php" class="register-link">Register here</a></p>
        </div>
        
        <div id="notification" class="notification"></div>
    </div>

    <script src="../js/script.js"></script>
</body>
</html>
