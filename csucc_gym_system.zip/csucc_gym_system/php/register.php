<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Registration - CSUCC Gym Reservation System</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="login-body">
    <div class="login-background">
        <div class="login-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
    </div>
    
    <div class="login-container">
        <div class="login-header">
            <div class="logo">
                <i class="fas fa-user-plus"></i>
                <h1>Faculty Registration</h1>
            </div>
            <p class="login-subtitle">Join the CSUCC Gym System</p>
        </div>
        
        <form id="registerForm" class="login-form">
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-user form-icon"></i>
                    <input type="text" placeholder="Full Name (e.g., Juan Dela Cruz)" id="fullname" required>
                </div>
                <small id="fullnameError" class="error-text" style="display: none;"></small>
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-at form-icon"></i>
                    <input type="text" placeholder="Username" id="username" required>
                </div>
                <small id="usernameError" class="error-text" style="display: none;"></small>
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-envelope form-icon"></i>
                    <input type="email" placeholder="Email Address (@csucc.edu.ph)" id="email" required>
                </div>
                <small id="emailError" class="error-text" style="display: none;"></small>
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock form-icon"></i>
                    <input type="password" placeholder="Password" id="password" required>
                    <i class="fas fa-eye toggle-password" id="togglePassword" onclick="togglePasswordVisibility()"></i>
                </div>
                <div id="passwordStrength" class="password-strength-bar">
                    <div class="strength-bar"></div>
                </div>
                <small id="strengthText" class="strength-text"></small>
                <small id="strengthFeedback" class="hint-text" style="display: none;"></small>
            </div>
            
            <button type="submit" class="login-btn">
                <span>Create Account</span>
                <i class="fas fa-arrow-right"></i>
            </button>
        </form>
        
        <div class="login-footer">
            <p>Already registered? <a href="login.php" class="register-link">Login here</a></p>
        </div>
        
        <div id="notification" class="notification"></div>
    </div>

    <script src="../js/script.js"></script>
    <script src="../js/register-validation.js"></script>
</body>
</html>
