<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - CSUCC Gym Reservation System</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="login-body">
    <div class="login-background">
        <div class="login-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
    </div>
    
    <div class="login-container">
        <div class="login-header">
            <div class="logo">
                <i class="fas fa-lock-open"></i>
                <h1>Create New Password</h1>
            </div>
            <p class="login-subtitle">Enter your new password below</p>
        </div>
        
        <form id="resetPasswordForm" class="login-form">
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="New Password" id="newPassword" required>
                <i class="fas fa-eye toggle-password" onclick="togglePassword('newPassword')"></i>
            </div>
            
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="Confirm New Password" id="confirmPassword" required>
                <i class="fas fa-eye toggle-password" onclick="togglePassword('confirmPassword')"></i>
            </div>
            
            <button type="submit" class="login-btn">
                <span>Reset Password</span>
                <i class="fas fa-check"></i>
            </button>
        </form>
        
        <div class="login-footer">
            <p>Remember your password? <a href="index.php" class="register-link">Login here</a></p>
        </div>
        
        <div id="notification" class="notification"></div>
    </div>

    <script src="../js/script.js"></script>
    <script src="../js/reset-password.js"></script>
</body>
</html>
