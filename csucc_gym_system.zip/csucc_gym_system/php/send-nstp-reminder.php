<?php
/**
 * NSTP Reminder Scheduler
 * 
 * This script sends automatic reminders to GenServe every Friday
 * for the upcoming Saturday's NSTP setup requirements.
 * 
 * Setup Instructions:
 * 1. Add this to your crontab to run every Friday at a specific time (e.g., 9:00 AM):
 *    0 9 * * 5 /usr/bin/php /path/to/csucc_gym_system/php/send-nstp-reminder.php
 * 
 * 2. For Windows Task Scheduler:
 *    - Create a new task
 *    - Set trigger: Weekly, Friday, at desired time
 *    - Action: Start a program
 *    - Program: C:\xampp\php\php.exe
 *    - Arguments: C:\xampp\htdocs\csucc_gym_system\php\send-nstp-reminder.php
 * 
 * 3. For manual testing, you can call this script directly via browser or command line
 */

require_once __DIR__ . '/db.php';

// Set timezone (adjust to your timezone)
date_default_timezone_set('Asia/Manila');

$db = db_connect();

// Call the API endpoint
$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/api.php?action=sendNSTPReminder';

// Use cURL to call the endpoint
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Log the result
$logFile = __DIR__ . '/../logs/nstp-reminder.log';
$logDir = dirname($logFile);
if (!file_exists($logDir)) {
    @mkdir($logDir, 0755, true);
}

$timestamp = date('Y-m-d H:i:s');
$logMessage = "[{$timestamp}] HTTP {$httpCode}: {$response}\n";
file_put_contents($logFile, $logMessage, FILE_APPEND);

// If called from command line, output result
if (php_sapi_name() === 'cli') {
    echo $logMessage;
    exit($httpCode === 200 ? 0 : 1);
}

// If called from browser, show result
header('Content-Type: application/json');
echo $response;
?>

